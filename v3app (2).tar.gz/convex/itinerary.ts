import { v } from "convex/values";
import {
  mutation,
  query,
  type MutationCtx,
  type QueryCtx,
} from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { fail, requireBooking } from "./lib/access";
import {
  itineraryItemTypeValidator,
  type ItineraryItemType,
} from "./schema/itinerary";

// Bounds keep the reactive itinerary query small even for long programmes.
export const ITEM_LIMIT = 500;
const DAY_LIMIT = 400;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/;

const itemFields = {
  date: v.string(),
  type: itineraryItemTypeValidator,
  startTime: v.optional(v.string()),
  endTime: v.optional(v.string()),
  title: v.string(),
  description: v.optional(v.string()),
  location: v.optional(v.string()),
  supplierId: v.optional(v.id("suppliers")),
  internalNotes: v.optional(v.string()),
};

export type ItemFields = {
  date: string;
  type: ItineraryItemType;
  startTime?: string;
  endTime?: string;
  title: string;
  description?: string;
  location?: string;
  supplierId?: Id<"suppliers">;
  internalNotes?: string;
};

const trim = (s: string | undefined) => s?.trim() || undefined;

/** Every calendar day from start to end inclusive (YYYY-MM-DD). */
export function eachDay(start: string, end: string, max = DAY_LIMIT): string[] {
  const days: string[] = [];
  const cursor = new Date(`${start}T00:00:00Z`);
  const last = new Date(`${end}T00:00:00Z`);
  while (cursor <= last && days.length < max) {
    days.push(cursor.toISOString().slice(0, 10));
    cursor.setUTCDate(cursor.getUTCDate() + 1);
  }
  return days;
}

export function checkDate(booking: Doc<"bookings">, date: string) {
  if (!DATE_PATTERN.test(date)) fail("BAD_REQUEST", "Pick a valid day.");
  if (date < booking.startDate || date > booking.endDate) {
    fail("BAD_REQUEST", "That day is outside the booking dates.");
  }
}

export async function cleanItem(
  ctx: MutationCtx,
  fields: ItemFields,
): Promise<ItemFields> {
  const cleaned: ItemFields = {
    date: fields.date,
    type: fields.type,
    startTime: trim(fields.startTime),
    endTime: trim(fields.endTime),
    title: fields.title.trim(),
    description: trim(fields.description),
    location: trim(fields.location),
    supplierId: fields.supplierId,
    internalNotes: trim(fields.internalNotes),
  };
  if (!cleaned.title) fail("BAD_REQUEST", "Add a title.");
  if (cleaned.title.length > 200)
    fail("BAD_REQUEST", "Keep the title under 200 characters.");
  for (const time of [cleaned.startTime, cleaned.endTime]) {
    if (time && !TIME_PATTERN.test(time))
      fail("BAD_REQUEST", "Use 24-hour times like 09:30.");
  }
  if (cleaned.endTime && !cleaned.startTime) {
    fail("BAD_REQUEST", "Add a start time before the end time.");
  }
  if (
    cleaned.startTime &&
    cleaned.endTime &&
    cleaned.endTime < cleaned.startTime
  ) {
    fail("BAD_REQUEST", "The end time must be after the start time.");
  }
  if (
    cleaned.supplierId &&
    !(await ctx.db.get("suppliers", cleaned.supplierId))
  ) {
    fail("NOT_FOUND", "Supplier not found.");
  }
  return cleaned;
}

/** Loads an item and checks the caller may work on its booking. */
async function requireItem(ctx: MutationCtx, id: Id<"itineraryItems">) {
  const item = await ctx.db.get("itineraryItems", id);
  if (!item) fail("NOT_FOUND", "Itinerary item not found.");
  const { booking } = await requireBooking(ctx, item.bookingId);
  return { item, booking };
}

export function itemsOf(ctx: QueryCtx | MutationCtx, bookingId: Id<"bookings">) {
  return ctx.db
    .query("itineraryItems")
    .withIndex("by_booking_and_date", (q) => q.eq("bookingId", bookingId));
}

/** Timed items in time order, untimed ones after them in the order added. */
function compareItems(a: Doc<"itineraryItems">, b: Doc<"itineraryItems">) {
  if (a.startTime && b.startTime) {
    return (
      a.startTime.localeCompare(b.startTime) ||
      a._creationTime - b._creationTime
    );
  }
  if (a.startTime) return -1;
  if (b.startTime) return 1;
  return a._creationTime - b._creationTime;
}

export const get = query({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    return await buildItinerary(ctx, booking);
  },
});

/** Day-by-day programme with suppliers resolved. Callers check access. */
export async function buildItinerary(ctx: QueryCtx, booking: Doc<"bookings">) {
  const [dayRows, items] = await Promise.all([
    ctx.db
      .query("itineraryDays")
      .withIndex("by_booking_and_date", (q) => q.eq("bookingId", booking._id))
      .take(DAY_LIMIT),
    itemsOf(ctx, booking._id).take(ITEM_LIMIT),
  ]);

  const supplierIds = [
    ...new Set(items.flatMap((i) => (i.supplierId ? [i.supplierId] : []))),
  ];
  const suppliers = await Promise.all(
    supplierIds.map((id) => ctx.db.get("suppliers", id)),
  );
  const supplierById = new Map(
    suppliers.flatMap((s) => (s ? [[s._id, s] as const] : [])),
  );

  // Days from the booking dates, plus any day that still holds content
  // after the booking dates were changed, so nothing silently disappears.
  const dates = new Set(eachDay(booking.startDate, booking.endDate));
  for (const row of [...dayRows, ...items]) dates.add(row.date);

  const dayByDate = new Map(dayRows.map((d) => [d.date, d]));
  const days = [...dates].sort().map((date) => {
    const row = dayByDate.get(date);
    return {
      date,
      title: row?.title,
      notes: row?.notes,
      outsideDates: date < booking.startDate || date > booking.endDate,
      items: items
        .filter((i) => i.date === date)
        .sort(compareItems)
        .map((i) => {
          const supplier = i.supplierId
            ? supplierById.get(i.supplierId)
            : undefined;
          return {
            ...i,
            supplier: supplier
              ? {
                  _id: supplier._id,
                  name: supplier.name,
                  category: supplier.category,
                }
              : null,
          };
        }),
    };
  });

  return {
    days,
    itemCount: items.length,
    isFull: items.length >= ITEM_LIMIT,
  };
}

export const saveDay = mutation({
  args: {
    bookingId: v.id("bookings"),
    date: v.string(),
    title: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    const title = trim(args.title);
    const notes = trim(args.notes);
    if (title && title.length > 200)
      fail("BAD_REQUEST", "Keep the day title under 200 characters.");
    const existing = await ctx.db
      .query("itineraryDays")
      .withIndex("by_booking_and_date", (q) =>
        q.eq("bookingId", booking._id).eq("date", args.date),
      )
      .unique();
    if (existing) {
      if (!title && !notes) {
        await ctx.db.delete("itineraryDays", existing._id);
      } else {
        await ctx.db.replace("itineraryDays", existing._id, {
          bookingId: booking._id,
          date: args.date,
          title,
          notes,
        });
      }
      return null;
    }
    checkDate(booking, args.date);
    if (title || notes) {
      await ctx.db.insert("itineraryDays", {
        bookingId: booking._id,
        date: args.date,
        title,
        notes,
      });
    }
    return null;
  },
});

export const addItem = mutation({
  args: { bookingId: v.id("bookings"), ...itemFields },
  handler: async (ctx, args): Promise<Id<"itineraryItems">> => {
    const { bookingId, ...rest } = args;
    const { booking } = await requireBooking(ctx, bookingId);
    checkDate(booking, rest.date);
    const existing = await itemsOf(ctx, booking._id).take(ITEM_LIMIT);
    if (existing.length >= ITEM_LIMIT) {
      fail("BAD_REQUEST", `An itinerary can hold up to ${ITEM_LIMIT} items.`);
    }
    const fields = await cleanItem(ctx, rest);
    return await ctx.db.insert("itineraryItems", {
      bookingId: booking._id,
      ...fields,
      updatedAt: new Date().toISOString(),
    });
  },
});

export const updateItem = mutation({
  args: { id: v.id("itineraryItems"), ...itemFields },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    const { item, booking } = await requireItem(ctx, id);
    // Items left outside changed booking dates can stay put, but moves must land inside.
    if (rest.date !== item.date) checkDate(booking, rest.date);
    const fields = await cleanItem(ctx, rest);
    await ctx.db.replace("itineraryItems", id, {
      bookingId: item.bookingId,
      ...fields,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const removeItem = mutation({
  args: { id: v.id("itineraryItems") },
  handler: async (ctx, args) => {
    await requireItem(ctx, args.id);
    await ctx.db.delete("itineraryItems", args.id);
    return null;
  },
});
