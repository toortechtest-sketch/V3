import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string, email: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub, email });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner", "owner@toor.tech");
  const manager = as(t, "mgr", "mgr@toor.tech");
  const newbie = as(t, "new", "new@toor.tech");
  const ownerId = await owner.mutation(api.users.updateCurrentUser, {});
  const managerId = await manager.mutation(api.users.updateCurrentUser, {});
  const newbieId = await newbie.mutation(api.users.updateCurrentUser, {});
  return { t, owner, manager, newbie, ownerId, managerId, newbieId };
}

describe("staff access", () => {
  it("makes only the first signed-in person the owner; others wait", async () => {
    const { owner, manager } = await setup();
    expect(await owner.query(api.staff.me, {})).toMatchObject({
      status: "active",
      role: "owner",
    });
    expect(await manager.query(api.staff.me, {})).toMatchObject({
      status: "pending",
      role: null,
    });
  });

  it("denies pending users and signed-out callers", async () => {
    const { t, newbie } = await setup();
    await expect(newbie.query(api.staff.listTeam, {})).rejects.toThrow(
      /not been approved/,
    );
    await expect(t.query(api.staff.listTeam, {})).rejects.toThrow(
      /signed in/,
    );
    expect(await t.query(api.staff.me, {})).toEqual({ status: "unsynced" });
  });

  it("lets owners approve staff and revoke access", async () => {
    const { owner, newbie, newbieId } = await setup();
    await owner.mutation(api.staff.setRole, { userId: newbieId, role: "agent" });
    expect(await newbie.query(api.staff.me, {})).toMatchObject({
      status: "active",
      role: "agent",
    });
    await owner.mutation(api.staff.revokeAccess, { userId: newbieId });
    expect(await newbie.query(api.staff.me, {})).toMatchObject({
      status: "pending",
    });
  });

  it("stops agents from managing the team", async () => {
    const { owner, newbie, newbieId, managerId } = await setup();
    await owner.mutation(api.staff.setRole, { userId: newbieId, role: "agent" });
    await expect(
      newbie.mutation(api.staff.setRole, { userId: managerId, role: "agent" }),
    ).rejects.toThrow(/permission required/);
  });

  it("only owners can grant or change owner access", async () => {
    const { owner, manager, managerId, newbieId, ownerId } = await setup();
    await owner.mutation(api.staff.setRole, {
      userId: managerId,
      role: "global_manager",
    });
    await expect(
      manager.mutation(api.staff.setRole, { userId: newbieId, role: "owner" }),
    ).rejects.toThrow(/Only an owner/);
    await expect(
      manager.mutation(api.staff.revokeAccess, { userId: ownerId }),
    ).rejects.toThrow(/Only an owner/);
    // Managers can still approve regular staff.
    await manager.mutation(api.staff.setRole, {
      userId: newbieId,
      role: "agency_manager",
    });
  });

  it("prevents changing your own access", async () => {
    const { owner, ownerId } = await setup();
    await expect(
      owner.mutation(api.staff.revokeAccess, { userId: ownerId }),
    ).rejects.toThrow(/your own access/);
  });

  it("does not re-promote anyone once an owner exists", async () => {
    const { manager, newbie } = await setup();
    await manager.mutation(api.users.updateCurrentUser, {});
    await newbie.mutation(api.users.updateCurrentUser, {});
    expect(await manager.query(api.staff.me, {})).toMatchObject({
      status: "pending",
    });
  });
});
