import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const DRAFT = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-12-02",
  endDate: "2026-12-07",
  pax: 12,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  const pending = as(t, "p");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  await pending.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  return { owner, agentA, agentB, pending, aId, bId };
}

describe("bookings", () => {
  it("numbers references per start year", async () => {
    const { owner } = await setup();
    const first = await owner.mutation(api.bookings.create, DRAFT);
    const second = await owner.mutation(api.bookings.create, DRAFT);
    const other = await owner.mutation(api.bookings.create, {
      ...DRAFT,
      startDate: "2027-01-02",
      endDate: "2027-01-03",
    });
    const refs = await Promise.all(
      [first, second, other].map(async (id) => {
        const b = await owner.query(api.bookings.get, { id });
        return [b?.reference, b?.stage];
      }),
    );
    expect(refs).toEqual([
      ["GM-2026-0001", "enquiry"],
      ["GM-2026-0002", "enquiry"],
      ["GM-2027-0001", "enquiry"],
    ]);
  });

  it("keeps agents to their own bookings", async () => {
    const { owner, agentA, agentB } = await setup();
    const id = await agentA.mutation(api.bookings.create, DRAFT);
    expect(await agentB.query(api.bookings.get, { id })).toBeNull();
    expect(await agentA.query(api.bookings.get, { id: "bogus" })).toBeNull();
    await expect(
      agentB.mutation(api.bookings.setStage, { id, stage: "quoted" }),
    ).rejects.toThrow(/not found/);
    const opts = { paginationOpts: { numItems: 10, cursor: null } };
    expect((await agentB.query(api.bookings.list, opts)).page).toHaveLength(0);
    expect((await owner.query(api.bookings.list, opts)).page).toHaveLength(1);
    const mine = { ...opts, mineOnly: true };
    expect((await owner.query(api.bookings.list, mine)).page).toHaveLength(0);
  });

  it("blocks pending staff entirely", async () => {
    const { pending } = await setup();
    await expect(pending.mutation(api.bookings.create, DRAFT)).rejects.toThrow(
      /not been approved/,
    );
  });

  it("only lets managers reassign bookings", async () => {
    const { owner, agentA, agentB, bId } = await setup();
    const id = await agentA.mutation(api.bookings.create, DRAFT);
    await expect(
      agentA.mutation(api.bookings.update, { id, ...DRAFT, ownerId: bId }),
    ).rejects.toThrow(/Only managers/);
    await owner.mutation(api.bookings.update, { id, ...DRAFT, ownerId: bId });
    expect((await agentB.query(api.bookings.get, { id }))?.ownerId).toBe(bId);
  });

  it("rejects end dates before start dates", async () => {
    const { owner } = await setup();
    await expect(
      owner.mutation(api.bookings.create, { ...DRAFT, endDate: "2026-11-01" }),
    ).rejects.toThrow(/before the start/);
  });

  it("groups bookings by stage on the board", async () => {
    const { owner } = await setup();
    const id = await owner.mutation(api.bookings.create, DRAFT);
    await owner.mutation(api.bookings.setStage, { id, stage: "confirmed" });
    const board = await owner.query(api.bookings.board, {});
    const confirmed = board.find((c) => c.stage === "confirmed");
    expect(confirmed?.bookings.map((b) => b._id)).toEqual([id]);
  });
});
