import { v } from "convex/values";
import { mutation, query, type MutationCtx, type QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { fail, isManagerRole, requireBooking } from "./lib/access";
import {
  INSTALLMENT_LIMIT,
  INVOICE_LIMIT,
  PAYMENT_LIMIT,
  installmentsOf,
  invoicesOf,
  paymentsOf,
  quoteSell,
} from "./lib/financeData";
import { financeOf, requireFinanceUnlocked } from "./lib/financeLock";
import { financeSummary, installmentAmount, invoiceBalances } from "./lib/financeMath";
import { money } from "./lib/quoteMath";
import { invoiceKindValidator, paymentMethodValidator, type InvoiceKind } from "./schema/finance";

const MAX_AMOUNT = 1e9;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

const NUMBER_PREFIX: Record<InvoiceKind, string> = { invoice: "INV", credit_note: "CN" };

const trim = (s: string | undefined) => s?.trim() || undefined;

function checkAmount(n: number, label: string) {
  if (!Number.isFinite(n) || n <= 0 || n > MAX_AMOUNT) {
    fail("BAD_REQUEST", `${label} must be more than 0.`);
  }
}

function checkDate(d: string | undefined, label: string) {
  if (d !== undefined && !DATE_PATTERN.test(d)) fail("BAD_REQUEST", `Pick a valid ${label}.`);
}

function checkText(s: string, label: string, max = 200) {
  if (!s) fail("BAD_REQUEST", `Add a ${label}.`);
  if (s.length > max) fail("BAD_REQUEST", `Keep the ${label} under ${max} characters.`);
}

async function contractValueOf(ctx: QueryCtx | MutationCtx, booking: Doc<"bookings">) {
  const finance = await financeOf(ctx, booking._id);
  return finance?.contractValue ?? (await quoteSell(ctx, booking));
}

/** Next "INV-YYYY-NNNN" / "CN-YYYY-NNNN" for the issue year, shared across bookings. */
async function nextNumber(ctx: MutationCtx, kind: InvoiceKind, issueDate: string) {
  const prefix = `${NUMBER_PREFIX[kind]}-${issueDate.slice(0, 4)}-`;
  const latest = await ctx.db
    .query("invoices")
    .withIndex("by_number", (q) => q.gte("number", prefix).lt("number", `${prefix}\uffff`))
    .order("desc")
    .first();
  const next = latest ? Number.parseInt(latest.number.slice(prefix.length), 10) + 1 : 1;
  return `${prefix}${String(next).padStart(4, "0")}`;
}

async function touch(ctx: MutationCtx, bookingId: Id<"bookings">) {
  await ctx.db.patch("bookings", bookingId, { updatedAt: new Date().toISOString() });
}

async function insertInvoice(
  ctx: MutationCtx,
  booking: Doc<"bookings">,
  userId: Id<"users">,
  fields: {
    kind: InvoiceKind;
    label: string;
    amount: number;
    issueDate: string;
    dueDate?: string;
    notes?: string;
  },
) {
  const existing = await invoicesOf(ctx, booking._id);
  if (existing.length >= INVOICE_LIMIT) {
    fail("BAD_REQUEST", `A booking can hold up to ${INVOICE_LIMIT} invoices.`);
  }
  const label = fields.label.trim();
  checkText(label, "description");
  checkAmount(fields.amount, "Amount");
  checkDate(fields.issueDate, "issue date");
  checkDate(fields.dueDate, "due date");
  if (fields.dueDate && fields.dueDate < fields.issueDate) {
    fail("BAD_REQUEST", "The due date can't be before the issue date.");
  }
  const id = await ctx.db.insert("invoices", {
    bookingId: booking._id,
    kind: fields.kind,
    number: await nextNumber(ctx, fields.kind, fields.issueDate),
    label,
    amount: money(fields.amount),
    issueDate: fields.issueDate,
    dueDate: fields.kind === "invoice" ? fields.dueDate : undefined,
    status: "issued",
    notes: trim(fields.notes),
    createdById: userId,
    updatedAt: new Date().toISOString(),
  });
  await touch(ctx, booking._id);
  return id;
}

async function requireInvoice(ctx: MutationCtx, id: Id<"invoices">) {
  const invoice = await ctx.db.get("invoices", id);
  if (!invoice) fail("NOT_FOUND", "Invoice not found.");
  const access = await requireBooking(ctx, invoice.bookingId);
  return { invoice, ...access };
}

async function requireInstallment(ctx: MutationCtx, id: Id<"paymentInstallments">) {
  const installment = await ctx.db.get("paymentInstallments", id);
  if (!installment) fail("NOT_FOUND", "Instalment not found.");
  const access = await requireBooking(ctx, installment.bookingId);
  return { installment, ...access };
}

/** Allocated invoice must be an issued invoice on the same booking. */
async function checkAllocation(
  ctx: MutationCtx,
  bookingId: Id<"bookings">,
  invoiceId: Id<"invoices"> | undefined,
) {
  if (!invoiceId) return;
  const invoice = await ctx.db.get("invoices", invoiceId);
  if (!invoice || invoice.bookingId !== bookingId) fail("NOT_FOUND", "Invoice not found.");
  if (invoice.kind !== "invoice" || invoice.status !== "issued") {
    fail("BAD_REQUEST", "Payments can only be matched to an issued invoice.");
  }
}

export const get = query({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking, staff } = await requireBooking(ctx, args.bookingId);
    const [finance, invoices, payments, installments, sell] = await Promise.all([
      financeOf(ctx, booking._id),
      invoicesOf(ctx, booking._id),
      paymentsOf(ctx, booking._id),
      installmentsOf(ctx, booking._id),
      quoteSell(ctx, booking),
    ]);
    const contractValue = finance?.contractValue ?? sell;
    const balances = invoiceBalances(invoices, payments);
    const numberById = new Map(invoices.map((i) => [i._id, i.number] as const));
    const lockedBy = finance?.lockedById ? await ctx.db.get("users", finance.lockedById) : null;

    return {
      currency: booking.currency,
      rateToBase: booking.exchangeRateToBase,
      startDate: booking.startDate,
      quoteSell: sell,
      contractValue,
      contractValueIsCustom: finance?.contractValue !== undefined,
      lock: finance?.lockedAt
        ? { lockedAt: finance.lockedAt, lockedByName: lockedBy?.name ?? "Someone" }
        : null,
      canUnlock: isManagerRole(staff.role),
      summary: financeSummary(contractValue, invoices, payments),
      installments: installments.map((i) => ({
        ...i,
        amount: installmentAmount(i.percent, contractValue),
        invoiceNumber: i.invoiceId ? (numberById.get(i.invoiceId) ?? null) : null,
      })),
      invoices: [...invoices]
        .sort((a, b) => b.issueDate.localeCompare(a.issueDate) || b._creationTime - a._creationTime)
        .map((i) => ({ ...i, balance: balances.get(i._id) ?? { paid: 0, open: 0, isPaid: false } })),
      payments: [...payments]
        .sort((a, b) => b.receivedDate.localeCompare(a.receivedDate))
        .map((p) => ({ ...p, invoiceNumber: p.invoiceId ? (numberById.get(p.invoiceId) ?? null) : null })),
      limits: {
        invoicesFull: invoices.length >= INVOICE_LIMIT,
        paymentsFull: payments.length >= PAYMENT_LIMIT,
        installmentsFull: installments.length >= INSTALLMENT_LIMIT,
      },
    };
  },
});

export const setContractValue = mutation({
  args: { bookingId: v.id("bookings"), contractValue: v.optional(v.number()) },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    await requireFinanceUnlocked(ctx, booking._id);
    if (args.contractValue !== undefined) checkAmount(args.contractValue, "Package value");
    const contractValue = args.contractValue === undefined ? undefined : money(args.contractValue);
    const existing = await financeOf(ctx, booking._id);
    const updatedAt = new Date().toISOString();
    if (existing) await ctx.db.patch("bookingFinance", existing._id, { contractValue, updatedAt });
    else await ctx.db.insert("bookingFinance", { bookingId: booking._id, contractValue, updatedAt });
    await touch(ctx, booking._id);
    return null;
  },
});

export const setLocked = mutation({
  args: { bookingId: v.id("bookings"), locked: v.boolean() },
  handler: async (ctx, args) => {
    const { booking, staff } = await requireBooking(ctx, args.bookingId);
    // Anyone on the booking can close it; only managers can reopen it.
    if (!args.locked && !isManagerRole(staff.role)) {
      fail("FORBIDDEN", "Only an owner or global manager can reopen a locked booking.");
    }
    const existing = await financeOf(ctx, booking._id);
    if ((existing?.lockedAt !== undefined) === args.locked) return null;
    const fields = {
      lockedAt: args.locked ? new Date().toISOString() : undefined,
      lockedById: args.locked ? staff.user._id : undefined,
      updatedAt: new Date().toISOString(),
    };
    if (existing) await ctx.db.patch("bookingFinance", existing._id, fields);
    else await ctx.db.insert("bookingFinance", { bookingId: booking._id, ...fields });
    await touch(ctx, booking._id);
    return null;
  },
});

const installmentFields = { label: v.string(), percent: v.number(), dueDate: v.string() };

function cleanInstallment(fields: { label: string; percent: number; dueDate: string }) {
  const label = fields.label.trim();
  checkText(label, "label", 100);
  if (!Number.isFinite(fields.percent) || fields.percent <= 0 || fields.percent > 100) {
    fail("BAD_REQUEST", "Share must be between 0 and 100%.");
  }
  checkDate(fields.dueDate, "due date");
  return { label, percent: fields.percent, dueDate: fields.dueDate };
}

export const addInstallment = mutation({
  args: { bookingId: v.id("bookings"), ...installmentFields },
  handler: async (ctx, args): Promise<Id<"paymentInstallments">> => {
    const { bookingId, ...rest } = args;
    const { booking } = await requireBooking(ctx, bookingId);
    await requireFinanceUnlocked(ctx, booking._id);
    if ((await installmentsOf(ctx, booking._id)).length >= INSTALLMENT_LIMIT) {
      fail("BAD_REQUEST", `A schedule can hold up to ${INSTALLMENT_LIMIT} instalments.`);
    }
    const id = await ctx.db.insert("paymentInstallments", {
      bookingId: booking._id,
      ...cleanInstallment(rest),
      updatedAt: new Date().toISOString(),
    });
    await touch(ctx, booking._id);
    return id;
  },
});

/** Standard schedule: 30% deposit now, 70% balance 30 days before departure. */
export const applyStandardSchedule = mutation({
  args: { bookingId: v.id("bookings"), today: v.string() },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    await requireFinanceUnlocked(ctx, booking._id);
    checkDate(args.today, "date");
    if ((await installmentsOf(ctx, booking._id)).length > 0) {
      fail("CONFLICT", "This booking already has a payment schedule.");
    }
    const balanceDue = new Date(`${booking.startDate}T00:00:00Z`);
    balanceDue.setUTCDate(balanceDue.getUTCDate() - 30);
    const balanceDay = balanceDue.toISOString().slice(0, 10);
    const updatedAt = new Date().toISOString();
    const items = [
      { label: "Deposit", percent: 30, dueDate: args.today },
      { label: "Balance", percent: 70, dueDate: balanceDay < args.today ? args.today : balanceDay },
    ];
    for (const item of items) {
      await ctx.db.insert("paymentInstallments", { bookingId: booking._id, ...item, updatedAt });
    }
    await touch(ctx, booking._id);
    return null;
  },
});

export const updateInstallment = mutation({
  args: { id: v.id("paymentInstallments"), ...installmentFields },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    const { installment } = await requireInstallment(ctx, id);
    await requireFinanceUnlocked(ctx, installment.bookingId);
    if (installment.invoiceId) fail("BAD_REQUEST", "This instalment is already invoiced.");
    await ctx.db.patch("paymentInstallments", id, {
      ...cleanInstallment(rest),
      updatedAt: new Date().toISOString(),
    });
    await touch(ctx, installment.bookingId);
    return null;
  },
});

export const removeInstallment = mutation({
  args: { id: v.id("paymentInstallments") },
  handler: async (ctx, args) => {
    const { installment } = await requireInstallment(ctx, args.id);
    await requireFinanceUnlocked(ctx, installment.bookingId);
    if (installment.invoiceId) {
      fail("BAD_REQUEST", "This instalment is already invoiced. Void the invoice first.");
    }
    await ctx.db.delete("paymentInstallments", args.id);
    await touch(ctx, installment.bookingId);
    return null;
  },
});

export const invoiceInstallment = mutation({
  args: { id: v.id("paymentInstallments"), issueDate: v.string() },
  handler: async (ctx, args): Promise<Id<"invoices">> => {
    const { installment, booking, staff } = await requireInstallment(ctx, args.id);
    await requireFinanceUnlocked(ctx, booking._id);
    if (installment.invoiceId) fail("CONFLICT", "This instalment is already invoiced.");
    const amount = installmentAmount(installment.percent, await contractValueOf(ctx, booking));
    if (amount <= 0) fail("BAD_REQUEST", "Set a package value or add quote lines first.");
    const invoiceId = await insertInvoice(ctx, booking, staff.user._id, {
      kind: "invoice",
      label: `${installment.label} (${installment.percent}%)`,
      amount,
      issueDate: args.issueDate,
      dueDate: installment.dueDate < args.issueDate ? args.issueDate : installment.dueDate,
    });
    await ctx.db.patch("paymentInstallments", installment._id, {
      invoiceId,
      updatedAt: new Date().toISOString(),
    });
    return invoiceId;
  },
});

export const createInvoice = mutation({
  args: {
    bookingId: v.id("bookings"),
    kind: invoiceKindValidator,
    label: v.string(),
    amount: v.number(),
    issueDate: v.string(),
    dueDate: v.optional(v.string()),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"invoices">> => {
    const { bookingId, ...fields } = args;
    const { booking, staff } = await requireBooking(ctx, bookingId);
    // Credit notes are the one correction still allowed on a locked booking.
    if (fields.kind === "invoice") await requireFinanceUnlocked(ctx, booking._id);
    return await insertInvoice(ctx, booking, staff.user._id, fields);
  },
});

export const voidInvoice = mutation({
  args: { id: v.id("invoices") },
  handler: async (ctx, args) => {
    const { invoice } = await requireInvoice(ctx, args.id);
    await requireFinanceUnlocked(ctx, invoice.bookingId);
    if (invoice.status === "void") return null;
    const allocated = (await paymentsOf(ctx, invoice.bookingId)).some(
      (p) => p.invoiceId === invoice._id,
    );
    if (allocated) {
      fail("BAD_REQUEST", "Payments are matched to this invoice. Remove or re-match them first.");
    }
    await ctx.db.patch("invoices", invoice._id, {
      status: "void",
      updatedAt: new Date().toISOString(),
    });
    // Free the instalment so it can be invoiced again.
    const installments = await installmentsOf(ctx, invoice.bookingId);
    for (const i of installments.filter((i) => i.invoiceId === invoice._id)) {
      await ctx.db.patch("paymentInstallments", i._id, {
        invoiceId: undefined,
        updatedAt: new Date().toISOString(),
      });
    }
    await touch(ctx, invoice.bookingId);
    return null;
  },
});

export const recordPayment = mutation({
  args: {
    bookingId: v.id("bookings"),
    amount: v.number(),
    receivedDate: v.string(),
    method: paymentMethodValidator,
    reference: v.optional(v.string()),
    invoiceId: v.optional(v.id("invoices")),
    notes: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"payments">> => {
    const { bookingId, ...fields } = args;
    const { booking, staff } = await requireBooking(ctx, bookingId);
    await requireFinanceUnlocked(ctx, booking._id);
    if ((await paymentsOf(ctx, booking._id)).length >= PAYMENT_LIMIT) {
      fail("BAD_REQUEST", `A booking can hold up to ${PAYMENT_LIMIT} payments.`);
    }
    checkAmount(fields.amount, "Amount");
    checkDate(fields.receivedDate, "date");
    await checkAllocation(ctx, booking._id, fields.invoiceId);
    const reference = trim(fields.reference);
    if (reference && reference.length > 100) fail("BAD_REQUEST", "Keep the reference short.");
    const id = await ctx.db.insert("payments", {
      bookingId: booking._id,
      ...fields,
      amount: money(fields.amount),
      reference,
      notes: trim(fields.notes),
      createdById: staff.user._id,
      updatedAt: new Date().toISOString(),
    });
    await touch(ctx, booking._id);
    return id;
  },
});

export const removePayment = mutation({
  args: { id: v.id("payments") },
  handler: async (ctx, args) => {
    const payment = await ctx.db.get("payments", args.id);
    if (!payment) fail("NOT_FOUND", "Payment not found.");
    await requireBooking(ctx, payment.bookingId);
    await requireFinanceUnlocked(ctx, payment.bookingId);
    await ctx.db.delete("payments", args.id);
    await touch(ctx, payment.bookingId);
    return null;
  },
});
