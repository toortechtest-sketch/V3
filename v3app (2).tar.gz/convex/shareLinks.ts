import { v } from "convex/values";
import {
  action,
  internalMutation,
  mutation,
  query,
  type MutationCtx,
  type QueryCtx,
} from "./_generated/server";
import { internal } from "./_generated/api";
import type { Doc, Id } from "./_generated/dataModel";
import { fail, requireBooking } from "./lib/access";
import { shareLinkKindValidator, type ShareLinkKind } from "./schema/shareLinks";

// Bounds keep the reactive list small; old links can be revoked to make room.
const LINK_LIMIT = 50;
const REQUEST_LIMIT = 20;
const MAX_DAYS = 180;
const DAY_MS = 24 * 60 * 60 * 1000;

/** 24 random bytes as hex. Needs Web Crypto, so only call from an action. */
function randomToken() {
  const bytes = crypto.getRandomValues(new Uint8Array(24));
  return Array.from(bytes, (b) => b.toString(16).padStart(2, "0")).join("");
}

export type LinkState = "active" | "expired" | "revoked";

export function linkState(link: Doc<"shareLinks">, now: number): LinkState {
  if (link.revokedAt) return "revoked";
  if (Date.parse(link.expiresAt) <= now) return "expired";
  return "active";
}

async function requireLink(ctx: MutationCtx, id: Id<"shareLinks">) {
  const link = await ctx.db.get("shareLinks", id);
  if (!link) fail("NOT_FOUND", "Link not found.");
  await requireBooking(ctx, link.bookingId);
  return link;
}

/** Extra staff-facing detail per link kind. */
async function linkDetail(ctx: QueryCtx, link: Doc<"shareLinks">) {
  if (link.kind === "confirmation") {
    const requests = await ctx.db
      .query("clientChangeRequests")
      .withIndex("by_link", (q) => q.eq("linkId", link._id))
      .order("desc")
      .take(REQUEST_LIMIT);
    return { clientRequests: requests, change: null };
  }
  if (link.kind === "hotel_response" && link.changeId) {
    const change = await ctx.db.get("reservationChanges", link.changeId);
    const reservation = change ? await ctx.db.get("reservations", change.reservationId) : null;
    return {
      clientRequests: [],
      change:
        change && reservation
          ? {
              status: change.status,
              supplierName: reservation.supplierName,
              description: reservation.description,
              responseNote: change.responseNote ?? null,
            }
          : null,
    };
  }
  return { clientRequests: [], change: null };
}

export const list = query({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    const links = await ctx.db
      .query("shareLinks")
      .withIndex("by_booking", (q) => q.eq("bookingId", booking._id))
      .order("desc")
      .take(LINK_LIMIT);
    const now = Date.now();
    return await Promise.all(
      links.map(async (link) => ({
        ...link,
        state: linkState(link, now),
        ...(await linkDetail(ctx, link)),
      })),
    );
  },
});

/**
 * Creates a link with a cryptographically random token. Runs as an action
 * because mutations only get a seeded (predictable) random source.
 * Hotel response links reuse an active link for the same change.
 */
export const create = action({
  args: {
    bookingId: v.id("bookings"),
    kind: shareLinkKindValidator,
    days: v.number(),
    changeId: v.optional(v.id("reservationChanges")),
  },
  handler: async (ctx, args): Promise<{ token: string }> => {
    const token: string = await ctx.runMutation(internal.shareLinks.insert, {
      ...args,
      token: randomToken(),
    });
    return { token };
  },
});

async function checkHotelChange(
  ctx: MutationCtx,
  bookingId: Id<"bookings">,
  changeId: Id<"reservationChanges"> | undefined,
) {
  if (!changeId) fail("BAD_REQUEST", "Pick the change request the hotel should answer.");
  const change = await ctx.db.get("reservationChanges", changeId);
  if (!change || change.bookingId !== bookingId) fail("NOT_FOUND", "Change request not found.");
  if (change.status !== "pending") fail("CONFLICT", "This change has already been answered.");
  return change;
}

export const insert = internalMutation({
  args: {
    bookingId: v.id("bookings"),
    kind: shareLinkKindValidator,
    days: v.number(),
    token: v.string(),
    changeId: v.optional(v.id("reservationChanges")),
  },
  handler: async (ctx, args): Promise<string> => {
    // Auth carries over from the calling action, so access is checked here.
    const { staff, booking } = await requireBooking(ctx, args.bookingId);
    if (!Number.isInteger(args.days) || args.days < 1 || args.days > MAX_DAYS) {
      fail("BAD_REQUEST", `Links can last between 1 and ${MAX_DAYS} days.`);
    }
    const existing = await ctx.db
      .query("shareLinks")
      .withIndex("by_booking", (q) => q.eq("bookingId", booking._id))
      .take(LINK_LIMIT);

    let changeId: Id<"reservationChanges"> | undefined;
    if (args.kind === "hotel_response") {
      const change = await checkHotelChange(ctx, booking._id, args.changeId);
      changeId = change._id;
      const now = Date.now();
      const reusable = existing.find(
        (l) => l.changeId === change._id && linkState(l, now) === "active",
      );
      if (reusable) return reusable.token;
    } else if (args.changeId) {
      fail("BAD_REQUEST", "Only hotel response links answer a change request.");
    }

    if (existing.length >= LINK_LIMIT) {
      fail("BAD_REQUEST", `A booking can have up to ${LINK_LIMIT} links. Turn off old ones first.`);
    }
    await ctx.db.insert("shareLinks", {
      bookingId: booking._id,
      kind: args.kind satisfies ShareLinkKind,
      token: args.token,
      expiresAt: new Date(Date.now() + args.days * DAY_MS).toISOString(),
      createdById: staff.user._id,
      viewCount: 0,
      changeId,
    });
    return args.token;
  },
});

export const revoke = mutation({
  args: { id: v.id("shareLinks") },
  handler: async (ctx, args) => {
    const link = await requireLink(ctx, args.id);
    if (!link.revokedAt) {
      await ctx.db.patch("shareLinks", link._id, { revokedAt: new Date().toISOString() });
    }
    return null;
  },
});

/** Staff mark a client's change request as dealt with (or reopen it). */
export const setRequestHandled = mutation({
  args: { id: v.id("clientChangeRequests"), handled: v.boolean() },
  handler: async (ctx, args) => {
    const request = await ctx.db.get("clientChangeRequests", args.id);
    if (!request) fail("NOT_FOUND", "Request not found.");
    const { staff } = await requireBooking(ctx, request.bookingId);
    await ctx.db.patch(
      "clientChangeRequests",
      request._id,
      args.handled
        ? { handledAt: new Date().toISOString(), handledById: staff.user._id }
        : { handledAt: undefined, handledById: undefined },
    );
    return null;
  },
});
