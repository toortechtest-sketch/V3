import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "agent");
  const pending = as(t, "pending");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await pending.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  return { owner, agent, pending };
}

const page = { paginationOpts: { numItems: 20, cursor: null } };

describe("clients", () => {
  it("shares one alphabetical list across staff", async () => {
    const { owner, agent } = await setup();
    await agent.mutation(api.clients.create, { kind: "company", name: "zeta" });
    await owner.mutation(api.clients.create, { kind: "company", name: "Acme" });
    const names = (await agent.query(api.clients.list, page)).page.map(
      (c) => c.name,
    );
    expect(names).toEqual(["Acme", "zeta"]);
  });

  it("blocks staff awaiting approval", async () => {
    const { pending } = await setup();
    await expect(pending.query(api.clients.list, page)).rejects.toThrow(
      /not been approved/,
    );
  });

  it("links people to companies and blocks deleting a company with people", async () => {
    const { owner, agent } = await setup();
    const company = await agent.mutation(api.clients.create, {
      kind: "company",
      name: "Acme",
    });
    const person = await agent.mutation(api.clients.create, {
      kind: "individual",
      name: "Jane Doe",
      parentClientId: company,
    });
    const detail = await agent.query(api.clients.get, { id: company });
    expect(detail.members.map((m) => m._id)).toEqual([person]);

    await expect(
      agent.mutation(api.clients.remove, { id: person }),
    ).rejects.toThrow(/permission required/);
    await expect(
      owner.mutation(api.clients.remove, { id: company }),
    ).rejects.toThrow(/People are linked/);
    await owner.mutation(api.clients.remove, { id: person });
    await owner.mutation(api.clients.remove, { id: company });
  });

  it("only lets people belong to a company", async () => {
    const { agent } = await setup();
    const person = await agent.mutation(api.clients.create, {
      kind: "individual",
      name: "Jane",
    });
    await expect(
      agent.mutation(api.clients.create, {
        kind: "individual",
        name: "Bob",
        parentClientId: person,
      }),
    ).rejects.toThrow(/existing company/);
  });

  it("clears emptied fields on edit", async () => {
    const { agent } = await setup();
    const id = await agent.mutation(api.clients.create, {
      kind: "company",
      name: "Acme",
      phone: "+34 600",
    });
    await agent.mutation(api.clients.update, {
      id,
      kind: "company",
      name: "Acme",
      phone: "  ",
    });
    expect((await agent.query(api.clients.get, { id })).phone).toBeUndefined();
  });
});
