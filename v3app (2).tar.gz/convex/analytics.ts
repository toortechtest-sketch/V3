import { v } from "convex/values";
import { query, type QueryCtx } from "./_generated/server";
import type { Doc } from "./_generated/dataModel";
import { requireManager } from "./lib/access";
import { invoicesOf, paymentsOf, quoteSell } from "./lib/financeData";
import { financeOf } from "./lib/financeLock";
import { financeSummary } from "./lib/financeMath";
import { money } from "./lib/quoteMath";
import { BOOKING_STAGES, type BookingStage } from "./schema/bookings";

/**
 * Each booking sampled here costs several indexed reads (finance, invoices,
 * payments, reservations), so every stage sample is capped the same way the
 * booking finance overview caps its own per-stage reads.
 */
const PER_STAGE_LIMIT = 30;
const RESERVATION_LIMIT = 30;
const TOP_N = 5;
const MONTHS_BACK = 6;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

const WON_STAGES: readonly BookingStage[] = ["confirmed", "operating", "closed"];
const DECIDED_STAGES: readonly BookingStage[] = [...WON_STAGES, "cancelled"];

async function bookingsInStage(ctx: QueryCtx, stage: BookingStage) {
  const rows = await ctx.db
    .query("bookings")
    .withIndex("by_stage_and_start_date", (q) => q.eq("stage", stage))
    .order("desc")
    .take(PER_STAGE_LIMIT + 1);
  return { rows: rows.slice(0, PER_STAGE_LIMIT), truncated: rows.length > PER_STAGE_LIMIT };
}

async function contractValueOf(ctx: QueryCtx, booking: Doc<"bookings">) {
  const finance = await financeOf(ctx, booking._id);
  return finance?.contractValue ?? (await quoteSell(ctx, booking));
}

function reservationsOf(ctx: QueryCtx, bookingId: Doc<"bookings">["_id"]) {
  return ctx.db
    .query("reservations")
    .withIndex("by_booking_and_start_date", (q) => q.eq("bookingId", bookingId))
    .take(RESERVATION_LIMIT);
}

/** Last `n` "YYYY-MM" month keys ending with the month of `today`. */
function lastMonths(n: number, today: string): string[] {
  const [y, m] = today.slice(0, 7).split("-").map(Number);
  const keys: string[] = [];
  for (let i = n - 1; i >= 0; i--) {
    const d = new Date(Date.UTC(y, m - 1 - i, 1));
    keys.push(`${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`);
  }
  return keys;
}

function addTop(map: Map<string, { value: number; count: number }>, key: string, value: number) {
  const existing = map.get(key) ?? { value: 0, count: 0 };
  map.set(key, { value: money(existing.value + value), count: existing.count + 1 });
}

function topN(map: Map<string, { value: number; count: number }>, n: number) {
  return [...map.entries()]
    .map(([name, v]) => ({ name, value: v.value, count: v.count }))
    .sort((a, b) => b.value - a.value)
    .slice(0, n);
}

/** Business performance across the most recent bookings in every stage. */
export const overview = query({
  args: { today: v.string() },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    if (!DATE_PATTERN.test(args.today)) throw new Error("Pick a valid date.");

    const months = lastMonths(MONTHS_BACK, args.today);
    const monthlyReceived = new Map<string, number>(months.map((m) => [m, 0]));
    const monthlyInvoiced = new Map<string, number>(months.map((m) => [m, 0]));
    const clients = new Map<string, { value: number; count: number }>();
    const suppliers = new Map<string, { value: number; count: number }>();

    let truncated = false;
    const pipeline: { stage: BookingStage; count: number; value: number }[] = [];

    for (const stage of BOOKING_STAGES) {
      const { rows, truncated: stageTruncated } = await bookingsInStage(ctx, stage);
      if (stageTruncated) truncated = true;

      let stageValue = 0;
      const nonCancelled = stage !== "cancelled";

      for (const booking of rows) {
        const contractValue = await contractValueOf(ctx, booking);
        const valueInBase = money(contractValue * booking.exchangeRateToBase);
        stageValue += valueInBase;

        if (!nonCancelled) continue;

        const [invoices, payments, reservations] = await Promise.all([
          invoicesOf(ctx, booking._id),
          paymentsOf(ctx, booking._id),
          reservationsOf(ctx, booking._id),
        ]);
        const summary = financeSummary(contractValue, invoices, payments);
        addTop(clients, booking.clientName, money(summary.received * booking.exchangeRateToBase));

        for (const payment of payments) {
          const key = payment.receivedDate.slice(0, 7);
          if (monthlyReceived.has(key)) {
            monthlyReceived.set(
              key,
              money(monthlyReceived.get(key)! + payment.amount * booking.exchangeRateToBase),
            );
          }
        }
        for (const invoice of invoices) {
          if (invoice.kind !== "invoice" || invoice.status !== "issued") continue;
          const key = invoice.issueDate.slice(0, 7);
          if (monthlyInvoiced.has(key)) {
            monthlyInvoiced.set(
              key,
              money(monthlyInvoiced.get(key)! + invoice.amount * booking.exchangeRateToBase),
            );
          }
        }
        for (const reservation of reservations) {
          if (reservation.costPerUnit === undefined) continue;
          const cost = money(reservation.costPerUnit * reservation.units * booking.exchangeRateToBase);
          addTop(suppliers, reservation.supplierName, cost);
        }
      }

      pipeline.push({ stage, count: rows.length, value: money(stageValue) });
    }

    const decided = pipeline
      .filter((p) => DECIDED_STAGES.includes(p.stage))
      .reduce((s, p) => s + p.count, 0);
    const won = pipeline
      .filter((p) => WON_STAGES.includes(p.stage))
      .reduce((s, p) => s + p.count, 0);

    return {
      truncated,
      sampleSize: pipeline.reduce((s, p) => s + p.count, 0),
      pipeline,
      conversion: { decided, won, rate: decided > 0 ? money((won / decided) * 100) : null },
      monthlyTrend: months.map((m) => ({
        month: m,
        received: monthlyReceived.get(m) ?? 0,
        invoiced: monthlyInvoiced.get(m) ?? 0,
      })),
      topClients: topN(clients, TOP_N).map((c) => ({
        clientName: c.name,
        received: c.value,
        bookingCount: c.count,
      })),
      topSuppliers: topN(suppliers, TOP_N).map((s) => ({
        supplierName: s.name,
        cost: s.value,
        reservationCount: s.count,
      })),
    };
  },
});
