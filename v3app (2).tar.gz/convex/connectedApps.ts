import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { requireManager } from "./lib/access";
import {
  appPreferenceValidator,
  connectedAppKeyValidator,
} from "./schema/connectedApps";

/** Managers' saved choices. The table holds at most one row per app. */
export const listPreferences = query({
  args: {},
  handler: async (ctx) => {
    await requireManager(ctx);
    const rows = await ctx.db.query("connectedApps").take(50);
    return Promise.all(
      rows.map(async (row) => {
        const by = await ctx.db.get("users", row.updatedById);
        return {
          appKey: row.appKey,
          preference: row.preference,
          updatedAt: row.updatedAt,
          updatedByName: by?.name ?? by?.email ?? null,
        };
      }),
    );
  },
});

/** Pass `preference: null` to clear the choice. */
export const setPreference = mutation({
  args: {
    appKey: connectedAppKeyValidator,
    preference: v.union(appPreferenceValidator, v.null()),
  },
  handler: async (ctx, args) => {
    const { user } = await requireManager(ctx);
    const existing = await ctx.db
      .query("connectedApps")
      .withIndex("by_app_key", (q) => q.eq("appKey", args.appKey))
      .unique();

    if (args.preference === null) {
      if (existing) await ctx.db.delete("connectedApps", existing._id);
      return null;
    }

    const fields = {
      preference: args.preference,
      updatedAt: new Date().toISOString(),
      updatedById: user._id,
    };
    if (existing) {
      await ctx.db.patch("connectedApps", existing._id, fields);
    } else {
      await ctx.db.insert("connectedApps", { appKey: args.appKey, ...fields });
    }
    return null;
  },
});
