import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import { fail, requireManager, requireStaff } from "./lib/access";
import { clientKindValidator, type ClientKind } from "./schema/clients";

// Cap for "people at this company" and the company picker, which load in full.
const MEMBER_LIMIT = 200;
const COMPANY_PICKER_LIMIT = 20;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const editableFields = {
  kind: clientKindValidator,
  name: v.string(),
  parentClientId: v.optional(v.id("clients")),
  contactName: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  address: v.optional(v.string()),
  city: v.optional(v.string()),
  country: v.optional(v.string()),
  taxId: v.optional(v.string()),
  notes: v.optional(v.string()),
};

export type ClientFields = Fields;
type Fields = {
  kind: ClientKind;
  name: string;
  parentClientId?: Id<"clients">;
  contactName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  country?: string;
  taxId?: string;
  notes?: string;
};

/** Trim strings and drop empty ones so they aren't stored as "". */
function clean(fields: Fields): Fields {
  const trim = (s: string | undefined) => s?.trim() || undefined;
  return {
    kind: fields.kind,
    name: fields.name.trim(),
    // Only individuals belong to a company.
    parentClientId:
      fields.kind === "individual" ? fields.parentClientId : undefined,
    contactName: trim(fields.contactName),
    email: trim(fields.email)?.toLowerCase(),
    phone: trim(fields.phone),
    address: trim(fields.address),
    city: trim(fields.city),
    country: trim(fields.country),
    taxId: trim(fields.taxId),
    notes: trim(fields.notes),
  };
}

async function validate(
  ctx: MutationCtx,
  fields: Fields,
  selfId?: Id<"clients">,
) {
  if (!fields.name) fail("BAD_REQUEST", "Add the client name.");
  if (fields.email && !EMAIL_PATTERN.test(fields.email)) {
    fail("BAD_REQUEST", "That email address doesn't look right.");
  }
  if (fields.parentClientId) {
    if (fields.parentClientId === selfId) {
      fail("BAD_REQUEST", "A client can't belong to itself.");
    }
    const parent = await ctx.db.get("clients", fields.parentClientId);
    if (!parent || parent.kind !== "company") {
      fail("BAD_REQUEST", "Pick an existing company.");
    }
  }
}

function derived(fields: Fields) {
  return {
    sortName: fields.name.toLowerCase(),
    searchText: [fields.name, fields.contactName, fields.email, fields.city]
      .filter(Boolean)
      .join(" ")
      .toLowerCase(),
  };
}

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    kind: v.optional(clientKindValidator),
    search: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const { kind } = args;
    const term = args.search?.trim().toLowerCase();
    if (term) {
      return await ctx.db
        .query("clients")
        .withSearchIndex("search_text", (q) => {
          const s = q.search("searchText", term);
          return kind ? s.eq("kind", kind) : s;
        })
        .paginate(args.paginationOpts);
    }
    const ordered = kind
      ? ctx.db
          .query("clients")
          .withIndex("by_kind_and_sort_name", (q) => q.eq("kind", kind))
      : ctx.db.query("clients").withIndex("by_sort_name");
    return await ordered.paginate(args.paginationOpts);
  },
});

export const get = query({
  args: { id: v.id("clients") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const client = await ctx.db.get("clients", args.id);
    if (!client) fail("NOT_FOUND", "Client not found.");
    const [parent, creator, members] = await Promise.all([
      client.parentClientId
        ? ctx.db.get("clients", client.parentClientId)
        : null,
      ctx.db.get("users", client.createdById),
      client.kind === "company"
        ? ctx.db
            .query("clients")
            .withIndex("by_parent", (q) => q.eq("parentClientId", client._id))
            .take(MEMBER_LIMIT)
        : [],
    ]);
    return {
      ...client,
      parent: parent ? { _id: parent._id, name: parent.name } : null,
      createdByName: creator?.name ?? creator?.email ?? null,
      members: members
        .map((m) => ({
          _id: m._id,
          name: m.name,
          email: m.email ?? null,
          phone: m.phone ?? null,
        }))
        .sort((a, b) => a.name.localeCompare(b.name)),
    };
  },
});

/** Companies matching a name, for the "works at" picker. */
export const searchCompanies = query({
  args: { search: v.string() },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const term = args.search.trim().toLowerCase();
    const rows = term
      ? await ctx.db
          .query("clients")
          .withSearchIndex("search_text", (q) =>
            q.search("searchText", term).eq("kind", "company"),
          )
          .take(COMPANY_PICKER_LIMIT)
      : await ctx.db
          .query("clients")
          .withIndex("by_kind_and_sort_name", (q) => q.eq("kind", "company"))
          .take(COMPANY_PICKER_LIMIT);
    return rows.map((c) => ({ _id: c._id, name: c.name, city: c.city ?? null }));
  },
});

/** Shared by `create` and AI import so both apply the same rules. */
export async function insertClient(
  ctx: MutationCtx,
  createdById: Id<"users">,
  input: Fields,
): Promise<Id<"clients">> {
  const fields = clean(input);
  await validate(ctx, fields);
  return await ctx.db.insert("clients", {
    ...fields,
    ...derived(fields),
    createdById,
    updatedAt: new Date().toISOString(),
  });
}

export const create = mutation({
  args: editableFields,
  handler: async (ctx, args): Promise<Id<"clients">> => {
    const staff = await requireStaff(ctx);
    return await insertClient(ctx, staff.user._id, args);
  },
});

export const update = mutation({
  args: { id: v.id("clients"), ...editableFields },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const { id, ...rest } = args;
    const existing = await ctx.db.get("clients", id);
    if (!existing) fail("NOT_FOUND", "Client not found.");
    const fields = clean(rest);
    await validate(ctx, fields, id);
    if (existing.kind === "company" && fields.kind === "individual") {
      const member = await ctx.db
        .query("clients")
        .withIndex("by_parent", (q) => q.eq("parentClientId", id))
        .first();
      if (member) {
        fail(
          "CONFLICT",
          "People are linked to this company. Move them first, then change the type.",
        );
      }
    }
    // replace (not patch) so cleared optional fields are actually removed
    await ctx.db.replace("clients", id, {
      ...fields,
      ...derived(fields),
      createdById: existing.createdById,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("clients") },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const client = await ctx.db.get("clients", args.id);
    if (!client) fail("NOT_FOUND", "Client not found.");
    const member = await ctx.db
      .query("clients")
      .withIndex("by_parent", (q) => q.eq("parentClientId", args.id))
      .first();
    if (member) {
      fail(
        "CONFLICT",
        "People are linked to this company. Remove or move them first.",
      );
    }
    await ctx.db.delete("clients", args.id);
    return null;
  },
});
