import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-12-02",
  endDate: "2026-12-07",
  pax: 12,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

const PAGE = { paginationOpts: { numItems: 20, cursor: null } };

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  const ownerId = await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  return { owner, agentA, agentB, ownerId, aId, bookingId };
}

describe("tasks", () => {
  it("lists open tasks soonest first with undated last", async () => {
    const { agentA, bookingId } = await setup();
    const add = (title: string, dueDate?: string) =>
      agentA.mutation(api.tasks.create, { bookingId, kind: "task", title, dueDate });
    await add("Someday");
    await add("Later", "2026-11-20");
    await add("Soon", "2026-11-01");
    const { open } = await agentA.query(api.tasks.listForBooking, { bookingId });
    expect(open.map((t) => t.title)).toEqual(["Soon", "Later", "Someday"]);
  });

  it("moves completed tasks out of the open list", async () => {
    const { agentA, bookingId } = await setup();
    const id = await agentA.mutation(api.tasks.create, {
      bookingId,
      kind: "follow_up",
      title: "Chase hotel",
      dueDate: "2026-11-01",
    });
    await agentA.mutation(api.tasks.setStatus, { id, status: "done" });
    const { open, done } = await agentA.query(api.tasks.listForBooking, { bookingId });
    expect(open).toHaveLength(0);
    expect(done[0]).toMatchObject({ title: "Chase hotel", status: "done" });
    expect(done[0].completedAt).toBeTypeOf("string");

    const mineOpen = await agentA.query(api.tasks.list, { ...PAGE, scope: "mine", done: false });
    expect(mineOpen.page).toHaveLength(0);
  });

  it("only assigns to the booking owner or a manager", async () => {
    const { agentA, agentB, bookingId, ownerId } = await setup();
    const bId = await agentB.mutation(api.users.updateCurrentUser, {});
    await expect(
      agentA.mutation(api.tasks.create, {
        bookingId,
        kind: "task",
        title: "Send rooming",
        assigneeId: bId,
      }),
    ).rejects.toThrow(/booking owner or a manager/);
    await agentA.mutation(api.tasks.create, {
      bookingId,
      kind: "task",
      title: "Approve discount",
      assigneeId: ownerId,
    });
  });

  it("keeps other agents out", async () => {
    const { agentA, agentB, bookingId } = await setup();
    const id = await agentA.mutation(api.tasks.create, { bookingId, kind: "task", title: "Call" });
    await expect(agentB.query(api.tasks.listForBooking, { bookingId })).rejects.toThrow(
      /Booking not found/,
    );
    await expect(agentB.mutation(api.tasks.setStatus, { id, status: "done" })).rejects.toThrow(
      /Task not found/,
    );
    const everyone = await agentB.query(api.tasks.list, { ...PAGE, scope: "everyone", done: false });
    expect(everyone.page).toHaveLength(0);
  });

  it("shows a manager's assigned task in their inbox with the booking link", async () => {
    const { owner, agentA, bookingId, ownerId } = await setup();
    await agentA.mutation(api.tasks.create, {
      bookingId,
      kind: "task",
      title: "Approve discount",
      assigneeId: ownerId,
    });
    const mine = await owner.query(api.tasks.list, { ...PAGE, scope: "mine", done: false });
    expect(mine.page[0]).toMatchObject({
      title: "Approve discount",
      booking: { reference: "GM-2026-0001" },
    });
  });

  it("lets only the creator or a manager delete", async () => {
    const { owner, agentA, bookingId, aId } = await setup();
    const id = await owner.mutation(api.tasks.create, {
      bookingId,
      kind: "task",
      title: "Send programme",
      assigneeId: aId,
    });
    await expect(agentA.mutation(api.tasks.remove, { id })).rejects.toThrow(/Only the person/);
    await owner.mutation(api.tasks.remove, { id });
    const { open } = await owner.query(api.tasks.listForBooking, { bookingId });
    expect(open).toHaveLength(0);
  });
});
