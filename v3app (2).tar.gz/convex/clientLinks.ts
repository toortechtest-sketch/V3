import { v } from "convex/values";
import { mutation, query, type QueryCtx } from "./_generated/server";
import type { Doc } from "./_generated/dataModel";
import { fail } from "./lib/access";
import { applyChangeDecision } from "./lib/reservationChanges";
import { priceLine, quoteTotals } from "./lib/quoteMath";
import { installmentsOf, invoicesOf, paymentsOf } from "./lib/financeData";
import { financeOf } from "./lib/financeLock";
import { financeSummary, installmentAmount } from "./lib/financeMath";
import { buildItinerary } from "./itinerary";
import { linkState } from "./shareLinks";
import { QUOTE_SECTIONS } from "./schema/quotes";
import { offerDecisionValidator } from "./schema/shareLinks";

/*
 * Client-facing endpoints. No sign-in: the random link token is the only key.
 * Everything returned is client-safe: no costs, margins, markups, internal
 * notes, staff names or record IDs.
 */

const TOKEN_PATTERN = /^[0-9a-f]{48}$/;
const LINE_LIMIT = 300;
const RESERVATION_LIMIT = 200;
const REQUEST_LIMIT = 20;

/** The link and its booking, or null when unknown, expired or revoked. */
async function openLink(ctx: QueryCtx, token: string) {
  if (!TOKEN_PATTERN.test(token)) return null;
  const link = await ctx.db
    .query("shareLinks")
    .withIndex("by_token", (q) => q.eq("token", token))
    .unique();
  if (!link || linkState(link, Date.now()) !== "active") return null;
  const booking = await ctx.db.get("bookings", link.bookingId);
  if (!booking || booking.stage === "cancelled") return null;
  return { link, booking };
}

function bookingSummary(booking: Doc<"bookings">) {
  return {
    reference: booking.reference,
    title: booking.title,
    clientName: booking.clientName,
    destination: booking.destination,
    startDate: booking.startDate,
    endDate: booking.endDate,
    pax: booking.pax,
  };
}

async function clientItinerary(ctx: QueryCtx, booking: Doc<"bookings">) {
  const { days } = await buildItinerary(ctx, booking);
  return days
    .filter((d) => !d.outsideDates)
    .map((d) => ({
      date: d.date,
      title: d.title ?? null,
      notes: d.notes ?? null,
      items: d.items.map((i) => ({
        key: `${i.date}-${i._creationTime}`,
        type: i.type,
        startTime: i.startTime ?? null,
        endTime: i.endTime ?? null,
        title: i.title,
        description: i.description ?? null,
        location: i.location ?? null,
        supplierName: i.supplier?.name ?? null,
      })),
    }));
}

async function clientOffer(ctx: QueryCtx, booking: Doc<"bookings">) {
  const [settings, lines] = await Promise.all([
    ctx.db
      .query("quotes")
      .withIndex("by_booking", (q) => q.eq("bookingId", booking._id))
      .unique(),
    ctx.db
      .query("quoteLines")
      .withIndex("by_booking_and_section", (q) => q.eq("bookingId", booking._id))
      .take(LINE_LIMIT),
  ]);
  const defaultMarkup = booking.markupPercent ?? 0;
  const freePlaces = settings?.freePlaces ?? 0;
  const opts = { pax: booking.pax, freePlaces, rateToBase: 1 };
  const priced = lines
    .sort((a, b) => a._creationTime - b._creationTime)
    .map((line) => ({ line, priced: priceLine(line, booking.pax, defaultMarkup) }));

  const sections = QUOTE_SECTIONS.map((section) => {
    const inSection = priced.filter((p) => p.line.section === section);
    return {
      section,
      inclusions: inSection.map((p) => p.line.description),
      sell: quoteTotals(inSection.map((p) => p.priced), opts).sell,
    };
  }).filter((s) => s.inclusions.length > 0);

  const totals = quoteTotals(priced.map((p) => p.priced), opts);
  return {
    currency: booking.currency,
    sections,
    total: totals.sell,
    payingPax: totals.payingPax,
    freePlaces,
    perPayingGuest: totals.perPayingGuest,
    validUntil: settings?.validUntil ?? null,
    terms: settings?.terms ?? null,
  };
}

async function clientReservations(ctx: QueryCtx, booking: Doc<"bookings">) {
  const reservations = await ctx.db
    .query("reservations")
    .withIndex("by_booking_and_start_date", (q) => q.eq("bookingId", booking._id))
    .take(RESERVATION_LIMIT);
  // Only what is actually held for the client; no costs, prices or notes.
  return reservations
    .filter((r) => r.status === "confirmed" || r.status === "requested")
    .map((r) => ({
      key: `${r.startDate}-${r._creationTime}`,
      type: r.type,
      status: r.status,
      supplierName: r.supplierName,
      description: r.description,
      startDate: r.startDate,
      endDate: r.endDate ?? null,
      units: r.units,
      unitLabel: r.unitLabel ?? null,
      board: r.board ?? null,
      confirmationNumber: r.status === "confirmed" ? (r.supplierRef ?? null) : null,
    }));
}

/**
 * Payment status for the client: what's due, what's been paid, and the next
 * due date. No invoice line items, internal notes, or payment references.
 */
async function clientPaymentStatus(ctx: QueryCtx, booking: Doc<"bookings">) {
  const [finance, invoices, payments, installments, sell] = await Promise.all([
    financeOf(ctx, booking._id),
    invoicesOf(ctx, booking._id),
    paymentsOf(ctx, booking._id),
    installmentsOf(ctx, booking._id),
    (async () => {
      const lines = await ctx.db
        .query("quoteLines")
        .withIndex("by_booking_and_section", (q) => q.eq("bookingId", booking._id))
        .take(LINE_LIMIT);
      const markup = booking.markupPercent ?? 0;
      return lines.reduce((s, l) => s + priceLine(l, booking.pax, markup).sell, 0);
    })(),
  ]);
  const contractValue = finance?.contractValue ?? sell;
  const summary = financeSummary(contractValue, invoices, payments);
  // Instalments not yet invoiced are the ones still ahead for the client.
  const upcoming = installments
    .filter((i) => i.invoiceId === undefined)
    .map((i) => ({ label: i.label, amount: installmentAmount(i.percent, contractValue), dueDate: i.dueDate }))
    .sort((a, b) => a.dueDate.localeCompare(b.dueDate));
  return {
    currency: booking.currency,
    total: summary.contractValue,
    received: summary.received,
    outstanding: Math.max(0, summary.outstanding),
    isPaidInFull: summary.outstanding <= 0 && summary.contractValue > 0,
    nextDue: upcoming[0] ?? null,
  };
}

async function clientRequests(ctx: QueryCtx, link: Doc<"shareLinks">) {
  const requests = await ctx.db
    .query("clientChangeRequests")
    .withIndex("by_link", (q) => q.eq("linkId", link._id))
    .order("desc")
    .take(REQUEST_LIMIT);
  return requests.map((r) => ({
    key: r.createdAt,
    name: r.name,
    message: r.message,
    createdAt: r.createdAt,
    handled: r.handledAt !== undefined,
  }));
}

/** The one change a hotel response link is for, or null if it is gone. */
async function hotelChange(ctx: QueryCtx, link: Doc<"shareLinks">) {
  if (!link.changeId) return null;
  const change = await ctx.db.get("reservationChanges", link.changeId);
  if (!change || change.bookingId !== link.bookingId) return null;
  const reservation = await ctx.db.get("reservations", change.reservationId);
  if (!reservation) return null;
  return {
    reservation: {
      type: reservation.type,
      supplierName: reservation.supplierName,
      description: reservation.description,
      startDate: reservation.startDate,
      endDate: reservation.endDate ?? null,
      units: reservation.units,
      unitLabel: reservation.unitLabel ?? null,
      board: reservation.board ?? null,
      supplierRef: reservation.supplierRef ?? null,
    },
    change: {
      kind: change.kind,
      changes: change.changes,
      previous: change.previous,
      message: change.message ?? null,
      status: change.status,
      requestedAt: change.requestedAt,
      respondedAt: change.respondedAt ?? null,
      responseNote: change.responseNote ?? null,
    },
  };
}

function cleanText(value: string, label: string, max: number) {
  const text = value.trim();
  if (!text) fail("BAD_REQUEST", `Add ${label}.`);
  if (text.length > max) fail("BAD_REQUEST", `Keep ${label} under ${max.toLocaleString("en")} characters.`);
  return text;
}

export const view = query({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const opened = await openLink(ctx, args.token);
    if (!opened) return { status: "unavailable" as const };
    const { link, booking } = opened;
    const base = {
      status: "ok" as const,
      expiresAt: link.expiresAt,
      booking: bookingSummary(booking),
    };
    if (link.kind === "hotel_response") {
      const hotel = await hotelChange(ctx, link);
      if (!hotel) return { status: "unavailable" as const };
      // Suppliers only see their own reservation: no client, prices or programme.
      return {
        status: "ok" as const,
        expiresAt: link.expiresAt,
        kind: "hotel_response" as const,
        booking: { reference: booking.reference, title: booking.title },
        ...hotel,
      };
    }
    if (link.kind === "itinerary") {
      return { ...base, kind: "itinerary" as const, days: await clientItinerary(ctx, booking) };
    }
    if (link.kind === "confirmation") {
      return {
        ...base,
        kind: "confirmation" as const,
        reservations: await clientReservations(ctx, booking),
        days: await clientItinerary(ctx, booking),
        requests: await clientRequests(ctx, link),
        payment: await clientPaymentStatus(ctx, booking),
      };
    }
    return {
      ...base,
      kind: "offer" as const,
      offer: await clientOffer(ctx, booking),
      days: await clientItinerary(ctx, booking),
      response: link.response ?? null,
    };
  },
});

/** Counts an opening so staff can see whether the client looked. */
export const recordView = mutation({
  args: { token: v.string() },
  handler: async (ctx, args) => {
    const opened = await openLink(ctx, args.token);
    if (!opened) return null;
    await ctx.db.patch("shareLinks", opened.link._id, {
      viewCount: opened.link.viewCount + 1,
      lastViewedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const respondToOffer = mutation({
  args: {
    token: v.string(),
    decision: offerDecisionValidator,
    name: v.string(),
    message: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const opened = await openLink(ctx, args.token);
    if (!opened || opened.link.kind !== "offer") {
      fail("NOT_FOUND", "This link has expired or is no longer available.");
    }
    const { link, booking } = opened;
    if (link.response) fail("CONFLICT", "A response has already been sent for this offer.");
    const name = args.name.trim();
    const message = args.message?.trim() || undefined;
    if (!name) fail("BAD_REQUEST", "Add your name.");
    if (name.length > 120) fail("BAD_REQUEST", "Keep your name under 120 characters.");
    if (message && message.length > 2000) {
      fail("BAD_REQUEST", "Keep the message under 2,000 characters.");
    }
    const now = new Date().toISOString();
    await ctx.db.patch("shareLinks", link._id, {
      response: { decision: args.decision, name, message, respondedAt: now },
    });
    await ctx.db.patch("bookings", booking._id, { updatedAt: now });
    return null;
  },
});

/** The client asks for a change from their confirmation link; staff follow up. */
export const requestChange = mutation({
  args: { token: v.string(), name: v.string(), message: v.string() },
  handler: async (ctx, args) => {
    const opened = await openLink(ctx, args.token);
    if (!opened || opened.link.kind !== "confirmation") {
      fail("NOT_FOUND", "This link has expired or is no longer available.");
    }
    const { link, booking } = opened;
    const name = cleanText(args.name, "your name", 120);
    const message = cleanText(args.message, "what you would like to change", 2000);
    // Bounded per link so a shared link can't flood the booking.
    const existing = await ctx.db
      .query("clientChangeRequests")
      .withIndex("by_link", (q) => q.eq("linkId", link._id))
      .take(REQUEST_LIMIT);
    if (existing.length >= REQUEST_LIMIT) {
      fail("BAD_REQUEST", "You've sent the maximum number of requests here. Contact your travel team directly.");
    }
    const now = new Date().toISOString();
    await ctx.db.insert("clientChangeRequests", {
      bookingId: booking._id,
      linkId: link._id,
      name,
      message,
      createdAt: now,
    });
    await ctx.db.patch("bookings", booking._id, { updatedAt: now });
    return null;
  },
});

/** The hotel approves or declines the one change its link is for. */
export const respondAsHotel = mutation({
  args: {
    token: v.string(),
    decision: v.union(v.literal("approved"), v.literal("declined")),
    name: v.string(),
    note: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const opened = await openLink(ctx, args.token);
    if (!opened || opened.link.kind !== "hotel_response" || !opened.link.changeId) {
      fail("NOT_FOUND", "This link has expired or is no longer available.");
    }
    const change = await ctx.db.get("reservationChanges", opened.link.changeId);
    if (!change || change.bookingId !== opened.booking._id) {
      fail("NOT_FOUND", "This link has expired or is no longer available.");
    }
    if (change.status !== "pending") fail("CONFLICT", "This request has already been answered.");
    const reservation = await ctx.db.get("reservations", change.reservationId);
    if (!reservation || reservation.status !== "confirmed") {
      fail("CONFLICT", "This reservation can no longer be changed here.");
    }
    const name = cleanText(args.name, "your name", 120);
    const note = args.note?.trim() || undefined;
    if (note && note.length > 1000) fail("BAD_REQUEST", "Keep the note under 1,000 characters.");
    const responseNote = `${name}, via response link${note ? `: ${note}` : ""}`;
    await applyChangeDecision(ctx, change, args.decision, responseNote, undefined);
    return null;
  },
});
