import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-12-01",
  endDate: "2026-12-04",
  pax: 20,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

const HOTEL = {
  type: "hotel" as const,
  supplierName: "Hotel Arts",
  description: "Deluxe sea view",
  startDate: "2026-12-01",
  endDate: "2026-12-04",
  units: 10,
  unitLabel: "rooms",
  board: "breakfast" as const,
  supplierRef: "HA-991",
  costPerUnit: 180,
  sellPerUnit: 240,
  notes: "SECRET-RES-NOTE",
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  const reservationId = await agentA.mutation(api.reservations.create, {
    bookingId,
    status: "confirmed",
    ...HOTEL,
  });
  await agentA.mutation(api.reservations.create, {
    bookingId,
    status: "option",
    ...HOTEL,
    supplierName: "Option Hotel",
  });
  return { t, agentA, agentB, bookingId, reservationId };
}

async function pendingChange(agentA: ReturnType<typeof as>, reservationId: Awaited<ReturnType<typeof setup>>["reservationId"]) {
  return await agentA.mutation(api.reservations.requestChange, {
    reservationId,
    kind: "change",
    changes: { units: 12 },
    message: "Two more rooms please",
  });
}

describe("confirmation links", () => {
  it("shows confirmed services without costs and takes client change requests", async () => {
    const { t, agentA, bookingId } = await setup();
    const { token } = await agentA.action(api.shareLinks.create, { bookingId, kind: "confirmation", days: 14 });

    const view = await t.query(api.clientLinks.view, { token });
    if (view.status !== "ok" || view.kind !== "confirmation") throw new Error("expected confirmation");
    // Options are not shown to the client
    expect(view.reservations).toHaveLength(1);
    expect(view.reservations[0]).toMatchObject({ supplierName: "Hotel Arts", confirmationNumber: "HA-991" });
    const json = JSON.stringify(view);
    for (const secret of ["SECRET", "180", "240", "cost", "sell", bookingId]) {
      expect(json).not.toContain(secret);
    }

    await expect(
      t.mutation(api.clientLinks.requestChange, { token, name: "Jane", message: "  " }),
    ).rejects.toThrow(/change/i);
    await t.mutation(api.clientLinks.requestChange, { token, name: "Jane", message: "One more room" });

    const [link] = await agentA.query(api.shareLinks.list, { bookingId });
    expect(link.clientRequests).toHaveLength(1);
    await agentA.mutation(api.shareLinks.setRequestHandled, { id: link.clientRequests[0]._id, handled: true });
    const after = await t.query(api.clientLinks.view, { token });
    if (after.status !== "ok" || after.kind !== "confirmation") throw new Error("expected confirmation");
    expect(after.requests[0].handled).toBe(true);
  });
});

describe("hotel response links", () => {
  it("lets the hotel approve once and applies the change", async () => {
    const { t, agentA, bookingId, reservationId } = await setup();
    const changeId = await pendingChange(agentA, reservationId);
    const { token } = await agentA.action(api.shareLinks.create, {
      bookingId,
      kind: "hotel_response",
      days: 14,
      changeId,
    });
    // Asking again reuses the active link
    const again = await agentA.action(api.shareLinks.create, {
      bookingId,
      kind: "hotel_response",
      days: 14,
      changeId,
    });
    expect(again.token).toBe(token);

    const view = await t.query(api.clientLinks.view, { token });
    if (view.status !== "ok" || view.kind !== "hotel_response") throw new Error("expected hotel view");
    expect(view.change.changes.units).toBe(12);
    const json = JSON.stringify(view);
    for (const secret of ["SECRET", "Acme", "180", "240", bookingId]) {
      expect(json).not.toContain(secret);
    }

    await t.mutation(api.clientLinks.respondAsHotel, { token, decision: "approved", name: "Maria" });
    await expect(
      t.mutation(api.clientLinks.respondAsHotel, { token, decision: "declined", name: "Maria" }),
    ).rejects.toThrow(/already/i);

    const { reservations } = await agentA.query(api.reservations.list, { bookingId });
    const res = reservations.find((r) => r._id === reservationId);
    expect(res?.units).toBe(12);
    expect(res?.history[0]).toMatchObject({ status: "approved" });
    expect(res?.history[0].responseNote).toContain("Maria");
  });

  it("only links pending changes on bookings the staff member can access", async () => {
    const { t, agentA, agentB, bookingId, reservationId } = await setup();
    const changeId = await pendingChange(agentA, reservationId);
    await expect(
      agentB.action(api.shareLinks.create, { bookingId, kind: "hotel_response", days: 7, changeId }),
    ).rejects.toThrow(/not found/i);
    await expect(
      agentA.action(api.shareLinks.create, { bookingId, kind: "hotel_response", days: 7 }),
    ).rejects.toThrow(/change request/i);

    const { token } = await agentA.action(api.shareLinks.create, {
      bookingId,
      kind: "hotel_response",
      days: 7,
      changeId,
    });
    await agentA.mutation(api.reservations.withdrawChange, { changeId });
    await expect(
      t.mutation(api.clientLinks.respondAsHotel, { token, decision: "approved", name: "Maria" }),
    ).rejects.toThrow(/already/i);
    await expect(
      agentA.action(api.shareLinks.create, { bookingId, kind: "hotel_response", days: 7, changeId }),
    ).rejects.toThrow(/already been answered/i);
  });
});
