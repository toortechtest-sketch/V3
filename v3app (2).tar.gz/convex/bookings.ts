import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";
import {
  mutation,
  query,
  type MutationCtx,
  type QueryCtx,
} from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import {
  canAccessBooking,
  fail,
  isManagerRole,
  requireBooking,
  requireManager,
  requireStaff,
  type Staff,
} from "./lib/access";
import { ownerNames } from "./lib/owners";
import {
  bookingStageValidator,
  bookingTypeValidator,
  BOARD_STAGES,
  currencyValidator,
} from "./schema/bookings";

const editableFields = {
  title: v.string(),
  type: bookingTypeValidator,
  clientName: v.string(),
  clientContactName: v.optional(v.string()),
  clientContactEmail: v.optional(v.string()),
  clientContactPhone: v.optional(v.string()),
  destination: v.string(),
  startDate: v.string(),
  endDate: v.string(),
  pax: v.number(),
  currency: currencyValidator,
  exchangeRateToBase: v.number(),
  markupPercent: v.optional(v.number()),
  notes: v.optional(v.string()),
};

type EditableFields = {
  title: string;
  clientName: string;
  destination: string;
  startDate: string;
  endDate: string;
  pax: number;
  currency: string;
  exchangeRateToBase: number;
  markupPercent?: number;
};

const BOARD_COLUMN_LIMIT = 50;
const DAY_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

function validate(fields: EditableFields) {
  if (!fields.title.trim()) fail("BAD_REQUEST", "Add a booking title.");
  if (!fields.clientName.trim()) fail("BAD_REQUEST", "Add a client name.");
  if (!fields.destination.trim()) fail("BAD_REQUEST", "Add a destination.");
  if (!DAY_PATTERN.test(fields.startDate) || !DAY_PATTERN.test(fields.endDate)) {
    fail("BAD_REQUEST", "Dates must be valid calendar days.");
  }
  if (fields.endDate < fields.startDate) {
    fail("BAD_REQUEST", "End date cannot be before the start date.");
  }
  if (!Number.isInteger(fields.pax) || fields.pax < 1) {
    fail("BAD_REQUEST", "A booking needs at least one traveller.");
  }
  if (!(fields.exchangeRateToBase > 0)) {
    fail("BAD_REQUEST", "Exchange rate must be greater than zero.");
  }
  if (fields.currency === "EUR" && fields.exchangeRateToBase !== 1) {
    fail("BAD_REQUEST", "EUR bookings use an exchange rate of 1.");
  }
  if (fields.markupPercent !== undefined && fields.markupPercent < 0) {
    fail("BAD_REQUEST", "Markup cannot be negative.");
  }
}

function buildSearchText(b: {
  reference: string;
  title: string;
  clientName: string;
  destination: string;
}) {
  return [b.reference, b.title, b.clientName, b.destination]
    .join(" ")
    .toLowerCase();
}

/** Trim optional strings and drop empty ones so they aren't stored as "". */
function clean<T extends Record<string, unknown>>(fields: T): T {
  const out: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(fields)) {
    const next = typeof value === "string" ? value.trim() : value;
    out[key] = next === "" ? undefined : next;
  }
  return out as T;
}

/** Next "GM-YYYY-NNNN" reference for the booking's start year (V2 format). */
async function nextReference(ctx: MutationCtx, startDate: string) {
  const prefix = `GM-${startDate.slice(0, 4)}-`;
  const latest = await ctx.db
    .query("bookings")
    .withIndex("by_reference", (q) =>
      q.gte("reference", prefix).lt("reference", `${prefix}\uffff`),
    )
    .order("desc")
    .first();
  const next = latest
    ? Number.parseInt(latest.reference.slice(prefix.length), 10) + 1
    : 1;
  return `${prefix}${String(next).padStart(4, "0")}`;
}

/** Only active staff can own bookings. */
async function requireAssignableOwner(ctx: MutationCtx, userId: Id<"users">) {
  const role = await ctx.db
    .query("staffRoles")
    .withIndex("by_user", (q) => q.eq("userId", userId))
    .unique();
  if (!role) fail("BAD_REQUEST", "Bookings can only be assigned to staff.");
}

function canSeeAll(staff: Staff) {
  return isManagerRole(staff.role);
}

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    stage: v.optional(bookingStageValidator),
    search: v.optional(v.string()),
    mineOnly: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx);
    const all = canSeeAll(staff) && !args.mineOnly;
    const ownerId = staff.user._id;
    const stage = args.stage;
    const term = args.search?.trim().toLowerCase();

    const results = term
      ? await ctx.db
          .query("bookings")
          .withSearchIndex("search_text", (q) => {
            let s = q.search("searchText", term);
            if (!all) s = s.eq("ownerId", ownerId);
            if (stage) s = s.eq("stage", stage);
            return s;
          })
          .paginate(args.paginationOpts)
      : await (all
          ? stage
            ? ctx.db
                .query("bookings")
                .withIndex("by_stage_and_start_date", (q) =>
                  q.eq("stage", stage),
                )
            : ctx.db.query("bookings").withIndex("by_start_date")
          : stage
            ? ctx.db
                .query("bookings")
                .withIndex("by_owner_and_stage_and_start_date", (q) =>
                  q.eq("ownerId", ownerId).eq("stage", stage),
                )
            : ctx.db
                .query("bookings")
                .withIndex("by_owner_and_start_date", (q) =>
                  q.eq("ownerId", ownerId),
                )
        )
          .order("desc")
          .paginate(args.paginationOpts);

    const names = await ownerNames(ctx, results.page);
    return {
      ...results,
      page: results.page.map((b) => ({
        ...b,
        ownerName: names.get(b.ownerId) ?? null,
      })),
    };
  },
});

/** Active stages for the board, soonest departure first. */
export const board = query({
  args: { mineOnly: v.optional(v.boolean()) },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx);
    const all = canSeeAll(staff) && !args.mineOnly;
    const ownerId = staff.user._id;
    const columns = await Promise.all(
      BOARD_STAGES.map(async (stage) => {
        const rows = await (all
          ? ctx.db
              .query("bookings")
              .withIndex("by_stage_and_start_date", (q) => q.eq("stage", stage))
          : ctx.db
              .query("bookings")
              .withIndex("by_owner_and_stage_and_start_date", (q) =>
                q.eq("ownerId", ownerId).eq("stage", stage),
              )
        )
          .order("asc")
          .take(BOARD_COLUMN_LIMIT + 1);
        return {
          stage,
          bookings: rows.slice(0, BOARD_COLUMN_LIMIT),
          hasMore: rows.length > BOARD_COLUMN_LIMIT,
        };
      }),
    );
    const names = await ownerNames(
      ctx,
      columns.flatMap((c) => c.bookings),
    );
    return columns.map((c) => ({
      ...c,
      bookings: c.bookings.map((b) => ({
        ...b,
        ownerName: names.get(b.ownerId) ?? null,
      })),
    }));
  },
});

/**
 * Takes a raw URL string and returns null for malformed, missing or
 * inaccessible IDs alike, so the overview page shows a calm "not found".
 */
export const get = query({
  args: { id: v.string() },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx);
    const id = ctx.db.normalizeId("bookings", args.id);
    const booking = id ? await ctx.db.get("bookings", id) : null;
    if (!booking || !canAccessBooking(staff, booking)) return null;
    const [owner, creator] = await Promise.all([
      ctx.db.get("users", booking.ownerId),
      ctx.db.get("users", booking.createdById),
    ]);
    return {
      ...booking,
      ownerName: owner?.name ?? owner?.email ?? null,
      createdByName: creator?.name ?? creator?.email ?? null,
      canReassign: isManagerRole(staff.role),
    };
  },
});

/** Active staff a manager can assign bookings to. */
export const listAssignableOwners = query({
  args: {},
  handler: async (ctx) => {
    await requireManager(ctx);
    const roles = await ctx.db.query("staffRoles").take(500);
    const users = await Promise.all(
      roles.map((r) => ctx.db.get("users", r.userId)),
    );
    return users
      .filter((u): u is Doc<"users"> => u !== null)
      .map((u) => ({ userId: u._id, name: u.name ?? u.email ?? "Unnamed" }))
      .sort((a, b) => a.name.localeCompare(b.name));
  },
});

/**
 * Resolves who owns a booking. Non-managers can only keep themselves (create)
 * or the current owner (update); managers may pick any active staff member.
 */
async function resolveOwner(
  ctx: MutationCtx,
  staff: Staff,
  requested: Id<"users"> | undefined,
  current: Id<"users">,
) {
  if (!requested || requested === current) return current;
  if (!isManagerRole(staff.role)) {
    fail("FORBIDDEN", "Only managers can assign bookings to others.");
  }
  await requireAssignableOwner(ctx, requested);
  return requested;
}

export const create = mutation({
  args: {
    ...editableFields,
    stage: v.optional(bookingStageValidator),
    ownerId: v.optional(v.id("users")),
  },
  handler: async (ctx, args): Promise<Id<"bookings">> => {
    const staff = await requireStaff(ctx);
    const { ownerId: requested, stage, ...rest } = args;
    const fields = clean(rest);
    validate(fields);
    const ownerId = await resolveOwner(ctx, staff, requested, staff.user._id);
    const reference = await nextReference(ctx, fields.startDate);
    return await ctx.db.insert("bookings", {
      ...fields,
      reference,
      stage: stage ?? "enquiry",
      ownerId,
      createdById: staff.user._id,
      updatedAt: new Date().toISOString(),
      searchText: buildSearchText({ ...fields, reference }),
    });
  },
});

export const update = mutation({
  args: {
    id: v.id("bookings"),
    ...editableFields,
    ownerId: v.optional(v.id("users")),
  },
  handler: async (ctx, args) => {
    const { staff, booking } = await requireBooking(ctx, args.id);
    const { id, ownerId: requested, ...rest } = args;
    const fields = clean(rest);
    validate(fields);
    const ownerId = await resolveOwner(ctx, staff, requested, booking.ownerId);
    await ctx.db.patch("bookings", id, {
      // Explicitly clear optional fields the user emptied.
      clientContactName: undefined,
      clientContactEmail: undefined,
      clientContactPhone: undefined,
      markupPercent: undefined,
      notes: undefined,
      ...fields,
      ownerId,
      updatedAt: new Date().toISOString(),
      searchText: buildSearchText({ ...fields, reference: booking.reference }),
    });
    return null;
  },
});

export const setStage = mutation({
  args: { id: v.id("bookings"), stage: bookingStageValidator },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.id);
    if (booking.stage === args.stage) return null;
    await ctx.db.patch("bookings", args.id, {
      stage: args.stage,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});
