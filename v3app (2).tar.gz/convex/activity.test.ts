import { convexTest } from "convex-test";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "a");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  return { owner, agent, agentId };
}

describe("activity heartbeat", () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it("accumulates duration across consecutive heartbeats", async () => {
    const { agent } = await setup();
    vi.setSystemTime(new Date("2026-10-04T09:00:00.000Z"));
    await agent.mutation(api.activity.heartbeat, {});
    vi.setSystemTime(new Date("2026-10-04T09:01:00.000Z"));
    await agent.mutation(api.activity.heartbeat, {});
    vi.setSystemTime(new Date("2026-10-04T09:02:00.000Z"));
    await agent.mutation(api.activity.heartbeat, {});

    const stats = await agent.query(api.activity.myStats, {});
    expect(stats.todayMs).toBe(2 * 60 * 1000);
    expect(stats.recentSessions).toHaveLength(1);
    expect(stats.online).toBe(true);
  });

  it("starts a new session after a long gap", async () => {
    const { agent } = await setup();
    vi.setSystemTime(new Date("2026-10-04T09:00:00.000Z"));
    await agent.mutation(api.activity.heartbeat, {});
    vi.setSystemTime(new Date("2026-10-04T09:01:00.000Z"));
    await agent.mutation(api.activity.heartbeat, {});
    // A 10-minute gap exceeds the heartbeat tolerance.
    vi.setSystemTime(new Date("2026-10-04T09:11:00.000Z"));
    await agent.mutation(api.activity.heartbeat, {});

    const stats = await agent.query(api.activity.myStats, {});
    expect(stats.recentSessions).toHaveLength(2);
  });

  it("keeps each person's own time separate", async () => {
    const { owner, agent } = await setup();
    vi.setSystemTime(new Date("2026-10-04T09:00:00.000Z"));
    await agent.mutation(api.activity.heartbeat, {});
    vi.setSystemTime(new Date("2026-10-04T09:05:00.000Z"));
    await agent.mutation(api.activity.heartbeat, {});

    const ownerStats = await owner.query(api.activity.myStats, {});
    expect(ownerStats.todayMs).toBe(0);
    const agentStats = await agent.query(api.activity.myStats, {});
    expect(agentStats.todayMs).toBe(5 * 60 * 1000);
  });
});

describe("activity access control", () => {
  it("lets a manager see every staff member's stats", async () => {
    const { owner, agent, agentId } = await setup();
    const rows = await owner.query(api.activity.teamStats, {});
    expect(rows.map((r) => r.userId)).toContain(agentId);
    const detail = await owner.query(api.activity.memberStats, { userId: agentId });
    expect(detail).toBeDefined();
    void agent;
  });

  it("blocks a non-manager from the team or member views", async () => {
    const { agent, agentId } = await setup();
    await expect(agent.query(api.activity.teamStats, {})).rejects.toThrow(/manager/);
    await expect(agent.query(api.activity.memberStats, { userId: agentId })).rejects.toThrow(/manager/);
  });
});
