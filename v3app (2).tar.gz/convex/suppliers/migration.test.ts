import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  await owner.mutation(api.users.updateCurrentUser, {});
  return { t, owner };
}

describe("supplier migration dry-run tooling", () => {
  it("previews a mapped legacy supplier without writing anything", async () => {
    const { owner } = await setup();
    const supplierId = await owner.mutation(api.suppliers.create, {
      name: "Hotel Arts",
      category: "hotel",
      status: "active",
      hotelClass: "5-star",
      totalRooms: 200,
    });
    await owner.mutation(api.suppliers.addRoomType, {
      supplierId,
      name: "Deluxe double",
      occupancy: 2,
      board: "breakfast",
      nightlyRate: 220,
    });

    const preview = await owner.query(api.suppliers.migration.preview, {
      paginationOpts: { numItems: 50, cursor: null },
    });
    const row = preview.page.find((r) => r.supplierId === supplierId)!;
    expect(row.status).toBe("mapped");
    expect(row.mappedPrimaryType).toBe("hotel");
    expect(row.alreadyProcessed).toBe(false);

    // A dry run never changes supplier data.
    const dryRun = await owner.mutation(api.suppliers.migration.runBackfill, {
      paginationOpts: { numItems: 50, cursor: null },
      dryRun: true,
    });
    expect(dryRun.mapped).toBe(1);
    const supplier = await owner.query(api.suppliers.get, { id: supplierId });
    expect(supplier.primaryType).toBeUndefined();
    const caps = await owner.query(api.suppliers.capabilities.list, { supplierId });
    expect(caps).toHaveLength(0);
  });

  it("backfills primary type, capability, profile and room-type products idempotently", async () => {
    const { owner } = await setup();
    const supplierId = await owner.mutation(api.suppliers.create, {
      name: "Hotel Arts",
      category: "hotel",
      status: "active",
      hotelClass: "5-star",
      totalRooms: 200,
    });
    await owner.mutation(api.suppliers.addRoomType, {
      supplierId,
      name: "Deluxe double",
      occupancy: 2,
      board: "breakfast",
      nightlyRate: 220,
    });

    const run1 = await owner.mutation(api.suppliers.migration.runBackfill, {
      paginationOpts: { numItems: 50, cursor: null },
      dryRun: false,
    });
    expect(run1.mapped).toBe(1);

    const supplier = await owner.query(api.suppliers.get, { id: supplierId });
    expect(supplier.primaryType).toBe("hotel");
    const caps = await owner.query(api.suppliers.capabilities.list, { supplierId });
    expect(caps).toMatchObject([{ category: "hotel", isPrimary: true }]);
    const profile = await owner.query(api.suppliers.profiles.get, {
      supplierId,
      category: "hotel",
    });
    expect(profile?.attributes).toMatchObject({ totalRooms: 200 });
    const products = await owner.query(api.suppliers.products.list, { supplierId });
    expect(products).toHaveLength(1);
    expect(products[0]).toMatchObject({ name: "Deluxe double" });
    const rates = await owner.query(api.suppliers.products.listRates, {
      productId: products[0]._id,
    });
    expect(rates).toHaveLength(1);
    expect(rates[0].amount).toBe(220);

    // Rerun must be a no-op: no duplicate products/capabilities, and it's
    // reported as already migrated rather than mapped again.
    const run2 = await owner.mutation(api.suppliers.migration.runBackfill, {
      paginationOpts: { numItems: 50, cursor: null },
      dryRun: false,
    });
    expect(run2.mapped).toBe(0);
    expect(run2.alreadyMigrated).toBe(1);
    const productsAfterRerun = await owner.query(api.suppliers.products.list, { supplierId });
    expect(productsAfterRerun).toHaveLength(1);
    const capsAfterRerun = await owner.query(api.suppliers.capabilities.list, { supplierId });
    expect(capsAfterRerun).toHaveLength(1);
  });

  it("flags a supplier whose primary type was already set to something else as ambiguous, never overwriting it", async () => {
    const { t, owner } = await setup();
    const supplierId = await owner.mutation(api.suppliers.create, {
      name: "Mixed Co",
      category: "restaurant",
      status: "active",
    });
    // Simulate legacy data where primaryType was set independently of the
    // legacy category (e.g. by an earlier tool), rather than through
    // setPrimaryType, which always keeps both fields in sync.
    await t.run(async (ctx) => {
      await ctx.db.patch("suppliers", supplierId, { primaryType: "venue" });
    });

    const preview = await owner.query(api.suppliers.migration.preview, {
      paginationOpts: { numItems: 50, cursor: null },
    });
    const row = preview.page.find((r) => r.supplierId === supplierId)!;
    expect(row.status).toBe("ambiguous");

    await owner.mutation(api.suppliers.migration.runBackfill, {
      paginationOpts: { numItems: 50, cursor: null },
      dryRun: false,
    });
    const supplier = await owner.query(api.suppliers.get, { id: supplierId });
    // Must stay exactly as the staff member set it, never silently overwritten.
    expect(supplier.primaryType).toBe("venue");
  });

  it("blocks non-managers from previewing or running the backfill", async () => {
    const { t, owner } = await setup();
    const agent = as(t, "agent");
    await agent.mutation(api.users.updateCurrentUser, {});
    await expect(
      agent.query(api.suppliers.migration.preview, {
        paginationOpts: { numItems: 50, cursor: null },
      }),
    ).rejects.toThrow();
    await expect(
      agent.mutation(api.suppliers.migration.runBackfill, {
        paginationOpts: { numItems: 50, cursor: null },
        dryRun: true,
      }),
    ).rejects.toThrow();
    // Sanity: owner (manager) can.
    await expect(
      owner.query(api.suppliers.migration.preview, {
        paginationOpts: { numItems: 50, cursor: null },
      }),
    ).resolves.toBeDefined();
  });
});
