import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { fail, requireManager, requireStaff } from "../lib/access";
import {
  CATEGORY_REGISTRY,
  attributesValidator,
  serviceCategoryValidator,
  type ServiceCategory,
} from "../schema/supplierCategories";
import { supplierProductStatusValidator } from "../schema/supplierProfiles";
import { requireSupplier } from "./capabilities";
import { cleanAttributes, type AttributeValue } from "./profiles";
import { findPoolReferencing } from "./allotments";

const PRODUCT_LIMIT = 300;
const RATE_LIMIT = 50;

async function requireCapability(ctx: MutationCtx, supplierId: Id<"suppliers">, category: ServiceCategory) {
  const row = await ctx.db
    .query("supplierCapabilities")
    .withIndex("by_supplier_and_category", (q) =>
      q.eq("supplierId", supplierId).eq("category", category),
    )
    .unique();
  if (!row) {
    fail("BAD_REQUEST", "Enable this category as a service before adding a product to it.");
  }
}

async function requireProduct(ctx: MutationCtx, id: Id<"supplierProducts">) {
  const product = await ctx.db.get("supplierProducts", id);
  if (!product) fail("NOT_FOUND", "Product not found.");
  return product;
}

const productFields = {
  supplierId: v.id("suppliers"),
  category: serviceCategoryValidator,
  name: v.string(),
  subtype: v.optional(v.string()),
  supplierReference: v.optional(v.string()),
  internalReference: v.optional(v.string()),
  description: v.optional(v.string()),
  status: supplierProductStatusValidator,
  attributes: attributesValidator,
};

export const list = query({
  args: {
    supplierId: v.id("suppliers"),
    category: v.optional(serviceCategoryValidator),
    status: v.optional(supplierProductStatusValidator),
  },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const rows = args.category
      ? await ctx.db
          .query("supplierProducts")
          .withIndex("by_supplier_and_category_and_status", (q) =>
            args.status
              ? q.eq("supplierId", args.supplierId).eq("category", args.category!).eq("status", args.status)
              : q.eq("supplierId", args.supplierId).eq("category", args.category!),
          )
          .take(PRODUCT_LIMIT)
      : await ctx.db
          .query("supplierProducts")
          .withIndex("by_supplier_and_category_and_status", (q) => q.eq("supplierId", args.supplierId))
          .take(PRODUCT_LIMIT);
    return rows;
  },
});

export const create = mutation({
  args: productFields,
  handler: async (ctx, args): Promise<Id<"supplierProducts">> => {
    const staff = await requireStaff(ctx);
    await requireSupplier(ctx, args.supplierId);
    await requireCapability(ctx, args.supplierId, args.category);
    const name = args.name.trim();
    if (!name) fail("BAD_REQUEST", "Add the product name.");
    const existing = await ctx.db
      .query("supplierProducts")
      .withIndex("by_supplier_and_category_and_status", (q) => q.eq("supplierId", args.supplierId))
      .take(PRODUCT_LIMIT);
    if (existing.length >= PRODUCT_LIMIT) {
      fail("BAD_REQUEST", `A supplier can have up to ${PRODUCT_LIMIT} products.`);
    }
    const entry = CATEGORY_REGISTRY[args.category];
    return await ctx.db.insert("supplierProducts", {
      supplierId: args.supplierId,
      category: args.category,
      name,
      subtype: args.subtype,
      supplierReference: args.supplierReference?.trim() || undefined,
      internalReference: args.internalReference?.trim() || undefined,
      description: args.description?.trim() || undefined,
      status: args.status,
      schemaVersion: entry.schemaVersion,
      attributes: cleanAttributes(entry.productFields, args.attributes as Record<string, AttributeValue>),
      createdById: staff.user._id,
      updatedAt: new Date().toISOString(),
    });
  },
});

export const update = mutation({
  args: { id: v.id("supplierProducts"), ...productFields },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const { id, ...rest } = args;
    const existing = await requireProduct(ctx, id);
    if (existing.category !== rest.category) {
      await requireCapability(ctx, rest.supplierId, rest.category);
    }
    const name = rest.name.trim();
    if (!name) fail("BAD_REQUEST", "Add the product name.");
    const entry = CATEGORY_REGISTRY[rest.category];
    await ctx.db.patch("supplierProducts", id, {
      category: rest.category,
      name,
      subtype: rest.subtype,
      supplierReference: rest.supplierReference?.trim() || undefined,
      internalReference: rest.internalReference?.trim() || undefined,
      description: rest.description?.trim() || undefined,
      status: rest.status,
      schemaVersion: entry.schemaVersion,
      attributes: cleanAttributes(entry.productFields, rest.attributes as Record<string, AttributeValue>),
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

/** Archives rather than deletes, so historical rate/booking references stay valid. */
export const archive = mutation({
  args: { id: v.id("supplierProducts") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const product = await requireProduct(ctx, args.id);
    if (product.status === "archived") return null;
    await ctx.db.patch("supplierProducts", args.id, {
      status: "archived",
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("supplierProducts") },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const product = await requireProduct(ctx, args.id);
    const rates = await ctx.db
      .query("supplierRates")
      .withIndex("by_product", (q) => q.eq("productId", args.id))
      .first();
    if (rates) {
      fail("CONFLICT", "This product has rates. Remove them first, or archive the product instead.");
    }
    const pool = await findPoolReferencing(ctx, product.supplierId, { productId: product._id });
    if (pool) {
      fail("CONFLICT", "This product has an allotment. Delete it first.");
    }
    await ctx.db.delete("supplierProducts", product._id);
    return null;
  },
});

// --- Rates ------------------------------------------------------------

const rateFields = {
  productId: v.id("supplierProducts"),
  rateName: v.optional(v.string()),
  supplierRateReference: v.optional(v.string()),
  currency: v.string(),
  amount: v.optional(v.number()),
  pricingUnit: v.string(),
  validFrom: v.optional(v.string()),
  validTo: v.optional(v.string()),
  minQuantity: v.optional(v.number()),
  maxQuantity: v.optional(v.number()),
  minimumCharge: v.optional(v.number()),
  taxMode: v.union(v.literal("included"), v.literal("excluded"), v.literal("unknown")),
  taxRate: v.optional(v.number()),
  rateBasis: v.union(v.literal("net"), v.literal("gross"), v.literal("unknown")),
  availabilityStatus: v.union(
    v.literal("on_request"),
    v.literal("confirmed_allocation"),
    v.literal("other"),
  ),
  conditions: v.optional(v.string()),
  sourceWording: v.optional(v.string()),
};

const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const CURRENCY_PATTERN = /^[A-Z]{3}$/;

function validateRate(fields: {
  currency: string;
  amount?: number;
  pricingUnit: string;
  validFrom?: string;
  validTo?: string;
  taxRate?: number;
}) {
  if (!CURRENCY_PATTERN.test(fields.currency)) fail("BAD_REQUEST", "Use a 3-letter currency code.");
  if (!fields.pricingUnit.trim()) fail("BAD_REQUEST", "Add a pricing unit.");
  // Missing amount is a valid "price on request" row; a negative amount is not.
  if (fields.amount !== undefined && fields.amount < 0) {
    fail("BAD_REQUEST", "Price can't be negative. Use a credit/adjustment for corrections.");
  }
  if (fields.validFrom && !DATE_PATTERN.test(fields.validFrom)) fail("BAD_REQUEST", "Invalid valid-from date.");
  if (fields.validTo && !DATE_PATTERN.test(fields.validTo)) fail("BAD_REQUEST", "Invalid valid-to date.");
  if (fields.validFrom && fields.validTo && fields.validFrom > fields.validTo) {
    fail("BAD_REQUEST", "Valid-from must be before valid-to.");
  }
  if (fields.taxRate !== undefined && (fields.taxRate < 0 || fields.taxRate > 100)) {
    fail("BAD_REQUEST", "Tax rate must be between 0 and 100%.");
  }
}

export const listRates = query({
  args: { productId: v.id("supplierProducts") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    return await ctx.db
      .query("supplierRates")
      .withIndex("by_product", (q) => q.eq("productId", args.productId))
      .take(RATE_LIMIT);
  },
});

/** Aggregated rates across a supplier, for the Rates tab with product/category filters. */
export const listForSupplier = query({
  args: { supplierId: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const products = await ctx.db
      .query("supplierProducts")
      .withIndex("by_supplier_and_category_and_status", (q) => q.eq("supplierId", args.supplierId))
      .take(PRODUCT_LIMIT);
    const rateLists = await Promise.all(
      products.map((p) =>
        ctx.db
          .query("supplierRates")
          .withIndex("by_product", (q) => q.eq("productId", p._id))
          .take(RATE_LIMIT),
      ),
    );
    return products.map((product, i) => ({ product, rates: rateLists[i] }));
  },
});

export const createRate = mutation({
  args: rateFields,
  handler: async (ctx, args): Promise<Id<"supplierRates">> => {
    const staff = await requireStaff(ctx);
    const product = await requireProduct(ctx, args.productId);
    const existing = await ctx.db
      .query("supplierRates")
      .withIndex("by_product", (q) => q.eq("productId", args.productId))
      .take(RATE_LIMIT);
    if (existing.length >= RATE_LIMIT) {
      fail("BAD_REQUEST", `A product can have up to ${RATE_LIMIT} rates.`);
    }
    validateRate(args);
    return await ctx.db.insert("supplierRates", {
      ...args,
      rateName: args.rateName?.trim() || undefined,
      supplierRateReference: args.supplierRateReference?.trim() || undefined,
      conditions: args.conditions?.trim() || undefined,
      sourceWording: args.sourceWording?.trim() || undefined,
      supplierId: product.supplierId,
      createdById: staff.user._id,
      updatedAt: new Date().toISOString(),
    });
  },
});

export const updateRate = mutation({
  args: { id: v.id("supplierRates"), ...rateFields },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const { id, ...rest } = args;
    const existing = await ctx.db.get("supplierRates", id);
    if (!existing) fail("NOT_FOUND", "Rate not found.");
    validateRate(rest);
    await ctx.db.patch("supplierRates", id, {
      ...rest,
      rateName: rest.rateName?.trim() || undefined,
      supplierRateReference: rest.supplierRateReference?.trim() || undefined,
      conditions: rest.conditions?.trim() || undefined,
      sourceWording: rest.sourceWording?.trim() || undefined,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const removeRate = mutation({
  args: { id: v.id("supplierRates") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const existing = await ctx.db.get("supplierRates", args.id);
    if (!existing) fail("NOT_FOUND", "Rate not found.");
    await ctx.db.delete("supplierRates", args.id);
    return null;
  },
});
