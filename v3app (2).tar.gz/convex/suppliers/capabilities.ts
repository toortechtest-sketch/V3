import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { fail, requireStaff } from "../lib/access";
import { serviceCategoryValidator, type ServiceCategory } from "../schema/supplierCategories";
import { serviceToLegacy } from "../schema/supplierCategories";

const CAPABILITY_LIMIT = 20;

export function capabilitiesOf(ctx: MutationCtx, supplierId: Id<"suppliers">) {
  return ctx.db
    .query("supplierCapabilities")
    .withIndex("by_supplier", (q) => q.eq("supplierId", supplierId))
    .take(CAPABILITY_LIMIT);
}

export async function requireSupplier(ctx: MutationCtx, id: Id<"suppliers">) {
  const supplier = await ctx.db.get("suppliers", id);
  if (!supplier) fail("NOT_FOUND", "Supplier not found.");
  return supplier;
}

/** Lists this supplier's capabilities, primary first. */
export const list = query({
  args: { supplierId: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const rows = await ctx.db
      .query("supplierCapabilities")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .take(CAPABILITY_LIMIT);
    return rows.sort((a, b) => Number(b.isPrimary) - Number(a.isPrimary));
  },
});

async function activeProductsIn(
  ctx: MutationCtx,
  supplierId: Id<"suppliers">,
  category: ServiceCategory,
) {
  return await ctx.db
    .query("supplierProducts")
    .withIndex("by_supplier_and_category_and_status", (q) =>
      q.eq("supplierId", supplierId).eq("category", category).eq("status", "active"),
    )
    .first();
}

/**
 * Sets the supplier's primary type, creating that capability if missing.
 * The previous primary (if any) becomes an additional service rather than
 * being removed, so its profile/product data is never dropped.
 */
export const setPrimaryType = mutation({
  args: { supplierId: v.id("suppliers"), category: serviceCategoryValidator, otherLabel: v.optional(v.string()) },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const supplier = await requireSupplier(ctx, args.supplierId);
    const existing = await capabilitiesOf(ctx, args.supplierId);
    const now = new Date().toISOString();

    for (const row of existing) {
      if (row.category === args.category && row.isPrimary) continue;
      if (row.isPrimary) await ctx.db.patch("supplierCapabilities", row._id, { isPrimary: false });
    }
    const target = existing.find((r) => r.category === args.category);
    if (target) {
      await ctx.db.patch("supplierCapabilities", target._id, {
        isPrimary: true,
        otherLabel: args.category === "other" ? args.otherLabel : undefined,
      });
    } else {
      if (existing.length >= CAPABILITY_LIMIT) {
        fail("BAD_REQUEST", `A supplier can offer up to ${CAPABILITY_LIMIT} categories.`);
      }
      await ctx.db.insert("supplierCapabilities", {
        supplierId: args.supplierId,
        category: args.category,
        otherLabel: args.category === "other" ? args.otherLabel : undefined,
        isPrimary: true,
        createdAt: now,
      });
    }
    await ctx.db.patch("suppliers", supplier._id, {
      primaryType: args.category,
      category: serviceToLegacy(args.category),
    });
    return null;
  },
});

/** Enables an additional service (capability) without changing the primary type. */
export const addCapability = mutation({
  args: { supplierId: v.id("suppliers"), category: serviceCategoryValidator, otherLabel: v.optional(v.string()) },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    await requireSupplier(ctx, args.supplierId);
    const existing = await capabilitiesOf(ctx, args.supplierId);
    if (existing.some((r) => r.category === args.category)) return null;
    if (existing.length >= CAPABILITY_LIMIT) {
      fail("BAD_REQUEST", `A supplier can offer up to ${CAPABILITY_LIMIT} categories.`);
    }
    await ctx.db.insert("supplierCapabilities", {
      supplierId: args.supplierId,
      category: args.category,
      otherLabel: args.category === "other" ? args.otherLabel : undefined,
      isPrimary: false,
      createdAt: new Date().toISOString(),
    });
    return null;
  },
});

/**
 * Removes an additional service. Blocked while active products use it, and
 * never allowed on the primary type (change the primary type instead).
 */
export const removeCapability = mutation({
  args: { supplierId: v.id("suppliers"), category: serviceCategoryValidator },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    await requireSupplier(ctx, args.supplierId);
    const row = await ctx.db
      .query("supplierCapabilities")
      .withIndex("by_supplier_and_category", (q) =>
        q.eq("supplierId", args.supplierId).eq("category", args.category),
      )
      .unique();
    if (!row) return null;
    if (row.isPrimary) {
      fail("BAD_REQUEST", "Change the primary type instead of removing it.");
    }
    const activeProduct = await activeProductsIn(ctx, args.supplierId, args.category);
    if (activeProduct) {
      fail(
        "CONFLICT",
        "This service has active products. Archive or reclassify them first.",
      );
    }
    await ctx.db.delete("supplierCapabilities", row._id);
    return null;
  },
});
