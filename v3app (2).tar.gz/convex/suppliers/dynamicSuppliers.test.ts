import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "agent");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  const supplierId = await agent.mutation(api.suppliers.create, {
    name: "Hotel Arts",
    category: "hotel",
    status: "active",
  });
  return { t, owner, agent, supplierId };
}

describe("dynamic suppliers: capabilities", () => {
  it("sets a primary type and demotes the previous one instead of deleting it", async () => {
    const { agent, supplierId } = await setup();
    await agent.mutation(api.suppliers.capabilities.setPrimaryType, {
      supplierId,
      category: "hotel",
    });
    let caps = await agent.query(api.suppliers.capabilities.list, { supplierId });
    expect(caps).toHaveLength(1);
    expect(caps[0]).toMatchObject({ category: "hotel", isPrimary: true });

    await agent.mutation(api.suppliers.capabilities.setPrimaryType, {
      supplierId,
      category: "restaurant",
    });
    caps = await agent.query(api.suppliers.capabilities.list, { supplierId });
    expect(caps).toHaveLength(2);
    const hotel = caps.find((c) => c.category === "hotel")!;
    const restaurant = caps.find((c) => c.category === "restaurant")!;
    expect(hotel.isPrimary).toBe(false);
    expect(restaurant.isPrimary).toBe(true);

    const supplier = await agent.query(api.suppliers.get, { id: supplierId });
    expect(supplier.primaryType).toBe("restaurant");
    // Legacy category mirror stays in sync for existing consumers
    expect(supplier.category).toBe("restaurant");
  });

  it("adds additional services without disturbing the primary type", async () => {
    const { agent, supplierId } = await setup();
    await agent.mutation(api.suppliers.capabilities.setPrimaryType, { supplierId, category: "hotel" });
    await agent.mutation(api.suppliers.capabilities.addCapability, { supplierId, category: "venue" });
    await agent.mutation(api.suppliers.capabilities.addCapability, { supplierId, category: "transport" });
    const caps = await agent.query(api.suppliers.capabilities.list, { supplierId });
    expect(caps.map((c) => c.category).sort()).toEqual(["hotel", "transport", "venue"]);
    expect(caps.find((c) => c.category === "hotel")!.isPrimary).toBe(true);
  });

  it("blocks removing the primary type and removing a service with active products", async () => {
    const { agent, supplierId } = await setup();
    await agent.mutation(api.suppliers.capabilities.setPrimaryType, { supplierId, category: "hotel" });
    await expect(
      agent.mutation(api.suppliers.capabilities.removeCapability, { supplierId, category: "hotel" }),
    ).rejects.toThrow(/primary type/);

    await agent.mutation(api.suppliers.capabilities.addCapability, { supplierId, category: "restaurant" });
    await agent.mutation(api.suppliers.products.create, {
      supplierId,
      category: "restaurant",
      name: "Set lunch menu",
      status: "active",
      attributes: {},
    });
    await expect(
      agent.mutation(api.suppliers.capabilities.removeCapability, { supplierId, category: "restaurant" }),
    ).rejects.toThrow(/active products/);
  });
});

describe("dynamic suppliers: products and rates", () => {
  it("never requires hotel fields for a restaurant product, and keeps categories apart", async () => {
    const { agent, supplierId } = await setup();
    await agent.mutation(api.suppliers.capabilities.setPrimaryType, { supplierId, category: "restaurant" });
    const productId = await agent.mutation(api.suppliers.products.create, {
      supplierId,
      category: "restaurant",
      name: "Gala dinner",
      status: "active",
      attributes: { mealType: "dinner", minPax: 20, roomType: "Grand Ballroom" },
    });
    const products = await agent.query(api.suppliers.products.list, { supplierId });
    const product = products.find((p) => p._id === productId)!;
    // roomType is a hotel-only field; it must never leak into a restaurant product
    expect(product.attributes).not.toHaveProperty("roomType");
    expect(product.attributes).toMatchObject({ mealType: "dinner", minPax: 20 });
  });

  it("rejects a product in a category the supplier hasn't enabled", async () => {
    const { agent, supplierId } = await setup();
    await agent.mutation(api.suppliers.capabilities.setPrimaryType, { supplierId, category: "hotel" });
    await expect(
      agent.mutation(api.suppliers.products.create, {
        supplierId,
        category: "transport",
        name: "Airport transfer",
        status: "active",
        attributes: {},
      }),
    ).rejects.toThrow(/Enable this category/);
  });

  it("supports price-on-request, zero price, and rejects negative price", async () => {
    const { agent, supplierId } = await setup();
    await agent.mutation(api.suppliers.capabilities.setPrimaryType, { supplierId, category: "hotel" });
    const productId = await agent.mutation(api.suppliers.products.create, {
      supplierId,
      category: "hotel",
      name: "Deluxe double",
      status: "active",
      attributes: {},
    });
    const onRequest = await agent.mutation(api.suppliers.products.createRate, {
      productId,
      currency: "EUR",
      pricingUnit: "room/night",
      taxMode: "unknown",
      rateBasis: "unknown",
      availabilityStatus: "on_request",
    });
    const zero = await agent.mutation(api.suppliers.products.createRate, {
      productId,
      amount: 0,
      currency: "EUR",
      pricingUnit: "room/night",
      taxMode: "unknown",
      rateBasis: "unknown",
      availabilityStatus: "on_request",
    });
    const rates = await agent.query(api.suppliers.products.listRates, { productId });
    expect(rates.find((r) => r._id === onRequest)!.amount).toBeUndefined();
    expect(rates.find((r) => r._id === zero)!.amount).toBe(0);

    await expect(
      agent.mutation(api.suppliers.products.createRate, {
        productId,
        amount: -10,
        currency: "EUR",
        pricingUnit: "room/night",
        taxMode: "unknown",
        rateBasis: "unknown",
        availabilityStatus: "on_request",
      }),
    ).rejects.toThrow(/negative/);
  });

  it("blocks deleting a product that still has rates, archiving instead", async () => {
    const { owner, agent, supplierId } = await setup();
    await agent.mutation(api.suppliers.capabilities.setPrimaryType, { supplierId, category: "hotel" });
    const productId = await agent.mutation(api.suppliers.products.create, {
      supplierId,
      category: "hotel",
      name: "Deluxe double",
      status: "active",
      attributes: {},
    });
    await agent.mutation(api.suppliers.products.createRate, {
      productId,
      amount: 180,
      currency: "EUR",
      pricingUnit: "room/night",
      taxMode: "unknown",
      rateBasis: "unknown",
      availabilityStatus: "on_request",
    });
    await expect(owner.mutation(api.suppliers.products.remove, { id: productId })).rejects.toThrow(
      /has rates/,
    );
    await agent.mutation(api.suppliers.products.archive, { id: productId });
    const products = await agent.query(api.suppliers.products.list, { supplierId });
    expect(products.find((p) => p._id === productId)!.status).toBe("archived");
  });
});

describe("dynamic suppliers: contacts", () => {
  it("allows at most one primary contact per supplier", async () => {
    const { agent, supplierId } = await setup();
    const a = await agent.mutation(api.suppliers.contacts.create, {
      supplierId,
      name: "Maria Garcia",
      isPrimary: true,
    });
    const b = await agent.mutation(api.suppliers.contacts.create, {
      supplierId,
      name: "Jordi Puig",
      isPrimary: true,
    });
    const contacts = await agent.query(api.suppliers.contacts.list, { supplierId });
    expect(contacts.find((c) => c._id === a)!.isPrimary).toBe(false);
    expect(contacts.find((c) => c._id === b)!.isPrimary).toBe(true);
  });

  it("rejects a malformed contact email", async () => {
    const { agent, supplierId } = await setup();
    await expect(
      agent.mutation(api.suppliers.contacts.create, {
        supplierId,
        name: "Maria Garcia",
        email: "not-an-email",
        isPrimary: false,
      }),
    ).rejects.toThrow(/doesn't look right/);
  });
});

describe("dynamic suppliers: access control", () => {
  it("blocks a signed-in-but-unapproved user from every endpoint", async () => {
    const t = convexTest(schema, modules);
    await as(t, "owner").mutation(api.users.updateCurrentUser, {});
    const stranger = as(t, "x");
    await stranger.mutation(api.users.updateCurrentUser, {});
    const { supplierId } = await setup();
    await expect(
      stranger.query(api.suppliers.capabilities.list, { supplierId }),
    ).rejects.toThrow(/not been approved/);
    await expect(
      stranger.mutation(api.suppliers.capabilities.setPrimaryType, { supplierId, category: "hotel" }),
    ).rejects.toThrow(/not been approved/);
  });
});
