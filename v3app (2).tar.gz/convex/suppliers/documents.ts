import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { fail, requireStaff } from "../lib/access";
import { supplierDocumentTypeValidator } from "../schema/supplierProfiles";
import { requireSupplier } from "./capabilities";

const DOCUMENT_LIMIT = 200;
const LINK_LIMIT = 50;
const MAX_SIZE_BYTES = 25 * 1024 * 1024;

export const generateUploadUrl = mutation({
  args: {},
  handler: async (ctx) => {
    await requireStaff(ctx);
    return await ctx.storage.generateUploadUrl();
  },
});

async function withUrl(ctx: { storage: { getUrl: (id: Id<"_storage">) => Promise<string | null> } }, doc: Doc<"supplierDocuments">) {
  return { ...doc, url: await ctx.storage.getUrl(doc.storageId) };
}

export const list = query({
  args: { supplierId: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const rows = await ctx.db
      .query("supplierDocuments")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .take(DOCUMENT_LIMIT);
    return await Promise.all(rows.map((d) => withUrl(ctx, d)));
  },
});

export const create = mutation({
  args: {
    supplierId: v.id("suppliers"),
    title: v.string(),
    type: supplierDocumentTypeValidator,
    storageId: v.id("_storage"),
    mimeType: v.string(),
    size: v.number(),
    validFrom: v.optional(v.string()),
    validTo: v.optional(v.string()),
    productId: v.optional(v.id("supplierProducts")),
    rateId: v.optional(v.id("supplierRates")),
  },
  handler: async (ctx, args): Promise<Id<"supplierDocuments">> => {
    const staff = await requireStaff(ctx);
    await requireSupplier(ctx, args.supplierId);
    const title = args.title.trim();
    if (!title) fail("BAD_REQUEST", "Add a document title.");
    if (args.size > MAX_SIZE_BYTES) fail("BAD_REQUEST", "That file is too large (max 25MB).");
    const existing = await ctx.db
      .query("supplierDocuments")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .take(DOCUMENT_LIMIT);
    if (existing.length >= DOCUMENT_LIMIT) {
      fail("BAD_REQUEST", `A supplier can have up to ${DOCUMENT_LIMIT} documents.`);
    }
    // Verify the product/rate (when linked) actually belongs to this supplier.
    if (args.productId) {
      const product = await ctx.db.get("supplierProducts", args.productId);
      if (!product || product.supplierId !== args.supplierId) {
        fail("BAD_REQUEST", "That product does not belong to this supplier.");
      }
    }
    if (args.rateId) {
      const rate = await ctx.db.get("supplierRates", args.rateId);
      if (!rate || rate.supplierId !== args.supplierId) {
        fail("BAD_REQUEST", "That rate does not belong to this supplier.");
      }
    }
    const documentId = await ctx.db.insert("supplierDocuments", {
      supplierId: args.supplierId,
      title,
      type: args.type,
      storageId: args.storageId,
      mimeType: args.mimeType,
      size: args.size,
      validFrom: args.validFrom,
      validTo: args.validTo,
      uploadedById: staff.user._id,
      uploadedAt: new Date().toISOString(),
    });
    if (args.productId || args.rateId) {
      await ctx.db.insert("supplierDocumentLinks", {
        documentId,
        productId: args.productId,
        rateId: args.rateId,
      });
    }
    return documentId;
  },
});

export const linksFor = query({
  args: { documentId: v.id("supplierDocuments") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    return await ctx.db
      .query("supplierDocumentLinks")
      .withIndex("by_document", (q) => q.eq("documentId", args.documentId))
      .take(LINK_LIMIT);
  },
});

export const remove = mutation({
  args: { id: v.id("supplierDocuments") },
  handler: async (ctx: MutationCtx, args) => {
    await requireStaff(ctx);
    const doc = await ctx.db.get("supplierDocuments", args.id);
    if (!doc) fail("NOT_FOUND", "Document not found.");
    const links = await ctx.db
      .query("supplierDocumentLinks")
      .withIndex("by_document", (q) => q.eq("documentId", args.id))
      .take(LINK_LIMIT);
    await Promise.all(links.map((l) => ctx.db.delete("supplierDocumentLinks", l._id)));
    await ctx.storage.delete(doc.storageId);
    await ctx.db.delete("supplierDocuments", args.id);
    return null;
  },
});
