import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { fail, requireStaff } from "../lib/access";
import { requireSupplier } from "./capabilities";

const CONTACT_LIMIT = 50;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function requireContact(ctx: MutationCtx, id: Id<"supplierContacts">) {
  const contact = await ctx.db.get("supplierContacts", id);
  if (!contact) fail("NOT_FOUND", "Contact not found.");
  return contact;
}

export const list = query({
  args: { supplierId: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const rows = await ctx.db
      .query("supplierContacts")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .take(CONTACT_LIMIT);
    return rows.sort((a, b) => Number(b.isPrimary) - Number(a.isPrimary));
  },
});

const contactFields = {
  supplierId: v.id("suppliers"),
  name: v.string(),
  role: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  preferredLanguage: v.optional(v.string()),
  isPrimary: v.boolean(),
  notes: v.optional(v.string()),
};

function cleanContact(fields: {
  name: string;
  role?: string;
  email?: string;
  phone?: string;
  preferredLanguage?: string;
  notes?: string;
}) {
  const name = fields.name.trim();
  if (!name) fail("BAD_REQUEST", "Add the contact's name.");
  const email = fields.email?.trim().toLowerCase();
  if (email && !EMAIL_PATTERN.test(email)) fail("BAD_REQUEST", "That email address doesn't look right.");
  return {
    name,
    role: fields.role?.trim() || undefined,
    email: email || undefined,
    phone: fields.phone?.trim() || undefined,
    preferredLanguage: fields.preferredLanguage?.trim() || undefined,
    notes: fields.notes?.trim() || undefined,
  };
}

/** At most one primary contact per supplier; demotes any previous one. */
async function enforceSinglePrimary(
  ctx: MutationCtx,
  supplierId: Id<"suppliers">,
  exceptId: Id<"supplierContacts"> | undefined,
) {
  const existing = await ctx.db
    .query("supplierContacts")
    .withIndex("by_supplier", (q) => q.eq("supplierId", supplierId))
    .take(CONTACT_LIMIT);
  for (const row of existing) {
    if (row.isPrimary && row._id !== exceptId) {
      await ctx.db.patch("supplierContacts", row._id, { isPrimary: false });
    }
  }
}

export const create = mutation({
  args: contactFields,
  handler: async (ctx, args): Promise<Id<"supplierContacts">> => {
    await requireStaff(ctx);
    await requireSupplier(ctx, args.supplierId);
    const existing = await ctx.db
      .query("supplierContacts")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .take(CONTACT_LIMIT);
    if (existing.length >= CONTACT_LIMIT) {
      fail("BAD_REQUEST", `A supplier can have up to ${CONTACT_LIMIT} contacts.`);
    }
    if (args.isPrimary) await enforceSinglePrimary(ctx, args.supplierId, undefined);
    const { supplierId, isPrimary, ...rest } = args;
    return await ctx.db.insert("supplierContacts", {
      supplierId,
      isPrimary,
      ...cleanContact(rest),
      updatedAt: new Date().toISOString(),
    });
  },
});

export const update = mutation({
  args: { id: v.id("supplierContacts"), ...contactFields },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const { id, supplierId, isPrimary, ...rest } = args;
    const existing = await requireContact(ctx, id);
    if (existing.supplierId !== supplierId) fail("BAD_REQUEST", "Contact does not belong to that supplier.");
    if (isPrimary) await enforceSinglePrimary(ctx, supplierId, id);
    await ctx.db.patch("supplierContacts", id, {
      isPrimary,
      ...cleanContact(rest),
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("supplierContacts") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    await requireContact(ctx, args.id);
    await ctx.db.delete("supplierContacts", args.id);
    return null;
  },
});
