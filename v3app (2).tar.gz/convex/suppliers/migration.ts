import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "../_generated/server";
import type { Doc } from "../_generated/dataModel";
import { requireManager } from "../lib/access";
import { CATEGORY_REGISTRY, legacyToService, type ServiceCategory } from "../schema/supplierCategories";
import { ROOM_TYPE_LIMIT } from "../suppliers";
import { cleanAttributes, type AttributeValue } from "./profiles";

// Bounded batch so one mutation call always finishes well inside Convex's
// per-function write limits even for hotels with many room types.
const BACKFILL_BATCH_LIMIT = 25;

export type MigrationStatus = "mapped" | "ambiguous" | "skipped";

/**
 * Decides what the backfill would do for a supplier, without writing
 * anything. "mapped" means the legacy category can become the primary type
 * cleanly. "skipped" means it's already set to that value (nothing to do).
 * "ambiguous" means a primary type was already set by hand to something
 * else — never silently overwritten.
 */
function classify(supplier: Doc<"suppliers">): {
  status: MigrationStatus;
  mappedPrimaryType: ServiceCategory;
  note?: string;
} {
  const mappedPrimaryType = legacyToService(supplier.category);
  if (supplier.primaryType === mappedPrimaryType) {
    return { status: "skipped", mappedPrimaryType, note: "Primary type already matches the legacy category." };
  }
  if (supplier.primaryType && supplier.primaryType !== mappedPrimaryType) {
    return {
      status: "ambiguous",
      mappedPrimaryType,
      note: `Primary type is already "${supplier.primaryType}", which differs from the legacy category mapping ("${mappedPrimaryType}"). Resolve by hand.`,
    };
  }
  return { status: "mapped", mappedPrimaryType };
}

/** Supplier-level capability/profile mapped from legacy category + hotel fields. Never overwrites existing rows. */
async function migrateHotelProfile(ctx: MutationCtx, supplier: Doc<"suppliers">) {
  const existing = await ctx.db
    .query("supplierProfiles")
    .withIndex("by_supplier_and_category", (q) => q.eq("supplierId", supplier._id).eq("category", "hotel"))
    .unique();
  if (existing) return;

  const raw: Record<string, AttributeValue> = {};
  if (supplier.hotelClass) raw.classification = supplier.hotelClass.replace(/-/g, " ");
  if (supplier.totalRooms !== undefined) raw.totalRooms = supplier.totalRooms;
  const facilityParts: string[] = [];
  if (supplier.meetingRooms !== undefined) facilityParts.push(`${supplier.meetingRooms} meeting rooms`);
  if (supplier.largestMeetingCapacity !== undefined) {
    facilityParts.push(`largest capacity ${supplier.largestMeetingCapacity} guests`);
  }
  if (facilityParts.length) raw.meetingFacilitiesSummary = facilityParts.join(", ");

  const entry = CATEGORY_REGISTRY.hotel;
  const attributes = cleanAttributes(entry.profileFields, raw);
  if (Object.keys(attributes).length === 0) return;
  await ctx.db.insert("supplierProfiles", {
    supplierId: supplier._id,
    category: "hotel",
    schemaVersion: entry.schemaVersion,
    attributes,
    updatedAt: new Date().toISOString(),
  });
}

/** Legacy room types become hotel products (+ a rate, when a nightly rate exists). Keyed by room name so reruns never duplicate. */
async function migrateHotelRooms(ctx: MutationCtx, supplier: Doc<"suppliers">) {
  const rooms = await ctx.db
    .query("supplierRoomTypes")
    .withIndex("by_supplier", (q) => q.eq("supplierId", supplier._id))
    .take(ROOM_TYPE_LIMIT);
  if (rooms.length === 0) return;

  const existingProducts = await ctx.db
    .query("supplierProducts")
    .withIndex("by_supplier_and_category_and_status", (q) => q.eq("supplierId", supplier._id).eq("category", "hotel"))
    .take(ROOM_TYPE_LIMIT);
  const existingNames = new Set(existingProducts.map((p) => p.name));

  const entry = CATEGORY_REGISTRY.hotel;
  for (const room of rooms) {
    if (existingNames.has(room.name)) continue;
    const raw: Record<string, AttributeValue> = {
      roomType: room.name,
      maxOccupancy: room.occupancy,
      boardBases: [room.board.replace(/-/g, " ")],
    };
    const productId = await ctx.db.insert("supplierProducts", {
      supplierId: supplier._id,
      category: "hotel",
      name: room.name,
      subtype: "room",
      status: "active",
      schemaVersion: entry.schemaVersion,
      attributes: cleanAttributes(entry.productFields, raw),
      createdById: supplier.createdById,
      updatedAt: new Date().toISOString(),
    });
    if (room.nightlyRate !== undefined) {
      await ctx.db.insert("supplierRates", {
        productId,
        supplierId: supplier._id,
        currency: supplier.currency ?? "EUR",
        amount: room.nightlyRate,
        pricingUnit: "room/night",
        taxMode: "unknown",
        rateBasis: "unknown",
        availabilityStatus: "confirmed_allocation",
        conditions: room.notes,
        createdById: supplier.createdById,
        updatedAt: new Date().toISOString(),
      });
    }
  }
}

async function applyMapping(ctx: MutationCtx, supplier: Doc<"suppliers">, mappedPrimaryType: ServiceCategory) {
  await ctx.db.patch("suppliers", supplier._id, { primaryType: mappedPrimaryType });

  const existingCap = await ctx.db
    .query("supplierCapabilities")
    .withIndex("by_supplier_and_category", (q) =>
      q.eq("supplierId", supplier._id).eq("category", mappedPrimaryType),
    )
    .unique();
  if (!existingCap) {
    await ctx.db.insert("supplierCapabilities", {
      supplierId: supplier._id,
      category: mappedPrimaryType,
      isPrimary: true,
      createdAt: new Date().toISOString(),
    });
  } else if (!existingCap.isPrimary) {
    await ctx.db.patch("supplierCapabilities", existingCap._id, { isPrimary: true });
  }

  if (mappedPrimaryType === "hotel") {
    await migrateHotelProfile(ctx, supplier);
    await migrateHotelRooms(ctx, supplier);
  }
}

/**
 * Read-only report: for each supplier, shows what the backfill would do.
 * Writes nothing, so it's safe to run repeatedly as a dry run before
 * triggering `runBackfill`.
 */
export const preview = query({
  args: { paginationOpts: paginationOptsValidator },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const page = await ctx.db.query("suppliers").withIndex("by_sort_name").paginate(args.paginationOpts);
    const logs = await Promise.all(
      page.page.map((s) =>
        ctx.db
          .query("supplierMigrationLog")
          .withIndex("by_supplier", (q) => q.eq("supplierId", s._id))
          .unique(),
      ),
    );
    return {
      ...page,
      page: page.page.map((supplier, i) => {
        const log = logs[i];
        const classified = log
          ? { status: log.status, mappedPrimaryType: log.mappedPrimaryType, note: log.note }
          : classify(supplier);
        return {
          supplierId: supplier._id,
          name: supplier.name,
          legacyCategory: supplier.category,
          alreadyProcessed: log !== null,
          status: classified.status,
          mappedPrimaryType: classified.mappedPrimaryType,
          note: classified.note,
        };
      }),
    };
  },
});

/**
 * Idempotent backfill. Processes one bounded batch of suppliers per call;
 * the client pages through with the returned cursor until `isDone`.
 *
 * `dryRun: true` only tallies what would happen — it never writes a
 * migration log row or touches supplier data, so it can be re-run freely
 * without affecting a later real run. `dryRun: false` performs the mapping
 * once per supplier and logs it, so reruns skip already-migrated suppliers
 * instead of reprocessing or duplicating their data.
 */
export const runBackfill = mutation({
  args: { paginationOpts: paginationOptsValidator, dryRun: v.boolean() },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const page = await ctx.db.query("suppliers").withIndex("by_sort_name").paginate(args.paginationOpts);
    const counts = { mapped: 0, ambiguous: 0, skipped: 0, alreadyMigrated: 0 };

    for (const supplier of page.page) {
      const existingLog = await ctx.db
        .query("supplierMigrationLog")
        .withIndex("by_supplier", (q) => q.eq("supplierId", supplier._id))
        .unique();
      if (existingLog) {
        counts.alreadyMigrated += 1;
        continue;
      }

      const classified = classify(supplier);
      counts[classified.status] += 1;
      if (args.dryRun) continue;

      if (classified.status === "mapped") {
        await applyMapping(ctx, supplier, classified.mappedPrimaryType);
      }
      await ctx.db.insert("supplierMigrationLog", {
        supplierId: supplier._id,
        status: classified.status,
        legacyCategory: supplier.category,
        mappedPrimaryType: classified.mappedPrimaryType,
        note: classified.note,
        dryRun: false,
        processedAt: new Date().toISOString(),
      });
    }

    return { ...counts, isDone: page.isDone, continueCursor: page.continueCursor };
  },
});

export const BATCH_LIMIT = BACKFILL_BATCH_LIMIT;
