import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { fail, requireStaff } from "../lib/access";
import {
  CATEGORY_REGISTRY,
  attributesValidator,
  serviceCategoryValidator,
  type FieldDef,
  type ServiceCategory,
} from "../schema/supplierCategories";
import { requireSupplier } from "./capabilities";

export type AttributeValue = string | number | boolean | string[];

/**
 * Keeps only known fields for the category, coerces each value to the
 * field's declared type, and drops unknown keys so attributes can't drift
 * from the registry that validates and renders them.
 */
export function cleanAttributes(
  fields: readonly FieldDef[],
  raw: Record<string, AttributeValue>,
): Record<string, AttributeValue> {
  const out: Record<string, AttributeValue> = {};
  for (const field of fields) {
    const value = raw[field.key];
    if (value === undefined || value === null || value === "") continue;
    if (field.type === "number") {
      const n = typeof value === "number" ? value : Number(value);
      if (!Number.isFinite(n)) continue;
      out[field.key] = n;
    } else if (field.type === "boolean") {
      out[field.key] = Boolean(value);
    } else if (field.type === "list") {
      const list = Array.isArray(value) ? value : String(value).split(",");
      const cleaned = list.map((v) => String(v).trim()).filter(Boolean);
      if (cleaned.length) out[field.key] = cleaned;
    } else if (field.type === "enum") {
      const s = String(value);
      if (field.options?.includes(s)) out[field.key] = s;
    } else {
      const s = String(value).trim();
      if (s) out[field.key] = s.slice(0, 2000);
    }
  }
  return out;
}

async function ensureCapability(
  ctx: MutationCtx,
  supplierId: Id<"suppliers">,
  category: ServiceCategory,
) {
  const row = await ctx.db
    .query("supplierCapabilities")
    .withIndex("by_supplier_and_category", (q) =>
      q.eq("supplierId", supplierId).eq("category", category),
    )
    .unique();
  if (!row) {
    fail("BAD_REQUEST", "Enable this category as a service before adding its profile.");
  }
}

export const get = query({
  args: { supplierId: v.id("suppliers"), category: serviceCategoryValidator },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    return await ctx.db
      .query("supplierProfiles")
      .withIndex("by_supplier_and_category", (q) =>
        q.eq("supplierId", args.supplierId).eq("category", args.category),
      )
      .unique();
  },
});

const PROFILE_LIMIT = 20;

/** All of a supplier's profiles at once, for the edit form. Bounded by the capability limit. */
export const listForSupplier = query({
  args: { supplierId: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    return await ctx.db
      .query("supplierProfiles")
      .withIndex("by_supplier_and_category", (q) => q.eq("supplierId", args.supplierId))
      .take(PROFILE_LIMIT);
  },
});

export const upsert = mutation({
  args: {
    supplierId: v.id("suppliers"),
    category: serviceCategoryValidator,
    attributes: attributesValidator,
  },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    await requireSupplier(ctx, args.supplierId);
    await ensureCapability(ctx, args.supplierId, args.category);
    const entry = CATEGORY_REGISTRY[args.category];
    const attributes = cleanAttributes(entry.profileFields, args.attributes as Record<string, AttributeValue>);
    const existing = await ctx.db
      .query("supplierProfiles")
      .withIndex("by_supplier_and_category", (q) =>
        q.eq("supplierId", args.supplierId).eq("category", args.category),
      )
      .unique();
    const updatedAt = new Date().toISOString();
    if (existing) {
      await ctx.db.patch("supplierProfiles", existing._id, { attributes, updatedAt });
    } else {
      await ctx.db.insert("supplierProfiles", {
        supplierId: args.supplierId,
        category: args.category,
        schemaVersion: entry.schemaVersion,
        attributes,
        updatedAt,
      });
    }
    return null;
  },
});
