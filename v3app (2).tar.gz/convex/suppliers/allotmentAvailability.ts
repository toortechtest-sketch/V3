import { v } from "convex/values";
import { query } from "../_generated/server";
import { fail, requireStaff } from "../lib/access";
import { computeSlotAvailability } from "../lib/allotmentAvailability";
import { supplierCategoryValidator } from "../schema/suppliers";
import { POOL_LIMIT, requirePool, slotsOf } from "./allotments";

/**
 * Pools a reservation could link to for a given supplier + category: enabled
 * pools with at least one enabled, non-stopped, non-released dated slot. Used
 * by the reservation dialog's "Contracted allotment" picker, which never
 * trusts this list for authorization — booking still re-validates and
 * reconciles against live capacity in the reservation mutation itself.
 */
export const listSellablePools = query({
  args: { supplierId: v.id("suppliers"), category: supplierCategoryValidator },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const pools = await ctx.db
      .query("allotmentPools")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .take(POOL_LIMIT + 1);
    const matching = pools.filter((p) => p.enabled && p.category === args.category);
    const slotLists = await Promise.all(matching.map((p) => slotsOf(ctx, p._id)));
    const now = Date.now();
    return matching
      .map((pool, i) => {
        const sellable = slotLists[i].filter((s) => s.enabled && !s.stopSale && s.releaseAt > now);
        return { ...pool, sellableSlotCount: sellable.length };
      })
      .filter((p) => p.sellableSlotCount > 0);
  },
});

/**
 * Live availability for one pool's dated slots, restricted to the service
 * keys the caller needs (a hotel's nights, or a specific departure). Returns
 * only the keys that exist, so the frontend can detect a missing date.
 */
export const previewAvailability = query({
  args: { poolId: v.id("allotmentPools"), serviceKeys: v.array(v.string()) },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const pool = await requirePool(ctx, args.poolId);
    if (args.serviceKeys.length === 0 || args.serviceKeys.length > 366) {
      fail("BAD_REQUEST", "Invalid date selection.");
    }
    const wanted = new Set(args.serviceKeys);
    const slots = (await slotsOf(ctx, pool._id)).filter((s) => wanted.has(s.serviceKey));
    const bySlot = await computeSlotAvailability(ctx, pool, slots);
    return slots.map((s) => ({
      serviceKey: s.serviceKey,
      serviceDate: s.serviceDate,
      capacity: s.capacity,
      releaseAt: s.releaseAt,
      available: bySlot.get(s._id)?.available ?? 0,
    }));
  },
});

/**
 * Every still-sellable dated departure for a "session" pool, for staff to
 * pick from. Hotel-night pools don't use this: their nights are derived from
 * the reservation's own check-in/check-out dates via `previewAvailability`.
 */
export const listSellableSlots = query({
  args: { poolId: v.id("allotmentPools") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const pool = await requirePool(ctx, args.poolId);
    const slots = await slotsOf(ctx, pool._id);
    const now = Date.now();
    const sellable = slots.filter((s) => s.enabled && !s.stopSale && s.releaseAt > now);
    const bySlot = await computeSlotAvailability(ctx, pool, sellable);
    return sellable
      .map((s) => ({
        serviceKey: s.serviceKey,
        serviceDate: s.serviceDate,
        capacity: s.capacity,
        releaseAt: s.releaseAt,
        available: bySlot.get(s._id)?.available ?? 0,
      }))
      .sort((a, b) => a.serviceDate.localeCompare(b.serviceDate));
  },
});
