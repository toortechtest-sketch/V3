import { v } from "convex/values";
import { mutation, query, type MutationCtx, type QueryCtx } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { fail, requireManager, requireStaff } from "../lib/access";
import { computeSlotAvailability } from "../lib/allotmentAvailability";
import { serviceToLegacy } from "../schema/supplierCategories";
import type { SupplierCategory } from "../schema/suppliers";

export const POOL_LIMIT = 100;
const SLOT_LIMIT = 500;
const BULK_LIMIT = 366;
const PRODUCT_LIMIT = 300;
const ROOM_TYPE_LIMIT = 100;
const MAX_SLOT_ALLOCATIONS = 2000;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

type Ctx = QueryCtx | MutationCtx;

function assertValidTimezone(timezone: string) {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: timezone });
  } catch {
    fail("BAD_REQUEST", "Use a valid IANA time zone, like Europe/Lisbon.");
  }
}

export async function requirePool(ctx: Ctx, id: Id<"allotmentPools">) {
  const pool = await ctx.db.get("allotmentPools", id);
  if (!pool) fail("NOT_FOUND", "Allotment pool not found.");
  return pool;
}

export function slotsOf(ctx: Ctx, poolId: Id<"allotmentPools">) {
  return ctx.db
    .query("allotmentSlots")
    .withIndex("by_pool_key", (q) => q.eq("poolId", poolId))
    .take(SLOT_LIMIT + 1);
}

/**
 * Finds the allotment pool (if any) for a supplier, or a specific product or
 * room type belonging to it. Callers use this to block deleting a resource
 * that still has a pool, with their own context-specific error message.
 */
export async function findPoolReferencing(
  ctx: MutationCtx,
  supplierId: Id<"suppliers">,
  match: { productId?: Id<"supplierProducts">; roomTypeId?: Id<"supplierRoomTypes"> } = {},
) {
  const pools = await ctx.db
    .query("allotmentPools")
    .withIndex("by_supplier", (q) => q.eq("supplierId", supplierId))
    .take(POOL_LIMIT + 1);
  return (
    pools.find((p) =>
      match.productId
        ? p.productId === match.productId
        : match.roomTypeId
          ? p.roomTypeId === match.roomTypeId
          : true,
    ) ?? null
  );
}

async function assertCapacityAllowed(
  ctx: MutationCtx,
  slot: { _id: Id<"allotmentSlots">; retired: number },
  newCapacity: number,
) {
  const rows = await ctx.db
    .query("allotmentAllocations")
    .withIndex("by_slot", (q) => q.eq("slotId", slot._id))
    .take(MAX_SLOT_ALLOCATIONS + 1);
  if (rows.length > MAX_SLOT_ALLOCATIONS) {
    fail("CONFLICT", "Too many reservations on this date to edit safely.");
  }
  const committed = rows.reduce((n, a) => n + a.quantity, 0);
  if (slot.retired + committed > newCapacity) {
    fail(
      "CONFLICT",
      "Capacity can't go below the units already held, confirmed, or retired.",
    );
  }
}

// --- Pools ----------------------------------------------------------------

export const listPools = query({
  args: { supplierId: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const pools = await ctx.db
      .query("allotmentPools")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .take(POOL_LIMIT);
    const resources = await Promise.all(
      pools.map((p) =>
        p.productId
          ? ctx.db.get("supplierProducts", p.productId)
          : ctx.db.get("supplierRoomTypes", p.roomTypeId!),
      ),
    );
    return pools.map((pool, i) => ({
      ...pool,
      resourceName: resources[i]?.name ?? "Unknown resource",
    }));
  },
});

/** Products and room types this supplier owns that don't already have a pool. */
export const listPoolableResources = query({
  args: { supplierId: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const [products, roomTypes, pools] = await Promise.all([
      ctx.db
        .query("supplierProducts")
        .withIndex("by_supplier_and_category_and_status", (q) =>
          q.eq("supplierId", args.supplierId),
        )
        .take(PRODUCT_LIMIT),
      ctx.db
        .query("supplierRoomTypes")
        .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
        .take(ROOM_TYPE_LIMIT),
      ctx.db
        .query("allotmentPools")
        .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
        .take(POOL_LIMIT),
    ]);
    const pooledProductIds = new Set(pools.flatMap((p) => (p.productId ? [p.productId] : [])));
    const pooledRoomTypeIds = new Set(pools.flatMap((p) => (p.roomTypeId ? [p.roomTypeId] : [])));
    return {
      products: products
        .filter((p) => p.status === "active" && !pooledProductIds.has(p._id))
        .map((p) => ({ _id: p._id, name: p.name, category: p.category })),
      roomTypes: roomTypes
        .filter((r) => !pooledRoomTypeIds.has(r._id))
        .map((r) => ({ _id: r._id, name: r.name })),
    };
  },
});

export const createPool = mutation({
  args: {
    supplierId: v.id("suppliers"),
    productId: v.optional(v.id("supplierProducts")),
    roomTypeId: v.optional(v.id("supplierRoomTypes")),
    name: v.string(),
    kind: v.union(v.literal("hotel_night"), v.literal("session")),
    unit: v.string(),
    timezone: v.string(),
    contractReference: v.string(),
  },
  handler: async (ctx, args): Promise<Id<"allotmentPools">> => {
    const staff = await requireManager(ctx);
    const supplier = await ctx.db.get("suppliers", args.supplierId);
    if (!supplier) fail("NOT_FOUND", "Supplier not found.");
    if (Boolean(args.productId) === Boolean(args.roomTypeId)) {
      fail("BAD_REQUEST", "Choose exactly one resource for this pool.");
    }
    const name = args.name.trim();
    if (!name) fail("BAD_REQUEST", "Add a name for this pool.");
    const unit = args.unit.trim();
    if (!unit) fail("BAD_REQUEST", "Add the inventory unit, like room or seat.");
    const contractReference = args.contractReference.trim();
    if (!contractReference) fail("BAD_REQUEST", "Add a contract reference.");
    assertValidTimezone(args.timezone);

    let category: SupplierCategory;
    if (args.roomTypeId) {
      const room = await ctx.db.get("supplierRoomTypes", args.roomTypeId);
      if (!room || room.supplierId !== args.supplierId) {
        fail("BAD_REQUEST", "Room type not found for this supplier.");
      }
      category = "hotel";
    } else {
      const product = await ctx.db.get("supplierProducts", args.productId!);
      if (!product || product.supplierId !== args.supplierId) {
        fail("BAD_REQUEST", "Product not found for this supplier.");
      }
      category = serviceToLegacy(product!.category);
    }
    if (args.kind === "hotel_night" && category !== "hotel") {
      fail("BAD_REQUEST", "Hotel-night pools can only use a hotel resource.");
    }

    const existingPools = await ctx.db
      .query("allotmentPools")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.supplierId))
      .take(POOL_LIMIT + 1);
    if (existingPools.length > POOL_LIMIT) {
      fail("BAD_REQUEST", `A supplier can have up to ${POOL_LIMIT} allotment pools.`);
    }
    const duplicate = existingPools.find((p) =>
      args.roomTypeId ? p.roomTypeId === args.roomTypeId : p.productId === args.productId,
    );
    if (duplicate) fail("CONFLICT", "This resource already has an allotment pool.");

    return await ctx.db.insert("allotmentPools", {
      supplierId: args.supplierId,
      productId: args.productId,
      roomTypeId: args.roomTypeId,
      name,
      kind: args.kind,
      category,
      unit,
      timezone: args.timezone,
      contractReference,
      // Always starts disabled: a manager must add dates/capacity first.
      enabled: false,
      createdById: staff.user._id,
      updatedAt: new Date().toISOString(),
    });
  },
});

export const updatePool = mutation({
  args: {
    id: v.id("allotmentPools"),
    name: v.string(),
    unit: v.string(),
    timezone: v.string(),
    contractReference: v.string(),
  },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const pool = await requirePool(ctx, args.id);
    const name = args.name.trim();
    if (!name) fail("BAD_REQUEST", "Add a name for this pool.");
    const unit = args.unit.trim();
    if (!unit) fail("BAD_REQUEST", "Add the inventory unit.");
    const contractReference = args.contractReference.trim();
    if (!contractReference) fail("BAD_REQUEST", "Add a contract reference.");
    assertValidTimezone(args.timezone);
    await ctx.db.patch("allotmentPools", pool._id, {
      name,
      unit,
      timezone: args.timezone,
      contractReference,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const setPoolEnabled = mutation({
  args: { id: v.id("allotmentPools"), enabled: v.boolean() },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const pool = await requirePool(ctx, args.id);
    await ctx.db.patch("allotmentPools", pool._id, {
      enabled: args.enabled,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const removePool = mutation({
  args: { id: v.id("allotmentPools") },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const pool = await requirePool(ctx, args.id);
    const slots = await slotsOf(ctx, pool._id);
    if (slots.length > SLOT_LIMIT) {
      fail("CONFLICT", "This pool has too many dates to delete safely. Remove dates first.");
    }
    for (const slot of slots) {
      const allocation = await ctx.db
        .query("allotmentAllocations")
        .withIndex("by_slot", (q) => q.eq("slotId", slot._id))
        .first();
      if (allocation) {
        fail(
          "CONFLICT",
          "This pool has reservations using it. Cancel or move them first.",
        );
      }
    }
    for (const slot of slots) await ctx.db.delete("allotmentSlots", slot._id);
    await ctx.db.delete("allotmentPools", pool._id);
    return null;
  },
});

// --- Slots ------------------------------------------------------------

export const listSlots = query({
  args: { poolId: v.id("allotmentPools") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const slots = await slotsOf(ctx, args.poolId);
    return slots.sort((a, b) => a.serviceKey.localeCompare(b.serviceKey));
  },
});

const slotEntryValidator = v.object({
  serviceDate: v.string(),
  serviceKey: v.string(),
  capacity: v.number(),
  releaseAt: v.number(),
  enabled: v.boolean(),
  stopSale: v.boolean(),
  replenishOnReturn: v.boolean(),
});

/** Validated bulk add/edit of dated slots, all-or-nothing in one transaction. */
export const bulkUpsertSlots = mutation({
  args: { poolId: v.id("allotmentPools"), entries: v.array(slotEntryValidator) },
  handler: async (ctx, args) => {
    const staff = await requireManager(ctx);
    const pool = await requirePool(ctx, args.poolId);
    if (args.entries.length === 0) fail("BAD_REQUEST", "Add at least one date.");
    if (args.entries.length > BULK_LIMIT) {
      fail("BAD_REQUEST", `Add up to ${BULK_LIMIT} dates at a time.`);
    }

    const seen = new Set<string>();
    for (const entry of args.entries) {
      if (!DATE_PATTERN.test(entry.serviceDate)) {
        fail("BAD_REQUEST", "Use a valid YYYY-MM-DD date.");
      }
      if (pool.kind === "hotel_night" && entry.serviceKey !== entry.serviceDate) {
        fail("BAD_REQUEST", "A hotel night's departure ID must match its date.");
      }
      if (!entry.serviceKey.trim()) fail("BAD_REQUEST", "Add a departure identifier.");
      if (seen.has(entry.serviceKey)) fail("BAD_REQUEST", "Duplicate date or departure in this batch.");
      seen.add(entry.serviceKey);
      if (!Number.isSafeInteger(entry.capacity) || entry.capacity < 0) {
        fail("BAD_REQUEST", "Capacity must be a whole number of zero or more.");
      }
      if (!Number.isSafeInteger(entry.releaseAt) || entry.releaseAt < 0) {
        fail("BAD_REQUEST", "Invalid release deadline.");
      }
    }

    const existingSlots = await slotsOf(ctx, pool._id);
    if (existingSlots.length > SLOT_LIMIT) {
      fail("CONFLICT", "This pool has too many dates to edit in bulk.");
    }
    const existingByKey = new Map(existingSlots.map((s) => [s.serviceKey, s]));
    const newCount = args.entries.filter((e) => !existingByKey.has(e.serviceKey)).length;
    if (existingSlots.length + newCount > SLOT_LIMIT) {
      fail("BAD_REQUEST", `A pool can have up to ${SLOT_LIMIT} dates.`);
    }

    // Validate every capacity reduction before writing anything, so the
    // batch is all-or-nothing.
    for (const entry of args.entries) {
      const existing = existingByKey.get(entry.serviceKey);
      if (existing && entry.capacity < existing.capacity) {
        await assertCapacityAllowed(ctx, existing, entry.capacity);
      }
    }

    const now = new Date().toISOString();
    const beforeJson = JSON.stringify(
      args.entries.map((e) => existingByKey.get(e.serviceKey) ?? null),
    );
    for (const entry of args.entries) {
      const existing = existingByKey.get(entry.serviceKey);
      if (existing) {
        await ctx.db.patch("allotmentSlots", existing._id, {
          capacity: entry.capacity,
          enabled: entry.enabled,
          stopSale: entry.stopSale,
          releaseAt: entry.releaseAt,
          replenishOnReturn: entry.replenishOnReturn,
          updatedAt: now,
        });
      } else {
        await ctx.db.insert("allotmentSlots", {
          poolId: pool._id,
          serviceDate: entry.serviceDate,
          serviceKey: entry.serviceKey,
          capacity: entry.capacity,
          retired: 0,
          enabled: entry.enabled,
          stopSale: entry.stopSale,
          releaseAt: entry.releaseAt,
          replenishOnReturn: entry.replenishOnReturn,
          updatedAt: now,
        });
      }
    }
    await ctx.db.insert("allotmentAudit", {
      poolId: pool._id,
      actorId: staff.user._id,
      source: "suppliers.allotments.bulkUpsertSlots",
      reason: `Set ${args.entries.length} date(s)`,
      beforeJson,
      afterJson: JSON.stringify(args.entries),
      createdAt: now,
    });
    return null;
  },
});

export const removeSlot = mutation({
  args: { id: v.id("allotmentSlots") },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const slot = await ctx.db.get("allotmentSlots", args.id);
    if (!slot) fail("NOT_FOUND", "Date not found.");
    const allocation = await ctx.db
      .query("allotmentAllocations")
      .withIndex("by_slot", (q) => q.eq("slotId", slot._id))
      .first();
    if (allocation) {
      fail("CONFLICT", "This date has reservations using it. Cancel or move them first.");
    }
    await ctx.db.delete("allotmentSlots", slot._id);
    return null;
  },
});

// --- Availability -------------------------------------------------------

export const availability = query({
  args: { poolId: v.id("allotmentPools") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const pool = await requirePool(ctx, args.poolId);
    const slots = await slotsOf(ctx, pool._id);
    const bySlot = await computeSlotAvailability(ctx, pool, slots);
    return slots.map((s) => ({
      ...s,
      held: bySlot.get(s._id)?.held ?? 0,
      confirmed: bySlot.get(s._id)?.confirmed ?? 0,
      available: bySlot.get(s._id)?.available ?? 0,
    }));
  },
});
