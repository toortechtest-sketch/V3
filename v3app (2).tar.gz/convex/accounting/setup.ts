import { v } from "convex/values";
import { mutation, query } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { fail, isManagerRole, requireManager, requireStaff } from "../lib/access";
import {
  findAccount,
  findSettings,
  requireDay,
  requireLedger,
  todayUtc,
} from "../lib/accountingAccess";
import { DEFAULT_CHART } from "../lib/ledger";
import { currencyValidator } from "../schema/bookings";
import { accountTypeValidator } from "../schema/accounting";

const ACCOUNT_LIMIT = 200;
const CODE_PATTERN = /^\d{4}$/;

/** Whether the ledger exists and what the caller may do with it. */
export const status = query({
  args: {},
  handler: async (ctx) => {
    const staff = await requireStaff(ctx);
    if (!isManagerRole(staff.role)) return { allowed: false as const };
    return {
      allowed: true as const,
      settings: await findSettings(ctx),
      canSetUp: staff.role === "owner",
    };
  },
});

export const setUp = mutation({
  args: { currency: currencyValidator },
  handler: async (ctx, args): Promise<Id<"accountingSettings">> => {
    const staff = await requireManager(ctx);
    if (staff.role !== "owner") {
      fail("FORBIDDEN", "Only the owner can set up company accounting.");
    }
    if (await findSettings(ctx)) {
      fail("CONFLICT", "Company accounting is already set up.");
    }
    for (const account of DEFAULT_CHART) {
      if (!(await findAccount(ctx, account.code))) {
        await ctx.db.insert("accountingAccounts", { ...account, active: true });
      }
    }
    return await ctx.db.insert("accountingSettings", {
      currency: args.currency,
      nextNumber: 1,
    });
  },
});

/**
 * Locks every day up to and including `through`. Moving forward only, so
 * reported figures for closed periods can't change.
 */
export const closePeriod = mutation({
  args: { through: v.string() },
  handler: async (ctx, args) => {
    const { staff, settings } = await requireLedger(ctx);
    requireDay(args.through, "Close date");
    if (settings.closedThrough && args.through <= settings.closedThrough) {
      fail("BAD_REQUEST", `Already closed through ${settings.closedThrough}.`);
    }
    if (args.through > todayUtc()) {
      fail("BAD_REQUEST", "You can't close a period that hasn't ended yet.");
    }
    const strandedDraft = await ctx.db
      .query("accountingDocuments")
      .withIndex("by_state_and_issue_date", (q) =>
        q.eq("state", "draft").lte("issueDate", args.through),
      )
      .first();
    if (strandedDraft) {
      fail(
        "CONFLICT",
        "Post or delete the drafts dated in this period before closing it.",
      );
    }
    await ctx.db.patch("accountingSettings", settings._id, {
      closedThrough: args.through,
      closedById: staff.user._id,
    });
    return null;
  },
});

export const listAccounts = query({
  args: {},
  handler: async (ctx) => {
    await requireLedger(ctx);
    return await ctx.db
      .query("accountingAccounts")
      .withIndex("by_code")
      .take(ACCOUNT_LIMIT);
  },
});

export const createAccount = mutation({
  args: { code: v.string(), name: v.string(), type: accountTypeValidator },
  handler: async (ctx, args): Promise<Id<"accountingAccounts">> => {
    await requireLedger(ctx);
    const code = args.code.trim();
    const name = args.name.trim();
    if (!CODE_PATTERN.test(code)) fail("BAD_REQUEST", "Use a 4 digit account code.");
    if (!name || name.length > 80) {
      fail("BAD_REQUEST", "Add an account name under 80 characters.");
    }
    if (await findAccount(ctx, code)) {
      fail("CONFLICT", `Account ${code} already exists.`);
    }
    const count = await ctx.db.query("accountingAccounts").take(ACCOUNT_LIMIT);
    if (count.length >= ACCOUNT_LIMIT) {
      fail("CONFLICT", `The chart can have up to ${ACCOUNT_LIMIT} accounts.`);
    }
    return await ctx.db.insert("accountingAccounts", {
      code,
      name,
      type: args.type,
      active: true,
      system: false,
    });
  },
});

export const setAccountActive = mutation({
  args: { id: v.id("accountingAccounts"), active: v.boolean() },
  handler: async (ctx, args) => {
    await requireLedger(ctx);
    const account = await ctx.db.get("accountingAccounts", args.id);
    if (!account) fail("NOT_FOUND", "Account not found.");
    if (account.system && !args.active) {
      fail("BAD_REQUEST", "This account is used automatically and stays on.");
    }
    await ctx.db.patch("accountingAccounts", args.id, { active: args.active });
    return null;
  },
});
