import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { fail } from "../lib/access";
import {
  findAccount,
  requireDay,
  requireLedger,
  requireOpenDate,
} from "../lib/accountingAccess";
import {
  LedgerError,
  SYSTEM_ACCOUNTS,
  documentNumber,
  isMinor,
  issueEntries,
  paymentEntries,
  reverseEntries,
  sumMinor,
  type Entry,
} from "../lib/ledger";
import {
  documentItemValidator,
  documentKindValidator,
  documentStateValidator,
  type DocumentKind,
} from "../schema/accounting";

const ITEM_LIMIT = 100;
const PAYMENT_LIMIT = 200;

const draftFields = {
  kind: documentKindValidator,
  clientId: v.optional(v.id("clients")),
  supplierId: v.optional(v.id("suppliers")),
  bookingId: v.optional(v.id("bookings")),
  accountCode: v.optional(v.string()),
  issueDate: v.string(),
  dueDate: v.string(),
  reference: v.string(),
  items: v.array(documentItemValidator),
};

type DraftInput = {
  kind: DocumentKind;
  clientId?: Id<"clients">;
  supplierId?: Id<"suppliers">;
  bookingId?: Id<"bookings">;
  accountCode?: string;
  issueDate: string;
  dueDate: string;
  reference: string;
  items: { description: string; netMinor: number; taxMinor: number }[];
};

/** Turns ledger maths errors into readable ConvexErrors. */
function ledger<T>(fn: () => T): T {
  try {
    return fn();
  } catch (error) {
    if (error instanceof LedgerError) fail("BAD_REQUEST", error.message);
    throw error;
  }
}

async function resolveParty(ctx: MutationCtx, input: DraftInput) {
  if (input.kind === "invoice") {
    if (!input.clientId || input.supplierId) {
      fail("BAD_REQUEST", "Choose the client this invoice is for.");
    }
    const client = await ctx.db.get("clients", input.clientId);
    if (!client) fail("NOT_FOUND", "Client not found.");
    return { clientId: client._id, partyName: client.name };
  }
  if (!input.supplierId || input.clientId) {
    fail("BAD_REQUEST", "Choose the supplier this bill is from.");
  }
  const supplier = await ctx.db.get("suppliers", input.supplierId);
  if (!supplier) fail("NOT_FOUND", "Supplier not found.");
  return { supplierId: supplier._id, partyName: supplier.name };
}

async function resolveAccount(ctx: MutationCtx, kind: DocumentKind, code?: string) {
  const wanted = code ?? (kind === "invoice" ? SYSTEM_ACCOUNTS.revenue : SYSTEM_ACCOUNTS.costs);
  const account = await findAccount(ctx, wanted);
  const type = kind === "invoice" ? "revenue" : "expense";
  if (!account || !account.active || account.type !== type) {
    fail("BAD_REQUEST", `Choose an active ${type} account.`);
  }
  return account.code;
}

/** Validates and normalises a draft; shared by create and update. */
async function buildDraft(
  ctx: MutationCtx,
  settings: Doc<"accountingSettings">,
  input: DraftInput,
) {
  requireOpenDate(settings, input.issueDate, "Issue date");
  requireDay(input.dueDate, "Due date");
  if (input.dueDate < input.issueDate) {
    fail("BAD_REQUEST", "The due date can't be before the issue date.");
  }
  const reference = input.reference.trim();
  if (!reference || reference.length > 200) {
    fail("BAD_REQUEST", "Add a reference under 200 characters.");
  }
  if (!input.items.length || input.items.length > ITEM_LIMIT) {
    fail("BAD_REQUEST", `Add between 1 and ${ITEM_LIMIT} lines.`);
  }
  const items = input.items.map((item) => {
    const description = item.description.trim();
    if (!description || description.length > 500) {
      fail("BAD_REQUEST", "Every line needs a description under 500 characters.");
    }
    if (!isMinor(item.netMinor) || !isMinor(item.taxMinor)) {
      fail("BAD_REQUEST", "Line amounts must be zero or more.");
    }
    return { description, netMinor: item.netMinor, taxMinor: item.taxMinor };
  });
  const netMinor = ledger(() => sumMinor(items.map((i) => i.netMinor)));
  const taxMinor = ledger(() => sumMinor(items.map((i) => i.taxMinor)));
  if (netMinor <= 0) fail("BAD_REQUEST", "The net total must be above zero.");

  let booking: Doc<"bookings"> | null = null;
  if (input.bookingId) {
    booking = await ctx.db.get("bookings", input.bookingId);
    if (!booking) fail("NOT_FOUND", "Booking not found.");
  }
  return {
    kind: input.kind,
    ...(await resolveParty(ctx, input)),
    bookingId: booking?._id,
    bookingReference: booking?.reference,
    accountCode: await resolveAccount(ctx, input.kind, input.accountCode),
    currency: settings.currency,
    issueDate: input.issueDate,
    dueDate: input.dueDate,
    reference,
    items,
    netMinor,
    taxMinor,
    totalMinor: ledger(() => sumMinor([netMinor, taxMinor])),
  };
}

async function requireDocument(ctx: MutationCtx, id: Id<"accountingDocuments">) {
  const doc = await ctx.db.get("accountingDocuments", id);
  if (!doc) fail("NOT_FOUND", "Document not found.");
  return doc;
}

async function writeJournal(
  ctx: MutationCtx,
  args: {
    documentId: Id<"accountingDocuments">;
    date: string;
    event: Doc<"accountingJournals">["event"];
    entries: Entry[];
    createdById: Id<"users">;
    reason?: string;
  },
) {
  for (const line of args.entries) {
    const account = await findAccount(ctx, line.account);
    if (!account?.active) {
      fail("CONFLICT", `Account ${line.account} is switched off. Turn it back on first.`);
    }
  }
  return await ctx.db.insert("accountingJournals", args);
}

export const createDraft = mutation({
  args: draftFields,
  handler: async (ctx, args): Promise<Id<"accountingDocuments">> => {
    const { staff, settings } = await requireLedger(ctx);
    const draft = await buildDraft(ctx, settings, args);
    return await ctx.db.insert("accountingDocuments", {
      ...draft,
      state: "draft",
      paidMinor: 0,
      createdById: staff.user._id,
      updatedAt: new Date().toISOString(),
    });
  },
});

export const updateDraft = mutation({
  args: { id: v.id("accountingDocuments"), ...draftFields },
  handler: async (ctx, args) => {
    const { settings } = await requireLedger(ctx);
    const { id, ...input } = args;
    const doc = await requireDocument(ctx, id);
    if (doc.state !== "draft") fail("CONFLICT", "Only drafts can be edited.");
    const draft = await buildDraft(ctx, settings, input);
    // replace so cleared optional links (booking, party) are removed
    await ctx.db.replace("accountingDocuments", id, {
      ...draft,
      state: "draft",
      paidMinor: 0,
      createdById: doc.createdById,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const deleteDraft = mutation({
  args: { id: v.id("accountingDocuments") },
  handler: async (ctx, args) => {
    await requireLedger(ctx);
    const doc = await requireDocument(ctx, args.id);
    if (doc.state !== "draft") {
      fail("CONFLICT", "Posted documents can't be deleted. Reverse them instead.");
    }
    await ctx.db.delete("accountingDocuments", args.id);
    return null;
  },
});

/** Posts a draft: assigns the next number and writes the issue journal. */
export const post = mutation({
  args: { id: v.id("accountingDocuments") },
  handler: async (ctx, args): Promise<string> => {
    const { staff, settings } = await requireLedger(ctx);
    const doc = await requireDocument(ctx, args.id);
    if (doc.state === "posted" && doc.number) return doc.number;
    if (doc.state !== "draft") fail("CONFLICT", "Only drafts can be posted.");
    requireOpenDate(settings, doc.issueDate, "Issue date");
    const entries = ledger(() =>
      issueEntries(doc.kind, doc.accountCode, doc.netMinor, doc.taxMinor),
    );
    await writeJournal(ctx, {
      documentId: doc._id,
      date: doc.issueDate,
      event: "issue",
      entries,
      createdById: staff.user._id,
    });
    const number = documentNumber(doc.kind, settings.nextNumber);
    await ctx.db.patch("accountingSettings", settings._id, {
      nextNumber: settings.nextNumber + 1,
    });
    await ctx.db.patch("accountingDocuments", doc._id, {
      state: "posted",
      number,
      postedById: staff.user._id,
      updatedAt: new Date().toISOString(),
    });
    return number;
  },
});

export const recordPayment = mutation({
  args: {
    id: v.id("accountingDocuments"),
    amountMinor: v.number(),
    date: v.string(),
    reference: v.string(),
  },
  handler: async (ctx, args): Promise<Id<"accountingPayments">> => {
    const { staff, settings } = await requireLedger(ctx);
    const doc = await requireDocument(ctx, args.id);
    if (doc.state !== "posted") {
      fail("CONFLICT", "Payments can only be recorded on posted documents.");
    }
    requireOpenDate(settings, args.date, "Payment date");
    if (args.date < doc.issueDate) {
      fail("BAD_REQUEST", "A payment can't be dated before the document.");
    }
    const outstanding = doc.totalMinor - doc.paidMinor;
    if (!isMinor(args.amountMinor) || args.amountMinor <= 0) {
      fail("BAD_REQUEST", "Enter a payment amount above zero.");
    }
    if (args.amountMinor > outstanding) {
      fail("BAD_REQUEST", "That's more than the amount still outstanding.");
    }
    const reference = args.reference.trim();
    if (!reference || reference.length > 200) {
      fail("BAD_REQUEST", "Add a bank reference under 200 characters.");
    }
    const existing = await ctx.db
      .query("accountingPayments")
      .withIndex("by_document", (q) => q.eq("documentId", doc._id))
      .take(PAYMENT_LIMIT);
    if (existing.length >= PAYMENT_LIMIT) {
      fail("CONFLICT", `A document can have up to ${PAYMENT_LIMIT} payments.`);
    }
    const journalId = await writeJournal(ctx, {
      documentId: doc._id,
      date: args.date,
      event: "payment",
      entries: ledger(() => paymentEntries(doc.kind, args.amountMinor)),
      createdById: staff.user._id,
    });
    const id = await ctx.db.insert("accountingPayments", {
      documentId: doc._id,
      amountMinor: args.amountMinor,
      date: args.date,
      reference,
      journalId,
      createdById: staff.user._id,
    });
    await ctx.db.patch("accountingDocuments", doc._id, {
      paidMinor: doc.paidMinor + args.amountMinor,
      updatedAt: new Date().toISOString(),
    });
    return id;
  },
});

/** Cancels a posted, unpaid document with an equal and opposite journal. */
export const reverse = mutation({
  args: { id: v.id("accountingDocuments"), date: v.string(), reason: v.string() },
  handler: async (ctx, args) => {
    const { staff, settings } = await requireLedger(ctx);
    const doc = await requireDocument(ctx, args.id);
    if (doc.state !== "posted") fail("CONFLICT", "Only posted documents can be reversed.");
    if (doc.paidMinor !== 0) {
      fail("CONFLICT", "This document has payments, so it can't be reversed.");
    }
    requireOpenDate(settings, args.date, "Reversal date");
    if (args.date < doc.issueDate) {
      fail("BAD_REQUEST", "A reversal can't be dated before the document.");
    }
    const reason = args.reason.trim();
    if (!reason || reason.length > 500) {
      fail("BAD_REQUEST", "Add a reason under 500 characters.");
    }
    const entries = ledger(() =>
      reverseEntries(issueEntries(doc.kind, doc.accountCode, doc.netMinor, doc.taxMinor)),
    );
    await writeJournal(ctx, {
      documentId: doc._id,
      date: args.date,
      event: "reversal",
      entries,
      reason,
      createdById: staff.user._id,
    });
    await ctx.db.patch("accountingDocuments", doc._id, {
      state: "reversed",
      reversalReason: reason,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    kind: v.optional(documentKindValidator),
    state: v.optional(documentStateValidator),
  },
  handler: async (ctx, args) => {
    await requireLedger(ctx);
    const { kind, state } = args;
    const docs = ctx.db.query("accountingDocuments");
    const indexed =
      kind && state
        ? docs.withIndex("by_kind_and_state_and_issue_date", (q) =>
            q.eq("kind", kind).eq("state", state),
          )
        : kind
          ? docs.withIndex("by_kind_and_issue_date", (q) => q.eq("kind", kind))
          : state
            ? docs.withIndex("by_state_and_issue_date", (q) => q.eq("state", state))
            : docs.withIndex("by_issue_date");
    return await indexed.order("desc").paginate(args.paginationOpts);
  },
});

export const get = query({
  args: { id: v.id("accountingDocuments") },
  handler: async (ctx, args) => {
    await requireLedger(ctx);
    const doc = await ctx.db.get("accountingDocuments", args.id);
    if (!doc) return null;
    const [payments, journals] = await Promise.all([
      ctx.db
        .query("accountingPayments")
        .withIndex("by_document", (q) => q.eq("documentId", doc._id))
        .take(PAYMENT_LIMIT),
      ctx.db
        .query("accountingJournals")
        .withIndex("by_document", (q) => q.eq("documentId", doc._id))
        .take(PAYMENT_LIMIT + 2),
    ]);
    return { ...doc, payments, journals };
  },
});
