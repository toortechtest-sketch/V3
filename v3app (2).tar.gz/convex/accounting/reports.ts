import { v } from "convex/values";
import { query } from "../_generated/server";
import { fail } from "../lib/access";
import { requireDay, requireLedger } from "../lib/accountingAccess";
import { naturalBalance, type BalanceRow } from "../lib/ledger";

// Reports read journals directly. Fail loudly instead of returning a silently
// incomplete total; switch to stored running balances if this is ever hit.
const JOURNAL_LIMIT = 4000;
const ACCOUNT_LIMIT = 200;

/** Debit/credit totals per account for journals dated in [from, through]. */
export const trialBalance = query({
  args: { from: v.optional(v.string()), through: v.string() },
  handler: async (ctx, args) => {
    const { settings } = await requireLedger(ctx);
    requireDay(args.through, "Report date");
    const from = args.from;
    if (from !== undefined) {
      requireDay(from, "Start date");
      if (from > args.through) fail("BAD_REQUEST", "The start date is after the end date.");
    }
    const [journals, accounts] = await Promise.all([
      ctx.db
        .query("accountingJournals")
        .withIndex("by_date", (q) =>
          from ? q.gte("date", from).lte("date", args.through) : q.lte("date", args.through),
        )
        .take(JOURNAL_LIMIT + 1),
      ctx.db.query("accountingAccounts").withIndex("by_code").take(ACCOUNT_LIMIT),
    ]);
    if (journals.length > JOURNAL_LIMIT) {
      fail("CONFLICT", "This report covers too many entries. Choose a shorter period.");
    }
    const rows = new Map<string, BalanceRow>(
      accounts.map((a) => [a.code, { code: a.code, name: a.name, type: a.type, debit: 0, credit: 0 }]),
    );
    for (const journal of journals) {
      for (const entry of journal.entries) {
        const row = rows.get(entry.account);
        if (!row) continue;
        row.debit += entry.debit;
        row.credit += entry.credit;
      }
    }
    const list = [...rows.values()];
    const total = (type: BalanceRow["type"]) =>
      list.filter((r) => r.type === type).reduce((s, r) => s + naturalBalance(r), 0);
    return {
      currency: settings.currency,
      closedThrough: settings.closedThrough ?? null,
      journalCount: journals.length,
      rows: list,
      totals: {
        debit: list.reduce((s, r) => s + r.debit, 0),
        credit: list.reduce((s, r) => s + r.credit, 0),
        revenue: total("revenue"),
        expenses: total("expense"),
      },
    };
  },
});
