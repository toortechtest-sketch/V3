import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "agent");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  await owner.mutation(api.accounting.setup.setUp, { currency: "EUR" });
  const clientId = await owner.mutation(api.clients.create, {
    kind: "company",
    name: "Acme Corp",
  });
  const supplierId = await owner.mutation(api.suppliers.create, {
    name: "Hotel Arts",
    category: "hotel",
    status: "active",
  });
  return { t, owner, agent, clientId, supplierId };
}

const INVOICE = {
  kind: "invoice" as const,
  issueDate: "2026-03-10",
  dueDate: "2026-04-10",
  reference: "Spring incentive",
  items: [{ description: "Programme", netMinor: 100_000, taxMinor: 21_000 }],
};

const balances = async (owner: Awaited<ReturnType<typeof setup>>["owner"], through: string) => {
  const report = await owner.query(api.accounting.reports.trialBalance, { through });
  return Object.fromEntries(report.rows.map((r) => [r.code, r.debit - r.credit]));
};

describe("company accounting", () => {
  it("is limited to owners and global managers", async () => {
    const { agent } = await setup();
    expect(await agent.query(api.accounting.setup.status, {})).toEqual({ allowed: false });
    await expect(
      agent.query(api.accounting.documents.list, {
        paginationOpts: { numItems: 10, cursor: null },
      }),
    ).rejects.toThrow(/permission required/);
  });

  it("posts, collects and balances an invoice", async () => {
    const { owner, clientId } = await setup();
    const id = await owner.mutation(api.accounting.documents.createDraft, {
      ...INVOICE,
      clientId,
    });
    expect(await owner.mutation(api.accounting.documents.post, { id })).toBe("INV-0000001");

    let b = await balances(owner, "2026-12-31");
    expect(b["1100"]).toBe(121_000);
    expect(b["4000"]).toBe(-100_000);
    expect(b["2100"]).toBe(-21_000);

    await owner.mutation(api.accounting.documents.recordPayment, {
      id,
      amountMinor: 121_000,
      date: "2026-03-20",
      reference: "Bank 123",
    });
    b = await balances(owner, "2026-12-31");
    expect(b["1100"]).toBe(0);
    expect(b["1000"]).toBe(121_000);

    const report = await owner.query(api.accounting.reports.trialBalance, {
      through: "2026-12-31",
    });
    expect(report.totals.debit).toBe(report.totals.credit);
    expect(report.totals.revenue).toBe(100_000);
  });

  it("refuses overpayment and reversing paid documents", async () => {
    const { owner, clientId } = await setup();
    const id = await owner.mutation(api.accounting.documents.createDraft, {
      ...INVOICE,
      clientId,
    });
    await owner.mutation(api.accounting.documents.post, { id });
    await expect(
      owner.mutation(api.accounting.documents.recordPayment, {
        id,
        amountMinor: 121_001,
        date: "2026-03-20",
        reference: "x",
      }),
    ).rejects.toThrow(/more than the amount/);
    await owner.mutation(api.accounting.documents.recordPayment, {
      id,
      amountMinor: 1_000,
      date: "2026-03-20",
      reference: "Part",
    });
    await expect(
      owner.mutation(api.accounting.documents.reverse, {
        id,
        date: "2026-03-21",
        reason: "Mistake",
      }),
    ).rejects.toThrow(/has payments/);
  });

  it("reverses an unpaid bill back to zero", async () => {
    const { owner, supplierId } = await setup();
    const id = await owner.mutation(api.accounting.documents.createDraft, {
      ...INVOICE,
      kind: "bill" as const,
      supplierId,
    });
    expect(await owner.mutation(api.accounting.documents.post, { id })).toBe("BILL-0000001");
    await owner.mutation(api.accounting.documents.reverse, {
      id,
      date: "2026-03-11",
      reason: "Duplicate",
    });
    const b = await balances(owner, "2026-12-31");
    expect(b["2000"]).toBe(0);
    expect(b["5000"]).toBe(0);
  });

  it("locks closed periods", async () => {
    const { owner, clientId } = await setup();
    const draft = await owner.mutation(api.accounting.documents.createDraft, {
      ...INVOICE,
      clientId,
    });
    await expect(
      owner.mutation(api.accounting.setup.closePeriod, { through: "2026-03-31" }),
    ).rejects.toThrow(/drafts/);
    await owner.mutation(api.accounting.documents.post, { id: draft });
    await owner.mutation(api.accounting.setup.closePeriod, { through: "2026-03-31" });
    await expect(
      owner.mutation(api.accounting.documents.createDraft, { ...INVOICE, clientId }),
    ).rejects.toThrow(/closed period/);
    await expect(
      owner.mutation(api.accounting.documents.recordPayment, {
        id: draft,
        amountMinor: 100,
        date: "2026-03-15",
        reference: "Late",
      }),
    ).rejects.toThrow(/closed period/);
  });

  it("requires the right party for each document type", async () => {
    const { owner, supplierId } = await setup();
    await expect(
      owner.mutation(api.accounting.documents.createDraft, { ...INVOICE, supplierId }),
    ).rejects.toThrow(/client/);
  });
});
