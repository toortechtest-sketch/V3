import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { fail, requireManager, requireStaff } from "./lib/access";
import { HEARTBEAT_GAP_MS, isOnline, lastSeenOf, recentSessionsOf, sumSince } from "./lib/activity";

/**
 * Called by the frontend every ~60s while a staff member has the app open and
 * the tab is visible. Extends the current session, or starts a new one after
 * a gap (tab closed, computer slept, etc). Keeps writes to one row per beat.
 */
export const heartbeat = mutation({
  args: {},
  handler: async (ctx) => {
    const { user } = await requireStaff(ctx);
    const now = new Date().toISOString();
    const [latest] = await ctx.db
      .query("activitySessions")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .order("desc")
      .take(1);

    const gapMs = latest ? new Date(now).getTime() - new Date(latest.lastSeenAt).getTime() : Infinity;
    if (latest && gapMs <= HEARTBEAT_GAP_MS) {
      await ctx.db.patch("activitySessions", latest._id, {
        lastSeenAt: now,
        durationMs: latest.durationMs + gapMs,
      });
    } else {
      await ctx.db.insert("activitySessions", { userId: user._id, startedAt: now, lastSeenAt: now, durationMs: 0 });
    }
    return null;
  },
});

const DAY_MS = 24 * 60 * 60 * 1000;
const WEEK_MS = 7 * DAY_MS;

function startOfTodayIso() {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d.toISOString();
}

function statsFor(sessions: Awaited<ReturnType<typeof recentSessionsOf>>, nowIso: string) {
  const todayStart = startOfTodayIso();
  const weekStart = new Date(new Date(nowIso).getTime() - WEEK_MS).toISOString();
  const lastSeenAt = lastSeenOf(sessions);
  return {
    todayMs: sumSince(sessions, todayStart),
    weekMs: sumSince(sessions, weekStart),
    lastSeenAt,
    online: isOnline(lastSeenAt, nowIso),
    recentSessions: sessions.slice(0, 20).map((s) => ({
      startedAt: s.startedAt,
      lastSeenAt: s.lastSeenAt,
      durationMs: s.durationMs,
    })),
  };
}

/** The caller's own usage time. Everyone can see their own. */
export const myStats = query({
  args: {},
  handler: async (ctx) => {
    const { user } = await requireStaff(ctx);
    const sessions = await recentSessionsOf(ctx, user._id);
    return statsFor(sessions, new Date().toISOString());
  },
});

/** Every staff member's usage time. Owners and global managers only. */
export const teamStats = query({
  args: {},
  handler: async (ctx) => {
    await requireManager(ctx);
    const [users, roles] = await Promise.all([
      ctx.db.query("users").take(500),
      ctx.db.query("staffRoles").take(500),
    ]);
    const roleByUser = new Map(roles.map((r) => [r.userId, r.role]));
    const staffUsers = users.filter((u) => roleByUser.has(u._id));
    const now = new Date().toISOString();

    const rows = await Promise.all(
      staffUsers.map(async (u) => {
        const sessions = await recentSessionsOf(ctx, u._id);
        const stats = statsFor(sessions, now);
        return {
          userId: u._id,
          name: u.name ?? null,
          email: u.email ?? null,
          role: roleByUser.get(u._id)!,
          todayMs: stats.todayMs,
          weekMs: stats.weekMs,
          lastSeenAt: stats.lastSeenAt,
          online: stats.online,
        };
      }),
    );
    rows.sort((a, b) => (b.lastSeenAt ?? "").localeCompare(a.lastSeenAt ?? ""));
    return rows;
  },
});

/** One staff member's detail (recent sessions). Owners and global managers only. */
export const memberStats = query({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    const target = await ctx.db.get("users", args.userId);
    if (!target) fail("NOT_FOUND", "Team member not found.");
    const sessions = await recentSessionsOf(ctx, args.userId);
    return statsFor(sessions, new Date().toISOString());
  },
});
