import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const DRAFT = {
  title: "Trip",
  type: "group" as const,
  clientName: "Acme",
  destination: "Lisbon",
  pax: 10,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "a");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  const create = (who: typeof owner, title: string, startDate: string, endDate: string) =>
    who.mutation(api.bookings.create, { ...DRAFT, title, startDate, endDate });
  return { owner, agent, create };
}

const OCT = { from: "2026-09-28", to: "2026-11-01" };
const titles = (r: { bookings: { title: string }[] }) => r.bookings.map((b) => b.title);

describe("departures.calendar", () => {
  it("includes bookings overlapping the window, including carry-overs", async () => {
    const { owner, create } = await setup();
    await create(owner, "Running", "2026-09-20", "2026-09-30");
    await create(owner, "Inside", "2026-10-10", "2026-10-12");
    await create(owner, "Ended", "2026-09-01", "2026-09-27");
    await create(owner, "Later", "2026-11-02", "2026-11-05");
    const res = await owner.query(api.departures.calendar, OCT);
    expect(titles(res)).toEqual(["Running", "Inside"]);
  });

  it("hides cancelled unless asked and respects booking visibility", async () => {
    const { owner, agent, create } = await setup();
    const id = await create(owner, "Gone", "2026-10-05", "2026-10-06");
    await owner.mutation(api.bookings.setStage, { id, stage: "cancelled" });
    await create(agent, "Agent trip", "2026-10-07", "2026-10-08");
    expect(titles(await owner.query(api.departures.calendar, OCT))).toEqual([
      "Agent trip",
    ]);
    expect(
      titles(
        await owner.query(api.departures.calendar, { ...OCT, includeCancelled: true }),
      ),
    ).toEqual(["Gone", "Agent trip"]);
    expect(
      titles(
        await agent.query(api.departures.calendar, { ...OCT, includeCancelled: true }),
      ),
    ).toEqual(["Agent trip"]);
  });

  it("rejects oversized ranges", async () => {
    const { owner } = await setup();
    await expect(
      owner.query(api.departures.calendar, { from: "2026-01-01", to: "2026-06-01" }),
    ).rejects.toThrow(/two months/);
  });
});
