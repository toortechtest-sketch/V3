import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";
import { eachDay } from "./itinerary";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-12-30",
  endDate: "2027-01-02",
  pax: 12,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  return { owner, agentA, agentB, bookingId };
}

describe("itinerary", () => {
  it("lists every day of the booking across month and year ends", () => {
    expect(eachDay("2026-12-30", "2027-01-02")).toEqual([
      "2026-12-30",
      "2026-12-31",
      "2027-01-01",
      "2027-01-02",
    ]);
  });

  it("orders timed items first, then untimed ones", async () => {
    const { agentA, bookingId } = await setup();
    const add = (title: string, startTime?: string) =>
      agentA.mutation(api.itinerary.addItem, {
        bookingId,
        date: "2026-12-31",
        type: "activity",
        title,
        startTime,
      });
    await add("Free evening");
    await add("Gala dinner", "20:00");
    await add("Walking tour", "09:30");
    const { days } = await agentA.query(api.itinerary.get, { bookingId });
    expect(days).toHaveLength(4);
    expect(days[1].items.map((i) => i.title)).toEqual([
      "Walking tour",
      "Gala dinner",
      "Free evening",
    ]);
  });

  it("rejects days outside the booking and bad times", async () => {
    const { agentA, bookingId } = await setup();
    const base = { bookingId, type: "meal" as const, title: "Lunch" };
    await expect(
      agentA.mutation(api.itinerary.addItem, { ...base, date: "2027-01-03" }),
    ).rejects.toThrow(/outside the booking/);
    await expect(
      agentA.mutation(api.itinerary.addItem, {
        ...base,
        date: "2027-01-01",
        startTime: "14:00",
        endTime: "13:00",
      }),
    ).rejects.toThrow(/after the start/);
  });

  it("hides another agent's itinerary", async () => {
    const { agentA, agentB, owner, bookingId } = await setup();
    const itemId = await agentA.mutation(api.itinerary.addItem, {
      bookingId,
      date: "2027-01-01",
      type: "transfer",
      title: "Airport pick-up",
    });
    await expect(agentB.query(api.itinerary.get, { bookingId })).rejects.toThrow(
      /Booking not found/,
    );
    await expect(
      agentB.mutation(api.itinerary.removeItem, { id: itemId }),
    ).rejects.toThrow(/Booking not found/);
    const seen = await owner.query(api.itinerary.get, { bookingId });
    expect(seen.itemCount).toBe(1);
  });

  it("keeps content on days that fall outside new booking dates", async () => {
    const { agentA, bookingId } = await setup();
    await agentA.mutation(api.itinerary.saveDay, {
      bookingId,
      date: "2027-01-02",
      title: "Departure day",
    });
    await agentA.mutation(api.bookings.update, {
      id: bookingId,
      ...BOOKING,
      endDate: "2027-01-01",
    });
    const { days } = await agentA.query(api.itinerary.get, { bookingId });
    const last = days[days.length - 1];
    expect(last).toMatchObject({ date: "2027-01-02", outsideDates: true, title: "Departure day" });
  });
});
