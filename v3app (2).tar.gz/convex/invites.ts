import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { fail, requireManager } from "./lib/access";
import { normalizeEmail } from "./lib/invites";
import { staffRoleValidator } from "./schema/staff";

const INVITE_LIMIT = 200;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export const list = query({
  args: {},
  handler: async (ctx) => {
    await requireManager(ctx);
    const invites = await ctx.db.query("staffInvites").order("desc").take(INVITE_LIMIT);
    return invites.map((i) => ({
      inviteId: i._id,
      email: i.email,
      role: i.role,
      invitedAt: i.invitedAt,
    }));
  },
});

/**
 * Pre-approves an email with a role. If that person has already signed in and
 * is waiting, they're approved immediately instead.
 */
export const create = mutation({
  args: { email: v.string(), role: staffRoleValidator },
  handler: async (ctx, args) => {
    const staff = await requireManager(ctx);
    const email = normalizeEmail(args.email);
    if (!EMAIL_PATTERN.test(email) || email.length > 254) {
      fail("BAD_REQUEST", "Enter a valid email address.");
    }
    if (args.role === "owner" && staff.role !== "owner") {
      fail("FORBIDDEN", "Only an owner can grant or change owner access.");
    }

    // Users table is small (team-sized) and emails aren't indexed there.
    const users = await ctx.db.query("users").take(500);
    const existingUser = users.find((u) => u.email && normalizeEmail(u.email) === email);
    if (existingUser) {
      const role = await ctx.db
        .query("staffRoles")
        .withIndex("by_user", (q) => q.eq("userId", existingUser._id))
        .unique();
      if (role) fail("CONFLICT", "This person already has access. Change their role in the list.");
      await ctx.db.insert("staffRoles", {
        userId: existingUser._id,
        role: args.role,
        assignedAt: new Date().toISOString(),
        assignedById: staff.user._id,
      });
      return { status: "approved" as const };
    }

    const existingInvite = await ctx.db
      .query("staffInvites")
      .withIndex("by_email", (q) => q.eq("email", email))
      .first();
    if (existingInvite?.role === "owner" && staff.role !== "owner") {
      fail("FORBIDDEN", "Only an owner can grant or change owner access.");
    }
    const invite = {
      email,
      role: args.role,
      invitedById: staff.user._id,
      invitedAt: new Date().toISOString(),
    };
    if (existingInvite) {
      await ctx.db.patch("staffInvites", existingInvite._id, invite);
    } else {
      await ctx.db.insert("staffInvites", invite);
    }
    return { status: "invited" as const };
  },
});

export const cancel = mutation({
  args: { inviteId: v.id("staffInvites") },
  handler: async (ctx, args) => {
    const staff = await requireManager(ctx);
    const invite = await ctx.db.get("staffInvites", args.inviteId);
    if (!invite) return null;
    if (invite.role === "owner" && staff.role !== "owner") {
      fail("FORBIDDEN", "Only an owner can grant or change owner access.");
    }
    await ctx.db.delete("staffInvites", invite._id);
    return null;
  },
});
