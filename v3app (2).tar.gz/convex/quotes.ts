import { v } from "convex/values";
import { mutation, query, type MutationCtx, type QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { fail, requireBooking } from "./lib/access";
import { requireFinanceUnlocked } from "./lib/financeLock";
import { priceLine, quoteTotals, type QuoteBasis } from "./lib/quoteMath";
import {
  QUOTE_SECTIONS,
  quoteBasisValidator,
  quoteSectionValidator,
  type QuoteSection,
} from "./schema/quotes";

// Keeps the reactive quote query small even for large programmes.
const LINE_LIMIT = 300;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const MAX_AMOUNT = 1e9;

const lineFields = {
  section: quoteSectionValidator,
  description: v.string(),
  supplierId: v.optional(v.id("suppliers")),
  basis: quoteBasisValidator,
  quantity: v.number(),
  times: v.number(),
  unitCost: v.number(),
  markupPercent: v.optional(v.number()),
  internalNotes: v.optional(v.string()),
};

type LineFields = {
  section: QuoteSection;
  description: string;
  supplierId?: Id<"suppliers">;
  basis: QuoteBasis;
  quantity: number;
  times: number;
  unitCost: number;
  markupPercent?: number;
  internalNotes?: string;
};

const trim = (s: string | undefined) => s?.trim() || undefined;

function checkNumber(n: number, label: string, min = 0, max = MAX_AMOUNT) {
  if (!Number.isFinite(n) || n < min || n > max) {
    fail("BAD_REQUEST", `${label} must be between ${min} and ${max.toLocaleString("en")}.`);
  }
}

async function cleanLine(ctx: MutationCtx, fields: LineFields): Promise<LineFields> {
  const cleaned: LineFields = {
    ...fields,
    description: fields.description.trim(),
    internalNotes: trim(fields.internalNotes),
    // Quantity only matters per unit; store 1 otherwise so totals stay obvious.
    quantity: fields.basis === "per_unit" ? fields.quantity : 1,
  };
  if (!cleaned.description) fail("BAD_REQUEST", "Add a description.");
  if (cleaned.description.length > 300) {
    fail("BAD_REQUEST", "Keep the description under 300 characters.");
  }
  checkNumber(cleaned.unitCost, "Unit cost");
  checkNumber(cleaned.quantity, "Quantity", 0, 100000);
  checkNumber(cleaned.times, "Times", 0, 1000);
  if (cleaned.markupPercent !== undefined) checkNumber(cleaned.markupPercent, "Markup", 0, 1000);
  if (cleaned.supplierId && !(await ctx.db.get("suppliers", cleaned.supplierId))) {
    fail("NOT_FOUND", "Supplier not found.");
  }
  return cleaned;
}

function linesOf(ctx: QueryCtx | MutationCtx, bookingId: Id<"bookings">) {
  return ctx.db
    .query("quoteLines")
    .withIndex("by_booking_and_section", (q) => q.eq("bookingId", bookingId));
}

function settingsOf(ctx: QueryCtx | MutationCtx, bookingId: Id<"bookings">) {
  return ctx.db
    .query("quotes")
    .withIndex("by_booking", (q) => q.eq("bookingId", bookingId))
    .unique();
}

async function requireLine(ctx: MutationCtx, id: Id<"quoteLines">) {
  const line = await ctx.db.get("quoteLines", id);
  if (!line) fail("NOT_FOUND", "Quote line not found.");
  const { booking } = await requireBooking(ctx, line.bookingId);
  await requireFinanceUnlocked(ctx, booking._id);
  return { line, booking };
}

async function touch(ctx: MutationCtx, booking: Doc<"bookings">) {
  await ctx.db.patch("bookings", booking._id, { updatedAt: new Date().toISOString() });
}

export const get = query({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    const [settings, lines] = await Promise.all([
      settingsOf(ctx, booking._id),
      linesOf(ctx, booking._id).take(LINE_LIMIT),
    ]);

    const supplierIds = [...new Set(lines.flatMap((l) => (l.supplierId ? [l.supplierId] : [])))];
    const suppliers = await Promise.all(supplierIds.map((id) => ctx.db.get("suppliers", id)));
    const supplierById = new Map(suppliers.flatMap((s) => (s ? [[s._id, s] as const] : [])));

    const defaultMarkup = booking.markupPercent ?? 0;
    const priced = lines.map((line) => {
      const supplier = line.supplierId ? supplierById.get(line.supplierId) : undefined;
      return {
        ...line,
        supplier: supplier
          ? { _id: supplier._id, name: supplier.name, category: supplier.category }
          : null,
        priced: priceLine(line, booking.pax, defaultMarkup),
      };
    });

    const freePlaces = settings?.freePlaces ?? 0;
    const sections = QUOTE_SECTIONS.map((section) => {
      const sectionLines = priced
        .filter((l) => l.section === section)
        .sort((a, b) => a._creationTime - b._creationTime);
      return {
        section,
        lines: sectionLines,
        totals: quoteTotals(
          sectionLines.map((l) => l.priced),
          { pax: booking.pax, freePlaces, rateToBase: booking.exchangeRateToBase },
        ),
      };
    }).filter((s) => s.lines.length > 0);

    return {
      currency: booking.currency,
      pax: booking.pax,
      rateToBase: booking.exchangeRateToBase,
      defaultMarkup,
      settings: {
        freePlaces,
        targetMarginPercent: settings?.targetMarginPercent,
        validUntil: settings?.validUntil,
        terms: settings?.terms,
      },
      sections,
      totals: quoteTotals(
        priced.map((l) => l.priced),
        { pax: booking.pax, freePlaces, rateToBase: booking.exchangeRateToBase },
      ),
      lineCount: lines.length,
      isFull: lines.length >= LINE_LIMIT,
    };
  },
});

export const saveSettings = mutation({
  args: {
    bookingId: v.id("bookings"),
    freePlaces: v.number(),
    targetMarginPercent: v.optional(v.number()),
    validUntil: v.optional(v.string()),
    terms: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    await requireFinanceUnlocked(ctx, booking._id);
    if (!Number.isInteger(args.freePlaces) || args.freePlaces < 0) {
      fail("BAD_REQUEST", "Free places must be a whole number.");
    }
    if (args.freePlaces >= booking.pax) {
      fail("BAD_REQUEST", "At least one traveller has to pay.");
    }
    if (args.targetMarginPercent !== undefined) {
      checkNumber(args.targetMarginPercent, "Target margin", 0, 99);
    }
    const validUntil = trim(args.validUntil);
    if (validUntil && !DATE_PATTERN.test(validUntil)) fail("BAD_REQUEST", "Pick a valid date.");
    const fields = {
      bookingId: booking._id,
      freePlaces: args.freePlaces,
      targetMarginPercent: args.targetMarginPercent,
      validUntil,
      terms: trim(args.terms),
      updatedAt: new Date().toISOString(),
    };
    const existing = await settingsOf(ctx, booking._id);
    if (existing) await ctx.db.replace("quotes", existing._id, fields);
    else await ctx.db.insert("quotes", fields);
    await touch(ctx, booking);
    return null;
  },
});

export const addLine = mutation({
  args: { bookingId: v.id("bookings"), ...lineFields },
  handler: async (ctx, args): Promise<Id<"quoteLines">> => {
    const { bookingId, ...rest } = args;
    const { booking } = await requireBooking(ctx, bookingId);
    await requireFinanceUnlocked(ctx, booking._id);
    const existing = await linesOf(ctx, booking._id).take(LINE_LIMIT);
    if (existing.length >= LINE_LIMIT) {
      fail("BAD_REQUEST", `A quote can hold up to ${LINE_LIMIT} lines.`);
    }
    const fields = await cleanLine(ctx, rest);
    const id = await ctx.db.insert("quoteLines", {
      bookingId: booking._id,
      ...fields,
      updatedAt: new Date().toISOString(),
    });
    await touch(ctx, booking);
    return id;
  },
});

export const updateLine = mutation({
  args: { id: v.id("quoteLines"), ...lineFields },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    const { line, booking } = await requireLine(ctx, id);
    const fields = await cleanLine(ctx, rest);
    await ctx.db.replace("quoteLines", id, {
      bookingId: line.bookingId,
      ...fields,
      updatedAt: new Date().toISOString(),
    });
    await touch(ctx, booking);
    return null;
  },
});

export const removeLine = mutation({
  args: { id: v.id("quoteLines") },
  handler: async (ctx, args) => {
    const { booking } = await requireLine(ctx, args.id);
    await ctx.db.delete("quoteLines", args.id);
    await touch(ctx, booking);
    return null;
  },
});
