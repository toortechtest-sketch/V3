import { v } from "convex/values";
import { mutation, query, type MutationCtx, type QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { fail, requireBooking } from "./lib/access";
import { requireFinanceUnlocked } from "./lib/financeLock";
import { applyChangeDecision } from "./lib/reservationChanges";
import { reconcileAllotment } from "./lib/reconcileAllotment";
import { boardValidator, supplierCategoryValidator, type BoardType, type SupplierCategory } from "./schema/suppliers";
import {
  changeFieldsValidator,
  reservationStatusValidator,
  type ReservationStatus,
} from "./schema/reservations";

// Bounds keep the reactive reservations query small.
const RESERVATION_LIMIT = 200;
const CHANGE_LIMIT = 300;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const MAX_AMOUNT = 1e9;
const REQUEST_KEY_PATTERN = /^[A-Za-z0-9_-]{1,100}$/;

const reservationFields = {
  type: supplierCategoryValidator,
  supplierId: v.optional(v.id("suppliers")),
  supplierName: v.string(),
  description: v.string(),
  startDate: v.string(),
  endDate: v.optional(v.string()),
  units: v.number(),
  unitLabel: v.optional(v.string()),
  board: v.optional(boardValidator),
  supplierRef: v.optional(v.string()),
  optionUntil: v.optional(v.string()),
  costPerUnit: v.optional(v.number()),
  sellPerUnit: v.optional(v.number()),
  notes: v.optional(v.string()),
  // Contracted-allotment link. Omitted means legacy/on-request: never treated
  // as unlimited stock once a pool link is set elsewhere.
  allotmentPoolId: v.optional(v.id("allotmentPools")),
  allotmentSessionKey: v.optional(v.string()),
  allotmentHoldUntil: v.optional(v.number()),
};

type ReservationFields = {
  type: SupplierCategory;
  supplierId?: Id<"suppliers">;
  supplierName: string;
  description: string;
  startDate: string;
  endDate?: string;
  units: number;
  unitLabel?: string;
  board?: BoardType;
  supplierRef?: string;
  optionUntil?: string;
  costPerUnit?: number;
  sellPerUnit?: number;
  notes?: string;
  allotmentPoolId?: Id<"allotmentPools">;
  allotmentSessionKey?: string;
  allotmentHoldUntil?: number;
};

type ChangeFields = Doc<"reservationChanges">["changes"];

const trim = (s: string | undefined) => s?.trim() || undefined;

function checkUnits(units: number) {
  if (!Number.isInteger(units) || units < 1 || units > 100000) {
    fail("BAD_REQUEST", "Quantity must be a whole number of at least 1.");
  }
}

function checkDates(startDate: string, endDate: string | undefined) {
  if (!DATE_PATTERN.test(startDate)) fail("BAD_REQUEST", "Pick a valid start date.");
  if (endDate !== undefined) {
    if (!DATE_PATTERN.test(endDate)) fail("BAD_REQUEST", "Pick a valid end date.");
    if (endDate < startDate) fail("BAD_REQUEST", "The end date cannot be before the start date.");
  }
}

/** Fingerprint for the idempotency ledger: cleanReservation always returns
 * fields in the same key order, so plain JSON.stringify is deterministic. */
function fingerprintOf(bookingId: Id<"bookings">, status: ReservationStatus, fields: ReservationFields): string {
  return JSON.stringify({ bookingId, status, fields });
}

async function cleanReservation(
  ctx: MutationCtx,
  fields: ReservationFields,
): Promise<ReservationFields> {
  const cleaned: ReservationFields = {
    ...fields,
    supplierName: fields.supplierName.trim(),
    description: fields.description.trim(),
    endDate: trim(fields.endDate),
    unitLabel: trim(fields.unitLabel),
    supplierRef: trim(fields.supplierRef),
    optionUntil: trim(fields.optionUntil),
    notes: trim(fields.notes),
    // Board basis only applies to hotels.
    board: fields.type === "hotel" ? fields.board : undefined,
    allotmentSessionKey: trim(fields.allotmentSessionKey),
  };
  if (!cleaned.supplierName) fail("BAD_REQUEST", "Add the supplier name.");
  if (!cleaned.description) fail("BAD_REQUEST", "Describe the service.");
  if (cleaned.supplierName.length > 200 || cleaned.description.length > 300) {
    fail("BAD_REQUEST", "Keep the supplier and description shorter.");
  }
  checkUnits(cleaned.units);
  checkDates(cleaned.startDate, cleaned.endDate);
  if (cleaned.optionUntil && !DATE_PATTERN.test(cleaned.optionUntil)) {
    fail("BAD_REQUEST", "Pick a valid option date.");
  }
  for (const [n, label] of [
    [cleaned.costPerUnit, "Cost"],
    [cleaned.sellPerUnit, "Sell price"],
  ] as const) {
    if (n !== undefined && (!Number.isFinite(n) || n < 0 || n > MAX_AMOUNT)) {
      fail("BAD_REQUEST", `${label} must be zero or more.`);
    }
  }
  if (cleaned.supplierId && !(await ctx.db.get("suppliers", cleaned.supplierId))) {
    fail("NOT_FOUND", "Supplier not found.");
  }
  if (cleaned.allotmentPoolId) {
    const pool = await ctx.db.get("allotmentPools", cleaned.allotmentPoolId);
    if (!pool) fail("NOT_FOUND", "Allotment not found.");
    if (!cleaned.supplierId || pool.supplierId !== cleaned.supplierId) {
      fail("BAD_REQUEST", "The allotment belongs to a different supplier.");
    }
    if (pool.kind === "session" && !cleaned.allotmentSessionKey) {
      fail("BAD_REQUEST", "Pick a dated departure for this allotment.");
    }
    if (cleaned.allotmentHoldUntil !== undefined) {
      if (!Number.isSafeInteger(cleaned.allotmentHoldUntil) || cleaned.allotmentHoldUntil <= Date.now()) {
        fail("BAD_REQUEST", "The hold expiry must be a valid future time.");
      }
    }
  } else {
    cleaned.allotmentSessionKey = undefined;
    cleaned.allotmentHoldUntil = undefined;
  }
  return cleaned;
}


/**
 * Confirmed reservations are held by the supplier on agreed terms, so staff
 * cannot edit them directly: every change goes through hotel approval.
 */
function requireDirectlyEditable(reservation: Doc<"reservations">) {
  if (reservation.status === "confirmed") {
    fail(
      "FORBIDDEN",
      "This reservation is confirmed. Request a change so the supplier can approve it first.",
    );
  }
}

async function requireReservation(ctx: QueryCtx | MutationCtx, id: Id<"reservations">) {
  const reservation = await ctx.db.get("reservations", id);
  if (!reservation) fail("NOT_FOUND", "Reservation not found.");
  const access = await requireBooking(ctx, reservation.bookingId);
  return { reservation, ...access };
}

function pendingChangeOf(ctx: QueryCtx | MutationCtx, reservationId: Id<"reservations">) {
  return ctx.db
    .query("reservationChanges")
    .withIndex("by_reservation_and_status", (q) =>
      q.eq("reservationId", reservationId).eq("status", "pending"),
    )
    .first();
}

export const list = query({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    const [reservations, changes] = await Promise.all([
      ctx.db
        .query("reservations")
        .withIndex("by_booking_and_start_date", (q) => q.eq("bookingId", booking._id))
        .take(RESERVATION_LIMIT),
      ctx.db
        .query("reservationChanges")
        .withIndex("by_booking", (q) => q.eq("bookingId", booking._id))
        .order("desc")
        .take(CHANGE_LIMIT),
    ]);

    const userIds = [...new Set(changes.map((c) => c.requestedById))];
    const supplierIds = [
      ...new Set(reservations.flatMap((r) => (r.supplierId ? [r.supplierId] : []))),
    ];
    const [users, suppliers] = await Promise.all([
      Promise.all(userIds.map((id) => ctx.db.get("users", id))),
      Promise.all(supplierIds.map((id) => ctx.db.get("suppliers", id))),
    ]);
    const nameById = new Map(users.flatMap((u) => (u ? [[u._id, u.name ?? "Someone"] as const] : [])));
    const supplierById = new Map(suppliers.flatMap((s) => (s ? [[s._id, s] as const] : [])));

    return {
      currency: booking.currency,
      isFull: reservations.length >= RESERVATION_LIMIT,
      reservations: reservations.map((r) => {
        const supplier = r.supplierId ? supplierById.get(r.supplierId) : undefined;
        const history = changes
          .filter((c) => c.reservationId === r._id)
          .map((c) => ({ ...c, requestedByName: nameById.get(c.requestedById) ?? "Someone" }));
        return {
          ...r,
          supplier: supplier
            ? {
                _id: supplier._id,
                name: supplier.name,
                category: supplier.category,
                email: supplier.email,
                contactName: supplier.contactName,
              }
            : null,
          pendingChange: history.find((c) => c.status === "pending") ?? null,
          history,
        };
      }),
    };
  },
});

export const create = mutation({
  args: {
    bookingId: v.id("bookings"),
    status: reservationStatusValidator,
    ...reservationFields,
    // Optional: supplied by clients that want safe retries on timeout.
    requestKey: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"reservations">> => {
    const { bookingId, status, requestKey, ...rest } = args;
    const { booking, staff } = await requireBooking(ctx, bookingId);
    const fields = await cleanReservation(ctx, rest);
    const fingerprint = fingerprintOf(bookingId, status, fields);

    if (requestKey) {
      if (!REQUEST_KEY_PATTERN.test(requestKey)) fail("BAD_REQUEST", "Invalid request key.");
      const attempt = await ctx.db
        .query("reservationCreateAttempts")
        .withIndex("by_booking_and_key", (q) => q.eq("bookingId", bookingId).eq("requestKey", requestKey))
        .unique();
      if (attempt) {
        if (attempt.fingerprint !== fingerprint) {
          fail("CONFLICT", "This request was already submitted with different details.");
        }
        return attempt.reservationId;
      }
    }

    const existing = await ctx.db
      .query("reservations")
      .withIndex("by_booking_and_start_date", (q) => q.eq("bookingId", booking._id))
      .take(RESERVATION_LIMIT);
    if (existing.length >= RESERVATION_LIMIT) {
      fail("BAD_REQUEST", `A booking can hold up to ${RESERVATION_LIMIT} reservations.`);
    }
    const reservationId = await ctx.db.insert("reservations", {
      bookingId: booking._id,
      status,
      ...fields,
      createdById: staff.user._id,
      updatedAt: new Date().toISOString(),
    });
    const reservation = await ctx.db.get("reservations", reservationId);
    if (reservation) {
      await reconcileAllotment(ctx, reservation, staff.user._id, "reservations.create");
    }
    if (requestKey) {
      await ctx.db.insert("reservationCreateAttempts", {
        bookingId,
        requestKey,
        fingerprint,
        reservationId,
        createdAt: new Date().toISOString(),
      });
    }
    return reservationId;
  },
});

export const update = mutation({
  args: { id: v.id("reservations"), ...reservationFields },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    const { reservation, staff } = await requireReservation(ctx, id);
    await requireFinanceUnlocked(ctx, reservation.bookingId);
    requireDirectlyEditable(reservation);
    const fields = await cleanReservation(ctx, rest);
    await ctx.db.replace("reservations", id, {
      bookingId: reservation.bookingId,
      status: reservation.status,
      createdById: reservation.createdById,
      ...fields,
      updatedAt: new Date().toISOString(),
    });
    const updated = await ctx.db.get("reservations", id);
    if (updated) {
      await reconcileAllotment(ctx, updated, staff.user._id, "reservations.update");
    }
    return null;
  },
});

export const setStatus = mutation({
  args: { id: v.id("reservations"), status: reservationStatusValidator },
  handler: async (ctx, args) => {
    const { reservation, staff } = await requireReservation(ctx, args.id);
    await requireFinanceUnlocked(ctx, reservation.bookingId);
    if (reservation.status === args.status) return null;
    // Leaving "confirmed" (including cancelling) needs supplier approval.
    requireDirectlyEditable(reservation);
    await ctx.db.patch("reservations", args.id, {
      status: args.status,
      updatedAt: new Date().toISOString(),
    });
    const updated = await ctx.db.get("reservations", args.id);
    if (updated) {
      await reconcileAllotment(ctx, updated, staff.user._id, "reservations.setStatus");
    }
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("reservations") },
  handler: async (ctx, args) => {
    const { reservation, staff } = await requireReservation(ctx, args.id);
    await requireFinanceUnlocked(ctx, reservation.bookingId);
    requireDirectlyEditable(reservation);
    // Release any held/confirmed inventory before deleting, so the slot stays
    // in sync (the allocation's reservation row would otherwise outlive it).
    await reconcileAllotment(ctx, reservation, staff.user._id, "reservations.remove", true);
    const changes = await ctx.db
      .query("reservationChanges")
      .withIndex("by_reservation_and_status", (q) => q.eq("reservationId", reservation._id))
      .take(CHANGE_LIMIT);
    for (const change of changes) await ctx.db.delete("reservationChanges", change._id);
    await ctx.db.delete("reservations", args.id);
    return null;
  },
});

function snapshot(reservation: Doc<"reservations">, keys: (keyof ChangeFields)[]): ChangeFields {
  const previous: ChangeFields = {};
  for (const key of keys) {
    if (key === "board") previous.board = reservation.board;
    else if (key === "units") previous.units = reservation.units;
    else previous[key] = reservation[key];
  }
  return previous;
}

/** Keeps only the fields that actually differ from the reservation. */
function diffChanges(reservation: Doc<"reservations">, input: ChangeFields): ChangeFields {
  const changes: ChangeFields = {};
  if (input.units !== undefined && input.units !== reservation.units) {
    checkUnits(input.units);
    changes.units = input.units;
  }
  const description = trim(input.description);
  if (description && description !== reservation.description) {
    if (description.length > 300) fail("BAD_REQUEST", "Keep the description under 300 characters.");
    changes.description = description;
  }
  if (input.startDate && input.startDate !== reservation.startDate) changes.startDate = input.startDate;
  if (input.endDate && input.endDate !== reservation.endDate) changes.endDate = input.endDate;
  if (input.board && input.board !== reservation.board && reservation.type === "hotel") {
    changes.board = input.board;
  }
  checkDates(changes.startDate ?? reservation.startDate, changes.endDate ?? reservation.endDate);
  return changes;
}

export const requestChange = mutation({
  args: {
    reservationId: v.id("reservations"),
    kind: v.union(v.literal("change"), v.literal("cancel")),
    changes: changeFieldsValidator,
    message: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<Id<"reservationChanges">> => {
    const { reservation, staff } = await requireReservation(ctx, args.reservationId);
    if (reservation.status !== "confirmed") {
      fail("BAD_REQUEST", "Only confirmed reservations need supplier approval. Edit it directly.");
    }
    if (await pendingChangeOf(ctx, reservation._id)) {
      fail("CONFLICT", "A change is already waiting on the supplier. Record their answer first.");
    }
    const message = trim(args.message);
    if (message && message.length > 2000) fail("BAD_REQUEST", "Keep the message under 2,000 characters.");
    const changes = args.kind === "change" ? diffChanges(reservation, args.changes) : {};
    const keys = Object.keys(changes) as (keyof ChangeFields)[];
    if (args.kind === "change" && keys.length === 0 && !message) {
      fail("BAD_REQUEST", "Change at least one detail or describe what you need.");
    }
    return await ctx.db.insert("reservationChanges", {
      bookingId: reservation.bookingId,
      reservationId: reservation._id,
      kind: args.kind,
      changes,
      previous: snapshot(reservation, keys),
      message,
      status: "pending",
      requestedById: staff.user._id,
      requestedAt: new Date().toISOString(),
    });
  },
});

async function requireChange(ctx: MutationCtx, id: Id<"reservationChanges">) {
  const change = await ctx.db.get("reservationChanges", id);
  if (!change) fail("NOT_FOUND", "Change request not found.");
  const { reservation, staff } = await requireReservation(ctx, change.reservationId);
  if (change.status !== "pending") fail("CONFLICT", "This request has already been answered.");
  return { change, reservation, staff };
}

/** Staff record the supplier's answer; approval applies the change. */
export const recordResponse = mutation({
  args: {
    changeId: v.id("reservationChanges"),
    decision: v.union(v.literal("approved"), v.literal("declined")),
    responseNote: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const { change, staff } = await requireChange(ctx, args.changeId);
    await applyChangeDecision(ctx, change, args.decision, trim(args.responseNote), staff.user._id);
    return null;
  },
});

export const withdrawChange = mutation({
  args: { changeId: v.id("reservationChanges") },
  handler: async (ctx, args) => {
    const { change, staff } = await requireChange(ctx, args.changeId);
    await ctx.db.patch("reservationChanges", change._id, {
      status: "withdrawn",
      respondedAt: new Date().toISOString(),
      recordedById: staff.user._id,
    });
    return null;
  },
});

export type { ReservationStatus };
