/* eslint-disable */
/**
 * Generated `api` utility.
 *
 * THIS CODE IS AUTOMATICALLY GENERATED.
 *
 * To regenerate, run `npx convex dev`.
 * @module
 */

import type * as accounting_documents from "../accounting/documents.js";
import type * as accounting_reports from "../accounting/reports.js";
import type * as accounting_setup from "../accounting/setup.js";
import type * as activity from "../activity.js";
import type * as ai_access from "../ai/access.js";
import type * as ai_extract from "../ai/extract.js";
import type * as ai_gateway from "../ai/gateway.js";
import type * as ai_limits from "../ai/limits.js";
import type * as ai_normalize from "../ai/normalize.js";
import type * as ai_save from "../ai/save.js";
import type * as ai_schemas from "../ai/schemas.js";
import type * as ai_web from "../ai/web.js";
import type * as analytics from "../analytics.js";
import type * as bookings from "../bookings.js";
import type * as clientLinks from "../clientLinks.js";
import type * as clients from "../clients.js";
import type * as connectedApps from "../connectedApps.js";
import type * as departures from "../departures.js";
import type * as finance from "../finance.js";
import type * as financeOverview from "../financeOverview.js";
import type * as gmail_client from "../gmail/client.js";
import type * as gmail_config from "../gmail/config.js";
import type * as gmail_crypto from "../gmail/crypto.js";
import type * as gmail_mailbox from "../gmail/mailbox.js";
import type * as gmail_mime from "../gmail/mime.js";
import type * as gmail_oauth from "../gmail/oauth.js";
import type * as gmail_store from "../gmail/store.js";
import type * as http from "../http.js";
import type * as invites from "../invites.js";
import type * as itinerary from "../itinerary.js";
import type * as lib_access from "../lib/access.js";
import type * as lib_accountingAccess from "../lib/accountingAccess.js";
import type * as lib_activity from "../lib/activity.js";
import type * as lib_allotmentAvailability from "../lib/allotmentAvailability.js";
import type * as lib_allotmentEngine from "../lib/allotmentEngine.js";
import type * as lib_financeData from "../lib/financeData.js";
import type * as lib_financeLock from "../lib/financeLock.js";
import type * as lib_financeMath from "../lib/financeMath.js";
import type * as lib_invites from "../lib/invites.js";
import type * as lib_ledger from "../lib/ledger.js";
import type * as lib_owners from "../lib/owners.js";
import type * as lib_quoteMath from "../lib/quoteMath.js";
import type * as lib_reconcileAllotment from "../lib/reconcileAllotment.js";
import type * as lib_reservationChanges from "../lib/reservationChanges.js";
import type * as quotes from "../quotes.js";
import type * as reservations from "../reservations.js";
import type * as schema_accounting from "../schema/accounting.js";
import type * as schema_activity from "../schema/activity.js";
import type * as schema_allotments from "../schema/allotments.js";
import type * as schema_bookings from "../schema/bookings.js";
import type * as schema_clients from "../schema/clients.js";
import type * as schema_connectedApps from "../schema/connectedApps.js";
import type * as schema_finance from "../schema/finance.js";
import type * as schema_gmail from "../schema/gmail.js";
import type * as schema_itinerary from "../schema/itinerary.js";
import type * as schema_quotes from "../schema/quotes.js";
import type * as schema_reservations from "../schema/reservations.js";
import type * as schema_shareLinks from "../schema/shareLinks.js";
import type * as schema_staff from "../schema/staff.js";
import type * as schema_supplierCategories from "../schema/supplierCategories.js";
import type * as schema_supplierProfiles from "../schema/supplierProfiles.js";
import type * as schema_suppliers from "../schema/suppliers.js";
import type * as schema_tasks from "../schema/tasks.js";
import type * as schema_travellers from "../schema/travellers.js";
import type * as shareLinks from "../shareLinks.js";
import type * as staff from "../staff.js";
import type * as suppliers from "../suppliers.js";
import type * as suppliers_allotmentAvailability from "../suppliers/allotmentAvailability.js";
import type * as suppliers_allotments from "../suppliers/allotments.js";
import type * as suppliers_capabilities from "../suppliers/capabilities.js";
import type * as suppliers_contacts from "../suppliers/contacts.js";
import type * as suppliers_documents from "../suppliers/documents.js";
import type * as suppliers_migration from "../suppliers/migration.js";
import type * as suppliers_products from "../suppliers/products.js";
import type * as suppliers_profiles from "../suppliers/profiles.js";
import type * as tasks from "../tasks.js";
import type * as today from "../today.js";
import type * as travellers from "../travellers.js";
import type * as users from "../users.js";

import type {
  ApiFromModules,
  FilterApi,
  FunctionReference,
} from "convex/server";

declare const fullApi: ApiFromModules<{
  "accounting/documents": typeof accounting_documents;
  "accounting/reports": typeof accounting_reports;
  "accounting/setup": typeof accounting_setup;
  activity: typeof activity;
  "ai/access": typeof ai_access;
  "ai/extract": typeof ai_extract;
  "ai/gateway": typeof ai_gateway;
  "ai/limits": typeof ai_limits;
  "ai/normalize": typeof ai_normalize;
  "ai/save": typeof ai_save;
  "ai/schemas": typeof ai_schemas;
  "ai/web": typeof ai_web;
  analytics: typeof analytics;
  bookings: typeof bookings;
  clientLinks: typeof clientLinks;
  clients: typeof clients;
  connectedApps: typeof connectedApps;
  departures: typeof departures;
  finance: typeof finance;
  financeOverview: typeof financeOverview;
  "gmail/client": typeof gmail_client;
  "gmail/config": typeof gmail_config;
  "gmail/crypto": typeof gmail_crypto;
  "gmail/mailbox": typeof gmail_mailbox;
  "gmail/mime": typeof gmail_mime;
  "gmail/oauth": typeof gmail_oauth;
  "gmail/store": typeof gmail_store;
  http: typeof http;
  invites: typeof invites;
  itinerary: typeof itinerary;
  "lib/access": typeof lib_access;
  "lib/accountingAccess": typeof lib_accountingAccess;
  "lib/activity": typeof lib_activity;
  "lib/allotmentAvailability": typeof lib_allotmentAvailability;
  "lib/allotmentEngine": typeof lib_allotmentEngine;
  "lib/financeData": typeof lib_financeData;
  "lib/financeLock": typeof lib_financeLock;
  "lib/financeMath": typeof lib_financeMath;
  "lib/invites": typeof lib_invites;
  "lib/ledger": typeof lib_ledger;
  "lib/owners": typeof lib_owners;
  "lib/quoteMath": typeof lib_quoteMath;
  "lib/reconcileAllotment": typeof lib_reconcileAllotment;
  "lib/reservationChanges": typeof lib_reservationChanges;
  quotes: typeof quotes;
  reservations: typeof reservations;
  "schema/accounting": typeof schema_accounting;
  "schema/activity": typeof schema_activity;
  "schema/allotments": typeof schema_allotments;
  "schema/bookings": typeof schema_bookings;
  "schema/clients": typeof schema_clients;
  "schema/connectedApps": typeof schema_connectedApps;
  "schema/finance": typeof schema_finance;
  "schema/gmail": typeof schema_gmail;
  "schema/itinerary": typeof schema_itinerary;
  "schema/quotes": typeof schema_quotes;
  "schema/reservations": typeof schema_reservations;
  "schema/shareLinks": typeof schema_shareLinks;
  "schema/staff": typeof schema_staff;
  "schema/supplierCategories": typeof schema_supplierCategories;
  "schema/supplierProfiles": typeof schema_supplierProfiles;
  "schema/suppliers": typeof schema_suppliers;
  "schema/tasks": typeof schema_tasks;
  "schema/travellers": typeof schema_travellers;
  shareLinks: typeof shareLinks;
  staff: typeof staff;
  suppliers: typeof suppliers;
  "suppliers/allotmentAvailability": typeof suppliers_allotmentAvailability;
  "suppliers/allotments": typeof suppliers_allotments;
  "suppliers/capabilities": typeof suppliers_capabilities;
  "suppliers/contacts": typeof suppliers_contacts;
  "suppliers/documents": typeof suppliers_documents;
  "suppliers/migration": typeof suppliers_migration;
  "suppliers/products": typeof suppliers_products;
  "suppliers/profiles": typeof suppliers_profiles;
  tasks: typeof tasks;
  today: typeof today;
  travellers: typeof travellers;
  users: typeof users;
}>;

/**
 * A utility for referencing Convex functions in your app's public API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = api.myModule.myFunction;
 * ```
 */
export declare const api: FilterApi<
  typeof fullApi,
  FunctionReference<any, "public">
>;

/**
 * A utility for referencing Convex functions in your app's internal API.
 *
 * Usage:
 * ```js
 * const myFunctionReference = internal.myModule.myFunction;
 * ```
 */
export declare const internal: FilterApi<
  typeof fullApi,
  FunctionReference<any, "internal">
>;

export declare const components: {};
