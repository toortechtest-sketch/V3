import { convexTest } from "convex-test";
import { afterEach, describe, expect, it, vi } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-11-02",
  endDate: "2026-11-04",
  pax: 10,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
  markupPercent: 25,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  await agentA.mutation(api.quotes.addLine, {
    bookingId,
    section: "accommodation",
    description: "Hotel Arts, 2 nights",
    basis: "per_person",
    quantity: 1,
    times: 2,
    unitCost: 100,
    internalNotes: "SECRET-COST-NOTE",
  });
  await agentA.mutation(api.itinerary.addItem, {
    bookingId,
    date: "2026-11-02",
    type: "meal",
    title: "Welcome dinner",
    internalNotes: "SECRET-ITEM-NOTE",
  });
  return { t, owner, agentA, agentB, bookingId };
}

afterEach(() => {
  vi.useRealTimers();
});

describe("client links", () => {
  it("shows the offer at selling price without leaking costs or notes", async () => {
    const { t, agentA, bookingId } = await setup();
    const { token } = await agentA.action(api.shareLinks.create, { bookingId, kind: "offer", days: 14 });
    expect(token).toMatch(/^[0-9a-f]{48}$/);

    const view = await t.query(api.clientLinks.view, { token });
    if (view.status !== "ok" || view.kind !== "offer") throw new Error("expected offer");
    // 10 pax × 2 × 100 = 2000 cost, + 25% = 2500
    expect(view.offer.total).toBe(2500);
    expect(view.offer.perPayingGuest).toBe(250);
    expect(view.days[0].items[0].title).toBe("Welcome dinner");

    const json = JSON.stringify(view);
    for (const secret of ["SECRET", "unitCost", "markup", "margin", "cost", bookingId]) {
      expect(json).not.toContain(secret);
    }
  });

  it("rejects unknown, revoked and expired tokens", async () => {
    const { t, agentA, bookingId } = await setup();
    expect((await t.query(api.clientLinks.view, { token: "0".repeat(48) })).status).toBe("unavailable");
    expect((await t.query(api.clientLinks.view, { token: bookingId })).status).toBe("unavailable");

    const { token } = await agentA.action(api.shareLinks.create, { bookingId, kind: "itinerary", days: 7 });
    const [link] = await agentA.query(api.shareLinks.list, { bookingId });
    await agentA.mutation(api.shareLinks.revoke, { id: link._id });
    expect((await t.query(api.clientLinks.view, { token })).status).toBe("unavailable");

    const fresh = await agentA.action(api.shareLinks.create, { bookingId, kind: "itinerary", days: 1 });
    expect((await t.query(api.clientLinks.view, { token: fresh.token })).status).toBe("ok");
    vi.useFakeTimers();
    vi.setSystemTime(Date.now() + 2 * 24 * 60 * 60 * 1000);
    expect((await t.query(api.clientLinks.view, { token: fresh.token })).status).toBe("unavailable");
  });

  it("only lets staff with booking access create or manage links", async () => {
    const { t, agentA, agentB, owner, bookingId } = await setup();
    await expect(
      agentB.action(api.shareLinks.create, { bookingId, kind: "offer", days: 7 }),
    ).rejects.toThrow(/not found/i);
    await expect(
      t.action(api.shareLinks.create, { bookingId, kind: "offer", days: 7 }),
    ).rejects.toThrow(/signed in/i);
    await expect(
      agentA.action(api.shareLinks.create, { bookingId, kind: "offer", days: 999 }),
    ).rejects.toThrow(/between/i);

    await agentA.action(api.shareLinks.create, { bookingId, kind: "offer", days: 7 });
    const [link] = await owner.query(api.shareLinks.list, { bookingId });
    await expect(agentB.mutation(api.shareLinks.revoke, { id: link._id })).rejects.toThrow(/not found/i);
  });

  it("records one client response per offer link and counts views", async () => {
    const { t, agentA, bookingId } = await setup();
    const { token } = await agentA.action(api.shareLinks.create, { bookingId, kind: "offer", days: 7 });
    await t.mutation(api.clientLinks.recordView, { token });

    await expect(
      t.mutation(api.clientLinks.respondToOffer, { token, decision: "accepted", name: "  " }),
    ).rejects.toThrow(/name/i);
    await t.mutation(api.clientLinks.respondToOffer, {
      token,
      decision: "accepted",
      name: "Jane Client",
      message: "Looks great",
    });
    await expect(
      t.mutation(api.clientLinks.respondToOffer, { token, decision: "declined", name: "Jane" }),
    ).rejects.toThrow(/already/i);

    const [link] = await agentA.query(api.shareLinks.list, { bookingId });
    expect(link.viewCount).toBe(1);
    expect(link.response).toMatchObject({ decision: "accepted", name: "Jane Client" });

    const itinerary = await agentA.action(api.shareLinks.create, { bookingId, kind: "itinerary", days: 7 });
    await expect(
      t.mutation(api.clientLinks.respondToOffer, { token: itinerary.token, decision: "accepted", name: "X" }),
    ).rejects.toThrow(/no longer available/i);
  });
});
