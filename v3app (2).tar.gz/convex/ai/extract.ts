import { v } from "convex/values";
import { action } from "../_generated/server";
import { internal } from "../_generated/api";
import { fail } from "../lib/access";
import { extractStructured } from "./gateway";
import { MAX_IMPORT_TEXT } from "./limits";
import {
  normalizeClients,
  normalizeItinerary,
  normalizeSuppliers,
  type ClientDraft,
  type ItineraryDraftDay,
  type ItineraryDraftItem,
  type SupplierDraft,
} from "./normalize";
import {
  clientsResultSchema,
  itineraryResultSchema,
  suppliersResultSchema,
} from "./schemas";
import { readWebsite } from "./web";

/**
 * AI only drafts. Nothing here writes to the database: staff review the
 * drafts and then call `ai/save` to create what they approved.
 */
const BASE =
  "You extract data for a group travel and events agency's staff workspace. " +
  "Only use facts present in the source. Use null for anything not stated; never invent " +
  "emails, phone numbers, prices or addresses. Keep notes short and factual.";

const source = v.union(
  v.object({ kind: v.literal("text"), text: v.string() }),
  v.object({ kind: v.literal("website"), url: v.string() }),
);

type Source = { kind: "text"; text: string } | { kind: "website"; url: string };

function checkText(raw: string): string {
  const text = raw.trim();
  if (text.length < 3) fail("BAD_REQUEST", "Paste some text to import from.");
  if (text.length > MAX_IMPORT_TEXT) {
    fail("BAD_REQUEST", "That's a lot of text. Import it in smaller parts.");
  }
  return text;
}

async function readSource(
  src: Source,
  subpages: RegExp,
): Promise<{ text: string; url?: string }> {
  if (src.kind === "website") return await readWebsite(src.url, subpages);
  return { text: checkText(src.text) };
}

export const extractClients = action({
  args: { source },
  handler: async (
    ctx,
    args,
  ): Promise<{ drafts: ClientDraft[]; existing: string[] }> => {
    await ctx.runQuery(internal.ai.access.staff, {});
    const { text: content, url } = await readSource(args.source, /contact|about|team|company/i);
    const fromWebsite = url !== undefined;
    const result = await extractStructured({
      name: "clients",
      schema: clientsResultSchema,
      system:
        BASE +
        " Extract the agency's clients: companies and individual people who book trips or events " +
        "(not hotels or suppliers). kind is 'company' for organisations and 'individual' for people. " +
        "For a company, contactName is its main contact. For a person who works at a company, set " +
        "companyName to that company and also list the company itself as its own record. " +
        (fromWebsite
          ? "This text comes from one company's website: return exactly that one company."
          : "Return every distinct client mentioned."),
      content,
    });
    const drafts = normalizeClients(result.clients);
    if (drafts.length === 0) fail("BAD_REQUEST", "No clients found in that text.");
    const existing = await ctx.runQuery(internal.ai.access.existingNames, {
      table: "clients",
      names: drafts.map((d) => d.name),
    });
    return { drafts, existing };
  },
});

export const extractSuppliers = action({
  args: { source },
  handler: async (
    ctx,
    args,
  ): Promise<{ drafts: SupplierDraft[]; existing: string[] }> => {
    await ctx.runQuery(internal.ai.access.staff, {});
    const { text: content, url: website } = await readSource(
      args.source,
      /room|accommodation|suite|contact|about|meeting|event/i,
    );
    const result = await extractStructured({
      name: "suppliers",
      schema: suppliersResultSchema,
      system:
        BASE +
        " Extract suppliers the agency books with: hotels, venues, transfer/coach companies, " +
        "restaurants, activities, airlines and others. Infer category from the services offered. " +
        "For hotels also give hotelClass, totalRooms, meetingRooms, largestMeetingCapacity and every " +
        "distinct room type (occupancy = guests it sleeps, board basis, nightly rate only if a price " +
        "is stated). Non-hotels have an empty roomTypes list and null hotel fields. currency is the " +
        "ISO code of prices shown, if any. " +
        (website
          ? "This text comes from one supplier's website: return exactly that one supplier."
          : "Return every distinct supplier mentioned."),
      content,
    });
    const drafts = normalizeSuppliers(result.suppliers, website);
    if (drafts.length === 0) fail("BAD_REQUEST", "No suppliers found in that text.");
    const existing = await ctx.runQuery(internal.ai.access.existingNames, {
      table: "suppliers",
      names: drafts.map((d) => d.name),
    });
    return { drafts, existing };
  },
});

export const extractItinerary = action({
  args: { bookingId: v.id("bookings"), text: v.string() },
  handler: async (
    ctx,
    args,
  ): Promise<{ days: ItineraryDraftDay[]; items: ItineraryDraftItem[] }> => {
    const booking = await ctx.runQuery(internal.ai.access.bookingDays, {
      bookingId: args.bookingId,
    });
    const content = checkText(args.text);
    const dayList = booking.days.map((d, i) => `Day ${i + 1} = ${d}`).join(", ");
    const result = await extractStructured({
      name: "itinerary",
      schema: itineraryResultSchema,
      system:
        BASE +
        ` Extract a day-by-day programme for the booking "${booking.title}" in ${booking.destination}. ` +
        `The booking runs ${booking.days.length} days: ${dayList}. Map every item to a dayNumber ` +
        "(1-based) using dates or 'Day N' in the text; if the text uses weekdays or dates, match them " +
        "to this list. Times are 24-hour HH:MM local time or null. Item types: arrival, departure, " +
        "transfer, hotel (check-in/out), meal, activity, meeting, flight, free-time, other. The " +
        "description is client-facing. Only include a day entry when the text gives that day a " +
        "headline or notes.",
      content,
    });
    const draft = normalizeItinerary(result, booking.days);
    if (draft.items.length === 0 && draft.days.length === 0) {
      fail("BAD_REQUEST", "No itinerary found in that text.");
    }
    return draft;
  },
});
