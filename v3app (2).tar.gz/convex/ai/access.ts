import { v } from "convex/values";
import { internalQuery } from "../_generated/server";
import { requireBooking, requireStaff } from "../lib/access";
import { eachDay } from "../itinerary";

/** Actions have no database, so they check the caller through these. */
export const staff = internalQuery({
  args: {},
  handler: async (ctx) => {
    await requireStaff(ctx);
    return null;
  },
});

/** Booking days for itinerary import, after checking booking access. */
export const bookingDays = internalQuery({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    return {
      title: booking.title,
      destination: booking.destination,
      days: eachDay(booking.startDate, booking.endDate),
    };
  },
});

/** Lower-cased names that already exist, so the review can flag duplicates. */
export const existingNames = internalQuery({
  args: {
    table: v.union(v.literal("clients"), v.literal("suppliers")),
    names: v.array(v.string()),
  },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const unique = [...new Set(args.names.map((n) => n.trim().toLowerCase()))].slice(0, 100);
    const found = await Promise.all(
      unique.map(async (sortName) => {
        const row =
          args.table === "clients"
            ? await ctx.db
                .query("clients")
                .withIndex("by_sort_name", (q) => q.eq("sortName", sortName))
                .first()
            : await ctx.db
                .query("suppliers")
                .withIndex("by_sort_name", (q) => q.eq("sortName", sortName))
                .first();
        return row ? sortName : null;
      }),
    );
    return found.filter((n): n is string => n !== null);
  },
});
