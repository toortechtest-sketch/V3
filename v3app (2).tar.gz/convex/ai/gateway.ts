import { z } from "zod";
import { fail } from "../lib/access";

const GATEWAY_URL = "https://ai-gateway.hercules.app/v1/chat/completions";
const MODEL = "openai/gpt-6-luna";

const completionSchema = z.object({
  choices: z
    .array(
      z.object({
        message: z.object({ content: z.string().nullable() }),
      }),
    )
    .min(1),
});

const AI_DOWN = "The AI service didn't respond. Please try again in a moment.";

/**
 * Asks the Hercules AI Gateway for JSON matching `schema` (strict structured
 * output) and validates the reply again here, so callers get typed data.
 * Plain fetch keeps this in the default runtime without the OpenAI SDK.
 */
export async function extractStructured<T extends z.ZodType>(opts: {
  name: string;
  schema: T;
  system: string;
  content: string;
}): Promise<z.infer<T>> {
  const apiKey = process.env.HERCULES_API_KEY;
  if (!apiKey) fail("EXTERNAL_SERVICE_ERROR", "AI is not set up for this app yet.");

  // The `$schema` key is not accepted inside response_format; undefined drops it.
  const jsonSchema = { ...z.toJSONSchema(opts.schema), $schema: undefined };

  let res: Response;
  try {
    res = await fetch(GATEWAY_URL, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: MODEL,
        reasoning_effort: "low",
        messages: [
          { role: "system", content: opts.system },
          { role: "user", content: opts.content },
        ],
        response_format: {
          type: "json_schema",
          json_schema: { name: opts.name, strict: true, schema: jsonSchema },
        },
      }),
    });
  } catch (error) {
    console.error("AI gateway request failed", error);
    fail("EXTERNAL_SERVICE_ERROR", AI_DOWN);
  }
  if (!res.ok) {
    console.error("AI gateway error", res.status, (await res.text()).slice(0, 500));
    fail("EXTERNAL_SERVICE_ERROR", AI_DOWN);
  }

  const completion = completionSchema.safeParse(await res.json());
  const content = completion.success ? completion.data.choices[0].message.content : null;
  if (!content) fail("EXTERNAL_SERVICE_ERROR", "The AI couldn't read that. Try a shorter or clearer text.");

  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch {
    fail("EXTERNAL_SERVICE_ERROR", "The AI reply was incomplete. Please try again.");
  }
  const result = opts.schema.safeParse(parsed);
  if (!result.success) {
    console.error("AI reply did not match schema", result.error.message);
    fail("EXTERNAL_SERVICE_ERROR", "The AI reply was incomplete. Please try again.");
  }
  return result.data;
}
