import { fail } from "../lib/access";

const HOME_CHARS = 14_000;
const SUBPAGE_CHARS = 8_000;
const FETCH_TIMEOUT_MS = 15_000;
const PRIVATE_HOST =
  /^(localhost|0\.|10\.|127\.|169\.254\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.|\[)|\.(local|internal|localhost)$/i;

/** Accepts "hotelarts.com" or a full URL; rejects non-web and private addresses. */
export function parseWebsite(input: string): URL {
  const raw = input.trim();
  let url: URL;
  try {
    url = new URL(/^https?:\/\//i.test(raw) ? raw : `https://${raw}`);
  } catch {
    fail("BAD_REQUEST", "That doesn't look like a website address.");
  }
  if (!["http:", "https:"].includes(url.protocol) || PRIVATE_HOST.test(url.hostname)) {
    fail("BAD_REQUEST", "Use a public website address, like hotelarts.com.");
  }
  return url;
}

/** Strips scripts, styles and tags from HTML into readable text. */
export function htmlToText(html: string): string {
  return html
    .replace(/<script[\s\S]*?<\/script>/gi, " ")
    .replace(/<style[\s\S]*?<\/style>/gi, " ")
    .replace(/<!--[\s\S]*?-->/g, " ")
    .replace(/<(br|p|div|li|h[1-6]|tr)[^>]*>/gi, "\n")
    .replace(/<[^>]+>/g, " ")
    .replace(/&nbsp;/g, " ")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, " ")
    .replace(/\n\s*\n+/g, "\n")
    .trim();
}

/** First same-site link whose address or label matches `keywords`. */
function findSubpage(html: string, page: URL, keywords: RegExp): URL | null {
  const linkRegex = /<a\s+[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi;
  for (const match of html.matchAll(linkRegex)) {
    const [, href, label] = match;
    if (!keywords.test(href) && !keywords.test(label.replace(/<[^>]+>/g, " "))) continue;
    try {
      const url = new URL(href, page);
      if (url.origin === page.origin && url.href !== page.href) return url;
    } catch {
      // Ignore unresolvable links.
    }
  }
  return null;
}

async function tryFetch(url: URL): Promise<string | null> {
  try {
    const res = await fetch(url, {
      headers: { "User-Agent": "Mozilla/5.0 (compatible; ToorImport/1.0)" },
      signal: AbortSignal.timeout(FETCH_TIMEOUT_MS),
    });
    return res.ok ? await res.text() : null;
  } catch {
    return null;
  }
}

/**
 * Readable text from a website's home page plus one useful subpage
 * (contact/about, or rooms for hotels), labelled for the AI.
 */
export async function readWebsite(
  input: string,
  subpageKeywords: RegExp,
): Promise<{ text: string; url: string }> {
  const page = parseWebsite(input);
  const home = await tryFetch(page);
  if (home === null) {
    fail(
      "BAD_REQUEST",
      "Couldn't open that website. Check the address, or copy the page text and paste it instead.",
    );
  }
  const subUrl = findSubpage(home, page, subpageKeywords);
  const sub = subUrl ? await tryFetch(subUrl) : null;

  let text = `Website: ${page.href}\n\n${htmlToText(home).slice(0, HOME_CHARS)}`;
  if (sub && subUrl) {
    text += `\n\n--- ${subUrl.href} ---\n${htmlToText(sub).slice(0, SUBPAGE_CHARS)}`;
  }
  if (text.length < 80) {
    fail("BAD_REQUEST", "That page has no readable text. Copy the details and paste them instead.");
  }
  return { text, url: page.href };
}
