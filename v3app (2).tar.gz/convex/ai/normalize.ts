import type { z } from "zod";
import type {
  ClientDraftRaw,
  SupplierDraftRaw,
  itineraryResultSchema,
} from "./schemas";
import {
  MAX_IMPORT_ITEMS,
  MAX_IMPORT_RECORDS,
  MAX_IMPORT_ROOM_TYPES,
} from "./limits";

/**
 * Turns raw AI replies into drafts that pass the normal save rules: nulls
 * become missing, bad emails/times/counts are dropped rather than failing
 * the whole review. Staff still check everything before anything is saved.
 */
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/;

export function text(value: string | null, max = 500): string | undefined {
  const t = value?.trim();
  return t ? t.slice(0, max) : undefined;
}

export function email(value: string | null): string | undefined {
  const t = value?.trim().toLowerCase();
  return t && EMAIL_PATTERN.test(t) ? t : undefined;
}

export function count(value: number | null): number | undefined {
  if (value === null || !Number.isFinite(value) || value < 0) return undefined;
  return Math.round(value);
}

/** Accepts "9:30" or "09:30"; anything else is dropped. */
export function time(value: string | null): string | undefined {
  const t = value?.trim();
  if (!t) return undefined;
  const padded = /^\d:\d\d$/.test(t) ? `0${t}` : t;
  return TIME_PATTERN.test(padded) ? padded : undefined;
}

export type ClientDraft = {
  kind: ClientDraftRaw["kind"];
  name: string;
  companyName?: string;
  contactName?: string;
  email?: string;
  phone?: string;
  address?: string;
  city?: string;
  country?: string;
  taxId?: string;
  notes?: string;
};

export function normalizeClients(raw: ClientDraftRaw[]): ClientDraft[] {
  return raw
    .map((c) => ({
      kind: c.kind,
      name: text(c.name, 200) ?? "",
      companyName: c.kind === "individual" ? text(c.companyName, 200) : undefined,
      contactName: text(c.contactName),
      email: email(c.email),
      phone: text(c.phone),
      address: text(c.address),
      city: text(c.city),
      country: text(c.country),
      taxId: text(c.taxId),
      notes: text(c.notes, 5000),
    }))
    .filter((c) => c.name)
    .slice(0, MAX_IMPORT_RECORDS);
}

export type RoomTypeDraft = {
  name: string;
  occupancy: number;
  board: SupplierDraftRaw["roomTypes"][number]["board"];
  nightlyRate?: number;
  notes?: string;
};

export type SupplierDraft = {
  name: string;
  category: SupplierDraftRaw["category"];
  city?: string;
  country?: string;
  address?: string;
  website?: string;
  contactName?: string;
  email?: string;
  phone?: string;
  notes?: string;
  hotelClass?: NonNullable<SupplierDraftRaw["hotelClass"]>;
  totalRooms?: number;
  meetingRooms?: number;
  largestMeetingCapacity?: number;
  currency?: NonNullable<SupplierDraftRaw["currency"]>;
  roomTypes: RoomTypeDraft[];
};

export function normalizeSuppliers(raw: SupplierDraftRaw[], website?: string): SupplierDraft[] {
  return raw
    .map((s): SupplierDraft => {
      const isHotel = s.category === "hotel";
      return {
        name: text(s.name, 200) ?? "",
        category: s.category,
        city: text(s.city),
        country: text(s.country),
        address: text(s.address),
        website: text(s.website) ?? website,
        contactName: text(s.contactName),
        email: email(s.email),
        phone: text(s.phone),
        notes: text(s.notes, 5000),
        currency: s.currency ?? undefined,
        hotelClass: isHotel ? (s.hotelClass ?? undefined) : undefined,
        totalRooms: isHotel ? count(s.totalRooms) : undefined,
        meetingRooms: isHotel ? count(s.meetingRooms) : undefined,
        largestMeetingCapacity: isHotel ? count(s.largestMeetingCapacity) : undefined,
        roomTypes: isHotel
          ? s.roomTypes
              .map((r) => ({
                name: text(r.name, 200) ?? "",
                occupancy: Math.min(50, Math.max(1, Math.round(r.occupancy) || 2)),
                board: r.board,
                nightlyRate:
                  r.nightlyRate !== null && r.nightlyRate >= 0 ? r.nightlyRate : undefined,
                notes: text(r.notes),
              }))
              .filter((r) => r.name)
              .slice(0, MAX_IMPORT_ROOM_TYPES)
          : [],
      };
    })
    .filter((s) => s.name)
    .slice(0, MAX_IMPORT_RECORDS);
}

export type ItineraryDraftDay = { date: string; title?: string; notes?: string };
export type ItineraryDraftItem = {
  // null when the AI placed it on a day outside the booking; staff pick one.
  date: string | null;
  type: z.infer<typeof itineraryResultSchema>["items"][number]["type"];
  startTime?: string;
  endTime?: string;
  title: string;
  description?: string;
  location?: string;
};

/** Maps AI day numbers (1-based) onto the booking's calendar days. */
export function normalizeItinerary(
  raw: z.infer<typeof itineraryResultSchema>,
  bookingDays: string[],
): { days: ItineraryDraftDay[]; items: ItineraryDraftItem[] } {
  const dateOf = (n: number) =>
    Number.isInteger(n) && n >= 1 && n <= bookingDays.length ? bookingDays[n - 1] : null;

  const seen = new Set<string>();
  const days: ItineraryDraftDay[] = [];
  for (const d of raw.days) {
    const date = dateOf(d.dayNumber);
    const title = text(d.title, 200);
    const notes = text(d.notes, 5000);
    if (!date || seen.has(date) || (!title && !notes)) continue;
    seen.add(date);
    days.push({ date, title, notes });
  }

  const items = raw.items
    .map((i): ItineraryDraftItem => {
      const startTime = time(i.startTime);
      const end = time(i.endTime);
      return {
        date: dateOf(i.dayNumber),
        type: i.type,
        startTime,
        // An end time needs a start time and must come after it.
        endTime: startTime && end && end >= startTime ? end : undefined,
        title: text(i.title, 200) ?? "",
        description: text(i.description, 5000),
        location: text(i.location),
      };
    })
    .filter((i) => i.title)
    .slice(0, MAX_IMPORT_ITEMS);

  return { days: days.sort((a, b) => a.date.localeCompare(b.date)), items };
}
