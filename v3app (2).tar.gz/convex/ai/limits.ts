// Shared by the import actions and the review UI.
export const MAX_IMPORT_TEXT = 30_000;
// Records created by one import, so a single review stays manageable.
export const MAX_IMPORT_RECORDS = 50;
export const MAX_IMPORT_ITEMS = 200;
export const MAX_IMPORT_ROOM_TYPES = 30;
