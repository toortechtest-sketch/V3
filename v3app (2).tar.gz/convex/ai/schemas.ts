import { z } from "zod";
import { CLIENT_KINDS } from "../schema/clients";
import { CURRENCIES } from "../schema/bookings";
import { ITINERARY_ITEM_TYPES } from "../schema/itinerary";
import {
  BOARD_TYPES,
  HOTEL_CLASSES,
  SUPPLIER_CATEGORIES,
} from "../schema/suppliers";

/**
 * Shapes the AI must return. Strict structured output needs every key present,
 * so "unknown" is null rather than missing. Keep these free of length/format
 * constraints: the gateway rejects many JSON Schema keywords in strict mode.
 */
const opt = z.string().nullable();
const optNum = z.number().nullable();

export const clientDraftSchema = z.object({
  kind: z.enum(CLIENT_KINDS),
  name: z.string(),
  // For people: the company they work at, used to link them on import.
  companyName: opt,
  contactName: opt,
  email: opt,
  phone: opt,
  address: opt,
  city: opt,
  country: opt,
  taxId: opt,
  notes: opt,
});

export const clientsResultSchema = z.object({ clients: z.array(clientDraftSchema) });

export const roomTypeDraftSchema = z.object({
  name: z.string(),
  occupancy: z.number(),
  board: z.enum(BOARD_TYPES),
  nightlyRate: optNum,
  notes: opt,
});

export const supplierDraftSchema = z.object({
  name: z.string(),
  category: z.enum(SUPPLIER_CATEGORIES),
  city: opt,
  country: opt,
  address: opt,
  website: opt,
  contactName: opt,
  email: opt,
  phone: opt,
  notes: opt,
  hotelClass: z.enum(HOTEL_CLASSES).nullable(),
  totalRooms: optNum,
  meetingRooms: optNum,
  largestMeetingCapacity: optNum,
  currency: z.enum(CURRENCIES).nullable(),
  roomTypes: z.array(roomTypeDraftSchema),
});

export const suppliersResultSchema = z.object({ suppliers: z.array(supplierDraftSchema) });

export const itineraryResultSchema = z.object({
  days: z.array(
    z.object({
      dayNumber: z.number(),
      title: opt,
      notes: opt,
    }),
  ),
  items: z.array(
    z.object({
      dayNumber: z.number(),
      type: z.enum(ITINERARY_ITEM_TYPES),
      startTime: opt,
      endTime: opt,
      title: z.string(),
      description: opt,
      location: opt,
    }),
  ),
});

export type ClientDraftRaw = z.infer<typeof clientDraftSchema>;
export type SupplierDraftRaw = z.infer<typeof supplierDraftSchema>;
