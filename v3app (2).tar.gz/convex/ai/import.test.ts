import { convexTest } from "convex-test";
import { afterEach, describe, expect, it, vi } from "vitest";
import { api } from "../_generated/api";
import schema from "../schema";
import { modules } from "../test.setup";
import { normalizeItinerary, normalizeSuppliers, time } from "./normalize";
import { parseWebsite } from "./web";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-05-10",
  endDate: "2026-05-12",
  pax: 12,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  const pending = as(t, "pending");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  await pending.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  return { t, agentA, agentB, pending, bookingId };
}

const page = { paginationOpts: { numItems: 50, cursor: null } };

describe("AI reply cleanup", () => {
  it("keeps valid times and drops the rest", () => {
    expect(time("9:30")).toBe("09:30");
    expect(time("21:05")).toBe("21:05");
    expect(time("25:00")).toBeUndefined();
    expect(time("noon")).toBeUndefined();
    expect(time(null)).toBeUndefined();
  });

  it("maps day numbers onto booking days and flags ones outside them", () => {
    const days = ["2026-05-10", "2026-05-11"];
    const draft = normalizeItinerary(
      {
        days: [{ dayNumber: 2, title: "Montserrat", notes: null }],
        items: [
          { dayNumber: 1, type: "transfer", startTime: "14:00", endTime: "13:00", title: "Airport", description: null, location: null },
          { dayNumber: 5, type: "meal", startTime: null, endTime: null, title: "Dinner", description: null, location: null },
          { dayNumber: 1, type: "other", startTime: null, endTime: null, title: "  ", description: null, location: null },
        ],
      },
      days,
    );
    expect(draft.days).toEqual([{ date: "2026-05-11", title: "Montserrat", notes: undefined }]);
    // End before start is dropped; empty titles are removed.
    expect(draft.items).toMatchObject([
      { date: "2026-05-10", startTime: "14:00", endTime: undefined, title: "Airport" },
      { date: null, title: "Dinner" },
    ]);
  });

  it("drops hotel-only details and bad emails from non-hotels", () => {
    const [s] = normalizeSuppliers([
      {
        name: "Barcelona Coaches",
        category: "transfer",
        city: null, country: null, address: null, website: null, contactName: null,
        email: "not an email", phone: null, notes: null,
        hotelClass: "5-star", totalRooms: 200, meetingRooms: null, largestMeetingCapacity: null,
        currency: null,
        roomTypes: [{ name: "Double", occupancy: 2, board: "breakfast", nightlyRate: 100, notes: null }],
      },
    ]);
    expect(s).toMatchObject({ email: undefined, hotelClass: undefined, totalRooms: undefined, roomTypes: [] });
  });

  it("rejects private network addresses for website import", () => {
    expect(parseWebsite("hotelarts.com").href).toBe("https://hotelarts.com/");
    expect(() => parseWebsite("http://localhost:3000")).toThrow(/public website/);
    expect(() => parseWebsite("192.168.1.1")).toThrow(/public website/);
  });
});

describe("creating reviewed drafts", () => {
  afterEach(() => {
    vi.unstubAllGlobals();
    vi.unstubAllEnvs();
  });

  it("links imported people to a company in the same import", async () => {
    const { agentA } = await setup();
    await agentA.mutation(api.ai.save.createClients, {
      clients: [
        { kind: "individual", name: "Maria Garcia", companyName: "acme pharma", email: "maria@acme.com" },
        { kind: "company", name: "Acme Pharma" },
      ],
    });
    const { page: rows } = await agentA.query(api.clients.list, page);
    const company = rows.find((c) => c.kind === "company");
    const person = rows.find((c) => c.kind === "individual");
    expect(person?.parentClientId).toBe(company?._id);
  });

  it("creates nothing when one reviewed record is invalid", async () => {
    const { agentA } = await setup();
    await expect(
      agentA.mutation(api.ai.save.createClients, {
        clients: [
          { kind: "company", name: "Good Co" },
          { kind: "company", name: "Bad Co", email: "nope" },
        ],
      }),
    ).rejects.toThrow(/email/);
    expect((await agentA.query(api.clients.list, page)).page).toHaveLength(0);
  });

  it("creates a hotel with its room types", async () => {
    const { agentA } = await setup();
    const [id] = await agentA.mutation(api.ai.save.createSuppliers, {
      suppliers: [
        {
          name: "Hotel Arts",
          category: "hotel",
          status: "active",
          roomTypes: [{ name: "Deluxe King", occupancy: 2, board: "breakfast", nightlyRate: 420 }],
        },
      ],
    });
    const hotel = await agentA.query(api.suppliers.get, { id });
    expect(hotel.roomTypes.map((r) => r.name)).toEqual(["Deluxe King"]);
  });

  it("only lets staff with booking access add itinerary items", async () => {
    const { agentA, agentB, pending, bookingId } = await setup();
    const args = {
      bookingId,
      days: [{ date: "2026-05-10", title: "Arrival" }],
      items: [{ date: "2026-05-10", type: "transfer" as const, startTime: "14:00", title: "Airport" }],
    };
    await expect(agentB.mutation(api.ai.save.createItinerary, args)).rejects.toThrow(/not found/);
    await expect(pending.mutation(api.ai.save.createClients, { clients: [{ kind: "company", name: "X" }] })).rejects.toThrow(/not been approved/);
    await expect(
      agentA.mutation(api.ai.save.createItinerary, {
        ...args,
        items: [{ ...args.items[0], date: "2026-06-01" }],
      }),
    ).rejects.toThrow(/outside the booking dates/);

    expect(await agentA.mutation(api.ai.save.createItinerary, args)).toBe(1);
    const itinerary = await agentA.query(api.itinerary.get, { bookingId });
    expect(itinerary.days[0]).toMatchObject({ title: "Arrival", items: [{ title: "Airport" }] });
  });

  it("drafts clients from the AI reply and flags existing names", async () => {
    const { agentA } = await setup();
    await agentA.mutation(api.clients.create, { kind: "company", name: "Acme Pharma" });
    const reply = {
      clients: [
        { kind: "company", name: "Acme Pharma", companyName: null, contactName: null, email: null, phone: null, address: null, city: null, country: null, taxId: null, notes: null },
        { kind: "individual", name: "Maria Garcia", companyName: "Acme Pharma", contactName: null, email: "Maria@Acme.com", phone: null, address: null, city: null, country: null, taxId: null, notes: null },
      ],
    };
    vi.stubEnv("HERCULES_API_KEY", "test-key");
    vi.stubGlobal(
      "fetch",
      vi.fn(async () =>
        Response.json({ choices: [{ message: { content: JSON.stringify(reply) } }] }),
      ),
    );
    const result = await agentA.action(api.ai.extract.extractClients, {
      source: { kind: "text", text: "Maria Garcia, Acme Pharma, maria@acme.com" },
    });
    expect(result.existing).toEqual(["acme pharma"]);
    expect(result.drafts[1]).toMatchObject({ email: "maria@acme.com", companyName: "Acme Pharma" });
    // Drafting never writes.
    expect((await agentA.query(api.clients.list, page)).page).toHaveLength(1);
  });
});
