import { v } from "convex/values";
import { mutation } from "../_generated/server";
import type { Id } from "../_generated/dataModel";
import { fail, requireBooking, requireStaff } from "../lib/access";
import { insertClient } from "../clients";
import { cleanRoom, insertSupplier } from "../suppliers";
import { ITEM_LIMIT, checkDate, cleanItem, itemsOf } from "../itinerary";
import { clientKindValidator } from "../schema/clients";
import { currencyValidator } from "../schema/bookings";
import { itineraryItemTypeValidator } from "../schema/itinerary";
import {
  boardValidator,
  hotelClassValidator,
  supplierCategoryValidator,
  supplierStatusValidator,
} from "../schema/suppliers";
import { MAX_IMPORT_ITEMS, MAX_IMPORT_RECORDS, MAX_IMPORT_ROOM_TYPES } from "./limits";

/**
 * Creates only what staff approved on the review screen. Everything runs in
 * one transaction through the same rules as manual entry, so one bad row
 * stops the whole import and nothing is half-created.
 */
const s = v.optional(v.string());

export const createClients = mutation({
  args: {
    clients: v.array(
      v.object({
        kind: clientKindValidator,
        name: v.string(),
        companyName: s,
        contactName: s,
        email: s,
        phone: s,
        address: s,
        city: s,
        country: s,
        taxId: s,
        notes: s,
      }),
    ),
  },
  handler: async (ctx, args): Promise<number> => {
    const staff = await requireStaff(ctx);
    if (args.clients.length === 0) fail("BAD_REQUEST", "Pick at least one client to create.");
    if (args.clients.length > MAX_IMPORT_RECORDS) {
      fail("BAD_REQUEST", `Import up to ${MAX_IMPORT_RECORDS} clients at a time.`);
    }
    // Companies first, so people in the same import can be linked to them.
    const ordered = [...args.clients].sort(
      (a, b) => Number(a.kind === "individual") - Number(b.kind === "individual"),
    );
    const companyIds = new Map<string, Id<"clients">>();
    for (const { companyName, ...client } of ordered) {
      let parentClientId: Id<"clients"> | undefined;
      const key = companyName?.trim().toLowerCase();
      if (client.kind === "individual" && key) {
        parentClientId =
          companyIds.get(key) ??
          (
            await ctx.db
              .query("clients")
              .withIndex("by_kind_and_sort_name", (q) =>
                q.eq("kind", "company").eq("sortName", key),
              )
              .first()
          )?._id;
      }
      const id = await insertClient(ctx, staff.user._id, { ...client, parentClientId });
      if (client.kind === "company") companyIds.set(client.name.trim().toLowerCase(), id);
    }
    return args.clients.length;
  },
});

export const createSuppliers = mutation({
  args: {
    suppliers: v.array(
      v.object({
        name: v.string(),
        category: supplierCategoryValidator,
        status: supplierStatusValidator,
        city: s,
        country: s,
        address: s,
        website: s,
        contactName: s,
        email: s,
        phone: s,
        notes: s,
        hotelClass: v.optional(hotelClassValidator),
        totalRooms: v.optional(v.number()),
        meetingRooms: v.optional(v.number()),
        largestMeetingCapacity: v.optional(v.number()),
        currency: v.optional(currencyValidator),
        roomTypes: v.array(
          v.object({
            name: v.string(),
            occupancy: v.number(),
            board: boardValidator,
            nightlyRate: v.optional(v.number()),
            notes: s,
          }),
        ),
      }),
    ),
  },
  handler: async (ctx, args): Promise<Id<"suppliers">[]> => {
    const staff = await requireStaff(ctx);
    if (args.suppliers.length === 0) fail("BAD_REQUEST", "Pick at least one supplier to create.");
    if (args.suppliers.length > MAX_IMPORT_RECORDS) {
      fail("BAD_REQUEST", `Import up to ${MAX_IMPORT_RECORDS} suppliers at a time.`);
    }
    const ids: Id<"suppliers">[] = [];
    for (const { roomTypes, ...supplier } of args.suppliers) {
      if (roomTypes.length > MAX_IMPORT_ROOM_TYPES) {
        fail("BAD_REQUEST", `Import up to ${MAX_IMPORT_ROOM_TYPES} room types per hotel.`);
      }
      const id = await insertSupplier(ctx, staff.user._id, supplier);
      if (supplier.category === "hotel") {
        for (const room of roomTypes) {
          await ctx.db.insert("supplierRoomTypes", { supplierId: id, ...cleanRoom(room) });
        }
      }
      ids.push(id);
    }
    return ids;
  },
});

export const createItinerary = mutation({
  args: {
    bookingId: v.id("bookings"),
    days: v.array(v.object({ date: v.string(), title: s, notes: s })),
    items: v.array(
      v.object({
        date: v.string(),
        type: itineraryItemTypeValidator,
        startTime: s,
        endTime: s,
        title: v.string(),
        description: s,
        location: s,
      }),
    ),
  },
  handler: async (ctx, args): Promise<number> => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    if (args.items.length + args.days.length === 0) {
      fail("BAD_REQUEST", "Pick at least one item to add.");
    }
    if (args.items.length > MAX_IMPORT_ITEMS) {
      fail("BAD_REQUEST", `Import up to ${MAX_IMPORT_ITEMS} items at a time.`);
    }
    const existing = await itemsOf(ctx, booking._id).take(ITEM_LIMIT);
    if (existing.length + args.items.length > ITEM_LIMIT) {
      fail("BAD_REQUEST", `An itinerary can hold up to ${ITEM_LIMIT} items.`);
    }

    // Day headlines and notes only fill empty days; existing ones are kept.
    for (const day of args.days) {
      checkDate(booking, day.date);
      const title = day.title?.trim().slice(0, 200) || undefined;
      const notes = day.notes?.trim() || undefined;
      if (!title && !notes) continue;
      const current = await ctx.db
        .query("itineraryDays")
        .withIndex("by_booking_and_date", (q) =>
          q.eq("bookingId", booking._id).eq("date", day.date),
        )
        .unique();
      if (!current) {
        await ctx.db.insert("itineraryDays", { bookingId: booking._id, date: day.date, title, notes });
      } else {
        await ctx.db.patch("itineraryDays", current._id, {
          title: current.title ?? title,
          notes: current.notes ?? notes,
        });
      }
    }

    const now = new Date().toISOString();
    for (const item of args.items) {
      checkDate(booking, item.date);
      const fields = await cleanItem(ctx, item);
      await ctx.db.insert("itineraryItems", { bookingId: booking._id, ...fields, updatedAt: now });
    }
    return args.items.length;
  },
});
