import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";
import { priceLine, quoteTotals } from "./lib/quoteMath";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-11-02",
  endDate: "2026-11-05",
  pax: 20,
  currency: "GBP" as const,
  exchangeRateToBase: 1.2,
  markupPercent: 25,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  return { owner, agentA, agentB, bookingId };
}

describe("quote math", () => {
  it("prices each basis and applies the default or own markup", () => {
    const perPerson = priceLine(
      { basis: "per_person", quantity: 1, times: 3, unitCost: 10 },
      20,
      25,
    );
    expect(perPerson).toMatchObject({ units: 20, cost: 600, sell: 750, margin: 150 });
    const rooms = priceLine(
      { basis: "per_unit", quantity: 10, times: 3, unitCost: 100, markupPercent: 10 },
      20,
      25,
    );
    expect(rooms).toMatchObject({ units: 10, cost: 3000, sell: 3300, markupPercent: 10 });
    const coach = priceLine({ basis: "fixed", quantity: 99, times: 1, unitCost: 450 }, 20, 0);
    expect(coach).toMatchObject({ units: 1, cost: 450, sell: 450, margin: 0 });
  });

  it("spreads the price over paying guests and converts to EUR", () => {
    const totals = quoteTotals(
      [{ units: 1, markupPercent: 25, cost: 800, sell: 1000, margin: 200 }],
      { pax: 21, freePlaces: 1, rateToBase: 1.2 },
    );
    expect(totals).toMatchObject({
      marginPercent: 20,
      payingPax: 20,
      perPayingGuest: 50,
      base: { cost: 960, sell: 1200, margin: 240 },
    });
  });

  it("has no margin % or per-guest price when nothing is sold", () => {
    const totals = quoteTotals([], { pax: 1, freePlaces: 1, rateToBase: 1 });
    expect(totals.marginPercent).toBeNull();
    expect(totals.perPayingGuest).toBeNull();
  });
});

describe("quotes", () => {
  it("groups lines into sections with totals", async () => {
    const { agentA, bookingId } = await setup();
    await agentA.mutation(api.quotes.addLine, {
      bookingId,
      section: "accommodation",
      description: "Hotel Arts, double rooms",
      basis: "per_unit",
      quantity: 10,
      times: 3,
      unitCost: 100,
    });
    await agentA.mutation(api.quotes.addLine, {
      bookingId,
      section: "meals",
      description: "Welcome dinner",
      basis: "per_person",
      quantity: 1,
      times: 1,
      unitCost: 40,
      markupPercent: 50,
    });
    const quote = await agentA.query(api.quotes.get, { bookingId });
    expect(quote.sections.map((s) => s.section)).toEqual(["accommodation", "meals"]);
    expect(quote.totals).toMatchObject({ cost: 3800, sell: 4950, margin: 1150 });
    expect(quote.totals.base.sell).toBe(5940);
  });

  it("rejects bad numbers and free places for everyone", async () => {
    const { agentA, bookingId } = await setup();
    await expect(
      agentA.mutation(api.quotes.addLine, {
        bookingId,
        section: "other",
        description: "Tips",
        basis: "fixed",
        quantity: 1,
        times: 1,
        unitCost: -5,
      }),
    ).rejects.toThrow(/Unit cost/);
    await expect(
      agentA.mutation(api.quotes.saveSettings, { bookingId, freePlaces: 20 }),
    ).rejects.toThrow(/has to pay/);
  });

  it("hides another agent's quote", async () => {
    const { agentA, agentB, owner, bookingId } = await setup();
    const lineId = await agentA.mutation(api.quotes.addLine, {
      bookingId,
      section: "transport",
      description: "Airport coach",
      basis: "fixed",
      quantity: 1,
      times: 2,
      unitCost: 450,
    });
    await expect(agentB.query(api.quotes.get, { bookingId })).rejects.toThrow(
      /Booking not found/,
    );
    await expect(agentB.mutation(api.quotes.removeLine, { id: lineId })).rejects.toThrow(
      /Booking not found/,
    );
    const seen = await owner.query(api.quotes.get, { bookingId });
    expect(seen.lineCount).toBe(1);
  });
});
