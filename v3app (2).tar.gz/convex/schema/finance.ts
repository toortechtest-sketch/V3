import { defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * Booking-level finance settings, one row per booking (created on first save).
 * Kept apart from `bookings` so finance writes don't contend with brief edits.
 */
export const bookingFinance = defineTable({
  bookingId: v.id("bookings"),
  // Agreed package value in the booking currency. Undefined = use the quote's
  // selling price, so the schedule follows the quote until a deal is agreed.
  contractValue: v.optional(v.number()),
  // Manual "closed for full payment" lock. Once set, existing invoices,
  // payments, schedule items and confirmed costs can no longer be changed;
  // only credit notes can be added.
  lockedAt: v.optional(v.string()),
  lockedById: v.optional(v.id("users")),
  updatedAt: v.string(),
}).index("by_booking", ["bookingId"]);

export const INVOICE_KINDS = ["invoice", "credit_note"] as const;
export type InvoiceKind = (typeof INVOICE_KINDS)[number];
export const invoiceKindValidator = v.union(v.literal("invoice"), v.literal("credit_note"));

export const INVOICE_STATUSES = ["issued", "void"] as const;
export type InvoiceStatus = (typeof INVOICE_STATUSES)[number];
export const invoiceStatusValidator = v.union(v.literal("issued"), v.literal("void"));

/** An invoice or credit note to the client. Amounts are positive, in the booking currency. */
export const invoices = defineTable({
  bookingId: v.id("bookings"),
  kind: invoiceKindValidator,
  // Sequential per year and kind: "INV-2026-0001" / "CN-2026-0001"
  number: v.string(),
  label: v.string(),
  amount: v.number(),
  // Calendar days, YYYY-MM-DD
  issueDate: v.string(),
  dueDate: v.optional(v.string()),
  status: invoiceStatusValidator,
  notes: v.optional(v.string()),
  createdById: v.id("users"),
  updatedAt: v.string(),
})
  .index("by_booking_and_issue_date", ["bookingId", "issueDate"])
  .index("by_number", ["number"]);

/** One planned instalment (deposit, balance…) of the contract value. */
export const paymentInstallments = defineTable({
  bookingId: v.id("bookings"),
  label: v.string(),
  // Share of the contract value. Not forced to total 100 so extras stay possible.
  percent: v.number(),
  // Calendar day, YYYY-MM-DD
  dueDate: v.string(),
  // Set once an invoice was raised for this instalment
  invoiceId: v.optional(v.id("invoices")),
  updatedAt: v.string(),
}).index("by_booking_and_due_date", ["bookingId", "dueDate"]);

export const PAYMENT_METHODS = ["bank_transfer", "card", "cash", "other"] as const;
export type PaymentMethod = (typeof PAYMENT_METHODS)[number];
export const paymentMethodValidator = v.union(
  v.literal("bank_transfer"),
  v.literal("card"),
  v.literal("cash"),
  v.literal("other"),
);

/** Money received from the client. Amounts are in the booking currency. */
export const payments = defineTable({
  bookingId: v.id("bookings"),
  amount: v.number(),
  // Calendar day, YYYY-MM-DD
  receivedDate: v.string(),
  method: paymentMethodValidator,
  reference: v.optional(v.string()),
  // Optional allocation, used for each invoice's paid / overdue state
  invoiceId: v.optional(v.id("invoices")),
  notes: v.optional(v.string()),
  createdById: v.id("users"),
  updatedAt: v.string(),
}).index("by_booking_and_received_date", ["bookingId", "receivedDate"]);
