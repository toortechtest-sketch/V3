import { v } from "convex/values";
import type { SupplierCategory } from "./suppliers";

/**
 * The ten service categories from the suppliers implementation package.
 * Deliberately separate from the legacy `suppliers.category` validator in
 * `./suppliers.ts` (hotel/transfer/restaurant/activity/venue/flight/other):
 * that one is read directly by itinerary, travellers, reservations and
 * quotes and must keep working unchanged. This is the new, additive
 * capability/profile model. `legacyToService`/`serviceToLegacy` below keep
 * the two in sync.
 */
export const SERVICE_CATEGORIES = [
  "hotel",
  "transport",
  "restaurant",
  "activity",
  "venue",
  "airline",
  "guide",
  "cruise",
  "equipment_event",
  "other",
] as const;
export type ServiceCategory = (typeof SERVICE_CATEGORIES)[number];

export const serviceCategoryValidator = v.union(
  v.literal("hotel"),
  v.literal("transport"),
  v.literal("restaurant"),
  v.literal("activity"),
  v.literal("venue"),
  v.literal("airline"),
  v.literal("guide"),
  v.literal("cruise"),
  v.literal("equipment_event"),
  v.literal("other"),
);

export const SERVICE_CATEGORY_LABELS: Record<ServiceCategory, string> = {
  hotel: "Hotel",
  transport: "Transfer / Transport",
  restaurant: "Restaurant",
  activity: "Activity / Excursion",
  venue: "Venue",
  airline: "Flight / Airline",
  guide: "Guide",
  cruise: "Cruise",
  equipment_event: "Equipment / Event supplier",
  other: "Other",
};

/** Maps a legacy supplier category onto its new service-category key. */
export function legacyToService(category: SupplierCategory): ServiceCategory {
  if (category === "transfer") return "transport";
  if (category === "flight") return "airline";
  return category;
}

/**
 * Maps a service-category key back onto the legacy 7-value set so existing
 * consumers (itinerary, travellers, reservations, quotes) keep working.
 * The three new categories with no legacy equivalent fall back to "other".
 */
export function serviceToLegacy(service: ServiceCategory): SupplierCategory {
  if (service === "transport") return "transfer";
  if (service === "airline") return "flight";
  if (service === "guide" || service === "cruise" || service === "equipment_event") return "other";
  return service;
}

// --- Field registry -------------------------------------------------------
// Drives both the dynamic form (client) and attribute validation (server).
// Kept as a static versioned TS config rather than a runtime custom-field
// builder — the "Other" category still accepts free-form attributes, but
// administrators can't define new typed fields through the UI yet.

export type FieldType = "text" | "number" | "boolean" | "list" | "enum";

export type FieldDef = {
  key: string;
  label: string;
  type: FieldType;
  /** For type "enum": the allowed values. For type "list": item examples only (free text list). */
  options?: readonly string[];
  placeholder?: string;
};

export type CategoryRegistryEntry = {
  schemaVersion: 1;
  /** Supplier-level profile fields for this category. */
  profileFields: readonly FieldDef[];
  /** Fields on a product/service of this category. */
  productFields: readonly FieldDef[];
  /** Pricing units this category's rates may use. */
  rateUnits: readonly string[];
  productSubtypes: readonly string[];
};

const text = (key: string, label: string, placeholder?: string): FieldDef => ({
  key,
  label,
  type: "text",
  placeholder,
});
const num = (key: string, label: string, placeholder?: string): FieldDef => ({
  key,
  label,
  type: "number",
  placeholder,
});
const bool = (key: string, label: string): FieldDef => ({ key, label, type: "boolean" });
const list = (key: string, label: string, placeholder?: string): FieldDef => ({
  key,
  label,
  type: "list",
  placeholder,
});

export const CATEGORY_REGISTRY: Record<ServiceCategory, CategoryRegistryEntry> = {
  hotel: {
    schemaVersion: 1,
    profileFields: [
      text("classification", "Classification", "5-star, boutique, unrated…"),
      num("totalRooms", "Total rooms"),
      text("checkInTime", "Check-in time", "14:00"),
      text("checkOutTime", "Check-out time", "11:00"),
      list("amenities", "Amenities", "Pool, spa, gym"),
      text("accessibilityNotes", "Accessibility notes"),
      text("meetingFacilitiesSummary", "Meeting facilities summary"),
    ],
    productFields: [
      text("roomType", "Room type", "Deluxe sea view double"),
      list("bedConfigurations", "Bed configurations", "1 king, 2 twin"),
      num("maxOccupancy", "Max occupancy"),
      num("maxAdults", "Max adults"),
      num("maxChildren", "Max children"),
      num("roomSize", "Room size (m²)"),
      list("boardBases", "Supported board bases", "Room only, breakfast, half board"),
      text("accessibility", "Accessibility"),
      list("inclusions", "Inclusions"),
    ],
    rateUnits: ["room/night", "person/night"],
    productSubtypes: ["room", "accommodation_package"],
  },
  transport: {
    schemaVersion: 1,
    profileFields: [
      list("serviceAreas", "Service areas"),
      text("fleetSummary", "Fleet summary"),
      text("licenceReferences", "Licences / insurance references"),
      text("dispatchContact", "Dispatch contact"),
    ],
    productFields: [
      text("vehicleClass", "Vehicle class / model", "Mercedes Sprinter, 19-seat"),
      num("seatsExcludingDriver", "Seats excluding driver"),
      text("luggageAllowance", "Luggage allowance"),
      text("origin", "Origin"),
      text("destination", "Destination"),
      text("routeArea", "Route / area"),
      text("accessibility", "Accessibility"),
      bool("driverIncluded", "Driver included"),
    ],
    rateUnits: ["vehicle/trip", "vehicle/hour", "vehicle/day"],
    productSubtypes: ["transfer", "hourly_disposal", "day_hire", "vehicle_hire"],
  },
  restaurant: {
    schemaVersion: 1,
    profileFields: [
      list("cuisine", "Cuisine"),
      num("totalSeatingCapacity", "Total seating capacity"),
      num("groupSeatingCapacity", "Group seating capacity"),
      text("operatingHours", "Operating hours"),
      list("dietaryCapabilities", "Dietary capabilities"),
      bool("privateDining", "Private dining"),
      text("accessibility", "Accessibility"),
    ],
    productFields: [
      enumField("mealType", "Meal type", ["breakfast", "lunch", "dinner", "other"]),
      text("menuTitle", "Menu title"),
      list("menuItems", "Menu items"),
      text("seatingOrPrivateRoom", "Seating / private room"),
      num("minPax", "Min pax"),
      num("maxPax", "Max pax"),
      list("dietaryOptions", "Dietary options"),
      list("beveragesIncluded", "Beverages included"),
    ],
    rateUnits: ["person/meal", "group/meal"],
    productSubtypes: ["meal", "menu", "private_dining"],
  },
  activity: {
    schemaVersion: 1,
    profileFields: [
      list("operatingDestinations", "Operating destinations"),
      list("activityCategories", "Activity categories"),
      text("operatorLicenceReferences", "Operator / licence references"),
      text("safetyAccessibilityNotes", "Safety / accessibility notes"),
    ],
    productFields: [
      num("durationMinutes", "Duration (minutes)"),
      list("operatingDays", "Operating days"),
      num("minPax", "Min pax"),
      num("maxPax", "Max pax"),
      text("meetingPickupPoint", "Meeting / pickup point"),
      bool("guideOrTransportIncluded", "Guide / transport included"),
      list("languages", "Languages"),
      num("minAge", "Min age"),
      num("maxAge", "Max age"),
      text("fitnessAccessibilityRestrictions", "Fitness / accessibility restrictions"),
      list("inclusions", "Inclusions"),
      list("exclusions", "Exclusions"),
    ],
    rateUnits: ["person/activity", "group/activity"],
    productSubtypes: ["activity", "excursion", "tour"],
  },
  venue: {
    schemaVersion: 1,
    profileFields: [
      text("venueType", "Venue type"),
      text("accessibility", "Accessibility"),
      text("openingHours", "Opening hours"),
      text("cateringPolicy", "Catering policy"),
      list("avFacilities", "AV / facilities"),
    ],
    productFields: [
      text("spaceName", "Space name"),
      num("area", "Area (m²)"),
      list("capacitiesBySetup", "Capacities by setup", "Theatre 200, banquet 150"),
      list("av", "AV"),
      text("cateringAvailability", "Catering availability"),
      text("setupAccessTimes", "Setup / access times"),
    ],
    rateUnits: ["space/hour", "space/day", "service/event"],
    productSubtypes: ["space_hire", "venue_hire"],
  },
  airline: {
    schemaVersion: 1,
    profileFields: [
      enumField("organizationSubtype", "Organisation subtype", [
        "airline",
        "charter_operator",
        "consolidator",
      ]),
      text("iataIcaoCodes", "IATA / ICAO codes"),
      list("operatingRegions", "Operating regions"),
      text("ticketingContact", "Ticketing / group contact"),
    ],
    productFields: [
      text("originAirport", "Origin airport"),
      text("destinationAirport", "Destination airport"),
      text("flightNumber", "Flight number"),
      text("cabinFareClass", "Cabin / fare class"),
      text("baggageAllowance", "Baggage allowance"),
      text("route", "Route"),
      text("fareReference", "Fare reference"),
    ],
    rateUnits: ["person/flight segment", "service/event"],
    productSubtypes: ["scheduled_flight", "charter", "group_fare"],
  },
  guide: {
    schemaVersion: 1,
    profileFields: [
      bool("isAgency", "Is agency (not an individual)"),
      list("languages", "Languages"),
      list("destinations", "Destinations"),
      text("licenceReferences", "Licence references / expiry"),
      list("specialties", "Specialties"),
      text("availabilityNotes", "Availability notes"),
    ],
    productFields: [
      text("serviceArea", "Service area"),
      list("language", "Language"),
      text("duration", "Duration (minutes or half/full-day)"),
      num("maxGroupSize", "Max group size"),
      text("specialty", "Specialty"),
      bool("transportIncluded", "Transport included"),
    ],
    rateUnits: ["guide/half-day", "guide/day", "guide/hour"],
    productSubtypes: ["guiding", "escort", "interpreter"],
  },
  cruise: {
    schemaVersion: 1,
    profileFields: [
      text("operatorLine", "Operator / line"),
      list("operatingRegions", "Operating regions"),
      list("shipsSummary", "Ships summary"),
      text("bookingContact", "Booking / group contact"),
    ],
    productFields: [
      text("ship", "Ship"),
      text("cabinType", "Cabin type"),
      num("occupancy", "Occupancy"),
      num("sailingDurationNights", "Sailing duration (nights)"),
      list("itineraryPorts", "Itinerary / ports"),
      text("embarkation", "Embarkation"),
      text("disembarkation", "Disembarkation"),
      list("sailingDates", "Sailing dates"),
      list("inclusions", "Inclusions"),
    ],
    rateUnits: ["cabin/night", "cabin/sailing", "person/sailing", "service/event"],
    productSubtypes: ["cabin", "cruise_package", "charter"],
  },
  equipment_event: {
    schemaVersion: 1,
    profileFields: [
      list("serviceCategories", "Service categories", "AV, staging, furniture, decor"),
      list("coverageAreas", "Coverage areas"),
      text("installationCapabilities", "Installation capabilities"),
      bool("technicianAvailability", "Technician availability"),
    ],
    productFields: [
      text("equipmentServiceCategory", "Equipment / service category"),
      text("modelSpecification", "Model / specification"),
      num("availableQuantity", "Available quantity"),
      num("setupStrikeDurationMinutes", "Setup / strike duration (minutes)"),
      bool("technicianIncluded", "Technician included"),
      text("rentalPeriod", "Rental period"),
      text("deliveryRequirements", "Delivery requirements"),
    ],
    rateUnits: ["item/day", "item/hour", "service/event"],
    productSubtypes: ["equipment_rental", "event_service"],
  },
  other: {
    schemaVersion: 1,
    profileFields: [
      text("customCategoryLabel", "Custom category label"),
      text("businessDescription", "Business description"),
    ],
    productFields: [text("serviceDescription", "Service description")],
    rateUnits: ["custom"],
    productSubtypes: ["service"],
  },
};

function enumField(key: string, label: string, options: readonly string[]): FieldDef {
  return { key, label, type: "enum", options };
}

/** All rate units across every category, for the Rates filter and validator. */
export const ALL_RATE_UNITS = [
  ...new Set(Object.values(CATEGORY_REGISTRY).flatMap((e) => e.rateUnits)),
  "custom",
] as const;

export const rateUnitValidator = v.string();

/**
 * Structured attributes bag for profiles/products: validated against the
 * category's field registry, not an opaque blob. Values are typed per
 * field (string / number / boolean / string list) by `cleanAttributes`.
 */
export const attributeValueValidator = v.union(
  v.string(),
  v.number(),
  v.boolean(),
  v.array(v.string()),
);
export const attributesValidator = v.record(v.string(), attributeValueValidator);
