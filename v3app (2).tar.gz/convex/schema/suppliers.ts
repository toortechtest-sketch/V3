import { defineTable } from "convex/server";
import { v } from "convex/values";
import { currencyValidator } from "./bookings";
import { serviceCategoryValidator } from "./supplierCategories";

// One merged list: V2 `suppliers` and V2 `hotels` both map here. Hotels are
// suppliers with category "hotel" plus the optional hotel-only fields below.
export const SUPPLIER_CATEGORIES = [
  "hotel",
  "transfer",
  "restaurant",
  "activity",
  "venue",
  "flight",
  "other",
] as const;
export type SupplierCategory = (typeof SUPPLIER_CATEGORIES)[number];

export const supplierCategoryValidator = v.union(
  v.literal("hotel"),
  v.literal("transfer"),
  v.literal("restaurant"),
  v.literal("activity"),
  v.literal("venue"),
  v.literal("flight"),
  v.literal("other"),
);

// Mirrors V2 hotel `status`, now available for every supplier.
export const SUPPLIER_STATUSES = ["preferred", "active", "archived"] as const;
export type SupplierStatus = (typeof SUPPLIER_STATUSES)[number];

export const supplierStatusValidator = v.union(
  v.literal("preferred"),
  v.literal("active"),
  v.literal("archived"),
);

// Mirrors V2 hotel `category` (star / quality class).
export const HOTEL_CLASSES = [
  "5-star-luxury",
  "5-star",
  "4-star-superior",
  "4-star",
  "3-star",
  "boutique",
  "resort",
  "apartment",
  "venue",
] as const;
export type HotelClass = (typeof HOTEL_CLASSES)[number];

export const hotelClassValidator = v.union(
  v.literal("5-star-luxury"),
  v.literal("5-star"),
  v.literal("4-star-superior"),
  v.literal("4-star"),
  v.literal("3-star"),
  v.literal("boutique"),
  v.literal("resort"),
  v.literal("apartment"),
  v.literal("venue"),
);

export const BOARD_TYPES = [
  "room-only",
  "breakfast",
  "half-board",
  "full-board",
  "all-inclusive",
] as const;
export type BoardType = (typeof BOARD_TYPES)[number];

export const boardValidator = v.union(
  v.literal("room-only"),
  v.literal("breakfast"),
  v.literal("half-board"),
  v.literal("full-board"),
  v.literal("all-inclusive"),
);

export const suppliers = defineTable({
  name: v.string(),
  category: supplierCategoryValidator,
  // New dynamic-suppliers primary type (one of the 10 service categories).
  // Optional/additive: legacy rows have none until the backfill runs, and
  // `category` above keeps being the source of truth for existing
  // itinerary/travellers/reservations/quotes consumers until then.
  primaryType: v.optional(serviceCategoryValidator),
  // Legal/trading name, if different from `name`
  legalName: v.optional(v.string()),
  status: supplierStatusValidator,
  city: v.optional(v.string()),
  country: v.optional(v.string()),
  address: v.optional(v.string()),
  website: v.optional(v.string()),
  contactName: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  notes: v.optional(v.string()),
  // Hotel-only details (V2 `hotels`)
  hotelClass: v.optional(hotelClassValidator),
  totalRooms: v.optional(v.number()),
  meetingRooms: v.optional(v.number()),
  largestMeetingCapacity: v.optional(v.number()),
  // Default contracting currency for rates
  currency: v.optional(currencyValidator),
  createdById: v.id("users"),
  // ISO 8601 UTC
  updatedAt: v.string(),
  // Lower-cased name for case-insensitive alphabetical ordering
  sortName: v.string(),
  // Lower-cased name, contact, email and city for one search index
  searchText: v.string(),
})
  .index("by_sort_name", ["sortName"])
  .index("by_category_and_sort_name", ["category", "sortName"])
  .searchIndex("search_text", {
    searchField: "searchText",
    filterFields: ["category"],
  });

// Mirrors V2 `hotelRoomTypes`, keyed to the merged suppliers table.
export const supplierRoomTypes = defineTable({
  supplierId: v.id("suppliers"),
  name: v.string(),
  // Guests the room sleeps
  occupancy: v.number(),
  board: boardValidator,
  // Indicative nightly rate in the supplier's currency, for `board`
  nightlyRate: v.optional(v.number()),
  notes: v.optional(v.string()),
}).index("by_supplier", ["supplierId"]);
