import { defineTable } from "convex/server";
import { v } from "convex/values";

// Same room types as V2 `passengers.roomType` so the V2 data move is 1:1.
export const ROOM_TYPES = ["single", "double", "twin", "triple", "suite"] as const;
export type RoomType = (typeof ROOM_TYPES)[number];

export const roomTypeValidator = v.union(
  v.literal("single"),
  v.literal("double"),
  v.literal("twin"),
  v.literal("triple"),
  v.literal("suite"),
);

// Mirrors V2 `roomAssignments.status`.
export const ROOM_STATUSES = ["tentative", "confirmed"] as const;
export type RoomStatus = (typeof ROOM_STATUSES)[number];

export const roomStatusValidator = v.union(v.literal("tentative"), v.literal("confirmed"));

/** One named person travelling on a booking (V2 `passengers`). */
export const travellers = defineTable({
  bookingId: v.id("bookings"),
  firstName: v.string(),
  lastName: v.string(),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  // Requested room type; the actual room lives on `roomId`
  roomPreference: roomTypeValidator,
  // Free text: who they asked to share with (V2 `sharingWith`)
  sharingWith: v.optional(v.string()),
  dietaryRequirements: v.optional(v.string()),
  notes: v.optional(v.string()),
  // Room they are placed in on the rooming list, if any
  roomId: v.optional(v.id("rooms")),
  createdById: v.id("users"),
  // Lower-cased "last first" for alphabetical ordering
  sortName: v.string(),
  // ISO 8601 UTC
  updatedAt: v.string(),
}).index("by_booking_and_sort_name", ["bookingId", "sortName"]);

/** One room on the booking's rooming list (V2 `roomAssignments`). */
export const rooms = defineTable({
  bookingId: v.id("bookings"),
  // Hotel the room is at; optional while the hotel is still being chosen
  supplierId: v.optional(v.id("suppliers")),
  roomType: roomTypeValidator,
  // Maximum guests in the room
  capacity: v.number(),
  // Hotel's room number once known
  roomNumber: v.optional(v.string()),
  status: roomStatusValidator,
  notes: v.optional(v.string()),
  // ISO 8601 UTC
  updatedAt: v.string(),
}).index("by_booking", ["bookingId"]);
