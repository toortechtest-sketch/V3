import { describe, expect, it } from "vitest";
import {
  CATEGORY_REGISTRY,
  SERVICE_CATEGORIES,
  legacyToService,
  serviceToLegacy,
} from "./supplierCategories";
import type { SupplierCategory } from "./suppliers";
import { SUPPLIER_CATEGORIES } from "./suppliers";

describe("legacy <-> service category mapping", () => {
  it("round-trips every legacy category through the service category and back", () => {
    for (const legacy of SUPPLIER_CATEGORIES) {
      const service = legacyToService(legacy);
      expect(SERVICE_CATEGORIES).toContain(service);
      // "other" is a lossy fallback target for the three new categories, but
      // every legacy category must round-trip to itself exactly.
      expect(serviceToLegacy(service)).toBe(legacy);
    }
  });

  it("maps transfer <-> transport and flight <-> airline explicitly", () => {
    expect(legacyToService("transfer")).toBe("transport");
    expect(legacyToService("flight")).toBe("airline");
    expect(serviceToLegacy("transport")).toBe("transfer");
    expect(serviceToLegacy("airline")).toBe("flight");
  });

  it("falls back new-only categories to the legacy 'other' bucket", () => {
    const newOnly: SupplierCategory[] = ["other", "other", "other"];
    expect([
      serviceToLegacy("guide"),
      serviceToLegacy("cruise"),
      serviceToLegacy("equipment_event"),
    ]).toEqual(newOnly);
  });
});

describe("category registry", () => {
  it("defines every service category with non-empty field sets", () => {
    for (const category of SERVICE_CATEGORIES) {
      const entry = CATEGORY_REGISTRY[category];
      expect(entry.schemaVersion).toBe(1);
      expect(entry.productFields.length).toBeGreaterThan(0);
      expect(entry.rateUnits.length).toBeGreaterThan(0);
    }
  });

  it("never mixes hotel-only fields into a different category's registry", () => {
    expect(CATEGORY_REGISTRY.restaurant.productFields.some((f) => f.key === "roomType")).toBe(
      false,
    );
    expect(CATEGORY_REGISTRY.hotel.productFields.some((f) => f.key === "roomType")).toBe(true);
  });
});
