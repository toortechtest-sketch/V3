import { defineTable } from "convex/server";
import { v } from "convex/values";

export const QUOTE_SECTIONS = [
  "accommodation",
  "transport",
  "meals",
  "activities",
  "venue",
  "staff",
  "other",
] as const;
export type QuoteSection = (typeof QUOTE_SECTIONS)[number];

export const quoteSectionValidator = v.union(
  v.literal("accommodation"),
  v.literal("transport"),
  v.literal("meals"),
  v.literal("activities"),
  v.literal("venue"),
  v.literal("staff"),
  v.literal("other"),
);

export const QUOTE_BASES = ["per_person", "per_unit", "fixed"] as const;

export const quoteBasisValidator = v.union(
  v.literal("per_person"),
  v.literal("per_unit"),
  v.literal("fixed"),
);

/** Quote-level settings, one row per booking (created on first save). */
export const quotes = defineTable({
  bookingId: v.id("bookings"),
  // Complimentary places (e.g. tour leader): their costs are spread over payers
  freePlaces: v.number(),
  // Warn when the overall margin falls below this % of the selling price
  targetMarginPercent: v.optional(v.number()),
  // Calendar day, YYYY-MM-DD
  validUntil: v.optional(v.string()),
  // Client-facing terms and inclusions
  terms: v.optional(v.string()),
  updatedAt: v.string(),
}).index("by_booking", ["bookingId"]);

/** One costed service. Amounts are in the booking currency. */
export const quoteLines = defineTable({
  bookingId: v.id("bookings"),
  section: quoteSectionValidator,
  description: v.string(),
  supplierId: v.optional(v.id("suppliers")),
  basis: quoteBasisValidator,
  // Rooms, vehicles, etc. Only used for "per_unit"
  quantity: v.number(),
  // Nights, days or number of services
  times: v.number(),
  unitCost: v.number(),
  // Undefined = use the booking's default markup
  markupPercent: v.optional(v.number()),
  // Staff only
  internalNotes: v.optional(v.string()),
  updatedAt: v.string(),
}).index("by_booking_and_section", ["bookingId", "section"]);
