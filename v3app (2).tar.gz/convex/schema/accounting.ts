import { defineTable } from "convex/server";
import { v } from "convex/values";
import { currencyValidator } from "./bookings";

// Mirrors V2 `accounting*` tables (single company) so the V2 data move is simple.
// All money is stored as integer minor units (cents) to avoid rounding drift.

export const ACCOUNT_TYPES = [
  "asset",
  "liability",
  "equity",
  "revenue",
  "expense",
] as const;
export type AccountType = (typeof ACCOUNT_TYPES)[number];
export const accountTypeValidator = v.union(
  v.literal("asset"),
  v.literal("liability"),
  v.literal("equity"),
  v.literal("revenue"),
  v.literal("expense"),
);

export const DOCUMENT_KINDS = ["invoice", "bill"] as const;
export type DocumentKind = (typeof DOCUMENT_KINDS)[number];
export const documentKindValidator = v.union(
  v.literal("invoice"),
  v.literal("bill"),
);

export const DOCUMENT_STATES = ["draft", "posted", "reversed"] as const;
export type DocumentState = (typeof DOCUMENT_STATES)[number];
export const documentStateValidator = v.union(
  v.literal("draft"),
  v.literal("posted"),
  v.literal("reversed"),
);

export const documentItemValidator = v.object({
  description: v.string(),
  netMinor: v.number(),
  taxMinor: v.number(),
});

export const journalEntryValidator = v.object({
  account: v.string(),
  debit: v.number(),
  credit: v.number(),
});

/** Singleton row: created once by the owner during setup. */
export const accountingSettings = defineTable({
  currency: currencyValidator,
  // Last closed calendar day (YYYY-MM-DD); nothing can be dated on or before it
  closedThrough: v.optional(v.string()),
  closedById: v.optional(v.id("users")),
  nextNumber: v.number(),
});

export const accountingAccounts = defineTable({
  code: v.string(),
  name: v.string(),
  type: accountTypeValidator,
  active: v.boolean(),
  // Accounts the ledger posts to automatically; they can't be switched off
  system: v.boolean(),
}).index("by_code", ["code"]);

export const accountingDocuments = defineTable({
  kind: documentKindValidator,
  state: documentStateValidator,
  // Assigned when posted, e.g. "INV-0000001"
  number: v.optional(v.string()),
  // Invoices are to clients, bills are from suppliers
  clientId: v.optional(v.id("clients")),
  supplierId: v.optional(v.id("suppliers")),
  // Denormalized so the list never needs extra reads
  partyName: v.string(),
  bookingId: v.optional(v.id("bookings")),
  bookingReference: v.optional(v.string()),
  // Revenue account for invoices, expense account for bills
  accountCode: v.string(),
  currency: currencyValidator,
  // Calendar days, YYYY-MM-DD
  issueDate: v.string(),
  dueDate: v.string(),
  reference: v.string(),
  items: v.array(documentItemValidator),
  netMinor: v.number(),
  taxMinor: v.number(),
  totalMinor: v.number(),
  paidMinor: v.number(),
  reversalReason: v.optional(v.string()),
  createdById: v.id("users"),
  postedById: v.optional(v.id("users")),
  // ISO 8601 UTC
  updatedAt: v.string(),
})
  .index("by_issue_date", ["issueDate"])
  .index("by_kind_and_issue_date", ["kind", "issueDate"])
  .index("by_state_and_issue_date", ["state", "issueDate"])
  .index("by_kind_and_state_and_issue_date", ["kind", "state", "issueDate"]);

export const accountingJournals = defineTable({
  documentId: v.id("accountingDocuments"),
  date: v.string(),
  event: v.union(
    v.literal("issue"),
    v.literal("payment"),
    v.literal("reversal"),
  ),
  entries: v.array(journalEntryValidator),
  reason: v.optional(v.string()),
  createdById: v.id("users"),
})
  .index("by_date", ["date"])
  .index("by_document", ["documentId"]);

export const accountingPayments = defineTable({
  documentId: v.id("accountingDocuments"),
  amountMinor: v.number(),
  date: v.string(),
  reference: v.string(),
  journalId: v.id("accountingJournals"),
  createdById: v.id("users"),
}).index("by_document", ["documentId"]);
