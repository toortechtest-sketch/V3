import { defineTable } from "convex/server";
import { v } from "convex/values";

/**
 * Additive contracted-inventory tables for the allotment feature. A pool
 * references exactly one existing resource (a dynamic-suppliers product or a
 * legacy room type) belonging to one supplier. Everything starts disabled
 * and with no capacity: a manager must explicitly create pools/slots with
 * real contracted quantities before any stock becomes sellable.
 */
export const allotmentPools = defineTable({
  supplierId: v.id("suppliers"),
  productId: v.optional(v.id("supplierProducts")),
  roomTypeId: v.optional(v.id("supplierRoomTypes")),
  // Exactly one resource ID; enforced by the manager mutation, not the schema.
  name: v.string(),
  kind: v.union(v.literal("hotel_night"), v.literal("session")),
  category: v.string(),
  // Explicit inventory unit: room / seat / vehicle / person / group / item…
  unit: v.string(),
  // IANA zone, never the browser's implicit timezone.
  timezone: v.string(),
  contractReference: v.string(),
  enabled: v.boolean(),
  createdById: v.id("users"),
  updatedAt: v.string(),
}).index("by_supplier", ["supplierId"]);

export const allotmentSlots = defineTable({
  poolId: v.id("allotmentPools"),
  serviceDate: v.string(),
  // Hotel: must equal serviceDate (YYYY-MM-DD). Session: a stable departure
  // identifier, never a translated display label.
  serviceKey: v.string(),
  capacity: v.number(),
  retired: v.number(),
  enabled: v.boolean(),
  stopSale: v.boolean(),
  // Explicit UTC epoch milliseconds.
  releaseAt: v.number(),
  replenishOnReturn: v.boolean(),
  updatedAt: v.string(),
}).index("by_pool_key", ["poolId", "serviceKey"]);

export const allotmentAllocations = defineTable({
  slotId: v.id("allotmentSlots"),
  reservationId: v.id("reservations"),
  quantity: v.number(),
  state: v.union(v.literal("hold"), v.literal("confirmed")),
  holdUntil: v.optional(v.number()),
})
  .index("by_slot", ["slotId"])
  .index("by_reservation", ["reservationId"]);

export const allotmentAudit = defineTable({
  reservationId: v.optional(v.id("reservations")),
  poolId: v.optional(v.id("allotmentPools")),
  actorId: v.optional(v.id("users")),
  source: v.string(),
  reason: v.string(),
  beforeJson: v.string(),
  afterJson: v.string(),
  createdAt: v.string(),
})
  .index("by_reservation", ["reservationId"])
  .index("by_pool", ["poolId"]);
