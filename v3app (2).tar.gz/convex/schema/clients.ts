import { defineTable } from "convex/server";
import { v } from "convex/values";

// Mirrors V2 `clients` so the V2 data move is a 1:1 mapping.
export const CLIENT_KINDS = ["company", "individual"] as const;
export type ClientKind = (typeof CLIENT_KINDS)[number];

export const clientKindValidator = v.union(
  v.literal("company"),
  v.literal("individual"),
);

export const clients = defineTable({
  kind: clientKindValidator,
  name: v.string(),
  // Only for individuals: the company they work for, if any.
  parentClientId: v.optional(v.id("clients")),
  contactName: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  address: v.optional(v.string()),
  city: v.optional(v.string()),
  country: v.optional(v.string()),
  taxId: v.optional(v.string()),
  notes: v.optional(v.string()),
  createdById: v.id("users"),
  // ISO 8601 UTC
  updatedAt: v.string(),
  // Lower-cased name for case-insensitive alphabetical ordering
  sortName: v.string(),
  // Lower-cased name, contact, email and city for one search index
  searchText: v.string(),
})
  .index("by_sort_name", ["sortName"])
  .index("by_kind_and_sort_name", ["kind", "sortName"])
  .index("by_parent", ["parentClientId"])
  .searchIndex("search_text", {
    searchField: "searchText",
    filterFields: ["kind"],
  });
