import { defineTable } from "convex/server";
import { v } from "convex/values";

// Same item types as V2 `itineraryItems` so the V2 data move is 1:1.
export const ITINERARY_ITEM_TYPES = [
  "arrival",
  "departure",
  "transfer",
  "hotel",
  "meal",
  "activity",
  "meeting",
  "flight",
  "free-time",
  "other",
] as const;
export type ItineraryItemType = (typeof ITINERARY_ITEM_TYPES)[number];

export const itineraryItemTypeValidator = v.union(
  v.literal("arrival"),
  v.literal("departure"),
  v.literal("transfer"),
  v.literal("hotel"),
  v.literal("meal"),
  v.literal("activity"),
  v.literal("meeting"),
  v.literal("flight"),
  v.literal("free-time"),
  v.literal("other"),
);

/**
 * Optional headline and notes for one calendar day of a booking. Days
 * themselves come from the booking dates; a row only exists once edited.
 */
export const itineraryDays = defineTable({
  bookingId: v.id("bookings"),
  // Calendar day, YYYY-MM-DD
  date: v.string(),
  title: v.optional(v.string()),
  notes: v.optional(v.string()),
}).index("by_booking_and_date", ["bookingId", "date"]);

/** One planned service or moment within a day. */
export const itineraryItems = defineTable({
  bookingId: v.id("bookings"),
  // Calendar day, YYYY-MM-DD
  date: v.string(),
  type: itineraryItemTypeValidator,
  // Local "HH:MM" at the destination
  startTime: v.optional(v.string()),
  endTime: v.optional(v.string()),
  title: v.string(),
  // Client-facing description
  description: v.optional(v.string()),
  location: v.optional(v.string()),
  supplierId: v.optional(v.id("suppliers")),
  // Staff only; never shown on client documents
  internalNotes: v.optional(v.string()),
  updatedAt: v.string(),
}).index("by_booking_and_date", ["bookingId", "date"]);
