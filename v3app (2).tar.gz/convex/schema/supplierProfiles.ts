import { defineTable } from "convex/server";
import { v } from "convex/values";
import { attributesValidator, serviceCategoryValidator } from "./supplierCategories";

// Additive tables for the dynamic suppliers model. Nothing here replaces or
// renames the legacy `suppliers`/`supplierRoomTypes` tables in
// `./suppliers.ts` — those keep working untouched. A supplier gains these
// rows progressively (via the dry-run backfill or new UI) without losing
// its original id, category or room data.

/**
 * One row per service category a supplier offers. Exactly one row per
 * supplier is flagged `isPrimary`; the rest are "additional services".
 * Unique per (supplierId, category) — enforced by the mutation layer via
 * `by_supplier` since Convex has no table-level unique constraint.
 */
export const supplierCapabilities = defineTable({
  supplierId: v.id("suppliers"),
  category: serviceCategoryValidator,
  // Free-text label, only meaningful when category is "other"
  otherLabel: v.optional(v.string()),
  isPrimary: v.boolean(),
  createdAt: v.string(),
})
  .index("by_supplier", ["supplierId"])
  .index("by_supplier_and_category", ["supplierId", "category"]);

/**
 * Supplier-level category details (not price rows). One per
 * (supplierId, category), created only when that capability is enabled.
 */
export const supplierProfiles = defineTable({
  supplierId: v.id("suppliers"),
  category: serviceCategoryValidator,
  schemaVersion: v.number(),
  attributes: attributesValidator,
  updatedAt: v.string(),
}).index("by_supplier_and_category", ["supplierId", "category"]);

export const SUPPLIER_PRODUCT_STATUSES = ["active", "archived"] as const;
export type SupplierProductStatus = (typeof SUPPLIER_PRODUCT_STATUSES)[number];
export const supplierProductStatusValidator = v.union(
  v.literal("active"),
  v.literal("archived"),
);

/** A named sellable item/offer belonging to one supplier and one category. */
export const supplierProducts = defineTable({
  supplierId: v.id("suppliers"),
  category: serviceCategoryValidator,
  name: v.string(),
  subtype: v.optional(v.string()),
  supplierReference: v.optional(v.string()),
  internalReference: v.optional(v.string()),
  description: v.optional(v.string()),
  status: supplierProductStatusValidator,
  schemaVersion: v.number(),
  attributes: attributesValidator,
  createdById: v.id("users"),
  updatedAt: v.string(),
})
  .index("by_supplier_and_category_and_status", ["supplierId", "category", "status"]);

export const TAX_MODES = ["included", "excluded", "unknown"] as const;
export type TaxMode = (typeof TAX_MODES)[number];
export const taxModeValidator = v.union(
  v.literal("included"),
  v.literal("excluded"),
  v.literal("unknown"),
);

export const RATE_BASES = ["net", "gross", "unknown"] as const;
export type RateBasis = (typeof RATE_BASES)[number];
export const rateBasisValidator = v.union(
  v.literal("net"),
  v.literal("gross"),
  v.literal("unknown"),
);

export const RATE_AVAILABILITY_STATUSES = ["on_request", "confirmed_allocation", "other"] as const;
export type RateAvailabilityStatus = (typeof RATE_AVAILABILITY_STATUSES)[number];
export const rateAvailabilityStatusValidator = v.union(
  v.literal("on_request"),
  v.literal("confirmed_allocation"),
  v.literal("other"),
);

/**
 * A price rule attached to a product. `amount` is undefined for an explicit
 * "price on request" row — never a stand-in for an unknown price. Zero is a
 * real, valid price.
 */
export const supplierRates = defineTable({
  productId: v.id("supplierProducts"),
  // Denormalized for the aggregated Rates view without an extra read per row
  supplierId: v.id("suppliers"),
  rateName: v.optional(v.string()),
  supplierRateReference: v.optional(v.string()),
  currency: v.string(),
  amount: v.optional(v.number()),
  pricingUnit: v.string(),
  validFrom: v.optional(v.string()),
  validTo: v.optional(v.string()),
  minQuantity: v.optional(v.number()),
  maxQuantity: v.optional(v.number()),
  minimumCharge: v.optional(v.number()),
  taxMode: taxModeValidator,
  taxRate: v.optional(v.number()),
  rateBasis: rateBasisValidator,
  availabilityStatus: rateAvailabilityStatusValidator,
  // Free-form structured notes (occupancy, board, route, weekdays, etc.)
  conditions: v.optional(v.string()),
  // Original supplier wording, preserved when interpretation is uncertain
  sourceWording: v.optional(v.string()),
  sourceDocumentId: v.optional(v.id("supplierDocuments")),
  createdById: v.id("users"),
  updatedAt: v.string(),
})
  .index("by_product", ["productId"])
  .index("by_supplier_and_valid_from", ["supplierId", "validFrom"]);

/** A person or department associated with a supplier. */
export const supplierContacts = defineTable({
  supplierId: v.id("suppliers"),
  name: v.string(),
  role: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  preferredLanguage: v.optional(v.string()),
  isPrimary: v.boolean(),
  notes: v.optional(v.string()),
  updatedAt: v.string(),
}).index("by_supplier", ["supplierId"]);

export const SUPPLIER_DOCUMENT_TYPES = [
  "contract",
  "rate_sheet",
  "menu",
  "licence",
  "insurance",
  "floor_plan",
  "other",
] as const;
export type SupplierDocumentType = (typeof SUPPLIER_DOCUMENT_TYPES)[number];
export const supplierDocumentTypeValidator = v.union(
  v.literal("contract"),
  v.literal("rate_sheet"),
  v.literal("menu"),
  v.literal("licence"),
  v.literal("insurance"),
  v.literal("floor_plan"),
  v.literal("other"),
);

/** A supplier-owned file, stored in Convex File Storage (private by default). */
export const supplierDocuments = defineTable({
  supplierId: v.id("suppliers"),
  title: v.string(),
  type: supplierDocumentTypeValidator,
  storageId: v.id("_storage"),
  mimeType: v.string(),
  size: v.number(),
  validFrom: v.optional(v.string()),
  validTo: v.optional(v.string()),
  uploadedById: v.id("users"),
  uploadedAt: v.string(),
}).index("by_supplier", ["supplierId"]);

/** Links one document to a product and/or rate it supports. */
export const supplierDocumentLinks = defineTable({
  documentId: v.id("supplierDocuments"),
  productId: v.optional(v.id("supplierProducts")),
  rateId: v.optional(v.id("supplierRates")),
})
  .index("by_document", ["documentId"])
  .index("by_product", ["productId"])
  .index("by_rate", ["rateId"]);

export const MIGRATION_LOG_STATUSES = ["mapped", "ambiguous", "skipped"] as const;
export type MigrationLogStatus = (typeof MIGRATION_LOG_STATUSES)[number];

/**
 * One row per legacy supplier processed by the dry-run/backfill tooling.
 * Keyed uniquely by supplierId so reruns are idempotent: a supplier already
 * logged is reported, not reprocessed or duplicated.
 */
export const supplierMigrationLog = defineTable({
  supplierId: v.id("suppliers"),
  status: v.union(v.literal("mapped"), v.literal("ambiguous"), v.literal("skipped")),
  legacyCategory: v.string(),
  mappedPrimaryType: v.optional(serviceCategoryValidator),
  note: v.optional(v.string()),
  dryRun: v.boolean(),
  processedAt: v.string(),
}).index("by_supplier", ["supplierId"]);
