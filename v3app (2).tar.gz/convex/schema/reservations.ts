import { defineTable } from "convex/server";
import { v } from "convex/values";
import { boardValidator, supplierCategoryValidator } from "./suppliers";

// Same statuses as V2 `reservations` so the V2 data move is 1:1.
export const RESERVATION_STATUSES = ["option", "requested", "confirmed", "cancelled"] as const;
export type ReservationStatus = (typeof RESERVATION_STATUSES)[number];

export const reservationStatusValidator = v.union(
  v.literal("option"),
  v.literal("requested"),
  v.literal("confirmed"),
  v.literal("cancelled"),
);

/** Fields a hotel-approved change may update on a confirmed reservation. */
export const changeFieldsValidator = v.object({
  units: v.optional(v.number()),
  startDate: v.optional(v.string()),
  endDate: v.optional(v.string()),
  description: v.optional(v.string()),
  board: v.optional(boardValidator),
});

/** One bookable service held with a supplier. Amounts are in the booking currency. */
export const reservations = defineTable({
  bookingId: v.id("bookings"),
  // Reservation types match supplier categories (V2 types are the same set)
  type: supplierCategoryValidator,
  status: reservationStatusValidator,
  supplierId: v.optional(v.id("suppliers")),
  // Always set, even when linked, so the reservation reads well on its own
  supplierName: v.string(),
  // Room type, transfer route, activity name…
  description: v.string(),
  // Calendar days, YYYY-MM-DD
  startDate: v.string(),
  endDate: v.optional(v.string()),
  units: v.number(),
  unitLabel: v.optional(v.string()),
  board: v.optional(boardValidator),
  // Supplier's confirmation number
  supplierRef: v.optional(v.string()),
  // Calendar day an option is held until
  optionUntil: v.optional(v.string()),
  costPerUnit: v.optional(v.number()),
  sellPerUnit: v.optional(v.number()),
  notes: v.optional(v.string()),
  // Links this reservation to a contracted-allotment pool slot. Absent means
  // legacy/on-request: never treated as unlimited stock on a confirmed link.
  allotmentPoolId: v.optional(v.id("allotmentPools")),
  // Required when the pool kind is "session": the dated departure identifier.
  allotmentSessionKey: v.optional(v.string()),
  // Explicit UTC epoch milliseconds; required whenever status is "option" and
  // the reservation is linked to a pool. Never inferred from optionUntil.
  allotmentHoldUntil: v.optional(v.number()),
  createdById: v.id("users"),
  updatedAt: v.string(),
}).index("by_booking_and_start_date", ["bookingId", "startDate"]);

/**
 * Idempotency ledger for `reservations.create`. A client retrying a timed-out
 * create (e.g. after a flaky connection) replays the same requestKey; a
 * fingerprint mismatch on a reused key is rejected rather than silently
 * creating a second reservation or applying different values.
 */
export const reservationCreateAttempts = defineTable({
  bookingId: v.id("bookings"),
  requestKey: v.string(),
  fingerprint: v.string(),
  reservationId: v.id("reservations"),
  createdAt: v.string(),
}).index("by_booking_and_key", ["bookingId", "requestKey"]);

export const CHANGE_STATUSES = ["pending", "approved", "declined", "withdrawn"] as const;
export type ChangeStatus = (typeof CHANGE_STATUSES)[number];

/**
 * A requested change to a confirmed reservation. Nothing is applied until the
 * hotel/supplier approves; the approval then updates the reservation.
 */
export const reservationChanges = defineTable({
  bookingId: v.id("bookings"),
  reservationId: v.id("reservations"),
  kind: v.union(v.literal("change"), v.literal("cancel")),
  // Requested new values (kind "change" only)
  changes: changeFieldsValidator,
  // Values at request time, for a clear before/after
  previous: changeFieldsValidator,
  message: v.optional(v.string()),
  status: v.union(
    v.literal("pending"),
    v.literal("approved"),
    v.literal("declined"),
    v.literal("withdrawn"),
  ),
  requestedById: v.id("users"),
  requestedAt: v.string(),
  respondedAt: v.optional(v.string()),
  // Who at the supplier answered and how, e.g. "Maria, by email"
  responseNote: v.optional(v.string()),
  recordedById: v.optional(v.id("users")),
})
  .index("by_booking", ["bookingId"])
  .index("by_reservation_and_status", ["reservationId", "status"]);
