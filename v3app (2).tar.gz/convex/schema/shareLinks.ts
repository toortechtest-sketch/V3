import { defineTable } from "convex/server";
import { v } from "convex/values";

export const SHARE_LINK_KINDS = ["offer", "itinerary", "confirmation", "hotel_response"] as const;
export type ShareLinkKind = (typeof SHARE_LINK_KINDS)[number];

export const shareLinkKindValidator = v.union(
  v.literal("offer"),
  v.literal("itinerary"),
  v.literal("confirmation"),
  v.literal("hotel_response"),
);

export const offerDecisionValidator = v.union(
  v.literal("accepted"),
  v.literal("declined"),
);

/**
 * A client- or supplier-facing link to one view of a booking. Opened by an
 * unguessable random token, never by a record ID, and only until it expires
 * or is revoked.
 */
export const shareLinks = defineTable({
  bookingId: v.id("bookings"),
  kind: shareLinkKindValidator,
  // Random, URL-safe, 48 hex characters
  token: v.string(),
  // ISO 8601 UTC
  expiresAt: v.string(),
  revokedAt: v.optional(v.string()),
  createdById: v.id("users"),
  viewCount: v.number(),
  lastViewedAt: v.optional(v.string()),
  // Hotel response links only: the one change request the supplier answers
  changeId: v.optional(v.id("reservationChanges")),
  // Offer links only: the client's answer (one per link)
  response: v.optional(
    v.object({
      decision: offerDecisionValidator,
      name: v.string(),
      message: v.optional(v.string()),
      respondedAt: v.string(),
    }),
  ),
})
  .index("by_token", ["token"])
  .index("by_booking", ["bookingId"]);

/** A change the client asked for from their confirmation link. Staff act on it. */
export const clientChangeRequests = defineTable({
  bookingId: v.id("bookings"),
  linkId: v.id("shareLinks"),
  name: v.string(),
  message: v.string(),
  // ISO 8601 UTC
  createdAt: v.string(),
  handledAt: v.optional(v.string()),
  handledById: v.optional(v.id("users")),
})
  .index("by_link", ["linkId"])
  .index("by_booking", ["bookingId"]);
