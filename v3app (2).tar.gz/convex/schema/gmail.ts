import { defineTable } from "convex/server";
import { v } from "convex/values";

/*
 * Gmail inbox. Mailboxes are private to the staff member who connects them.
 * No email content is stored: listing and reading happen live against the
 * Gmail API with the owner's own token. Only connection metadata, encrypted
 * tokens, short-lived OAuth state and content-free send attempts are kept.
 */

export const oauthStateStatus = v.union(
  v.literal("started"),
  v.literal("awaiting_completion"),
  v.literal("completed"),
  v.literal("failed"),
);

/** Single-use OAuth attempts. Only hashes of the state/completion secret are stored. */
export const gmailOAuthStates = defineTable({
  userId: v.id("users"),
  stateHash: v.string(),
  codeVerifier: v.string(), // encrypted
  returnOrigin: v.string(),
  status: oauthStateStatus,
  expiresAt: v.number(), // ms epoch
  createdAt: v.string(),
  // Initially "pending:<stateHash>"; replaced with the hash of the completion
  // secret once the callback succeeds. Always set so it can be indexed.
  completionHash: v.string(),
  pendingEmail: v.optional(v.string()),
  pendingScopes: v.optional(v.string()),
  pendingAccessToken: v.optional(v.string()), // encrypted
  pendingRefreshToken: v.optional(v.string()), // encrypted
  pendingExpiresAt: v.optional(v.number()),
  failureReason: v.optional(v.string()),
})
  .index("by_state_hash", ["stateHash"])
  .index("by_completion_hash", ["completionHash"])
  .index("by_user", ["userId"]);

export const connectionStatus = v.union(
  v.literal("active"),
  v.literal("needs_reconnect"),
);

export const gmailConnections = defineTable({
  userId: v.id("users"),
  googleEmail: v.string(),
  scopes: v.string(),
  status: connectionStatus,
  accessToken: v.string(), // AES-GCM encrypted
  refreshToken: v.string(), // AES-GCM encrypted
  accessTokenExpiresAt: v.number(), // ms epoch
  lastError: v.optional(v.string()),
  lastUsedAt: v.optional(v.string()),
  connectedAt: v.string(),
  updatedAt: v.string(),
}).index("by_user", ["userId"]);

export const sendStatus = v.union(
  v.literal("pending"),
  v.literal("sent"),
  v.literal("uncertain"),
  v.literal("failed"),
);

export const composeMode = v.union(
  v.literal("new"),
  v.literal("reply"),
  v.literal("forward"),
);

/** Idempotency ledger for sends. Holds no subject, body or addresses. */
export const gmailSendAttempts = defineTable({
  userId: v.id("users"),
  requestId: v.string(),
  messageIdHeader: v.string(),
  mode: composeMode,
  recipientCount: v.number(),
  status: sendStatus,
  gmailMessageId: v.optional(v.string()),
  gmailThreadId: v.optional(v.string()),
  errorCode: v.optional(v.string()),
  createdAt: v.string(),
  updatedAt: v.string(),
}).index("by_user_and_request", ["userId", "requestId"]);
