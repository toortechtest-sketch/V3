import { defineTable } from "convex/server";
import { v } from "convex/values";

// Values mirror V2 `groupFiles` so the V2 data move is a 1:1 mapping.
export const CURRENCIES = [
  "EUR",
  "USD",
  "GBP",
  "CHF",
  "AED",
  "SEK",
  "NOK",
  "DKK",
] as const;
export type Currency = (typeof CURRENCIES)[number];

export const currencyValidator = v.union(
  v.literal("EUR"),
  v.literal("USD"),
  v.literal("GBP"),
  v.literal("CHF"),
  v.literal("AED"),
  v.literal("SEK"),
  v.literal("NOK"),
  v.literal("DKK"),
);

export const BOOKING_STAGES = [
  "enquiry",
  "quoted",
  "confirmed",
  "operating",
  "closed",
  "cancelled",
] as const;
export type BookingStage = (typeof BOOKING_STAGES)[number];

/** Stages shown as columns on the board; closed/cancelled live in the list. */
export const BOARD_STAGES = [
  "enquiry",
  "quoted",
  "confirmed",
  "operating",
] as const satisfies readonly BookingStage[];

export const bookingStageValidator = v.union(
  v.literal("enquiry"),
  v.literal("quoted"),
  v.literal("confirmed"),
  v.literal("operating"),
  v.literal("closed"),
  v.literal("cancelled"),
);

export const BOOKING_TYPES = [
  "group",
  "meeting",
  "incentive",
  "conference",
  "event",
] as const;
export type BookingType = (typeof BOOKING_TYPES)[number];

export const bookingTypeValidator = v.union(
  v.literal("group"),
  v.literal("meeting"),
  v.literal("incentive"),
  v.literal("conference"),
  v.literal("event"),
);

export const bookings = defineTable({
  // Human readable sequential reference, e.g. "GM-2026-0001" (same as V2)
  reference: v.string(),
  title: v.string(),
  type: bookingTypeValidator,
  stage: bookingStageValidator,

  clientName: v.string(),
  clientContactName: v.optional(v.string()),
  clientContactEmail: v.optional(v.string()),
  clientContactPhone: v.optional(v.string()),

  destination: v.string(),
  // Calendar days, YYYY-MM-DD
  startDate: v.string(),
  endDate: v.string(),

  pax: v.number(),
  currency: currencyValidator,
  // Converts booking currency into the agency base currency (EUR)
  exchangeRateToBase: v.number(),
  // Default markup % suggested on top of costs (20 = cost + 20%)
  markupPercent: v.optional(v.number()),
  notes: v.optional(v.string()),

  // The staff member responsible. Agents and agency managers only see
  // bookings they own; owners and global managers see all.
  ownerId: v.id("users"),
  createdById: v.id("users"),
  // ISO 8601 UTC
  updatedAt: v.string(),

  // Lower-cased reference, title, client and destination for one search index
  searchText: v.string(),
})
  .index("by_reference", ["reference"])
  .index("by_start_date", ["startDate"])
  .index("by_stage_and_start_date", ["stage", "startDate"])
  .index("by_owner_and_start_date", ["ownerId", "startDate"])
  .index("by_owner_and_stage_and_start_date", ["ownerId", "stage", "startDate"])
  .searchIndex("search_text", {
    searchField: "searchText",
    filterFields: ["ownerId", "stage"],
  });
