import { defineTable } from "convex/server";
import { v } from "convex/values";

export const STAFF_ROLES = [
  "owner",
  "global_manager",
  "agency_manager",
  "agent",
] as const;

export type StaffRole = (typeof STAFF_ROLES)[number];

export const staffRoleValidator = v.union(
  v.literal("owner"),
  v.literal("global_manager"),
  v.literal("agency_manager"),
  v.literal("agent"),
);

export const users = defineTable({
  // Stable globally unique end user ID, saved as-is from identity.tokenIdentifier
  tokenIdentifier: v.string(),
  name: v.optional(v.string()),
  email: v.optional(v.string()),
}).index("by_token", ["tokenIdentifier"]);

// Roles live in their own table so a missing row means "no access" (fail
// closed) and "does an owner exist?" is a cheap indexed lookup.
export const staffRoles = defineTable({
  userId: v.id("users"),
  role: staffRoleValidator,
  // ISO 8601 UTC
  assignedAt: v.string(),
  assignedById: v.optional(v.id("users")),
})
  .index("by_user", ["userId"])
  .index("by_role", ["role"]);

// Pre-approved access for someone who hasn't signed in yet. Claimed (and
// deleted) on their first sign-in with a matching email.
export const staffInvites = defineTable({
  // Lowercased, trimmed
  email: v.string(),
  role: staffRoleValidator,
  invitedById: v.id("users"),
  // ISO 8601 UTC
  invitedAt: v.string(),
}).index("by_email", ["email"]);
