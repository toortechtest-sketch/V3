import { defineTable } from "convex/server";
import { v } from "convex/values";

// Statuses mirror V2 `tasks` so the V2 data move is a 1:1 mapping.
export const TASK_STATUSES = ["open", "in_progress", "done"] as const;
export type TaskStatus = (typeof TASK_STATUSES)[number];

export const taskStatusValidator = v.union(
  v.literal("open"),
  v.literal("in_progress"),
  v.literal("done"),
);

// Follow-ups are tasks about chasing someone (client, hotel, supplier). Later
// modules (offers, reservations) can create them automatically.
export const TASK_KINDS = ["task", "follow_up"] as const;
export type TaskKind = (typeof TASK_KINDS)[number];

export const taskKindValidator = v.union(
  v.literal("task"),
  v.literal("follow_up"),
);

/** Sorts after every YYYY-MM-DD so undated tasks come last. */
export const NO_DUE_KEY = "~";

export const tasks = defineTable({
  bookingId: v.id("bookings"),
  kind: taskKindValidator,
  title: v.string(),
  notes: v.optional(v.string()),
  // Calendar day, YYYY-MM-DD (V2 stored ISO datetimes)
  dueDate: v.optional(v.string()),
  status: taskStatusValidator,
  assigneeId: v.id("users"),
  createdById: v.id("users"),
  // ISO 8601 UTC
  updatedAt: v.string(),
  completedAt: v.optional(v.string()),

  // Derived from status/dueDate so open work can be paged in due order
  // (index fields can't be optional). Always set through `derived()`.
  isDone: v.boolean(),
  dueKey: v.string(),
})
  .index("by_booking_and_is_done_and_due_key", ["bookingId", "isDone", "dueKey"])
  .index("by_assignee_and_is_done_and_due_key", ["assigneeId", "isDone", "dueKey"])
  .index("by_is_done_and_due_key", ["isDone", "dueKey"]);
