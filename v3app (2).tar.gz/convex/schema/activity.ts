import { defineTable } from "convex/server";
import { v } from "convex/values";

// One row per continuous stretch of activity. A gap longer than
// ACTIVE_SESSION_GAP_MS (see convex/activity.ts) starts a new row instead of
// extending this one, so "today" and "this week" totals stay accurate.
export const activitySessions = defineTable({
  userId: v.id("users"),
  // ISO 8601 UTC
  startedAt: v.string(),
  // ISO 8601 UTC, bumped on every heartbeat
  lastSeenAt: v.string(),
  // Accumulated active time for this stretch, in milliseconds
  durationMs: v.number(),
}).index("by_user", ["userId"]);
