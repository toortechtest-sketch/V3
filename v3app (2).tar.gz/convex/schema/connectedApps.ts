import { defineTable } from "convex/server";
import { v } from "convex/values";

/** Integrations carried over from V2's Connected Apps. */
export const CONNECTED_APP_KEYS = [
  "gmail",
  "google_calendar",
  "google_drive",
  "google_contacts",
  "microsoft_365",
  "slack",
  "whatsapp",
  "xero",
  "quickbooks",
  "sage",
  "ai",
] as const;

export type ConnectedAppKey = (typeof CONNECTED_APP_KEYS)[number];

export const connectedAppKeyValidator = v.union(
  ...CONNECTED_APP_KEYS.map((key) => v.literal(key)),
);

export const APP_PREFERENCES = ["needed", "not_needed"] as const;
export type AppPreference = (typeof APP_PREFERENCES)[number];

export const appPreferenceValidator = v.union(
  v.literal("needed"),
  v.literal("not_needed"),
);

// One row per app, only once a manager has said whether the team needs it.
export const connectedApps = defineTable({
  appKey: connectedAppKeyValidator,
  preference: appPreferenceValidator,
  // ISO 8601 UTC
  updatedAt: v.string(),
  updatedById: v.id("users"),
}).index("by_app_key", ["appKey"]);
