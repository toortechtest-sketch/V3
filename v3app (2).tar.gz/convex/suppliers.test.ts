import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "agent");
  const pending = as(t, "pending");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await pending.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  return { owner, agent, pending };
}

const page = { paginationOpts: { numItems: 20, cursor: null } };
const HOTEL = {
  name: "Hotel Arts",
  category: "hotel",
  status: "active",
  hotelClass: "5-star",
  totalRooms: 483,
} as const;
const ROOM = { name: "Deluxe double", occupancy: 2, board: "breakfast" } as const;

describe("suppliers", () => {
  it("lists hotels and other suppliers together, filterable by type", async () => {
    const { agent } = await setup();
    await agent.mutation(api.suppliers.create, HOTEL);
    await agent.mutation(api.suppliers.create, {
      name: "Barcelona Coaches",
      category: "transfer",
      status: "preferred",
    });
    const all = await agent.query(api.suppliers.list, page);
    expect(all.page.map((s) => s.name)).toEqual(["Barcelona Coaches", "Hotel Arts"]);
    const hotels = await agent.query(api.suppliers.list, { ...page, category: "hotel" });
    expect(hotels.page.map((s) => s.name)).toEqual(["Hotel Arts"]);
  });

  it("blocks staff awaiting approval", async () => {
    const { pending } = await setup();
    await expect(pending.query(api.suppliers.list, page)).rejects.toThrow(
      /not been approved/,
    );
  });

  it("drops hotel-only details from non-hotel suppliers", async () => {
    const { agent } = await setup();
    const id = await agent.mutation(api.suppliers.create, {
      ...HOTEL,
      category: "restaurant",
    });
    const s = await agent.query(api.suppliers.get, { id });
    expect(s.hotelClass).toBeUndefined();
    expect(s.totalRooms).toBeUndefined();
  });

  it("manages hotel room types and only allows them on hotels", async () => {
    const { agent } = await setup();
    const hotel = await agent.mutation(api.suppliers.create, HOTEL);
    const room = await agent.mutation(api.suppliers.addRoomType, {
      supplierId: hotel,
      ...ROOM,
      nightlyRate: 240,
    });
    expect((await agent.query(api.suppliers.get, { id: hotel })).roomTypes).toHaveLength(1);

    await expect(
      agent.mutation(api.suppliers.addRoomType, { supplierId: hotel, ...ROOM, occupancy: 0 }),
    ).rejects.toThrow(/Sleeps/);
    await expect(
      agent.mutation(api.suppliers.update, { id: hotel, ...HOTEL, category: "venue" }),
    ).rejects.toThrow(/has room types/);

    const coach = await agent.mutation(api.suppliers.create, {
      name: "Coach",
      category: "transfer",
      status: "active",
    });
    await expect(
      agent.mutation(api.suppliers.addRoomType, { supplierId: coach, ...ROOM }),
    ).rejects.toThrow(/only for hotels/);

    await agent.mutation(api.suppliers.removeRoomType, { id: room });
    expect((await agent.query(api.suppliers.get, { id: hotel })).roomTypes).toHaveLength(0);
  });

  it("only managers delete, and deleting removes room types", async () => {
    const { owner, agent } = await setup();
    const hotel = await agent.mutation(api.suppliers.create, HOTEL);
    await agent.mutation(api.suppliers.addRoomType, { supplierId: hotel, ...ROOM });
    await expect(agent.mutation(api.suppliers.remove, { id: hotel })).rejects.toThrow(
      /permission required/,
    );
    await owner.mutation(api.suppliers.remove, { id: hotel });
    await expect(owner.query(api.suppliers.get, { id: hotel })).rejects.toThrow(
      /not found/,
    );
  });
});
