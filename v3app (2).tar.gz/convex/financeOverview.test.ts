import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Trip",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-11-02",
  endDate: "2026-11-05",
  pax: 10,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  await owner.mutation(api.users.updateCurrentUser, {});
  for (const agent of [agentA, agentB]) {
    const userId = await agent.mutation(api.users.updateCurrentUser, {});
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const a = await agentA.mutation(api.bookings.create, { ...BOOKING, title: "A trip" });
  const b = await agentB.mutation(api.bookings.create, {
    ...BOOKING,
    title: "B trip",
    currency: "USD",
    exchangeRateToBase: 0.5,
  });
  for (const id of [a, b]) await owner.mutation(api.bookings.setStage, { id, stage: "confirmed" });
  return { owner, agentA, agentB, a, b };
}

const TODAY = "2026-10-04";

describe("booking finance overview", () => {
  it("shows agents only their own bookings; managers see all", async () => {
    const { owner, agentA } = await setup();
    const mine = await agentA.query(api.financeOverview.overview, { scope: "active", today: TODAY });
    expect(mine.rows.map((r) => r.title)).toEqual(["A trip"]);
    expect(mine.seesAll).toBe(false);
    const all = await owner.query(api.financeOverview.overview, { scope: "active", today: TODAY });
    expect(all.rows.map((r) => r.title).sort()).toEqual(["A trip", "B trip"]);
  });

  it("totals overdue and outstanding in EUR using each booking's rate", async () => {
    const { owner, agentA, agentB, a, b } = await setup();
    await agentA.mutation(api.finance.createInvoice, {
      bookingId: a, kind: "invoice", label: "Deposit", amount: 300,
      issueDate: "2026-09-01", dueDate: "2026-09-15",
    });
    await agentA.mutation(api.finance.recordPayment, {
      bookingId: a, amount: 100, receivedDate: "2026-09-10", method: "card",
    });
    await agentB.mutation(api.finance.createInvoice, {
      bookingId: b, kind: "invoice", label: "Deposit", amount: 400,
      issueDate: "2026-10-01", dueDate: "2026-10-20",
    });
    const res = await owner.query(api.financeOverview.overview, { scope: "active", today: TODAY });
    const rowA = res.rows.find((r) => r.bookingId === a)!;
    expect(rowA).toMatchObject({ outstanding: 200, overdue: 300, overdueCount: 1 });
    const rowB = res.rows.find((r) => r.bookingId === b)!;
    expect(rowB).toMatchObject({ overdue: 0, nextDue: { date: "2026-10-20", amount: 400 } });
    // A: 200 EUR outstanding; B: 400 USD × 0.5 = 200 EUR
    expect(res.totals).toMatchObject({ outstanding: 400, overdue: 300, received: 100, overdueBookings: 1 });
  });

  it("rejects people without a role", async () => {
    const t = convexTest(schema, modules);
    await as(t, "owner").mutation(api.users.updateCurrentUser, {});
    const stranger = as(t, "x");
    await stranger.mutation(api.users.updateCurrentUser, {});
    await expect(
      stranger.query(api.financeOverview.overview, { scope: "active", today: TODAY }),
    ).rejects.toThrow(/not been approved/);
  });
});
