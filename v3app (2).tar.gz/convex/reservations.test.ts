import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-12-01",
  endDate: "2026-12-04",
  pax: 20,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

const HOTEL = {
  type: "hotel" as const,
  supplierName: "Hotel Arts",
  description: "Deluxe sea view",
  startDate: "2026-12-01",
  endDate: "2026-12-04",
  units: 10,
  unitLabel: "rooms",
  board: "breakfast" as const,
};

async function setup(status: "option" | "confirmed" = "confirmed") {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  const id = await agentA.mutation(api.reservations.create, { bookingId, status, ...HOTEL });
  return { agentA, agentB, bookingId, id };
}

describe("reservations", () => {
  it("allows direct edits and confirming while not confirmed", async () => {
    const { agentA, bookingId, id } = await setup("option");
    await agentA.mutation(api.reservations.update, { id, ...HOTEL, units: 12 });
    await agentA.mutation(api.reservations.setStatus, { id, status: "confirmed" });
    const { reservations } = await agentA.query(api.reservations.list, { bookingId });
    expect(reservations[0]).toMatchObject({ units: 12, status: "confirmed" });
  });

  it("blocks direct edits, status changes and removal once confirmed", async () => {
    const { agentA, id } = await setup();
    await expect(
      agentA.mutation(api.reservations.update, { id, ...HOTEL, units: 12 }),
    ).rejects.toThrow(/Request a change/);
    await expect(
      agentA.mutation(api.reservations.setStatus, { id, status: "cancelled" }),
    ).rejects.toThrow(/Request a change/);
    await expect(agentA.mutation(api.reservations.remove, { id })).rejects.toThrow(
      /Request a change/,
    );
  });

  it("applies a change only when the supplier approves", async () => {
    const { agentA, bookingId, id } = await setup();
    const changeId = await agentA.mutation(api.reservations.requestChange, {
      reservationId: id,
      kind: "change",
      changes: { units: 12, board: "half-board" },
    });
    let { reservations } = await agentA.query(api.reservations.list, { bookingId });
    expect(reservations[0].units).toBe(10);
    expect(reservations[0].pendingChange?.previous).toEqual({ units: 10, board: "breakfast" });

    await expect(
      agentA.mutation(api.reservations.requestChange, {
        reservationId: id,
        kind: "change",
        changes: { units: 14 },
      }),
    ).rejects.toThrow(/already waiting/);

    await agentA.mutation(api.reservations.recordResponse, {
      changeId,
      decision: "approved",
      responseNote: "Maria by email",
    });
    ({ reservations } = await agentA.query(api.reservations.list, { bookingId }));
    expect(reservations[0]).toMatchObject({ units: 12, board: "half-board", status: "confirmed" });
    expect(reservations[0].pendingChange).toBeNull();
    await expect(
      agentA.mutation(api.reservations.recordResponse, { changeId, decision: "declined" }),
    ).rejects.toThrow(/already been answered/);
  });

  it("leaves the reservation untouched when declined, and cancels on approved cancel", async () => {
    const { agentA, bookingId, id } = await setup();
    const declined = await agentA.mutation(api.reservations.requestChange, {
      reservationId: id,
      kind: "change",
      changes: { units: 2 },
    });
    await agentA.mutation(api.reservations.recordResponse, { changeId: declined, decision: "declined" });
    const cancel = await agentA.mutation(api.reservations.requestChange, {
      reservationId: id,
      kind: "cancel",
      changes: {},
    });
    await agentA.mutation(api.reservations.recordResponse, { changeId: cancel, decision: "approved" });
    const { reservations } = await agentA.query(api.reservations.list, { bookingId });
    expect(reservations[0]).toMatchObject({ units: 10, status: "cancelled" });
    expect(reservations[0].history).toHaveLength(2);
  });

  it("rejects an empty change request", async () => {
    const { agentA, id } = await setup();
    await expect(
      agentA.mutation(api.reservations.requestChange, {
        reservationId: id,
        kind: "change",
        changes: { units: 10 },
      }),
    ).rejects.toThrow(/at least one detail/);
  });

  it("hides another agent's reservations", async () => {
    const { agentB, bookingId, id } = await setup();
    await expect(agentB.query(api.reservations.list, { bookingId })).rejects.toThrow(
      /Booking not found/,
    );
    await expect(
      agentB.mutation(api.reservations.requestChange, { reservationId: id, kind: "cancel", changes: {} }),
    ).rejects.toThrow(/Booking not found/);
  });
});
