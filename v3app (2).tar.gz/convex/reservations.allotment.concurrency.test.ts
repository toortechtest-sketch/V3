import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import type { Id } from "./_generated/dataModel";
import schema from "./schema";
import { modules } from "./test.setup";

/**
 * Genuine concurrency, multi-step rollback, retry-idempotency and
 * stop-sale/release-boundary coverage for the allotment feature.
 *
 * reservations.allotment.test.ts only exercises sequential calls (explicitly
 * flagged by the vendor's INTEGRATION.md as NOT a concurrency test). This
 * file exercises actual parallel mutations and multi-slot failure paths.
 *
 * Pool/slot management mutations (milestone-32) don't exist yet, so capacity
 * and slot rows are seeded directly via `t.run`, the same approach the
 * existing allotment test file uses.
 */

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-12-01",
  endDate: "2026-12-04",
  pax: 20,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

const NIGHTS = ["2026-12-01", "2026-12-02"];

function hotelReservation(nights = 2) {
  return {
    type: "hotel" as const,
    supplierName: "Hotel Arts",
    description: "Deluxe sea view",
    startDate: NIGHTS[0],
    endDate: nights === 1 ? NIGHTS[1] : "2026-12-03",
    units: 1,
    unitLabel: "rooms",
    board: "breakfast" as const,
  };
}

/** Seeds a signed-in owner/agent, a booking, a supplier, and a pool with one slot per night. */
async function setup(capacities: number[] = [1, 1]) {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  const ownerId = await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: aId, role: "agent" });
  // Manager so it can access agentA's booking too: canAccessBooking only
  // lets a non-manager agent touch bookings they own themselves.
  await owner.mutation(api.staff.setRole, { userId: bId, role: "global_manager" });
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  const supplierId = await agentA.mutation(api.suppliers.create, {
    name: "Hotel Arts",
    category: "hotel",
    status: "active",
  });

  const { poolId, slotIds } = await t.run(async (ctx) => {
    const roomTypeId = await ctx.db.insert("supplierRoomTypes", {
      supplierId,
      name: "Deluxe sea view",
      occupancy: 2,
      board: "breakfast",
    });
    const poolId = await ctx.db.insert("allotmentPools", {
      supplierId,
      roomTypeId,
      name: "Deluxe sea view",
      kind: "hotel_night",
      category: "hotel",
      unit: "room",
      timezone: "Europe/Madrid",
      contractReference: "CONTRACT-1",
      enabled: true,
      createdById: ownerId,
      updatedAt: new Date().toISOString(),
    });
    const far = Date.now() + 1000 * 60 * 60 * 24 * 365;
    const slotIds: Id<"allotmentSlots">[] = [];
    for (let i = 0; i < NIGHTS.length; i++) {
      slotIds.push(
        await ctx.db.insert("allotmentSlots", {
          poolId,
          serviceDate: NIGHTS[i],
          serviceKey: NIGHTS[i],
          capacity: capacities[i] ?? 1,
          retired: 0,
          enabled: true,
          stopSale: false,
          releaseAt: far,
          replenishOnReturn: true,
          updatedAt: new Date().toISOString(),
        }),
      );
    }
    return { poolId, slotIds };
  });

  return { t, agentA, agentB, owner, bookingId, supplierId, poolId, slotIds };
}

async function allocationsFor(t: ReturnType<typeof convexTest>, reservationId: Id<"reservations">) {
  const all = await t.run((ctx) => ctx.db.query("allotmentAllocations").collect());
  return all.filter((row) => row.reservationId === reservationId);
}

async function auditCountFor(t: ReturnType<typeof convexTest>, reservationId: Id<"reservations">) {
  const all = await t.run((ctx) => ctx.db.query("allotmentAudit").collect());
  return all.filter((row) => row.reservationId === reservationId).length;
}

describe("allotment concurrency and lifecycle edge cases", () => {
  it("lets only one of two concurrent confirmations win the last room", async () => {
    const { t, agentA, agentB, bookingId, supplierId, poolId } = await setup([1, 1]);
    const args = {
      bookingId,
      status: "confirmed" as const,
      supplierId,
      allotmentPoolId: poolId,
      ...hotelReservation(),
    };
    // Fired together, not awaited sequentially: this is a genuine concurrent
    // race over the same slot capacity, unlike the sequential existing tests.
    const results = await Promise.allSettled([
      agentA.mutation(api.reservations.create, args),
      agentB.mutation(api.reservations.create, args),
    ]);

    const fulfilled = results.filter((r) => r.status === "fulfilled");
    const rejected = results.filter((r) => r.status === "rejected");
    expect(fulfilled).toHaveLength(1);
    expect(rejected).toHaveLength(1);
    expect(String((rejected[0] as PromiseRejectedResult).reason)).toMatch(/SOLD_OUT/);

    const winnerId = (fulfilled[0] as PromiseFulfilledResult<Id<"reservations">>).value;
    const rows = await allocationsFor(t, winnerId);
    expect(rows).toHaveLength(2);
    expect(rows.every((r) => r.state === "confirmed" && r.quantity === 1)).toBe(true);
  });

  it("rolls back every night when any single night in a multi-night stay is full", async () => {
    // Night 1 has room for two bookings, night 2 only one: a second multi-night
    // booking must fail entirely, including on the night that had room.
    const { t, agentA, bookingId, supplierId, poolId } = await setup([2, 1]);
    const first = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...hotelReservation(),
    });
    expect(await allocationsFor(t, first)).toHaveLength(2);

    await expect(
      agentA.mutation(api.reservations.create, {
        bookingId,
        status: "confirmed",
        supplierId,
        allotmentPoolId: poolId,
        ...hotelReservation(),
      }),
    ).rejects.toThrow(/SOLD_OUT/);

    // No partial allocation leaked onto the night that still had capacity.
    const all = await t.run((ctx) => ctx.db.query("allotmentAllocations").collect());
    expect(all).toHaveLength(2);
    expect(all.every((r) => r.reservationId === first)).toBe(true);
  });

  it("confirming a hold is idempotent across a retried status update", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup([1, 1]);
    const id = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "option",
      supplierId,
      allotmentPoolId: poolId,
      allotmentHoldUntil: Date.now() + 60_000,
      ...hotelReservation(),
    });
    expect(await allocationsFor(t, id)).toHaveLength(2);

    // Simulate a client retrying the same confirm request after a flaky response.
    await agentA.mutation(api.reservations.setStatus, { id, status: "confirmed" });
    await agentA.mutation(api.reservations.setStatus, { id, status: "confirmed" });

    const rows = await allocationsFor(t, id);
    expect(rows).toHaveLength(2);
    expect(rows.every((r) => r.state === "confirmed" && r.quantity === 1)).toBe(true);
  });

  it("blocks new consumption under stop-sale but lets an existing hold confirm", async () => {
    const { t, agentA, agentB, bookingId, supplierId, poolId, slotIds } = await setup([1, 1]);
    const held = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "option",
      supplierId,
      allotmentPoolId: poolId,
      allotmentHoldUntil: Date.now() + 60_000,
      ...hotelReservation(),
    });

    // A manager stops new sales on the pool (no admin mutation exists yet, so
    // the stop-sale flag is set directly, the same way the pool would be
    // edited once milestone-32 ships).
    await t.run(async (ctx) => {
      for (const slotId of slotIds) {
        await ctx.db.patch("allotmentSlots", slotId, { stopSale: true });
      }
    });

    // New consumption is rejected.
    await expect(
      agentB.mutation(api.reservations.create, {
        bookingId,
        status: "confirmed",
        supplierId,
        allotmentPoolId: poolId,
        ...hotelReservation(),
      }),
    ).rejects.toThrow(/CLOSED/);

    // The already-held stock can still confirm without increasing quantity.
    await agentA.mutation(api.reservations.setStatus, { id: held, status: "confirmed" });
    const rows = await allocationsFor(t, held);
    expect(rows).toHaveLength(2);
    expect(rows.every((r) => r.state === "confirmed")).toBe(true);
  });

  it("keeps a confirmed-change request pending when approval would overbook", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup([1, 1]);
    const id = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...hotelReservation(),
    });
    const changeId = await agentA.mutation(api.reservations.requestChange, {
      reservationId: id,
      kind: "change",
      changes: { units: 2 },
    });

    await expect(
      agentA.mutation(api.reservations.recordResponse, { changeId, decision: "approved" }),
    ).rejects.toThrow(/SOLD_OUT/);

    const change = await t.run((ctx) => ctx.db.get("reservationChanges", changeId));
    expect(change?.status).toBe("pending");
    const reservation = await t.run((ctx) => ctx.db.get("reservations", id));
    expect(reservation?.units).toBe(1);
    const rows = await allocationsFor(t, id);
    expect(rows).toHaveLength(2);
    expect(rows.every((r) => r.quantity === 1 && r.state === "confirmed")).toBe(true);
  });

  it("reconciles inventory through the supplier response-link approval path", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup([1, 1]);
    const id = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...hotelReservation(),
    });
    const changeId = await agentA.mutation(api.reservations.requestChange, {
      reservationId: id,
      kind: "cancel",
      changes: {},
    });

    // A 48-hex-char token, same shape clientLinks.view/respondAsHotel require.
    const token = "a".repeat(48);
    await t.run(async (ctx) => {
      await ctx.db.insert("shareLinks", {
        bookingId,
        kind: "hotel_response",
        token,
        expiresAt: new Date(Date.now() + 86_400_000).toISOString(),
        createdById: (await ctx.db.query("users").first())!._id,
        viewCount: 0,
        changeId,
      });
    });

    const anon = t; // respondAsHotel requires no sign-in: the token is the key
    await anon.mutation(api.clientLinks.respondAsHotel, {
      token,
      decision: "approved",
      name: "Maria",
    });

    const change = await t.run((ctx) => ctx.db.get("reservationChanges", changeId));
    expect(change?.status).toBe("approved");
    expect(await allocationsFor(t, id)).toHaveLength(0);
  });

  it("does not double-release or double-audit a cancellation that is retried", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup([1, 1]);
    const id = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...hotelReservation(),
    });
    const changeId = await agentA.mutation(api.reservations.requestChange, {
      reservationId: id,
      kind: "cancel",
      changes: {},
    });
    await agentA.mutation(api.reservations.recordResponse, { changeId, decision: "approved" });
    expect(await allocationsFor(t, id)).toHaveLength(0);
    const auditsAfterFirst = await auditCountFor(t, id);

    // A client retrying the same "approve" request hits the already-answered
    // guard and must not release stock a second time or audit twice.
    await expect(
      agentA.mutation(api.reservations.recordResponse, { changeId, decision: "approved" }),
    ).rejects.toThrow(/already been answered/);

    expect(await allocationsFor(t, id)).toHaveLength(0);
    expect(await auditCountFor(t, id)).toBe(auditsAfterFirst);
  });
});
