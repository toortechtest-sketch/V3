import { defineSchema } from "convex/server";
import { staffInvites, staffRoles, users } from "./schema/staff";
import { bookings } from "./schema/bookings";
import { clients } from "./schema/clients";
import { supplierRoomTypes, suppliers } from "./schema/suppliers";
import {
  supplierCapabilities,
  supplierContacts,
  supplierDocumentLinks,
  supplierDocuments,
  supplierMigrationLog,
  supplierProducts,
  supplierProfiles,
  supplierRates,
} from "./schema/supplierProfiles";
import { itineraryDays, itineraryItems } from "./schema/itinerary";
import { tasks } from "./schema/tasks";
import { quoteLines, quotes } from "./schema/quotes";
import {
  reservationChanges,
  reservationCreateAttempts,
  reservations,
} from "./schema/reservations";
import { rooms, travellers } from "./schema/travellers";
import {
  gmailConnections,
  gmailOAuthStates,
  gmailSendAttempts,
} from "./schema/gmail";
import {
  accountingAccounts,
  accountingDocuments,
  accountingJournals,
  accountingPayments,
  accountingSettings,
} from "./schema/accounting";
import { clientChangeRequests, shareLinks } from "./schema/shareLinks";
import { bookingFinance, invoices, paymentInstallments, payments } from "./schema/finance";
import { connectedApps } from "./schema/connectedApps";
import { activitySessions } from "./schema/activity";
import {
  allotmentAllocations,
  allotmentAudit,
  allotmentPools,
  allotmentSlots,
} from "./schema/allotments";

export default defineSchema({
  users,
  staffRoles,
  staffInvites,
  bookings,
  clients,
  suppliers,
  supplierRoomTypes,
  supplierCapabilities,
  supplierProfiles,
  supplierProducts,
  supplierRates,
  supplierContacts,
  supplierDocuments,
  supplierDocumentLinks,
  supplierMigrationLog,
  itineraryDays,
  itineraryItems,
  tasks,
  quotes,
  quoteLines,
  travellers,
  rooms,
  reservations,
  reservationChanges,
  reservationCreateAttempts,
  shareLinks,
  clientChangeRequests,
  connectedApps,
  bookingFinance,
  invoices,
  paymentInstallments,
  payments,
  accountingSettings,
  accountingAccounts,
  accountingDocuments,
  accountingJournals,
  accountingPayments,
  gmailOAuthStates,
  gmailConnections,
  gmailSendAttempts,
  activitySessions,
  allotmentPools,
  allotmentSlots,
  allotmentAllocations,
  allotmentAudit,
});
