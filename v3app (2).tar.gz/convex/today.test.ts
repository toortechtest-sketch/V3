import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";
import { addDays } from "./today";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const TODAY = "2026-10-04";
const DRAFT = {
  title: "Trip",
  type: "group" as const,
  clientName: "Acme",
  destination: "Lisbon",
  pax: 10,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "agent");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  return { owner, agent };
}

type Client = Awaited<ReturnType<typeof setup>>["owner"];

async function booking(
  who: Client,
  title: string,
  stage: "enquiry" | "quoted" | "confirmed" | "operating" | "closed",
  start: number,
  end: number,
) {
  return await who.mutation(api.bookings.create, {
    ...DRAFT,
    title,
    stage,
    startDate: addDays(TODAY, start),
    endDate: addDays(TODAY, end),
  });
}

describe("today overview", () => {
  it("sorts bookings into the right sections", async () => {
    const { owner } = await setup();
    const onTrip = await booking(owner, "On trip", "operating", -2, 2);
    await booking(owner, "Soon", "confirmed", 5, 8);
    await booking(owner, "Later", "confirmed", 30, 33);
    await booking(owner, "Ended", "confirmed", -10, -3);
    await booking(owner, "Closed", "closed", -10, -3);
    await booking(owner, "New enquiry", "enquiry", 40, 42);
    const quoted = await booking(owner, "Quoted", "quoted", 60, 62);
    await owner.mutation(api.quotes.saveSettings, {
      bookingId: quoted,
      freePlaces: 0,
      validUntil: addDays(TODAY, 3),
    });
    await owner.mutation(api.itinerary.addItem, {
      bookingId: onTrip,
      date: TODAY,
      type: "activity",
      title: "Tram tour",
      startTime: "10:00",
    });

    const data = await owner.query(api.today.overview, { today: TODAY });
    const titles = (rows: { title: string }[]) => rows.map((r) => r.title);
    expect(titles(data.travelling)).toEqual(["On trip"]);
    expect(titles(data.departing)).toEqual(["Soon"]);
    expect(titles(data.toReconcile)).toEqual(["Ended"]);
    expect(titles(data.needsQuote)).toEqual(["New enquiry"]);
    expect(titles(data.expiringQuotes)).toEqual(["Quoted"]);
    expect(data.programme.map((p) => p.title)).toEqual(["Tram tour"]);
  });

  it("agents only see their own bookings", async () => {
    const { owner, agent } = await setup();
    await booking(owner, "Owner trip", "operating", 0, 2);
    await booking(agent, "Agent trip", "operating", 0, 2);
    const forAgent = await agent.query(api.today.overview, { today: TODAY });
    expect(forAgent.travelling.map((b) => b.title)).toEqual(["Agent trip"]);
    expect(forAgent.seesAll).toBe(false);

    const forOwner = await owner.query(api.today.overview, { today: TODAY });
    expect(forOwner.travelling).toHaveLength(2);
    const mine = await owner.query(api.today.overview, { today: TODAY, mineOnly: true });
    expect(mine.travelling.map((b) => b.title)).toEqual(["Owner trip"]);
  });
});
