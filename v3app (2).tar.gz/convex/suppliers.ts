import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";
import { mutation, query, type MutationCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { fail, requireManager, requireStaff } from "./lib/access";
import { findPoolReferencing } from "./suppliers/allotments";
import { currencyValidator, type Currency } from "./schema/bookings";
import {
  boardValidator,
  hotelClassValidator,
  supplierCategoryValidator,
  supplierStatusValidator,
  type HotelClass,
  type SupplierCategory,
  type SupplierStatus,
} from "./schema/suppliers";

// Room types load in full on the supplier page, so keep each hotel bounded.
export const ROOM_TYPE_LIMIT = 100;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const editableFields = {
  name: v.string(),
  legalName: v.optional(v.string()),
  category: supplierCategoryValidator,
  status: supplierStatusValidator,
  city: v.optional(v.string()),
  country: v.optional(v.string()),
  address: v.optional(v.string()),
  website: v.optional(v.string()),
  contactName: v.optional(v.string()),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  notes: v.optional(v.string()),
  hotelClass: v.optional(hotelClassValidator),
  totalRooms: v.optional(v.number()),
  meetingRooms: v.optional(v.number()),
  largestMeetingCapacity: v.optional(v.number()),
  currency: v.optional(currencyValidator),
};

export type SupplierFields = Fields;
type Fields = {
  name: string;
  legalName?: string;
  category: SupplierCategory;
  status: SupplierStatus;
  city?: string;
  country?: string;
  address?: string;
  website?: string;
  contactName?: string;
  email?: string;
  phone?: string;
  notes?: string;
  hotelClass?: HotelClass;
  totalRooms?: number;
  meetingRooms?: number;
  largestMeetingCapacity?: number;
  currency?: Currency;
};

const trim = (s: string | undefined) => s?.trim() || undefined;

/** Trim strings, drop empties, and strip hotel-only fields from non-hotels. */
function clean(fields: Fields): Fields {
  const isHotel = fields.category === "hotel";
  return {
    name: fields.name.trim(),
    legalName: trim(fields.legalName),
    category: fields.category,
    status: fields.status,
    city: trim(fields.city),
    country: trim(fields.country),
    address: trim(fields.address),
    website: trim(fields.website),
    contactName: trim(fields.contactName),
    email: trim(fields.email)?.toLowerCase(),
    phone: trim(fields.phone),
    notes: trim(fields.notes),
    currency: fields.currency,
    hotelClass: isHotel ? fields.hotelClass : undefined,
    totalRooms: isHotel ? fields.totalRooms : undefined,
    meetingRooms: isHotel ? fields.meetingRooms : undefined,
    largestMeetingCapacity: isHotel ? fields.largestMeetingCapacity : undefined,
  };
}

function checkCount(value: number | undefined, label: string) {
  if (value !== undefined && (!Number.isInteger(value) || value < 0)) {
    fail("BAD_REQUEST", `${label} must be a whole number of 0 or more.`);
  }
}

function validate(fields: Fields) {
  if (!fields.name) fail("BAD_REQUEST", "Add the supplier name.");
  if (fields.email && !EMAIL_PATTERN.test(fields.email)) {
    fail("BAD_REQUEST", "That email address doesn't look right.");
  }
  checkCount(fields.totalRooms, "Total rooms");
  checkCount(fields.meetingRooms, "Meeting rooms");
  checkCount(fields.largestMeetingCapacity, "Largest meeting capacity");
}

function derived(fields: Fields) {
  return {
    sortName: fields.name.toLowerCase(),
    searchText: [fields.name, fields.contactName, fields.email, fields.city]
      .filter(Boolean)
      .join(" ")
      .toLowerCase(),
  };
}

async function requireSupplier(ctx: MutationCtx, id: Id<"suppliers">) {
  const supplier = await ctx.db.get("suppliers", id);
  if (!supplier) fail("NOT_FOUND", "Supplier not found.");
  return supplier;
}

async function requireHotel(ctx: MutationCtx, id: Id<"suppliers">) {
  const supplier = await requireSupplier(ctx, id);
  if (supplier.category !== "hotel") {
    fail("BAD_REQUEST", "Room types are only for hotels.");
  }
  return supplier;
}

function roomTypesOf(ctx: MutationCtx, supplierId: Id<"suppliers">) {
  return ctx.db
    .query("supplierRoomTypes")
    .withIndex("by_supplier", (q) => q.eq("supplierId", supplierId));
}

export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    category: v.optional(supplierCategoryValidator),
    search: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const { category } = args;
    const term = args.search?.trim().toLowerCase();
    if (term) {
      return await ctx.db
        .query("suppliers")
        .withSearchIndex("search_text", (q) => {
          const s = q.search("searchText", term);
          return category ? s.eq("category", category) : s;
        })
        .paginate(args.paginationOpts);
    }
    const ordered = category
      ? ctx.db
          .query("suppliers")
          .withIndex("by_category_and_sort_name", (q) =>
            q.eq("category", category),
          )
      : ctx.db.query("suppliers").withIndex("by_sort_name");
    return await ordered.paginate(args.paginationOpts);
  },
});

export const get = query({
  args: { id: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const supplier = await ctx.db.get("suppliers", args.id);
    if (!supplier) fail("NOT_FOUND", "Supplier not found.");
    const [creator, roomTypes] = await Promise.all([
      ctx.db.get("users", supplier.createdById),
      supplier.category === "hotel"
        ? ctx.db
            .query("supplierRoomTypes")
            .withIndex("by_supplier", (q) => q.eq("supplierId", supplier._id))
            .take(ROOM_TYPE_LIMIT)
        : ([] satisfies Doc<"supplierRoomTypes">[]),
    ]);
    return {
      ...supplier,
      createdByName: creator?.name ?? creator?.email ?? null,
      roomTypes: roomTypes.sort(
        (a, b) => a.occupancy - b.occupancy || a.name.localeCompare(b.name),
      ),
    };
  },
});

/** Shared by `create` and AI import so both apply the same rules. */
export async function insertSupplier(
  ctx: MutationCtx,
  createdById: Id<"users">,
  input: Fields,
): Promise<Id<"suppliers">> {
  const fields = clean(input);
  validate(fields);
  return await ctx.db.insert("suppliers", {
    ...fields,
    ...derived(fields),
    createdById,
    updatedAt: new Date().toISOString(),
  });
}

export const create = mutation({
  args: editableFields,
  handler: async (ctx, args): Promise<Id<"suppliers">> => {
    const staff = await requireStaff(ctx);
    return await insertSupplier(ctx, staff.user._id, args);
  },
});

export const update = mutation({
  args: { id: v.id("suppliers"), ...editableFields },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const { id, ...rest } = args;
    const existing = await requireSupplier(ctx, id);
    const fields = clean(rest);
    validate(fields);
    if (existing.category === "hotel" && fields.category !== "hotel") {
      if (await roomTypesOf(ctx, id).first()) {
        fail(
          "CONFLICT",
          "This hotel has room types. Remove them first, then change the type.",
        );
      }
    }
    // replace (not patch) so cleared optional fields are actually removed
    await ctx.db.replace("suppliers", id, {
      ...fields,
      ...derived(fields),
      createdById: existing.createdById,
      updatedAt: new Date().toISOString(),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("suppliers") },
  handler: async (ctx, args) => {
    await requireManager(ctx);
    await requireSupplier(ctx, args.id);
    const pool = await ctx.db
      .query("allotmentPools")
      .withIndex("by_supplier", (q) => q.eq("supplierId", args.id))
      .first();
    if (pool) {
      fail("CONFLICT", "This supplier has an allotment. Delete it first.");
    }
    // Bounded by ROOM_TYPE_LIMIT, so one transaction is enough.
    const rooms = await roomTypesOf(ctx, args.id).take(ROOM_TYPE_LIMIT + 1);
    await Promise.all(rooms.map((r) => ctx.db.delete("supplierRoomTypes", r._id)));
    await ctx.db.delete("suppliers", args.id);
    return null;
  },
});

const roomFields = {
  name: v.string(),
  occupancy: v.number(),
  board: boardValidator,
  nightlyRate: v.optional(v.number()),
  notes: v.optional(v.string()),
};

export type RoomFields = {
  name: string;
  occupancy: number;
  board: Doc<"supplierRoomTypes">["board"];
  nightlyRate?: number;
  notes?: string;
};

export function cleanRoom(fields: RoomFields): RoomFields {
  const room = { ...fields, name: fields.name.trim(), notes: trim(fields.notes) };
  if (!room.name) fail("BAD_REQUEST", "Add the room type name.");
  if (!Number.isInteger(room.occupancy) || room.occupancy < 1 || room.occupancy > 50) {
    fail("BAD_REQUEST", "Sleeps must be a whole number from 1 to 50.");
  }
  if (room.nightlyRate !== undefined && !(room.nightlyRate >= 0)) {
    fail("BAD_REQUEST", "Nightly rate can't be negative.");
  }
  return room;
}

export const addRoomType = mutation({
  args: { supplierId: v.id("suppliers"), ...roomFields },
  handler: async (ctx, args): Promise<Id<"supplierRoomTypes">> => {
    await requireStaff(ctx);
    const { supplierId, ...rest } = args;
    await requireHotel(ctx, supplierId);
    const existing = await roomTypesOf(ctx, supplierId).take(ROOM_TYPE_LIMIT);
    if (existing.length >= ROOM_TYPE_LIMIT) {
      fail("CONFLICT", `A hotel can have up to ${ROOM_TYPE_LIMIT} room types.`);
    }
    return await ctx.db.insert("supplierRoomTypes", {
      supplierId,
      ...cleanRoom(rest),
    });
  },
});

export const updateRoomType = mutation({
  args: { id: v.id("supplierRoomTypes"), ...roomFields },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const { id, ...rest } = args;
    const room = await ctx.db.get("supplierRoomTypes", id);
    if (!room) fail("NOT_FOUND", "Room type not found.");
    await ctx.db.replace("supplierRoomTypes", id, {
      supplierId: room.supplierId,
      ...cleanRoom(rest),
    });
    return null;
  },
});

export const removeRoomType = mutation({
  args: { id: v.id("supplierRoomTypes") },
  handler: async (ctx, args) => {
    await requireStaff(ctx);
    const room = await ctx.db.get("supplierRoomTypes", args.id);
    if (!room) fail("NOT_FOUND", "Room type not found.");
    const pool = await findPoolReferencing(ctx, room.supplierId, { roomTypeId: room._id });
    if (pool) {
      fail("CONFLICT", "This room type has an allotment. Delete it first.");
    }
    await ctx.db.delete("supplierRoomTypes", args.id);
    return null;
  },
});
