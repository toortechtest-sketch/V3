import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "agent");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  return { t, owner, agent };
}

describe("connected apps", () => {
  it("lets managers mark, change and clear a choice", async () => {
    const { owner } = await setup();
    await owner.mutation(api.connectedApps.setPreference, {
      appKey: "xero",
      preference: "needed",
    });
    await owner.mutation(api.connectedApps.setPreference, {
      appKey: "xero",
      preference: "not_needed",
    });
    const rows = await owner.query(api.connectedApps.listPreferences, {});
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ appKey: "xero", preference: "not_needed" });

    await owner.mutation(api.connectedApps.setPreference, {
      appKey: "xero",
      preference: null,
    });
    expect(await owner.query(api.connectedApps.listPreferences, {})).toEqual([]);
  });

  it("keeps agents and signed-out callers out", async () => {
    const { t, agent } = await setup();
    await expect(
      agent.query(api.connectedApps.listPreferences, {}),
    ).rejects.toThrow(/permission required/);
    await expect(
      agent.mutation(api.connectedApps.setPreference, {
        appKey: "slack",
        preference: "needed",
      }),
    ).rejects.toThrow(/permission required/);
    await expect(
      t.query(api.connectedApps.listPreferences, {}),
    ).rejects.toThrow(/signed in/);
  });
});
