import { v } from "convex/values";
import { query, type QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { fail, isManagerRole, requireStaff } from "./lib/access";
import { ownerNames } from "./lib/owners";
import type { BookingStage } from "./schema/bookings";

// Every list is bounded so this reactive query stays cheap as data grows.
const RECENT_LIMIT = 100;
const SOON_LIMIT = 25;
const ENQUIRY_LIMIT = 50;
const QUOTED_LIMIT = 50;
const PROGRAMME_BOOKINGS = 20;
const PROGRAMME_ITEMS_PER_BOOKING = 30;

const DEPARTING_WINDOW_DAYS = 14;
const QUOTE_EXPIRY_WINDOW_DAYS = 7;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

/** Shift a YYYY-MM-DD calendar day by whole days. */
export function addDays(day: string, days: number) {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}

type Scope = { all: boolean; ownerId: Id<"users"> };

const FIRST_DAY = "0000-01-01";
const LAST_DAY = "9999-12-31";

/** Bookings in one stage and the caller's scope, starting within [from, to]. */
function byStage(
  ctx: QueryCtx,
  scope: Scope,
  stage: BookingStage,
  from = FIRST_DAY,
  to = LAST_DAY,
) {
  return scope.all
    ? ctx.db
        .query("bookings")
        .withIndex("by_stage_and_start_date", (q) =>
          q.eq("stage", stage).gte("startDate", from).lte("startDate", to),
        )
    : ctx.db
        .query("bookings")
        .withIndex("by_owner_and_stage_and_start_date", (q) =>
          q
            .eq("ownerId", scope.ownerId)
            .eq("stage", stage)
            .gte("startDate", from)
            .lte("startDate", to),
        );
}

const byStart = (a: Doc<"bookings">, b: Doc<"bookings">) =>
  a.startDate.localeCompare(b.startDate);

export const overview = query({
  args: { today: v.string(), mineOnly: v.optional(v.boolean()) },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx);
    if (!DATE_PATTERN.test(args.today)) fail("BAD_REQUEST", "Invalid day.");
    const today = args.today;
    const scope: Scope = {
      all: isManagerRole(staff.role) && !args.mineOnly,
      ownerId: staff.user._id,
    };

    const [startedConfirmed, startedOperating, soon, enquiries, quoted] =
      await Promise.all([
        byStage(ctx, scope, "confirmed", FIRST_DAY, today).order("desc").take(RECENT_LIMIT),
        byStage(ctx, scope, "operating", FIRST_DAY, today).order("desc").take(RECENT_LIMIT),
        Promise.all(
          (["quoted", "confirmed", "operating"] as const).map((stage) =>
            byStage(
              ctx,
              scope,
              stage,
              addDays(today, 1),
              addDays(today, DEPARTING_WINDOW_DAYS),
            )
              .order("asc")
              .take(SOON_LIMIT),
          ),
        ),
        byStage(ctx, scope, "enquiry").order("asc").take(ENQUIRY_LIMIT + 1),
        byStage(ctx, scope, "quoted").order("asc").take(QUOTED_LIMIT),
      ]);

    // Started bookings are either on the road now or finished and waiting
    // to be reconciled and closed.
    const started = [...startedConfirmed, ...startedOperating];
    const travelling = started.filter((b) => b.endDate >= today).sort(byStart);
    const toReconcile = started
      .filter((b) => b.endDate < today)
      .sort((a, b) => a.endDate.localeCompare(b.endDate));
    const departing = soon.flat().sort(byStart).slice(0, SOON_LIMIT);

    const quoteRows = await Promise.all(
      quoted.map((b) =>
        ctx.db
          .query("quotes")
          .withIndex("by_booking", (q) => q.eq("bookingId", b._id))
          .unique(),
      ),
    );
    const expiryLimit = addDays(today, QUOTE_EXPIRY_WINDOW_DAYS);
    const expiringQuotes = quoted
      .map((booking, i) => ({ booking, validUntil: quoteRows[i]?.validUntil }))
      .filter(
        (q): q is { booking: Doc<"bookings">; validUntil: string } =>
          q.validUntil !== undefined && q.validUntil <= expiryLimit,
      )
      .sort((a, b) => a.validUntil.localeCompare(b.validUntil));

    const programmeBookings = travelling.slice(0, PROGRAMME_BOOKINGS);
    const programmeItems = await Promise.all(
      programmeBookings.map((b) =>
        ctx.db
          .query("itineraryItems")
          .withIndex("by_booking_and_date", (q) =>
            q.eq("bookingId", b._id).eq("date", today),
          )
          .take(PROGRAMME_ITEMS_PER_BOOKING),
      ),
    );
    const programme = programmeBookings
      .flatMap((b, i) =>
        programmeItems[i].map((item) => ({
          _id: item._id,
          type: item.type,
          title: item.title,
          startTime: item.startTime,
          endTime: item.endTime,
          location: item.location,
          bookingId: b._id,
          bookingReference: b.reference,
          bookingTitle: b.title,
        })),
      )
      .sort((a, b) => {
        if (a.startTime && b.startTime) return a.startTime.localeCompare(b.startTime);
        if (a.startTime) return -1;
        if (b.startTime) return 1;
        return 0;
      });

    const needsQuote = enquiries.slice(0, ENQUIRY_LIMIT);
    const names = await ownerNames(ctx, [
      ...travelling,
      ...departing,
      ...needsQuote,
      ...toReconcile,
      ...expiringQuotes.map((q) => q.booking),
    ]);
    const summary = (b: Doc<"bookings">) => ({
      _id: b._id,
      reference: b.reference,
      title: b.title,
      clientName: b.clientName,
      destination: b.destination,
      startDate: b.startDate,
      endDate: b.endDate,
      pax: b.pax,
      stage: b.stage,
      ownerName: names.get(b.ownerId) ?? null,
    });

    return {
      seesAll: scope.all,
      travelling: travelling.map(summary),
      departing: departing.map(summary),
      needsQuote: needsQuote.map(summary),
      needsQuoteHasMore: enquiries.length > ENQUIRY_LIMIT,
      expiringQuotes: expiringQuotes.map((q) => ({
        ...summary(q.booking),
        validUntil: q.validUntil,
      })),
      toReconcile: toReconcile.map(summary),
      programme,
    };
  },
});
