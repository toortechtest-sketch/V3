import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import type { Id } from "./_generated/dataModel";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-12-01",
  endDate: "2026-12-04",
  pax: 20,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

const HOTEL = {
  type: "hotel" as const,
  supplierName: "Hotel Arts",
  description: "Deluxe sea view",
  startDate: "2026-12-01",
  endDate: "2026-12-03", // 2 nights
  units: 1,
  unitLabel: "rooms",
  board: "breakfast" as const,
};

/** Seeds a signed-in owner/agent, a booking, a supplier, and a 1-night pool+slot pair. */
async function setup(capacity = 1) {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const ownerId = await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: aId, role: "agent" });
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  const supplierId = await agentA.mutation(api.suppliers.create, {
    name: "Hotel Arts",
    category: "hotel",
    status: "active",
  });

  const { poolId, slotIds } = await t.run(async (ctx) => {
    const roomTypeId = await ctx.db.insert("supplierRoomTypes", {
      supplierId,
      name: "Deluxe sea view",
      occupancy: 2,
      board: "breakfast",
    });
    const poolId = await ctx.db.insert("allotmentPools", {
      supplierId,
      roomTypeId,
      name: "Deluxe sea view",
      kind: "hotel_night",
      category: "hotel",
      unit: "room",
      timezone: "Europe/Madrid",
      contractReference: "CONTRACT-1",
      enabled: true,
      createdById: ownerId,
      updatedAt: new Date().toISOString(),
    });
    const far = Date.now() + 1000 * 60 * 60 * 24 * 365;
    const nights = ["2026-12-01", "2026-12-02"];
    const slotIds = [];
    for (const night of nights) {
      slotIds.push(
        await ctx.db.insert("allotmentSlots", {
          poolId,
          serviceDate: night,
          serviceKey: night,
          capacity,
          retired: 0,
          enabled: true,
          stopSale: false,
          releaseAt: far,
          replenishOnReturn: true,
          updatedAt: new Date().toISOString(),
        }),
      );
    }
    return { poolId, slotIds };
  });

  return { t, agentA, owner, bookingId, supplierId, poolId, slotIds };
}

/** Reads every allotment allocation row for a reservation, newest schema fields included. */
async function allocationCount(
  t: ReturnType<typeof convexTest>,
  reservationId: Id<"reservations">,
): Promise<number> {
  const all = await t.run((ctx) => ctx.db.query("allotmentAllocations").collect());
  return all.filter((row) => row.reservationId === reservationId).length;
}

describe("reservations + allotment reconciliation", () => {
  it("confirms a linked reservation and allocates its nights", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup();
    const id = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...HOTEL,
    });
    const all = await t.run((ctx) => ctx.db.query("allotmentAllocations").collect());
    const rows = all.filter((r) => r.reservationId === id);
    expect(rows).toHaveLength(2);
    expect(rows.every((r) => r.state === "confirmed" && r.quantity === 1)).toBe(true);
  });

  it("rejects booking the last room twice", async () => {
    const { agentA, bookingId, supplierId, poolId } = await setup(1);
    await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...HOTEL,
    });
    await expect(
      agentA.mutation(api.reservations.create, {
        bookingId,
        status: "confirmed",
        supplierId,
        allotmentPoolId: poolId,
        ...HOTEL,
      }),
    ).rejects.toThrow(/SOLD_OUT/);
  });

  it("allows a second booking once capacity covers both", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup(2);
    const first = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...HOTEL,
    });
    const second = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...HOTEL,
    });
    expect(await allocationCount(t, first)).toBe(2);
    expect(await allocationCount(t, second)).toBe(2);
  });

  it("releases allocated nights when a non-confirmed reservation is removed", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup(1);
    const id = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "option",
      supplierId,
      allotmentPoolId: poolId,
      allotmentHoldUntil: Date.now() + 60_000,
      ...HOTEL,
    });
    expect(await allocationCount(t, id)).toBe(2);
    await agentA.mutation(api.reservations.remove, { id });
    expect(await allocationCount(t, id)).toBe(0);

    // Capacity is free again for a new booking.
    const other = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...HOTEL,
    });
    expect(await allocationCount(t, other)).toBe(2);
  });

  it("leaves inventory untouched for a reservation with no pool link", async () => {
    const { t, agentA, bookingId, supplierId } = await setup();
    const id = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      ...HOTEL,
    });
    expect(await allocationCount(t, id)).toBe(0);
  });

  it("replays an identical create via requestKey instead of double-booking", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup(1);
    const args = {
      bookingId,
      status: "confirmed" as const,
      supplierId,
      allotmentPoolId: poolId,
      requestKey: "retry-1",
      ...HOTEL,
    };
    const first = await agentA.mutation(api.reservations.create, args);
    const second = await agentA.mutation(api.reservations.create, args);
    expect(second).toBe(first);
    expect(await allocationCount(t, first)).toBe(2);
  });

  it("rejects a reused requestKey with different details", async () => {
    const { agentA, bookingId, supplierId, poolId } = await setup(1);
    await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      requestKey: "retry-2",
      ...HOTEL,
    });
    await expect(
      agentA.mutation(api.reservations.create, {
        bookingId,
        status: "confirmed",
        supplierId,
        allotmentPoolId: poolId,
        requestKey: "retry-2",
        ...HOTEL,
        units: 2,
      }),
    ).rejects.toThrow(/already submitted/);
  });

  it("applies a change through approval and reconciles the resulting dates", async () => {
    const { t, agentA, bookingId, supplierId, poolId } = await setup(1);
    const id = await agentA.mutation(api.reservations.create, {
      bookingId,
      status: "confirmed",
      supplierId,
      allotmentPoolId: poolId,
      ...HOTEL,
    });
    const changeId = await agentA.mutation(api.reservations.requestChange, {
      reservationId: id,
      kind: "cancel",
      changes: {},
    });
    await agentA.mutation(api.reservations.recordResponse, { changeId, decision: "approved" });
    expect(await allocationCount(t, id)).toBe(0);
  });
});
