/**
 * Pure booking-finance calculations shared by the backend and the UI.
 * All amounts are in the booking currency.
 */
import { money } from "./quoteMath";

export type InvoiceInput = {
  _id: string;
  kind: "invoice" | "credit_note";
  status: "issued" | "void";
  amount: number;
  dueDate?: string;
};

export type PaymentInput = { amount: number; invoiceId?: string };

export type InvoiceBalance = {
  paid: number;
  // Never below zero; overpayments show up in the booking summary instead
  open: number;
  isPaid: boolean;
};

/** Paid / open per invoice, from the payments allocated to it. */
export function invoiceBalances(invoices: InvoiceInput[], payments: PaymentInput[]) {
  const paidBy = new Map<string, number>();
  for (const p of payments) {
    if (p.invoiceId) paidBy.set(p.invoiceId, (paidBy.get(p.invoiceId) ?? 0) + p.amount);
  }
  const result = new Map<string, InvoiceBalance>();
  for (const inv of invoices) {
    const paid = money(paidBy.get(inv._id) ?? 0);
    const owed = inv.kind === "invoice" && inv.status === "issued" ? inv.amount : 0;
    const open = money(Math.max(0, owed - paid));
    result.set(inv._id, { paid, open, isPaid: inv.kind === "invoice" && open === 0 });
  }
  return result;
}

export type FinanceSummary = {
  contractValue: number;
  invoiced: number;
  credited: number;
  // Invoiced minus credit notes
  netInvoiced: number;
  received: number;
  // What the client still owes on issued invoices (negative = overpaid)
  outstanding: number;
  // Contract value not yet covered by an invoice
  toInvoice: number;
};

export function financeSummary(
  contractValue: number,
  invoices: InvoiceInput[],
  payments: PaymentInput[],
): FinanceSummary {
  const sum = (kind: InvoiceInput["kind"]) =>
    money(
      invoices
        .filter((i) => i.kind === kind && i.status === "issued")
        .reduce((s, i) => s + i.amount, 0),
    );
  const invoiced = sum("invoice");
  const credited = sum("credit_note");
  const netInvoiced = money(invoiced - credited);
  const received = money(payments.reduce((s, p) => s + p.amount, 0));
  return {
    contractValue: money(contractValue),
    invoiced,
    credited,
    netInvoiced,
    received,
    outstanding: money(netInvoiced - received),
    toInvoice: money(contractValue - netInvoiced),
  };
}

/** Amount of an instalment, given as a share of the contract value. */
export const installmentAmount = (percent: number, contractValue: number) =>
  money((contractValue * percent) / 100);

/** True when an issued invoice is unpaid past its due day. `today` is YYYY-MM-DD. */
export function isOverdue(invoice: InvoiceInput, balance: InvoiceBalance, today: string) {
  return (
    invoice.kind === "invoice" &&
    invoice.status === "issued" &&
    balance.open > 0 &&
    invoice.dueDate !== undefined &&
    invoice.dueDate < today
  );
}
