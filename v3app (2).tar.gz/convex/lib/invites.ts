import type { Id } from "../_generated/dataModel";
import type { MutationCtx } from "../_generated/server";

export const normalizeEmail = (email: string) => email.trim().toLowerCase();

/**
 * Turns a pending invite into a role on first sign-in. Only runs for users
 * with no role yet, so an invite can never downgrade or override existing
 * access. Emails the auth provider explicitly marks unverified are ignored.
 */
export async function claimInvite(
  ctx: MutationCtx,
  userId: Id<"users">,
  email: string | undefined,
  emailVerified: boolean | undefined,
) {
  if (!email || emailVerified === false) return;
  const hasRole = await ctx.db
    .query("staffRoles")
    .withIndex("by_user", (q) => q.eq("userId", userId))
    .unique();
  if (hasRole) return;
  const invite = await ctx.db
    .query("staffInvites")
    .withIndex("by_email", (q) => q.eq("email", normalizeEmail(email)))
    .first();
  if (!invite) return;
  await ctx.db.insert("staffRoles", {
    userId,
    role: invite.role,
    assignedAt: new Date().toISOString(),
    assignedById: invite.invitedById,
  });
  await ctx.db.delete("staffInvites", invite._id);
}
