import type { Doc, Id } from "../_generated/dataModel";
import type { MutationCtx, QueryCtx } from "../_generated/server";

type Ctx = QueryCtx | MutationCtx;

// A gap longer than this starts a new session row instead of extending the
// last one. Matches the ~60s heartbeat interval with generous slack for a
// missed beat or a brief network hiccup.
export const HEARTBEAT_GAP_MS = 5 * 60 * 1000;

// Bounded so these reactive-ish queries stay cheap. A staff member who is
// active every day has at most one new row per gap, so recent history easily
// fits in this window.
const SESSION_LIMIT = 90;

export const recentSessionsOf = (ctx: Ctx, userId: Id<"users">) =>
  ctx.db
    .query("activitySessions")
    .withIndex("by_user", (q) => q.eq("userId", userId))
    .order("desc")
    .take(SESSION_LIMIT);

/**
 * Active time within a window, approximated by whether each session was
 * still active at or after the window started. A session that straddles the
 * boundary (e.g. started before midnight, still open after) counts in full
 * toward the newer window — acceptable for an internal usage overview, not
 * exact to the millisecond.
 */
export function sumSince(sessions: Doc<"activitySessions">[], sinceIso: string) {
  return sessions
    .filter((s) => s.lastSeenAt >= sinceIso)
    .reduce((total, s) => total + s.durationMs, 0);
}

export function lastSeenOf(sessions: Doc<"activitySessions">[]) {
  return sessions[0]?.lastSeenAt ?? null;
}

/** Treat a staff member as online if they've sent a heartbeat very recently. */
export const ONLINE_WINDOW_MS = 2 * 60 * 1000;
export const isOnline = (lastSeenAt: string | null, nowIso: string) =>
  lastSeenAt !== null && new Date(nowIso).getTime() - new Date(lastSeenAt).getTime() <= ONLINE_WINDOW_MS;
