/**
 * Pure double-entry helpers shared by the backend and the UI.
 * Every amount is an integer in minor units (cents).
 */
import type { AccountType, DocumentKind } from "../schema/accounting";

export type Entry = { account: string; debit: number; credit: number };

export const MAX_MINOR = 1_000_000_000_000;
export const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

/** Accounts the ledger posts to automatically. */
export const SYSTEM_ACCOUNTS = {
  bank: "1000",
  receivables: "1100",
  inputTax: "1200",
  payables: "2000",
  outputTax: "2100",
  revenue: "4000",
  costs: "5000",
} as const;

/** Same starter chart as V2, so migrated journals keep their codes. */
export const DEFAULT_CHART: readonly {
  code: string;
  name: string;
  type: AccountType;
  system: boolean;
}[] = [
  { code: "1000", name: "Bank clearing", type: "asset", system: true },
  { code: "1100", name: "Trade receivables", type: "asset", system: true },
  { code: "1200", name: "Recoverable input tax", type: "asset", system: true },
  { code: "1300", name: "Supplier prepayments", type: "asset", system: false },
  { code: "2000", name: "Trade payables", type: "liability", system: true },
  { code: "2100", name: "Output tax payable", type: "liability", system: true },
  { code: "2200", name: "Customer deposits", type: "liability", system: false },
  { code: "3000", name: "Opening equity", type: "equity", system: false },
  { code: "4000", name: "Travel service revenue", type: "revenue", system: true },
  { code: "5000", name: "Travel service costs", type: "expense", system: true },
];

export class LedgerError extends Error {}

export function isMinor(value: number) {
  return Number.isSafeInteger(value) && value >= 0 && value <= MAX_MINOR;
}

export function sumMinor(values: number[]): number {
  const total = values.reduce((a, b) => a + b, 0);
  if (!values.every(isMinor) || !isMinor(total)) {
    throw new LedgerError("Amounts must be positive and under 10 billion.");
  }
  return total;
}

/** True for a real calendar day in YYYY-MM-DD form. */
export function isCalendarDay(value: string) {
  if (!DATE_PATTERN.test(value)) return false;
  const parsed = new Date(`${value}T00:00:00Z`);
  return (
    Number.isFinite(parsed.getTime()) &&
    parsed.toISOString().slice(0, 10) === value
  );
}

export function isBalanced(entries: Entry[]) {
  if (entries.length < 2) return false;
  // Each line is either a debit or a credit, never both or neither.
  if (entries.some((e) => !isMinor(e.debit) || !isMinor(e.credit))) return false;
  if (entries.some((e) => (e.debit > 0) === (e.credit > 0))) return false;
  const debits = entries.reduce((a, e) => a + e.debit, 0);
  const credits = entries.reduce((a, e) => a + e.credit, 0);
  return debits === credits;
}

function checked(entries: Entry[]) {
  if (!isBalanced(entries)) throw new LedgerError("Journal does not balance.");
  return entries;
}

/** Entries when a document is posted. `account` is its revenue/expense account. */
export function issueEntries(
  kind: DocumentKind,
  account: string,
  net: number,
  tax: number,
): Entry[] {
  const total = sumMinor([net, tax]);
  if (net <= 0) throw new LedgerError("A document needs a net amount above zero.");
  const a = SYSTEM_ACCOUNTS;
  if (kind === "invoice") {
    return checked([
      { account: a.receivables, debit: total, credit: 0 },
      { account, debit: 0, credit: net },
      ...(tax ? [{ account: a.outputTax, debit: 0, credit: tax }] : []),
    ]);
  }
  return checked([
    { account, debit: net, credit: 0 },
    ...(tax ? [{ account: a.inputTax, debit: tax, credit: 0 }] : []),
    { account: a.payables, debit: 0, credit: total },
  ]);
}

/** Entries when money is received (invoice) or paid out (bill). */
export function paymentEntries(kind: DocumentKind, amount: number): Entry[] {
  if (!isMinor(amount) || amount <= 0) {
    throw new LedgerError("Payment must be above zero.");
  }
  const a = SYSTEM_ACCOUNTS;
  return checked(
    kind === "invoice"
      ? [
          { account: a.bank, debit: amount, credit: 0 },
          { account: a.receivables, debit: 0, credit: amount },
        ]
      : [
          { account: a.payables, debit: amount, credit: 0 },
          { account: a.bank, debit: 0, credit: amount },
        ],
  );
}

export function reverseEntries(entries: Entry[]): Entry[] {
  return checked(
    entries.map((e) => ({ account: e.account, debit: e.credit, credit: e.debit })),
  );
}

export type BalanceRow = {
  code: string;
  name: string;
  type: AccountType;
  debit: number;
  credit: number;
};

/** Natural balance: debit-normal for assets/expenses, credit-normal otherwise. */
export function naturalBalance(row: Pick<BalanceRow, "type" | "debit" | "credit">) {
  return row.type === "asset" || row.type === "expense"
    ? row.debit - row.credit
    : row.credit - row.debit;
}

export function documentNumber(kind: DocumentKind, n: number) {
  return `${kind === "invoice" ? "INV" : "BILL"}-${String(n).padStart(7, "0")}`;
}
