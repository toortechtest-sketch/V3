import { availability as computeAvailability } from "./allotmentEngine";
import type { QueryCtx, MutationCtx } from "../_generated/server";
import type { Doc } from "../_generated/dataModel";

const MAX_SLOT_ALLOCATIONS = 2000;

/**
 * Shared availability projection: loads every allocation for the given
 * slots, runs the pure engine, and returns held/confirmed/available per
 * slot. Used by both the manager-facing pool view and the booking-time
 * picker so the two never drift.
 */
export async function computeSlotAvailability(
  ctx: QueryCtx | MutationCtx,
  pool: Doc<"allotmentPools">,
  slots: Doc<"allotmentSlots">[],
) {
  const allocationLists = await Promise.all(
    slots.map((s) =>
      ctx.db
        .query("allotmentAllocations")
        .withIndex("by_slot", (q) => q.eq("slotId", s._id))
        .take(MAX_SLOT_ALLOCATIONS),
    ),
  );
  const engineSlots = slots.map((s) => ({
    id: s._id,
    capacity: s.capacity,
    retired: s.retired,
    enabled: s.enabled && pool.enabled,
    stopSale: s.stopSale,
    releaseAt: s.releaseAt,
    replenishOnReturn: s.replenishOnReturn,
  }));
  const engineAllocations = allocationLists.flat().map((a) => ({
    slotId: a.slotId,
    reservationId: a.reservationId,
    quantity: a.quantity,
    state: a.state,
    ...(a.holdUntil !== undefined ? { holdUntil: a.holdUntil } : {}),
  }));
  const result = computeAvailability(engineSlots, engineAllocations, Date.now());
  return new Map(result.map((r) => [r.slotId, r]));
}
