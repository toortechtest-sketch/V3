import type { Doc, Id } from "../_generated/dataModel";
import type { MutationCtx } from "../_generated/server";
import { reconcileAllotment } from "./reconcileAllotment";

export type ChangeDecision = "approved" | "declined";

/**
 * Closes a pending change request. Approval applies the requested values (or
 * cancels) on the reservation. Used by staff and by the hotel response link.
 * A capacity conflict throws and rolls back the whole mutation, including the
 * change-request patch, so the request stays "pending" for a retry.
 */
export async function applyChangeDecision(
  ctx: MutationCtx,
  change: Doc<"reservationChanges">,
  decision: ChangeDecision,
  responseNote: string | undefined,
  recordedById: Id<"users"> | undefined,
) {
  const now = new Date().toISOString();
  await ctx.db.patch("reservationChanges", change._id, {
    status: decision,
    respondedAt: now,
    responseNote,
    recordedById,
  });
  if (decision === "approved") {
    const patch: Partial<Doc<"reservations">> =
      change.kind === "cancel" ? { status: "cancelled" } : { ...change.changes };
    await ctx.db.patch("reservations", change.reservationId, { ...patch, updatedAt: now });
    const reservation = await ctx.db.get("reservations", change.reservationId);
    if (reservation) {
      await reconcileAllotment(ctx, reservation, recordedById, "reservationChanges.applyChangeDecision");
    }
  }
  await ctx.db.patch("bookings", change.bookingId, { updatedAt: now });
}
