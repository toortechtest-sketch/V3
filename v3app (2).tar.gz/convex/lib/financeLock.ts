import type { Id } from "../_generated/dataModel";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import { fail } from "./access";

type Ctx = QueryCtx | MutationCtx;

export function financeOf(ctx: Ctx, bookingId: Id<"bookings">) {
  return ctx.db
    .query("bookingFinance")
    .withIndex("by_booking", (q) => q.eq("bookingId", bookingId))
    .unique();
}

export async function isFinanceLocked(ctx: Ctx, bookingId: Id<"bookings">) {
  const finance = await financeOf(ctx, bookingId);
  return finance?.lockedAt !== undefined;
}

/**
 * A booking is locked once finance closes it for full payment (always a manual
 * action). Use in every mutation that changes money on a locked booking.
 */
export async function requireFinanceUnlocked(ctx: Ctx, bookingId: Id<"bookings">) {
  if (await isFinanceLocked(ctx, bookingId)) {
    fail(
      "FORBIDDEN",
      "This booking is finance locked. Add a credit note instead, or ask a manager to reopen it.",
    );
  }
}
