import { ConvexError } from "convex/values";
import type { Doc, Id } from "../_generated/dataModel";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import type { StaffRole } from "../schema/staff";

type Ctx = QueryCtx | MutationCtx;

export type ErrorCode =
  | "UNAUTHENTICATED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "BAD_REQUEST"
  | "CONFLICT"
  | "EXTERNAL_SERVICE_ERROR";

export function fail(code: ErrorCode, message: string): never {
  throw new ConvexError({ code, message });
}

/** Roles that can see every booking and manage the team. */
export const MANAGER_ROLES: readonly StaffRole[] = ["owner", "global_manager"];

export const isManagerRole = (role: StaffRole) => MANAGER_ROLES.includes(role);

export type Staff = { user: Doc<"users">; role: StaffRole };

/** Signed-in user row, or null when not signed in / not yet synced. */
export async function findCurrentUser(ctx: Ctx): Promise<Doc<"users"> | null> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) return null;
  return await ctx.db
    .query("users")
    .withIndex("by_token", (q) =>
      q.eq("tokenIdentifier", identity.tokenIdentifier),
    )
    .unique();
}

export async function findRole(
  ctx: Ctx,
  user: Doc<"users">,
): Promise<Doc<"staffRoles"> | null> {
  return await ctx.db
    .query("staffRoles")
    .withIndex("by_user", (q) => q.eq("userId", user._id))
    .unique();
}

/**
 * Fails closed: the caller must be signed in, provisioned in `users`, and hold
 * an explicit role row. No role row means no access.
 */
export async function requireStaff(ctx: Ctx): Promise<Staff> {
  const identity = await ctx.auth.getUserIdentity();
  if (!identity) fail("UNAUTHENTICATED", "You must be signed in.");
  const user = await findCurrentUser(ctx);
  if (!user) fail("FORBIDDEN", "Complete sign-in before continuing.");
  const role = await findRole(ctx, user);
  if (!role) fail("FORBIDDEN", "Your account has not been approved yet.");
  return { user, role: role.role };
}

/** Managers see every booking; everyone else only the bookings they own. */
export function canAccessBooking(staff: Staff, booking: Doc<"bookings">) {
  return isManagerRole(staff.role) || booking.ownerId === staff.user._id;
}

/**
 * Loads a booking the caller may work on. Missing and forbidden look the same
 * so IDs can't be probed.
 */
export async function requireBooking(
  ctx: Ctx,
  bookingId: Id<"bookings">,
): Promise<{ staff: Staff; booking: Doc<"bookings"> }> {
  const staff = await requireStaff(ctx);
  const booking = await ctx.db.get("bookings", bookingId);
  if (!booking || !canAccessBooking(staff, booking)) {
    fail("NOT_FOUND", "Booking not found.");
  }
  return { staff, booking };
}

export async function requireManager(ctx: Ctx): Promise<Staff> {
  const staff = await requireStaff(ctx);
  if (!isManagerRole(staff.role)) {
    fail("FORBIDDEN", "Owner or global manager permission required.");
  }
  return staff;
}
