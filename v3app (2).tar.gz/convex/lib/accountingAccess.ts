import type { Doc } from "../_generated/dataModel";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import { fail, requireManager, type Staff } from "./access";
import { isCalendarDay } from "./ledger";

type Ctx = QueryCtx | MutationCtx;

export async function findSettings(ctx: Ctx) {
  return await ctx.db.query("accountingSettings").first();
}

/**
 * Company accounting is limited to owners and global managers, and only
 * works once the owner has set up the ledger.
 */
export async function requireLedger(
  ctx: Ctx,
): Promise<{ staff: Staff; settings: Doc<"accountingSettings"> }> {
  const staff = await requireManager(ctx);
  const settings = await findSettings(ctx);
  if (!settings) fail("BAD_REQUEST", "Company accounting hasn't been set up yet.");
  return { staff, settings };
}

export function requireDay(value: string, label: string) {
  if (!isCalendarDay(value)) fail("BAD_REQUEST", `${label} isn't a valid date.`);
}

/** Closed periods are locked: nothing new can be dated inside them. */
export function requireOpenDate(
  settings: Doc<"accountingSettings">,
  date: string,
  label: string,
) {
  requireDay(date, label);
  if (settings.closedThrough && date <= settings.closedThrough) {
    fail(
      "CONFLICT",
      `${label} falls in a closed period (closed through ${settings.closedThrough}).`,
    );
  }
}

export async function findAccount(ctx: Ctx, code: string) {
  return await ctx.db
    .query("accountingAccounts")
    .withIndex("by_code", (q) => q.eq("code", code))
    .unique();
}

export function todayUtc() {
  return new Date().toISOString().slice(0, 10);
}
