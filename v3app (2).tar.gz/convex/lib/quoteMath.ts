/**
 * Pure quote calculations shared by the backend and the live preview in the UI.
 * Amounts are in the booking currency and rounded to cents at each line.
 */
export type QuoteBasis = "per_person" | "per_unit" | "fixed";

export const money = (n: number) => Math.round((n + Number.EPSILON) * 100) / 100;

export type PricedLineInput = {
  basis: QuoteBasis;
  quantity: number;
  times: number;
  unitCost: number;
  // Undefined falls back to the booking's default markup
  markupPercent?: number;
};

export type PricedLine = {
  units: number;
  markupPercent: number;
  cost: number;
  sell: number;
  margin: number;
};

/** How many units the unit cost applies to before multiplying by `times`. */
export function lineUnits(line: Pick<PricedLineInput, "basis" | "quantity">, pax: number) {
  if (line.basis === "per_person") return pax;
  if (line.basis === "per_unit") return line.quantity;
  return 1;
}

export function priceLine(line: PricedLineInput, pax: number, defaultMarkup: number): PricedLine {
  const markupPercent = line.markupPercent ?? defaultMarkup;
  const units = lineUnits(line, pax);
  const cost = money(line.unitCost * units * line.times);
  const sell = money(cost * (1 + markupPercent / 100));
  return { units, markupPercent, cost, sell, margin: money(sell - cost) };
}

export type QuoteTotals = {
  cost: number;
  sell: number;
  margin: number;
  // Margin as a share of the selling price, null when nothing is sold yet
  marginPercent: number | null;
  payingPax: number;
  perPayingGuest: number | null;
  base: { cost: number; sell: number; margin: number };
};

export function quoteTotals(
  lines: PricedLine[],
  opts: { pax: number; freePlaces: number; rateToBase: number },
): QuoteTotals {
  const cost = money(lines.reduce((s, l) => s + l.cost, 0));
  const sell = money(lines.reduce((s, l) => s + l.sell, 0));
  const margin = money(sell - cost);
  const payingPax = Math.max(0, opts.pax - opts.freePlaces);
  return {
    cost,
    sell,
    margin,
    marginPercent: sell > 0 ? money((margin / sell) * 100) : null,
    payingPax,
    perPayingGuest: payingPax > 0 ? money(sell / payingPax) : null,
    base: {
      cost: money(cost * opts.rateToBase),
      sell: money(sell * opts.rateToBase),
      margin: money(margin * opts.rateToBase),
    },
  };
}
