/**
 * INTERNAL helper, not a public endpoint. The caller MUST first authorize the
 * booking (via requireBooking/requireReservation) or validate the supplier
 * response link, then call this within its SAME mutation as every other
 * reservation lifecycle write (create/update/setStatus/remove/applyChangeDecision).
 */
import { fail } from "./access";
import type { MutationCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { AllotmentError, hotelNights, planChange, type Target } from "./allotmentEngine";

/** Bounds: fail closed rather than compute capacity from a truncated subset. */
const MAX_OLD_ROWS = 366;
const MAX_SLOT_ALLOCATIONS = 2000;
const MAX_TOTAL_ALLOCATIONS = 5000;

export async function reconcileAllotment(
  ctx: MutationCtx,
  reservation: Doc<"reservations">,
  actorId: Id<"users"> | undefined,
  source: string,
  deleting = false,
): Promise<void> {
  const now = Date.now();

  const oldRows = await ctx.db
    .query("allotmentAllocations")
    .withIndex("by_reservation", (q) => q.eq("reservationId", reservation._id))
    .take(MAX_OLD_ROWS + 1);
  if (oldRows.length > MAX_OLD_ROWS) {
    fail("CONFLICT", "Too many inventory rows; reconciliation required.");
  }

  const desiredSlots: Doc<"allotmentSlots">[] = [];
  const targets: Target[] = [];

  const wantsStock =
    !deleting &&
    reservation.allotmentPoolId !== undefined &&
    (reservation.status === "confirmed" || reservation.status === "option");

  if (wantsStock) {
    const poolId = reservation.allotmentPoolId!;
    const pool = await ctx.db.get("allotmentPools", poolId);
    if (!pool || pool.supplierId !== reservation.supplierId) {
      fail("BAD_REQUEST", "Allotment supplier mismatch.");
    }
    if (pool.kind === "hotel_night" && reservation.type !== "hotel") {
      fail("BAD_REQUEST", "Hotel inventory requires a hotel reservation.");
    }
    // Read the underlying resource too: reject broken or cross-supplier mappings.
    if (Boolean(pool.productId) === Boolean(pool.roomTypeId)) {
      fail("CONFLICT", "Pool must reference exactly one resource.");
    }
    const resource = pool.productId
      ? await ctx.db.get("supplierProducts", pool.productId)
      : await ctx.db.get("supplierRoomTypes", pool.roomTypeId!);
    if (!resource || resource.supplierId !== pool.supplierId) {
      fail("CONFLICT", "Invalid allotment resource.");
    }

    let keys: string[];
    try {
      keys =
        pool.kind === "hotel_night"
          ? hotelNights(reservation.startDate, reservation.endDate ?? "")
          : [reservation.allotmentSessionKey ?? ""];
    } catch {
      fail("BAD_REQUEST", "A hotel allotment needs valid check-in and checkout dates.");
    }

    for (const key of keys) {
      if (!key) fail("BAD_REQUEST", "Select the dated departure or service.");
      const slot = await ctx.db
        .query("allotmentSlots")
        .withIndex("by_pool_key", (q) => q.eq("poolId", pool._id).eq("serviceKey", key))
        .unique();
      if (!slot || (pool.kind === "session" && slot.serviceDate !== reservation.startDate)) {
        fail("CONFLICT", "No allotment exists for the required date or departure.");
      }
      desiredSlots.push({ ...slot, enabled: slot.enabled && pool.enabled });
      targets.push({
        slotId: slot._id,
        quantity: reservation.units,
        state: reservation.status === "option" ? "hold" : "confirmed",
        ...(reservation.status === "option" ? { holdUntil: reservation.allotmentHoldUntil } : {}),
      });
    }
  }

  // Missing link with no previous stock is legacy/on-request, not unlimited
  // stock. The scope must still include every slot the reservation previously
  // held so a removed link, cancellation or deletion releases that stock too.
  const scope = new Map(desiredSlots.map((s) => [s._id, s]));
  for (const row of oldRows) {
    if (!scope.has(row.slotId)) {
      const slot = await ctx.db.get("allotmentSlots", row.slotId);
      if (!slot) fail("CONFLICT", "Broken inventory reference.");
      scope.set(slot._id, slot);
    }
  }
  if (scope.size === 0) return;

  const allRows: Doc<"allotmentAllocations">[] = [];
  for (const slot of scope.values()) {
    const rows = await ctx.db
      .query("allotmentAllocations")
      .withIndex("by_slot", (q) => q.eq("slotId", slot._id))
      .take(MAX_SLOT_ALLOCATIONS + 1);
    if (rows.length > MAX_SLOT_ALLOCATIONS) {
      fail("CONFLICT", "Inventory scope exceeds safe limit; no changes applied.");
    }
    allRows.push(...rows);
  }
  if (allRows.length > MAX_TOTAL_ALLOCATIONS) {
    fail("CONFLICT", "Inventory scope too large; no changes applied.");
  }

  const slots = [...scope.values()].map((s) => ({
    id: s._id,
    capacity: s.capacity,
    retired: s.retired,
    enabled: s.enabled,
    stopSale: s.stopSale,
    releaseAt: s.releaseAt,
    replenishOnReturn: s.replenishOnReturn,
  }));
  const allocations = allRows.map((a) => ({
    slotId: a.slotId,
    reservationId: a.reservationId,
    quantity: a.quantity,
    state: a.state,
    ...(a.holdUntil !== undefined ? { holdUntil: a.holdUntil } : {}),
  }));

  let plan;
  try {
    plan = planChange(slots, allocations, reservation._id, targets, now);
  } catch (e) {
    if (e instanceof AllotmentError) fail("CONFLICT", `${e.code}: ${e.message}`);
    throw e;
  }

  const key = (a: { slotId: string; reservationId: string }) => `${a.slotId}|${a.reservationId}`;
  const next = new Map(plan.allocations.map((a) => [key(a), a]));
  const beforeJson = JSON.stringify({ slots, allocations });
  const afterJson = JSON.stringify(plan);
  let changed = false;

  for (const planned of plan.slots) {
    const original = scope.get(planned.id as Id<"allotmentSlots">)!;
    if (planned.retired !== original.retired) {
      await ctx.db.patch("allotmentSlots", original._id, {
        retired: planned.retired,
        updatedAt: new Date(now).toISOString(),
      });
      changed = true;
    }
  }

  for (const old of allRows) {
    const replacement = next.get(key(old));
    if (!replacement) {
      await ctx.db.delete("allotmentAllocations", old._id);
      changed = true;
    } else {
      if (
        old.quantity !== replacement.quantity ||
        old.state !== replacement.state ||
        old.holdUntil !== replacement.holdUntil
      ) {
        await ctx.db.patch("allotmentAllocations", old._id, {
          quantity: replacement.quantity,
          state: replacement.state,
          holdUntil: replacement.holdUntil,
        });
        changed = true;
      }
      next.delete(key(old));
    }
  }

  for (const a of next.values()) {
    await ctx.db.insert("allotmentAllocations", {
      slotId: a.slotId as Id<"allotmentSlots">,
      reservationId: a.reservationId as Id<"reservations">,
      quantity: a.quantity,
      state: a.state,
      holdUntil: a.holdUntil,
    });
    changed = true;
  }

  if (changed) {
    await ctx.db.insert("allotmentAudit", {
      reservationId: reservation._id,
      actorId,
      source,
      reason: "Reservation inventory reconciliation",
      beforeJson,
      afterJson,
      createdAt: new Date(now).toISOString(),
    });
  }
}
