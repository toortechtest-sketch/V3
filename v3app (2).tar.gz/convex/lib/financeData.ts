import type { Doc, Id } from "../_generated/dataModel";
import type { MutationCtx, QueryCtx } from "../_generated/server";
import { money, priceLine } from "./quoteMath";

type Ctx = QueryCtx | MutationCtx;

// Bounded so reactive finance queries stay small.
export const INVOICE_LIMIT = 200;
export const PAYMENT_LIMIT = 300;
export const INSTALLMENT_LIMIT = 20;
const QUOTE_LINE_LIMIT = 300;

export const invoicesOf = (ctx: Ctx, bookingId: Id<"bookings">) =>
  ctx.db
    .query("invoices")
    .withIndex("by_booking_and_issue_date", (q) => q.eq("bookingId", bookingId))
    .take(INVOICE_LIMIT);

export const paymentsOf = (ctx: Ctx, bookingId: Id<"bookings">) =>
  ctx.db
    .query("payments")
    .withIndex("by_booking_and_received_date", (q) => q.eq("bookingId", bookingId))
    .take(PAYMENT_LIMIT);

export const installmentsOf = (ctx: Ctx, bookingId: Id<"bookings">) =>
  ctx.db
    .query("paymentInstallments")
    .withIndex("by_booking_and_due_date", (q) => q.eq("bookingId", bookingId))
    .take(INSTALLMENT_LIMIT);

/** Selling price from the quote, so finance follows the quote until a deal is agreed. */
export async function quoteSell(ctx: Ctx, booking: Doc<"bookings">) {
  const lines = await ctx.db
    .query("quoteLines")
    .withIndex("by_booking_and_section", (q) => q.eq("bookingId", booking._id))
    .take(QUOTE_LINE_LIMIT);
  const markup = booking.markupPercent ?? 0;
  return money(lines.reduce((s, l) => s + priceLine(l, booking.pax, markup).sell, 0));
}
