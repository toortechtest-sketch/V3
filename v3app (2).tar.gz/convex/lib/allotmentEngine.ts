/** Pure inventory calculations. Persist the returned plan in ONE server transaction.
 * Never call from a client to authorize a booking. No database or network side effects.
 */
export type Slot = {
  id: string;
  capacity: number;
  retired: number;
  enabled: boolean;
  stopSale: boolean;
  releaseAt: number;
  replenishOnReturn: boolean;
};
export type Allocation = {
  slotId: string;
  reservationId: string;
  quantity: number;
  state: "hold" | "confirmed";
  holdUntil?: number;
};
export type Target = { slotId: string; quantity: number; state: "hold" | "confirmed"; holdUntil?: number };
export class AllotmentError extends Error {
  code: string;
  constructor(code: string, message: string) { super(message); this.code = code; }
}
function reject(code: string, message: string): never { throw new AllotmentError(code, message); }
function whole(n: number, label: string, minimum = 0) {
  if (!Number.isSafeInteger(n) || n < minimum) reject("INVALID", `${label} must be a whole number >= ${minimum}`);
}
function instant(n: number, label: string) {
  if (!Number.isSafeInteger(n) || n < 0 || n > 8640000000000000) reject("INVALID", `Invalid ${label}`);
}
function add(a: number, b: number) { const n = a + b; whole(n, "total"); return n; }
function validDate(value: string) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) reject("DATE", "Use YYYY-MM-DD");
  const n = Date.parse(`${value}T00:00:00.000Z`);
  if (!Number.isFinite(n) || new Date(n).toISOString().slice(0, 10) !== value) reject("DATE", "Invalid calendar date");
  return n;
}
/** Hotel checkout is exclusive. No local-machine timezone or DST arithmetic. */
export function hotelNights(checkIn: string, checkOut: string): string[] {
  const start = validDate(checkIn), end = validDate(checkOut);
  const length = (end - start) / 86400000;
  if (length < 1 || length > 366) reject("DATE", "Stay must be 1–366 nights");
  return Array.from({ length }, (_, n) => new Date(start + n * 86400000).toISOString().slice(0, 10));
}
function prepare(inputSlots: Slot[], inputAllocations: Allocation[], now: number) {
  instant(now, "clock");
  const slots = inputSlots.map(s => ({ ...s }));
  const map = new Map<string, Slot>();
  for (const slot of slots) {
    if (!slot.id || map.has(slot.id)) reject("INVALID", "Missing or duplicate slot");
    whole(slot.capacity, "capacity"); whole(slot.retired, "retired"); instant(slot.releaseAt, "release deadline");
    if (slot.retired > slot.capacity) reject("INVALID", "Retired units exceed capacity");
    for (const key of ["enabled", "stopSale", "replenishOnReturn"] as const) {
      if (typeof slot[key] !== "boolean") reject("INVALID", `Invalid ${key}`);
    }
    map.set(slot.id, slot);
  }
  const allocations: Allocation[] = [];
  const unique = new Set<string>();
  const beforeTotals = new Map<string, number>();
  for (const allocation of inputAllocations) {
    const a = { ...allocation }, slot = map.get(a.slotId);
    if (!slot || !a.reservationId) reject("INVALID", "Unresolved allocation reference");
    whole(a.quantity, "quantity", 1);
    if (!["hold", "confirmed"].includes(a.state)) reject("INVALID", "Unknown allocation state");
    if (a.state === "hold") instant(a.holdUntil!, "hold expiry");
    else if (a.holdUntil !== undefined) reject("INVALID", "Confirmed allocation cannot have an expiry");
    const key = JSON.stringify([a.slotId, a.reservationId]);
    if (unique.has(key)) reject("INVALID", "Duplicate reservation/slot allocation");
    unique.add(key);
    beforeTotals.set(a.slotId, add(beforeTotals.get(a.slotId) ?? 0, a.quantity));
    if (a.state === "hold" && a.holdUntil! <= now) {
      if (!slot.replenishOnReturn) slot.retired = add(slot.retired, a.quantity);
    } else allocations.push(a);
  }
  for (const s of inputSlots) {
    if (add(s.retired, beforeTotals.get(s.id) ?? 0) > s.capacity) reject("CORRUPT", "Inventory is already over capacity; reconcile before changing it");
  }
  return { slots, allocations, map };
}
/** Returns a complete plan for the supplied locked/read scope, including expired holds.
 * Adapter must read ALL allocations for EVERY old and new slot in one mutation.
 * Exactly one active allocation per reservation/slot. A retry produces the same state.
 */
export function planChange(inputSlots: Slot[], inputAllocations: Allocation[], reservationId: string, targets: Target[], now: number) {
  if (!reservationId) reject("INVALID", "Reservation is required");
  if (targets.length > 366) reject("INVALID", "Too many inventory slots");
  const { slots, allocations, map } = prepare(inputSlots, inputAllocations, now);
  const existing = new Map(allocations.filter(a => a.reservationId === reservationId).map(a => [a.slotId, a]));
  const others = allocations.filter(a => a.reservationId !== reservationId);
  const next = new Map<string, Allocation>();
  for (const t of targets) {
    const s = map.get(t.slotId);
    if (!s || next.has(t.slotId)) reject("INVALID", "Missing or duplicate target slot");
    whole(t.quantity, "quantity", 1);
    if (!["hold", "confirmed"].includes(t.state)) reject("INVALID", "Invalid target state");
    const old = existing.get(s.id);
    if (t.state === "hold") {
      instant(t.holdUntil!, "hold expiry");
      if (t.holdUntil! <= now) reject("EXPIRED", "Hold expiry must be in the future");
      // Holds cannot be extended through release. An existing grandfathered hold
      // may remain or confirm after release, but its deadline cannot be extended.
      if (t.holdUntil! > s.releaseAt && !(old?.state === "hold" && t.holdUntil! <= old.holdUntil!)) reject("RELEASED", "Hold extends beyond release deadline");
    } else if (t.holdUntil !== undefined) reject("INVALID", "Confirmation cannot have an expiry");
    if (old?.state === "confirmed" && t.state === "hold") reject("INVALID", "Confirmed stock cannot become a hold");
    const increase = t.quantity - (old?.quantity ?? 0);
    if (increase > 0 && (!s.enabled || s.stopSale || now >= s.releaseAt)) reject("CLOSED", "Slot is disabled, stopped or released");
    next.set(s.id, { ...t, reservationId });
  }
  // A return only replenishes sellable capacity if contract rules permit it.
  for (const [id, old] of existing) {
    const returned = Math.max(0, old.quantity - (next.get(id)?.quantity ?? 0));
    const s = map.get(id)!;
    if (!s.replenishOnReturn) s.retired = add(s.retired, returned);
  }
  const result = [...others, ...next.values()];
  const totals = new Map<string, number>();
  for (const a of result) totals.set(a.slotId, add(totals.get(a.slotId) ?? 0, a.quantity));
  for (const s of slots) {
    if (add(s.retired, totals.get(s.id) ?? 0) > s.capacity) reject("SOLD_OUT", "Insufficient allotment for at least one date or departure");
  }
  return { slots, allocations: result };
}
export function availability(inputSlots: Slot[], inputAllocations: Allocation[], now: number) {
  const { slots, allocations } = prepare(inputSlots, inputAllocations, now);
  return slots.map(s => {
    const rows = allocations.filter(a => a.slotId === s.id);
    const held = rows.filter(a => a.state === "hold").reduce((n, a) => add(n, a.quantity), 0);
    const confirmed = rows.filter(a => a.state === "confirmed").reduce((n, a) => add(n, a.quantity), 0);
    const remaining = s.capacity - s.retired - held - confirmed;
    return { slotId: s.id, held, confirmed, retired: s.retired,
      available: s.enabled && !s.stopSale && now < s.releaseAt ? Math.max(0, remaining) : 0 };
  });
}
