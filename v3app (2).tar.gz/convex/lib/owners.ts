import type { Doc, Id } from "../_generated/dataModel";
import type { QueryCtx } from "../_generated/server";

/** Display names for the owners of a set of bookings, one read per owner. */
export async function ownerNames(ctx: QueryCtx, bookings: Doc<"bookings">[]) {
  const ids = [...new Set(bookings.map((b) => b.ownerId))];
  const users = await Promise.all(ids.map((id) => ctx.db.get("users", id)));
  const names = new Map<Id<"users">, string | null>();
  ids.forEach((id, i) => names.set(id, users[i]?.name ?? users[i]?.email ?? null));
  return names;
}
