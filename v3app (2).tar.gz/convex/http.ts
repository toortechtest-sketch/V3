import { httpRouter } from "convex/server";
import { oauthCallback } from "./gmail/oauth";
import { CALLBACK_PATH } from "./gmail/config";

const http = httpRouter();

// Google redirects here after the staff member picks an account and grants access.
http.route({ path: CALLBACK_PATH, method: "GET", handler: oauthCallback });

export default http;
