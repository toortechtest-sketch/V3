import { v } from "convex/values";
import { query, type QueryCtx } from "./_generated/server";
import type { Doc } from "./_generated/dataModel";
import { fail, isManagerRole, requireStaff, type Staff } from "./lib/access";
import { invoicesOf, paymentsOf, quoteSell } from "./lib/financeData";
import { financeOf } from "./lib/financeLock";
import { financeSummary, invoiceBalances, isOverdue } from "./lib/financeMath";
import { money } from "./lib/quoteMath";
import type { BookingStage } from "./schema/bookings";

// Each booking costs several indexed reads, so the overview is capped.
const PER_STAGE_LIMIT = 40;
const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

const SCOPES = {
  active: ["enquiry", "quoted", "confirmed", "operating"],
  closed: ["closed"],
} as const satisfies Record<string, readonly BookingStage[]>;

async function bookingsInStage(ctx: QueryCtx, staff: Staff, stage: BookingStage) {
  // Agents and agency managers only ever see their own bookings.
  const q = isManagerRole(staff.role)
    ? ctx.db.query("bookings").withIndex("by_stage_and_start_date", (q) => q.eq("stage", stage))
    : ctx.db
        .query("bookings")
        .withIndex("by_owner_and_stage_and_start_date", (q) =>
          q.eq("ownerId", staff.user._id).eq("stage", stage),
        );
  return await q.order("desc").take(PER_STAGE_LIMIT);
}

async function rowFor(ctx: QueryCtx, booking: Doc<"bookings">, today: string) {
  const [finance, invoices, payments] = await Promise.all([
    financeOf(ctx, booking._id),
    invoicesOf(ctx, booking._id),
    paymentsOf(ctx, booking._id),
  ]);
  const contractValue = finance?.contractValue ?? (await quoteSell(ctx, booking));
  const summary = financeSummary(contractValue, invoices, payments);
  const balances = invoiceBalances(invoices, payments);

  let overdue = 0;
  let overdueCount = 0;
  let nextDue: { date: string; amount: number } | null = null;
  for (const inv of invoices) {
    const balance = balances.get(inv._id);
    if (!balance || balance.open <= 0 || inv.kind !== "invoice" || inv.status !== "issued") continue;
    if (isOverdue(inv, balance, today)) {
      overdue += balance.open;
      overdueCount += 1;
    } else if (inv.dueDate && (!nextDue || inv.dueDate < nextDue.date)) {
      nextDue = { date: inv.dueDate, amount: balance.open };
    }
  }

  return {
    bookingId: booking._id,
    reference: booking.reference,
    title: booking.title,
    clientName: booking.clientName,
    stage: booking.stage,
    startDate: booking.startDate,
    currency: booking.currency,
    rateToBase: booking.exchangeRateToBase,
    contractValue: summary.contractValue,
    netInvoiced: summary.netInvoiced,
    received: summary.received,
    outstanding: summary.outstanding,
    toInvoice: summary.toInvoice,
    overdue: money(overdue),
    overdueCount,
    nextDue,
    locked: finance?.lockedAt !== undefined,
  };
}

/** Money position across every booking the caller can see. */
export const overview = query({
  args: { scope: v.union(v.literal("active"), v.literal("closed")), today: v.string() },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx);
    if (!DATE_PATTERN.test(args.today)) fail("BAD_REQUEST", "Pick a valid date.");

    const perStage = await Promise.all(
      SCOPES[args.scope].map((stage) => bookingsInStage(ctx, staff, stage)),
    );
    const rows = await Promise.all(perStage.flat().map((b) => rowFor(ctx, b, args.today)));

    // Totals converted to the base currency (EUR) with each booking's own rate.
    const inBase = (pick: (r: (typeof rows)[number]) => number) =>
      money(rows.reduce((s, r) => s + pick(r) * r.rateToBase, 0));

    return {
      rows,
      truncated: perStage.some((list) => list.length >= PER_STAGE_LIMIT),
      seesAll: isManagerRole(staff.role),
      totals: {
        contractValue: inBase((r) => r.contractValue),
        received: inBase((r) => r.received),
        outstanding: inBase((r) => Math.max(0, r.outstanding)),
        overdue: inBase((r) => r.overdue),
        toInvoice: inBase((r) => Math.max(0, r.toInvoice)),
        overdueBookings: rows.filter((r) => r.overdue > 0).length,
        lockedBookings: rows.filter((r) => r.locked).length,
      },
    };
  },
});
