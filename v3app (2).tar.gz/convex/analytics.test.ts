import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Trip",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-11-02",
  endDate: "2026-11-05",
  pax: 10,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agent = as(t, "a");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  return { owner, agent };
}

const TODAY = "2026-10-04";

describe("analytics overview", () => {
  it("rejects non-managers", async () => {
    const { agent } = await setup();
    await expect(
      agent.query(api.analytics.overview, { today: TODAY }),
    ).rejects.toThrow(/Owner or global manager/);
  });

  it("buckets bookings by stage and computes a win rate", async () => {
    const { owner } = await setup();
    const enquiry = await owner.mutation(api.bookings.create, { ...BOOKING, title: "Enquiry trip" });
    const confirmed = await owner.mutation(api.bookings.create, { ...BOOKING, title: "Confirmed trip" });
    await owner.mutation(api.bookings.setStage, { id: confirmed, stage: "confirmed" });
    const cancelled = await owner.mutation(api.bookings.create, { ...BOOKING, title: "Cancelled trip" });
    await owner.mutation(api.bookings.setStage, { id: cancelled, stage: "cancelled" });

    const result = await owner.query(api.analytics.overview, { today: TODAY });
    const byStage = new Map(result.pipeline.map((p) => [p.stage, p.count]));
    expect(byStage.get("enquiry")).toBe(1);
    expect(byStage.get("confirmed")).toBe(1);
    expect(byStage.get("cancelled")).toBe(1);
    // Decided = confirmed + cancelled = 2, won = confirmed = 1 -> 50%
    expect(result.conversion).toMatchObject({ decided: 2, won: 1, rate: 50 });
    expect(enquiry).toBeDefined();
  });

  it("tallies received payments per client and per month", async () => {
    const { owner } = await setup();
    const booking = await owner.mutation(api.bookings.create, BOOKING);
    await owner.mutation(api.bookings.setStage, { id: booking, stage: "confirmed" });
    await owner.mutation(api.finance.setContractValue, { bookingId: booking, contractValue: 1000 });
    await owner.mutation(api.finance.recordPayment, {
      bookingId: booking, amount: 400, receivedDate: "2026-10-01", method: "card",
    });

    const result = await owner.query(api.analytics.overview, { today: TODAY });
    expect(result.topClients).toEqual([{ clientName: "Acme", received: 400, bookingCount: 1 }]);
    const october = result.monthlyTrend.find((m) => m.month === "2026-10");
    expect(october?.received).toBe(400);
  });
});
