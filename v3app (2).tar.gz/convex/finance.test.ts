import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";
import { financeSummary, invoiceBalances, isOverdue } from "./lib/financeMath";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-11-02",
  endDate: "2026-11-05",
  pax: 10,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
  markupPercent: 25,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  return { owner, agentA, agentB, bookingId };
}

describe("finance math", () => {
  const invoices = [
    { _id: "i1", kind: "invoice" as const, status: "issued" as const, amount: 300, dueDate: "2026-01-10" },
    { _id: "i2", kind: "invoice" as const, status: "void" as const, amount: 999 },
    { _id: "c1", kind: "credit_note" as const, status: "issued" as const, amount: 50 },
  ];

  it("ignores void invoices and nets credit notes", () => {
    const s = financeSummary(1000, invoices, [{ amount: 100, invoiceId: "i1" }, { amount: 20 }]);
    expect(s).toMatchObject({
      invoiced: 300,
      credited: 50,
      netInvoiced: 250,
      received: 120,
      outstanding: 130,
      toInvoice: 750,
    });
  });

  it("flags overdue only when unpaid past the due day", () => {
    const partly = invoiceBalances(invoices, [{ amount: 100, invoiceId: "i1" }]).get("i1")!;
    expect(partly).toEqual({ paid: 100, open: 200, isPaid: false });
    expect(isOverdue(invoices[0], partly, "2026-01-11")).toBe(true);
    expect(isOverdue(invoices[0], partly, "2026-01-10")).toBe(false);
    const paid = invoiceBalances(invoices, [{ amount: 300, invoiceId: "i1" }]).get("i1")!;
    expect(isOverdue(invoices[0], paid, "2026-02-01")).toBe(false);
  });
});

describe("booking finance", () => {
  it("follows the quote, invoices instalments and tracks payments", async () => {
    const { agentA, bookingId } = await setup();
    await agentA.mutation(api.quotes.addLine, {
      bookingId,
      section: "accommodation",
      description: "Hotel",
      basis: "fixed",
      quantity: 1,
      times: 1,
      unitCost: 800,
    });
    await agentA.mutation(api.finance.applyStandardSchedule, { bookingId, today: "2026-06-01" });
    let f = await agentA.query(api.finance.get, { bookingId });
    expect(f.contractValue).toBe(1000);
    expect(f.installments.map((i) => [i.label, i.amount, i.dueDate])).toEqual([
      ["Deposit", 300, "2026-06-01"],
      ["Balance", 700, "2026-10-03"],
    ]);

    const invoiceId = await agentA.mutation(api.finance.invoiceInstallment, {
      id: f.installments[0]._id,
      issueDate: "2026-06-01",
    });
    await agentA.mutation(api.finance.recordPayment, {
      bookingId,
      amount: 300,
      receivedDate: "2026-06-05",
      method: "bank_transfer",
      invoiceId,
    });
    f = await agentA.query(api.finance.get, { bookingId });
    expect(f.invoices[0].number).toBe("INV-2026-0001");
    expect(f.invoices[0].balance.isPaid).toBe(true);
    expect(f.summary).toMatchObject({ received: 300, outstanding: 0, toInvoice: 700 });
    await expect(
      agentA.mutation(api.finance.invoiceInstallment, { id: f.installments[0]._id, issueDate: "2026-06-02" }),
    ).rejects.toThrow(/already invoiced/);
  });

  it("locks money changes but still allows credit notes", async () => {
    const { owner, agentA, bookingId } = await setup();
    await agentA.mutation(api.finance.setContractValue, { bookingId, contractValue: 500 });
    await agentA.mutation(api.finance.setLocked, { bookingId, locked: true });

    await expect(
      agentA.mutation(api.finance.recordPayment, {
        bookingId,
        amount: 10,
        receivedDate: "2026-06-05",
        method: "cash",
      }),
    ).rejects.toThrow(/finance locked/);
    await expect(
      agentA.mutation(api.quotes.addLine, {
        bookingId,
        section: "other",
        description: "Extra",
        basis: "fixed",
        quantity: 1,
        times: 1,
        unitCost: 10,
      }),
    ).rejects.toThrow(/finance locked/);
    await agentA.mutation(api.finance.createInvoice, {
      bookingId,
      kind: "credit_note",
      label: "Goodwill",
      amount: 25,
      issueDate: "2026-06-05",
    });

    await expect(
      agentA.mutation(api.finance.setLocked, { bookingId, locked: false }),
    ).rejects.toThrow(/Only an owner/);
    await owner.mutation(api.finance.setLocked, { bookingId, locked: false });
    const f = await agentA.query(api.finance.get, { bookingId });
    expect(f.lock).toBeNull();
    expect(f.invoices[0].number).toBe("CN-2026-0001");
  });

  it("keeps other agents out", async () => {
    const { agentB, bookingId } = await setup();
    await expect(agentB.query(api.finance.get, { bookingId })).rejects.toThrow(/not found/);
    await expect(
      agentB.mutation(api.finance.setLocked, { bookingId, locked: true }),
    ).rejects.toThrow(/not found/);
  });
});
