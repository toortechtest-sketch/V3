import { paginationOptsValidator } from "convex/server";
import { v } from "convex/values";
import { mutation, query, type MutationCtx, type QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import {
  MANAGER_ROLES,
  canAccessBooking,
  fail,
  isManagerRole,
  requireBooking,
  requireStaff,
  type Staff,
} from "./lib/access";
import {
  NO_DUE_KEY,
  taskKindValidator,
  taskStatusValidator,
  type TaskStatus,
} from "./schema/tasks";

const BOOKING_OPEN_LIMIT = 200;
const BOOKING_DONE_LIMIT = 50;
const DAY_PATTERN = /^\d{4}-\d{2}-\d{2}$/;

const taskFields = {
  kind: taskKindValidator,
  title: v.string(),
  notes: v.optional(v.string()),
  dueDate: v.optional(v.string()),
  assigneeId: v.optional(v.id("users")),
};

const trim = (s: string | undefined) => s?.trim() || undefined;

/** Index helper fields, kept in one place so they never drift from the source. */
function derived(status: TaskStatus, dueDate: string | undefined) {
  return { isDone: status === "done", dueKey: dueDate ?? NO_DUE_KEY };
}

function clean(fields: { title: string; notes?: string; dueDate?: string }) {
  const title = fields.title.trim();
  const notes = trim(fields.notes);
  const dueDate = trim(fields.dueDate);
  if (!title) fail("BAD_REQUEST", "Add a task title.");
  if (title.length > 200) fail("BAD_REQUEST", "Keep the title under 200 characters.");
  if (notes && notes.length > 5000) fail("BAD_REQUEST", "Keep notes under 5,000 characters.");
  if (dueDate && !DAY_PATTERN.test(dueDate)) fail("BAD_REQUEST", "Pick a valid due date.");
  return { title, notes, dueDate };
}

/**
 * Tasks can go to whoever can open the booking: its owner or a manager.
 * That keeps every assignee able to act on the booking the task is about.
 */
async function requireAssignee(
  ctx: MutationCtx,
  booking: Doc<"bookings">,
  userId: Id<"users">,
) {
  if (userId === booking.ownerId) return;
  const role = await ctx.db
    .query("staffRoles")
    .withIndex("by_user", (q) => q.eq("userId", userId))
    .unique();
  if (!role || !isManagerRole(role.role)) {
    fail("BAD_REQUEST", "Assign tasks to the booking owner or a manager.");
  }
}

/** Assignees keep access to their own task even if the booking moves on. */
function canAccessTask(staff: Staff, task: Doc<"tasks">, booking: Doc<"bookings"> | null) {
  if (task.assigneeId === staff.user._id) return true;
  return booking !== null && canAccessBooking(staff, booking);
}

async function requireTask(ctx: MutationCtx, id: Id<"tasks">) {
  const staff = await requireStaff(ctx);
  const task = await ctx.db.get("tasks", id);
  const booking = task ? await ctx.db.get("bookings", task.bookingId) : null;
  // Missing and forbidden look the same, like bookings.
  if (!task || !canAccessTask(staff, task, booking)) fail("NOT_FOUND", "Task not found.");
  return { staff, task, booking };
}

async function displayNames(ctx: QueryCtx, ids: Id<"users">[]) {
  const unique = [...new Set(ids)];
  const users = await Promise.all(unique.map((id) => ctx.db.get("users", id)));
  return new Map(unique.map((id, i) => [id, users[i]?.name ?? users[i]?.email ?? null]));
}

/** Open tasks soonest first (undated last), then recently completed ones. */
export const listForBooking = query({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    const byDone = (isDone: boolean) =>
      ctx.db
        .query("tasks")
        .withIndex("by_booking_and_is_done_and_due_key", (q) =>
          q.eq("bookingId", booking._id).eq("isDone", isDone),
        );
    const [open, done] = await Promise.all([
      byDone(false).take(BOOKING_OPEN_LIMIT),
      byDone(true).order("desc").take(BOOKING_DONE_LIMIT),
    ]);
    const names = await displayNames(ctx, [...open, ...done].map((t) => t.assigneeId));
    const withName = (t: Doc<"tasks">) => ({ ...t, assigneeName: names.get(t.assigneeId) ?? null });
    return { open: open.map(withName), done: done.map(withName) };
  },
});

/**
 * Task inbox across bookings. "mine" pages tasks assigned to the caller;
 * "everyone" is for managers only. Filters are applied in the index, never
 * after paging.
 */
export const list = query({
  args: {
    paginationOpts: paginationOptsValidator,
    scope: v.union(v.literal("mine"), v.literal("everyone")),
    done: v.boolean(),
  },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx);
    const everyone = args.scope === "everyone" && isManagerRole(staff.role);
    const base = everyone
      ? ctx.db
          .query("tasks")
          .withIndex("by_is_done_and_due_key", (q) => q.eq("isDone", args.done))
      : ctx.db
          .query("tasks")
          .withIndex("by_assignee_and_is_done_and_due_key", (q) =>
            q.eq("assigneeId", staff.user._id).eq("isDone", args.done),
          );
    // Open work reads soonest due first; finished work latest due first.
    const results = await base.order(args.done ? "desc" : "asc").paginate(args.paginationOpts);

    const bookingIds = [...new Set(results.page.map((t) => t.bookingId))];
    const bookings = await Promise.all(bookingIds.map((id) => ctx.db.get("bookings", id)));
    const bookingById = new Map(bookingIds.map((id, i) => [id, bookings[i]]));
    const names = await displayNames(ctx, results.page.map((t) => t.assigneeId));

    return {
      ...results,
      page: results.page.map((t) => {
        const booking = bookingById.get(t.bookingId) ?? null;
        // The assignee may no longer see the booking itself; only link it if they can.
        const visible = booking && canAccessBooking(staff, booking) ? booking : null;
        return {
          ...t,
          assigneeName: names.get(t.assigneeId) ?? null,
          booking: visible
            ? { _id: visible._id, reference: visible.reference, title: visible.title }
            : null,
        };
      }),
    };
  },
});

/** People a task on this booking can be assigned to. */
export const listAssignees = query({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    const managerRoles = await Promise.all(
      MANAGER_ROLES.map((role) =>
        ctx.db
          .query("staffRoles")
          .withIndex("by_role", (q) => q.eq("role", role))
          .take(100),
      ),
    );
    const ids = [booking.ownerId, ...managerRoles.flat().map((r) => r.userId)];
    const names = await displayNames(ctx, ids);
    return [...names.entries()]
      .map(([userId, name]) => ({
        userId,
        name: name ?? "Unnamed",
        isBookingOwner: userId === booking.ownerId,
      }))
      .sort(
        (a, b) =>
          Number(b.isBookingOwner) - Number(a.isBookingOwner) || a.name.localeCompare(b.name),
      );
  },
});

export const create = mutation({
  args: { bookingId: v.id("bookings"), ...taskFields },
  handler: async (ctx, args): Promise<Id<"tasks">> => {
    const { staff, booking } = await requireBooking(ctx, args.bookingId);
    const fields = clean(args);
    const assigneeId = args.assigneeId ?? staff.user._id;
    await requireAssignee(ctx, booking, assigneeId);
    return await ctx.db.insert("tasks", {
      bookingId: booking._id,
      kind: args.kind,
      ...fields,
      status: "open",
      assigneeId,
      createdById: staff.user._id,
      updatedAt: new Date().toISOString(),
      ...derived("open", fields.dueDate),
    });
  },
});

export const update = mutation({
  args: { id: v.id("tasks"), ...taskFields },
  handler: async (ctx, args) => {
    const { task, booking } = await requireTask(ctx, args.id);
    const fields = clean(args);
    const assigneeId = args.assigneeId ?? task.assigneeId;
    if (assigneeId !== task.assigneeId) {
      if (!booking) fail("NOT_FOUND", "Booking not found.");
      await requireAssignee(ctx, booking, assigneeId);
    }
    await ctx.db.patch("tasks", task._id, {
      kind: args.kind,
      title: fields.title,
      // Explicit undefined clears fields the user emptied.
      notes: fields.notes,
      dueDate: fields.dueDate,
      assigneeId,
      updatedAt: new Date().toISOString(),
      ...derived(task.status, fields.dueDate),
    });
    return null;
  },
});

export const setStatus = mutation({
  args: { id: v.id("tasks"), status: taskStatusValidator },
  handler: async (ctx, args) => {
    const { task } = await requireTask(ctx, args.id);
    if (task.status === args.status) return null;
    const now = new Date().toISOString();
    await ctx.db.patch("tasks", task._id, {
      status: args.status,
      completedAt: args.status === "done" ? now : undefined,
      updatedAt: now,
      ...derived(args.status, task.dueDate),
    });
    return null;
  },
});

export const remove = mutation({
  args: { id: v.id("tasks") },
  handler: async (ctx, args) => {
    const { staff, task } = await requireTask(ctx, args.id);
    // Only the creator or a manager can delete; assignees can mark done instead.
    if (task.createdById !== staff.user._id && !isManagerRole(staff.role)) {
      fail("FORBIDDEN", "Only the person who created this task or a manager can delete it.");
    }
    await ctx.db.delete("tasks", task._id);
    return null;
  },
});
