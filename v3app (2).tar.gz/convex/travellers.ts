import { v } from "convex/values";
import { mutation, query, type MutationCtx, type QueryCtx } from "./_generated/server";
import type { Doc, Id } from "./_generated/dataModel";
import { fail, requireBooking } from "./lib/access";
import {
  roomStatusValidator,
  roomTypeValidator,
  type RoomStatus,
  type RoomType,
} from "./schema/travellers";

// Bounds keep the reactive rooming query small even for large conferences.
export const TRAVELLER_LIMIT = 1000;
export const ROOM_LIMIT = 600;
const BULK_LIMIT = 300;
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/** Guests a room sleeps unless the hotel says otherwise. */
export const DEFAULT_CAPACITY: Record<RoomType, number> = {
  single: 1,
  double: 2,
  twin: 2,
  triple: 3,
  suite: 2,
};

const trim = (s: string | undefined) => s?.trim() || undefined;
const now = () => new Date().toISOString();
const sortNameOf = (first: string, last: string) => `${last} ${first}`.trim().toLowerCase();

const travellerFields = {
  firstName: v.string(),
  lastName: v.string(),
  email: v.optional(v.string()),
  phone: v.optional(v.string()),
  roomPreference: roomTypeValidator,
  sharingWith: v.optional(v.string()),
  dietaryRequirements: v.optional(v.string()),
  notes: v.optional(v.string()),
};

type TravellerFields = {
  firstName: string;
  lastName: string;
  email?: string;
  phone?: string;
  roomPreference: RoomType;
  sharingWith?: string;
  dietaryRequirements?: string;
  notes?: string;
};

const roomFields = {
  supplierId: v.optional(v.id("suppliers")),
  roomType: roomTypeValidator,
  capacity: v.number(),
  roomNumber: v.optional(v.string()),
  status: roomStatusValidator,
  notes: v.optional(v.string()),
};

type RoomFields = {
  supplierId?: Id<"suppliers">;
  roomType: RoomType;
  capacity: number;
  roomNumber?: string;
  status: RoomStatus;
  notes?: string;
};

function cleanTraveller(fields: TravellerFields): TravellerFields {
  const cleaned: TravellerFields = {
    firstName: fields.firstName.trim(),
    lastName: fields.lastName.trim(),
    email: trim(fields.email)?.toLowerCase(),
    phone: trim(fields.phone),
    roomPreference: fields.roomPreference,
    sharingWith: trim(fields.sharingWith),
    dietaryRequirements: trim(fields.dietaryRequirements),
    notes: trim(fields.notes),
  };
  if (!cleaned.firstName && !cleaned.lastName) fail("BAD_REQUEST", "Add the traveller's name.");
  if (cleaned.firstName.length > 100 || cleaned.lastName.length > 100) {
    fail("BAD_REQUEST", "Keep names under 100 characters.");
  }
  if (cleaned.email && !EMAIL_PATTERN.test(cleaned.email)) {
    fail("BAD_REQUEST", "That email address doesn't look right.");
  }
  return cleaned;
}

async function cleanRoom(ctx: MutationCtx, fields: RoomFields): Promise<RoomFields> {
  const cleaned: RoomFields = {
    supplierId: fields.supplierId,
    roomType: fields.roomType,
    capacity: fields.capacity,
    roomNumber: trim(fields.roomNumber),
    status: fields.status,
    notes: trim(fields.notes),
  };
  if (!Number.isInteger(cleaned.capacity) || cleaned.capacity < 1 || cleaned.capacity > 12) {
    fail("BAD_REQUEST", "A room sleeps between 1 and 12 guests.");
  }
  if (cleaned.supplierId) {
    const supplier = await ctx.db.get("suppliers", cleaned.supplierId);
    if (!supplier) fail("NOT_FOUND", "Hotel not found.");
  }
  return cleaned;
}

function travellersOf(ctx: QueryCtx | MutationCtx, bookingId: Id<"bookings">) {
  return ctx.db
    .query("travellers")
    .withIndex("by_booking_and_sort_name", (q) => q.eq("bookingId", bookingId))
    .take(TRAVELLER_LIMIT);
}

function roomsOf(ctx: QueryCtx | MutationCtx, bookingId: Id<"bookings">) {
  return ctx.db
    .query("rooms")
    .withIndex("by_booking", (q) => q.eq("bookingId", bookingId))
    .take(ROOM_LIMIT);
}

async function requireTraveller(ctx: MutationCtx, id: Id<"travellers">) {
  const traveller = await ctx.db.get("travellers", id);
  if (!traveller) fail("NOT_FOUND", "Traveller not found.");
  const { booking } = await requireBooking(ctx, traveller.bookingId);
  return { traveller, booking };
}

async function requireRoom(ctx: MutationCtx, id: Id<"rooms">) {
  const room = await ctx.db.get("rooms", id);
  if (!room) fail("NOT_FOUND", "Room not found.");
  const { booking } = await requireBooking(ctx, room.bookingId);
  return { room, booking };
}

async function occupantsOf(ctx: MutationCtx, room: Doc<"rooms">) {
  const all = await travellersOf(ctx, room.bookingId);
  return all.filter((t) => t.roomId === room._id);
}

export const get = query({
  args: { bookingId: v.id("bookings") },
  handler: async (ctx, args) => {
    const { booking } = await requireBooking(ctx, args.bookingId);
    const [travellers, rooms] = await Promise.all([
      travellersOf(ctx, booking._id),
      roomsOf(ctx, booking._id),
    ]);

    const supplierIds = [...new Set(rooms.flatMap((r) => (r.supplierId ? [r.supplierId] : [])))];
    const suppliers = await Promise.all(supplierIds.map((id) => ctx.db.get("suppliers", id)));
    const supplierById = new Map(suppliers.flatMap((s) => (s ? [[s._id, s] as const] : [])));

    const occupants = new Map<Id<"rooms">, Doc<"travellers">[]>();
    for (const t of travellers) {
      if (!t.roomId) continue;
      occupants.set(t.roomId, [...(occupants.get(t.roomId) ?? []), t]);
    }

    const roomViews = rooms
      .map((room) => {
        const supplier = room.supplierId ? supplierById.get(room.supplierId) : undefined;
        return {
          ...room,
          supplier: supplier
            ? { _id: supplier._id, name: supplier.name, category: supplier.category }
            : null,
          occupants: (occupants.get(room._id) ?? []).map((t) => ({
            _id: t._id,
            firstName: t.firstName,
            lastName: t.lastName,
          })),
        };
      })
      // Group by hotel, then room number, then the order added.
      .sort(
        (a, b) =>
          (a.supplier?.name ?? "\uffff").localeCompare(b.supplier?.name ?? "\uffff") ||
          (a.roomNumber ?? "\uffff").localeCompare(b.roomNumber ?? "\uffff", undefined, {
            numeric: true,
          }) ||
          a._creationTime - b._creationTime,
      );

    const roomById = new Map(roomViews.map((r) => [r._id, r]));
    const travellerViews = travellers.map((t) => {
      const room = t.roomId ? roomById.get(t.roomId) : undefined;
      return {
        ...t,
        room: room
          ? { _id: room._id, roomType: room.roomType, roomNumber: room.roomNumber, hotel: room.supplier?.name }
          : null,
      };
    });

    return {
      travellers: travellerViews,
      rooms: roomViews,
      expectedPax: booking.pax,
      unassignedCount: travellers.filter((t) => !t.roomId).length,
      bedCount: rooms.reduce((sum, r) => sum + r.capacity, 0),
      isFull: travellers.length >= TRAVELLER_LIMIT,
      roomsFull: rooms.length >= ROOM_LIMIT,
    };
  },
});

export const addTraveller = mutation({
  args: { bookingId: v.id("bookings"), ...travellerFields },
  handler: async (ctx, args): Promise<Id<"travellers">> => {
    const { bookingId, ...rest } = args;
    const { booking, staff } = await requireBooking(ctx, bookingId);
    const existing = await travellersOf(ctx, booking._id);
    if (existing.length >= TRAVELLER_LIMIT) {
      fail("BAD_REQUEST", `A booking can hold up to ${TRAVELLER_LIMIT} travellers.`);
    }
    const fields = cleanTraveller(rest);
    return await ctx.db.insert("travellers", {
      bookingId: booking._id,
      ...fields,
      createdById: staff.user._id,
      sortName: sortNameOf(fields.firstName, fields.lastName),
      updatedAt: now(),
    });
  },
});

/** Adds many travellers from a pasted list in one go. */
export const addTravellers = mutation({
  args: {
    bookingId: v.id("bookings"),
    travellers: v.array(
      v.object({
        firstName: v.string(),
        lastName: v.string(),
        email: v.optional(v.string()),
        roomPreference: roomTypeValidator,
      }),
    ),
  },
  handler: async (ctx, args): Promise<number> => {
    const { booking, staff } = await requireBooking(ctx, args.bookingId);
    if (args.travellers.length === 0) fail("BAD_REQUEST", "Add at least one name.");
    if (args.travellers.length > BULK_LIMIT) {
      fail("BAD_REQUEST", `Add up to ${BULK_LIMIT} travellers at a time.`);
    }
    const existing = await travellersOf(ctx, booking._id);
    if (existing.length + args.travellers.length > TRAVELLER_LIMIT) {
      fail("BAD_REQUEST", `A booking can hold up to ${TRAVELLER_LIMIT} travellers.`);
    }
    const cleaned = args.travellers.map((t) => cleanTraveller(t));
    const updatedAt = now();
    for (const fields of cleaned) {
      await ctx.db.insert("travellers", {
        bookingId: booking._id,
        ...fields,
        createdById: staff.user._id,
        sortName: sortNameOf(fields.firstName, fields.lastName),
        updatedAt,
      });
    }
    return cleaned.length;
  },
});

export const updateTraveller = mutation({
  args: { id: v.id("travellers"), ...travellerFields },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    await requireTraveller(ctx, id);
    const fields = cleanTraveller(rest);
    await ctx.db.patch("travellers", id, {
      ...fields,
      sortName: sortNameOf(fields.firstName, fields.lastName),
      updatedAt: now(),
    });
    return null;
  },
});

export const removeTraveller = mutation({
  args: { id: v.id("travellers") },
  handler: async (ctx, args) => {
    await requireTraveller(ctx, args.id);
    await ctx.db.delete("travellers", args.id);
    return null;
  },
});

export const addRoom = mutation({
  args: { bookingId: v.id("bookings"), ...roomFields, count: v.optional(v.number()) },
  handler: async (ctx, args): Promise<number> => {
    const { bookingId, count = 1, ...rest } = args;
    const { booking } = await requireBooking(ctx, bookingId);
    if (!Number.isInteger(count) || count < 1 || count > 100) {
      fail("BAD_REQUEST", "Add between 1 and 100 rooms at a time.");
    }
    const existing = await roomsOf(ctx, booking._id);
    if (existing.length + count > ROOM_LIMIT) {
      fail("BAD_REQUEST", `A rooming list can hold up to ${ROOM_LIMIT} rooms.`);
    }
    const fields = await cleanRoom(ctx, rest);
    // Room numbers are unique per room, so only a single new room keeps one.
    const roomNumber = count === 1 ? fields.roomNumber : undefined;
    const updatedAt = now();
    for (let i = 0; i < count; i++) {
      await ctx.db.insert("rooms", { bookingId: booking._id, ...fields, roomNumber, updatedAt });
    }
    return count;
  },
});

export const updateRoom = mutation({
  args: { id: v.id("rooms"), ...roomFields },
  handler: async (ctx, args) => {
    const { id, ...rest } = args;
    const { room } = await requireRoom(ctx, id);
    const fields = await cleanRoom(ctx, rest);
    const occupants = await occupantsOf(ctx, room);
    if (fields.capacity < occupants.length) {
      fail(
        "BAD_REQUEST",
        `${occupants.length} guests are in this room. Move someone out before lowering the size.`,
      );
    }
    await ctx.db.replace("rooms", id, { bookingId: room.bookingId, ...fields, updatedAt: now() });
    return null;
  },
});

/** Removes a room; its guests go back to the unassigned list. */
export const removeRoom = mutation({
  args: { id: v.id("rooms") },
  handler: async (ctx, args) => {
    const { room } = await requireRoom(ctx, args.id);
    const updatedAt = now();
    for (const t of await occupantsOf(ctx, room)) {
      await ctx.db.patch("travellers", t._id, { roomId: undefined, updatedAt });
    }
    await ctx.db.delete("rooms", room._id);
    return null;
  },
});

/** Places a traveller in a room, or takes them out with `roomId: null`. */
export const assign = mutation({
  args: { travellerId: v.id("travellers"), roomId: v.union(v.id("rooms"), v.null()) },
  handler: async (ctx, args) => {
    const { traveller } = await requireTraveller(ctx, args.travellerId);
    if (args.roomId === null) {
      await ctx.db.patch("travellers", traveller._id, { roomId: undefined, updatedAt: now() });
      return null;
    }
    if (traveller.roomId === args.roomId) return null;
    const room = await ctx.db.get("rooms", args.roomId);
    if (!room || room.bookingId !== traveller.bookingId) fail("NOT_FOUND", "Room not found.");
    const occupants = await occupantsOf(ctx, room);
    if (occupants.length >= room.capacity) fail("CONFLICT", "That room is already full.");
    await ctx.db.patch("travellers", traveller._id, { roomId: room._id, updatedAt: now() });
    return null;
  },
});
