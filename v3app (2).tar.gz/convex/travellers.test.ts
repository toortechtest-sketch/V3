import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (t: ReturnType<typeof convexTest>, sub: string) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub });

const BOOKING = {
  title: "Flying Hogs",
  type: "group" as const,
  clientName: "Acme",
  destination: "Barcelona",
  startDate: "2026-12-30",
  endDate: "2027-01-02",
  pax: 4,
  currency: "EUR" as const,
  exchangeRateToBase: 1,
};

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner");
  const agentA = as(t, "a");
  const agentB = as(t, "b");
  await owner.mutation(api.users.updateCurrentUser, {});
  const aId = await agentA.mutation(api.users.updateCurrentUser, {});
  const bId = await agentB.mutation(api.users.updateCurrentUser, {});
  for (const userId of [aId, bId]) {
    await owner.mutation(api.staff.setRole, { userId, role: "agent" });
  }
  const bookingId = await agentA.mutation(api.bookings.create, BOOKING);
  return { owner, agentA, agentB, bookingId };
}

const person = (firstName: string, lastName: string) => ({
  firstName,
  lastName,
  roomPreference: "twin" as const,
});

describe("travellers and rooming", () => {
  it("lists travellers alphabetically by last name", async () => {
    const { agentA, bookingId } = await setup();
    await agentA.mutation(api.travellers.addTravellers, {
      bookingId,
      travellers: [person("Zoe", "Adams"), person("Ann", "Young"), person("Bob", "Moss")],
    });
    const data = await agentA.query(api.travellers.get, { bookingId });
    expect(data.travellers.map((t) => t.lastName)).toEqual(["Adams", "Moss", "Young"]);
    expect(data.unassignedCount).toBe(3);
  });

  it("fills a room up to its capacity and no further", async () => {
    const { agentA, bookingId } = await setup();
    const ids = await Promise.all(
      [person("A", "One"), person("B", "Two"), person("C", "Three")].map((p) =>
        agentA.mutation(api.travellers.addTraveller, { bookingId, ...p }),
      ),
    );
    await agentA.mutation(api.travellers.addRoom, {
      bookingId,
      roomType: "twin",
      capacity: 2,
      status: "tentative",
    });
    const [room] = (await agentA.query(api.travellers.get, { bookingId })).rooms;
    await agentA.mutation(api.travellers.assign, { travellerId: ids[0], roomId: room._id });
    await agentA.mutation(api.travellers.assign, { travellerId: ids[1], roomId: room._id });
    await expect(
      agentA.mutation(api.travellers.assign, { travellerId: ids[2], roomId: room._id }),
    ).rejects.toThrow(/already full/);
    await expect(
      agentA.mutation(api.travellers.updateRoom, {
        id: room._id,
        roomType: "single",
        capacity: 1,
        status: "tentative",
      }),
    ).rejects.toThrow(/Move someone out/);
    const data = await agentA.query(api.travellers.get, { bookingId });
    expect(data.rooms[0].occupants).toHaveLength(2);
    expect(data.unassignedCount).toBe(1);
  });

  it("sends guests back to unassigned when a room is removed", async () => {
    const { agentA, bookingId } = await setup();
    const id = await agentA.mutation(api.travellers.addTraveller, {
      bookingId,
      ...person("Ana", "Ruiz"),
    });
    await agentA.mutation(api.travellers.addRoom, {
      bookingId,
      roomType: "double",
      capacity: 2,
      status: "confirmed",
    });
    const [room] = (await agentA.query(api.travellers.get, { bookingId })).rooms;
    await agentA.mutation(api.travellers.assign, { travellerId: id, roomId: room._id });
    await agentA.mutation(api.travellers.removeRoom, { id: room._id });
    const data = await agentA.query(api.travellers.get, { bookingId });
    expect(data.rooms).toHaveLength(0);
    expect(data.travellers[0].room).toBeNull();
  });

  it("will not place a traveller in another booking's room", async () => {
    const { agentA, bookingId } = await setup();
    const otherId = await agentA.mutation(api.bookings.create, { ...BOOKING, title: "Other" });
    const id = await agentA.mutation(api.travellers.addTraveller, {
      bookingId,
      ...person("Ana", "Ruiz"),
    });
    await agentA.mutation(api.travellers.addRoom, {
      bookingId: otherId,
      roomType: "double",
      capacity: 2,
      status: "tentative",
    });
    const [room] = (await agentA.query(api.travellers.get, { bookingId: otherId })).rooms;
    await expect(
      agentA.mutation(api.travellers.assign, { travellerId: id, roomId: room._id }),
    ).rejects.toThrow(/Room not found/);
  });

  it("hides another agent's travellers", async () => {
    const { agentA, agentB, owner, bookingId } = await setup();
    const id = await agentA.mutation(api.travellers.addTraveller, {
      bookingId,
      ...person("Ana", "Ruiz"),
    });
    await expect(agentB.query(api.travellers.get, { bookingId })).rejects.toThrow(
      /Booking not found/,
    );
    await expect(agentB.mutation(api.travellers.removeTraveller, { id })).rejects.toThrow(
      /Booking not found/,
    );
    const seen = await owner.query(api.travellers.get, { bookingId });
    expect(seen.travellers).toHaveLength(1);
  });
});
