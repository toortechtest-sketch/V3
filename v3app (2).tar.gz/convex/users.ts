import { ConvexError } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Id } from "./_generated/dataModel";
import type { MutationCtx } from "./_generated/server";
import { claimInvite } from "./lib/invites";

/**
 * The very first person to sign in becomes the owner so the workspace can be
 * set up. After that, roles are only granted by owners/managers.
 */
async function bootstrapOwner(ctx: MutationCtx, userId: Id<"users">) {
  const anyOwner = await ctx.db
    .query("staffRoles")
    .withIndex("by_role", (q) => q.eq("role", "owner"))
    .first();
  if (anyOwner) return;
  const existing = await ctx.db
    .query("staffRoles")
    .withIndex("by_user", (q) => q.eq("userId", userId))
    .unique();
  if (existing) {
    await ctx.db.patch("staffRoles", existing._id, { role: "owner" });
    return;
  }
  await ctx.db.insert("staffRoles", {
    userId,
    role: "owner",
    assignedAt: new Date().toISOString(),
  });
}

export const updateCurrentUser = mutation({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "User not logged in",
      });
    }

    const user = await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier),
      )
      .unique();
    if (user !== null) {
      if (user.name !== identity.name || user.email !== identity.email) {
        await ctx.db.patch("users", user._id, {
          name: identity.name,
          email: identity.email,
        });
      }
      await bootstrapOwner(ctx, user._id);
      await claimInvite(ctx, user._id, identity.email, identity.emailVerified);
      return user._id;
    }
    const userId = await ctx.db.insert("users", {
      name: identity.name,
      email: identity.email,
      tokenIdentifier: identity.tokenIdentifier,
    });
    await bootstrapOwner(ctx, userId);
    await claimInvite(ctx, userId, identity.email, identity.emailVerified);
    return userId;
  },
});

export const getCurrentUser = query({
  args: {},
  handler: async (ctx) => {
    const identity = await ctx.auth.getUserIdentity();
    if (!identity) {
      throw new ConvexError({
        code: "UNAUTHENTICATED",
        message: "Called getCurrentUser without authentication present",
      });
    }
    return await ctx.db
      .query("users")
      .withIndex("by_token", (q) =>
        q.eq("tokenIdentifier", identity.tokenIdentifier),
      )
      .unique();
  },
});
