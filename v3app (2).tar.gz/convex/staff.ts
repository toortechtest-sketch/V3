import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import type { Doc } from "./_generated/dataModel";
import {
  fail,
  findCurrentUser,
  findRole,
  requireManager,
  type Staff,
} from "./lib/access";
import { staffRoleValidator, type StaffRole } from "./schema/staff";

// Team sizes are small; this cap keeps the reactive query bounded.
const TEAM_LIMIT = 500;

/** Current staff status. Never throws so the UI can show the right screen. */
export const me = query({
  args: {},
  handler: async (ctx) => {
    const user = await findCurrentUser(ctx);
    if (!user) return { status: "unsynced" as const };
    const role = await findRole(ctx, user);
    return {
      status: role ? ("active" as const) : ("pending" as const),
      userId: user._id,
      name: user.name ?? null,
      email: user.email ?? null,
      role: role?.role ?? null,
    };
  },
});

export const listTeam = query({
  args: {},
  handler: async (ctx) => {
    await requireManager(ctx);
    const [users, roles] = await Promise.all([
      ctx.db.query("users").take(TEAM_LIMIT),
      ctx.db.query("staffRoles").take(TEAM_LIMIT),
    ]);
    const roleByUser = new Map(roles.map((r) => [r.userId, r]));
    return users.map((u) => ({
      userId: u._id,
      name: u.name ?? null,
      email: u.email ?? null,
      joinedAt: u._creationTime,
      role: roleByUser.get(u._id)?.role ?? null,
    }));
  },
});

/** Shared rules for changing someone else's access. */
function assertCanManage(
  staff: Staff,
  target: Doc<"users">,
  currentRole: StaffRole | null,
  nextRole: StaffRole | null,
) {
  if (target._id === staff.user._id) {
    fail("FORBIDDEN", "You can't change your own access.");
  }
  const touchesOwner = currentRole === "owner" || nextRole === "owner";
  if (touchesOwner && staff.role !== "owner") {
    fail("FORBIDDEN", "Only an owner can grant or change owner access.");
  }
}

export const setRole = mutation({
  args: { userId: v.id("users"), role: staffRoleValidator },
  handler: async (ctx, args) => {
    const staff = await requireManager(ctx);
    const target = await ctx.db.get("users", args.userId);
    if (!target) fail("NOT_FOUND", "Team member not found.");
    const existing = await findRole(ctx, target);
    assertCanManage(staff, target, existing?.role ?? null, args.role);

    const assignment = {
      role: args.role,
      assignedAt: new Date().toISOString(),
      assignedById: staff.user._id,
    };
    if (existing) {
      await ctx.db.patch("staffRoles", existing._id, assignment);
    } else {
      await ctx.db.insert("staffRoles", { userId: target._id, ...assignment });
    }
    return null;
  },
});

export const revokeAccess = mutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const staff = await requireManager(ctx);
    const target = await ctx.db.get("users", args.userId);
    if (!target) fail("NOT_FOUND", "Team member not found.");
    const existing = await findRole(ctx, target);
    if (!existing) return null;
    assertCanManage(staff, target, existing.role, null);
    await ctx.db.delete("staffRoles", existing._id);
    return null;
  },
});
