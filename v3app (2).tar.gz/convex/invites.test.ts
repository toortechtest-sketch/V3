import { convexTest } from "convex-test";
import { describe, expect, it } from "vitest";
import { api } from "./_generated/api";
import schema from "./schema";
import { modules } from "./test.setup";

const ISSUER = "https://test.hercules-auth.com";
const as = (
  t: ReturnType<typeof convexTest>,
  sub: string,
  email: string,
  emailVerified = true,
) =>
  t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub, email, emailVerified });

async function setup() {
  const t = convexTest(schema, modules);
  const owner = as(t, "owner", "owner@toor.tech");
  await owner.mutation(api.users.updateCurrentUser, {});
  return { t, owner };
}

describe("team invites", () => {
  it("gives an invited person their role on first sign-in", async () => {
    const { t, owner } = await setup();
    await owner.mutation(api.invites.create, { email: " New@Toor.tech ", role: "agent" });
    const invited = as(t, "new", "new@toor.tech");
    await invited.mutation(api.users.updateCurrentUser, {});
    expect(await invited.query(api.staff.me, {})).toMatchObject({ status: "active", role: "agent" });
    expect(await owner.query(api.invites.list, {})).toEqual([]);
  });

  it("approves someone already waiting straight away", async () => {
    const { t, owner } = await setup();
    const waiting = as(t, "w", "wait@toor.tech");
    await waiting.mutation(api.users.updateCurrentUser, {});
    const result = await owner.mutation(api.invites.create, { email: "wait@toor.tech", role: "global_manager" });
    expect(result).toEqual({ status: "approved" });
    expect(await waiting.query(api.staff.me, {})).toMatchObject({ role: "global_manager" });
  });

  it("ignores invites when the sign-in email is unverified", async () => {
    const { t, owner } = await setup();
    await owner.mutation(api.invites.create, { email: "x@toor.tech", role: "owner" });
    const spoof = as(t, "spoof", "x@toor.tech", false);
    await spoof.mutation(api.users.updateCurrentUser, {});
    expect(await spoof.query(api.staff.me, {})).toMatchObject({ status: "pending" });
  });

  it("only lets owners invite owners, and blocks agents entirely", async () => {
    const { t, owner } = await setup();
    const mgr = as(t, "m", "m@toor.tech");
    const agent = as(t, "a", "a@toor.tech");
    await owner.mutation(api.invites.create, { email: "m@toor.tech", role: "global_manager" });
    await owner.mutation(api.invites.create, { email: "a@toor.tech", role: "agent" });
    await mgr.mutation(api.users.updateCurrentUser, {});
    await agent.mutation(api.users.updateCurrentUser, {});
    await expect(
      mgr.mutation(api.invites.create, { email: "boss@toor.tech", role: "owner" }),
    ).rejects.toThrow(/Only an owner/);
    await mgr.mutation(api.invites.create, { email: "ok@toor.tech", role: "agent" });
    await expect(
      agent.mutation(api.invites.create, { email: "z@toor.tech", role: "agent" }),
    ).rejects.toThrow(/permission required/);
  });

  it("rejects invalid emails and people who already have access", async () => {
    const { owner } = await setup();
    await expect(owner.mutation(api.invites.create, { email: "nope", role: "agent" })).rejects.toThrow(/valid email/);
    await expect(
      owner.mutation(api.invites.create, { email: "owner@toor.tech", role: "agent" }),
    ).rejects.toThrow(/already has access/);
  });

  it("cancelled invites grant nothing", async () => {
    const { t, owner } = await setup();
    await owner.mutation(api.invites.create, { email: "c@toor.tech", role: "agent" });
    const [invite] = await owner.query(api.invites.list, {});
    await owner.mutation(api.invites.cancel, { inviteId: invite.inviteId });
    const c = as(t, "c", "c@toor.tech");
    await c.mutation(api.users.updateCurrentUser, {});
    expect(await c.query(api.staff.me, {})).toMatchObject({ status: "pending" });
  });
});
