/**
 * MOCKED provider tests: every Google/Gmail HTTP call is intercepted by a
 * stubbed `fetch`. Nothing here touches a real mailbox or sends real email.
 */
import { convexTest } from "convex-test";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { api } from "../_generated/api";
import type { Id } from "../_generated/dataModel";
import schema from "../schema";
import { modules } from "../test.setup";
import { decryptSecret, encryptSecret, toBase64Url } from "./crypto";
import { GMAIL_SCOPE, isAllowedReturnOrigin } from "./config";
import {
  buildRawMessage,
  decodeBase64UrlText,
  headerSafe,
  replyRecipients,
  replySubject,
  shouldKeepThread,
} from "./mime";

const ISSUER = "https://test.hercules-auth.com";
const ORIGIN = "https://toor-test.onhercules.app";
const CLIENT_ID = "test-client.apps.googleusercontent.com";
const REQ = "11111111-2222-3333-4444-555555555555";

type Call = { url: string; method: string; body: string; auth: string | null };
type Handler = (url: URL, init: RequestInit) => Response;
let calls: Call[] = [];
let handler: Handler;

const json = (body: unknown, status = 200) =>
  new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json" } });

function idToken(email: string) {
  const enc = (o: unknown) => toBase64Url(new TextEncoder().encode(JSON.stringify(o)));
  return `${enc({ alg: "none" })}.${enc({ iss: "https://accounts.google.com", aud: CLIENT_ID, email, email_verified: true, exp: Math.floor(Date.now() / 1000) + 3600 })}.sig`;
}

beforeEach(() => {
  vi.stubEnv("GOOGLE_GMAIL_CLIENT_ID", CLIENT_ID);
  vi.stubEnv("GOOGLE_GMAIL_CLIENT_SECRET", "test-secret");
  vi.stubEnv("GMAIL_TOKEN_ENCRYPTION_KEY", toBase64Url(new Uint8Array(32).fill(7)));
  vi.stubEnv("CONVEX_SITE_URL", "https://test.convex.site");
  vi.stubEnv("GMAIL_ALLOWED_APP_ORIGINS", ORIGIN);
  calls = [];
  handler = () => json({ error: "unmocked" }, 500);
  vi.stubGlobal("fetch", async (input: string | URL, init: RequestInit = {}) => {
    const url = new URL(String(input));
    const headers = new Headers(init.headers);
    calls.push({ url: url.toString(), method: init.method ?? "GET", body: String(init.body ?? ""), auth: headers.get("Authorization") });
    return handler(url, init);
  });
});
afterEach(() => {
  vi.unstubAllEnvs();
  vi.unstubAllGlobals();
});

/** owner (first sign-in), two approved agents, one pending person. */
async function setup() {
  const t = convexTest(schema, modules);
  const as = (sub: string) =>
    t.withIdentity({ tokenIdentifier: `${ISSUER}|${sub}`, subject: sub, email: `${sub}@toor.tech` });
  const owner = as("owner");
  const agent = as("agent");
  const other = as("other");
  const pending = as("pending");
  await owner.mutation(api.users.updateCurrentUser, {});
  const agentId = await agent.mutation(api.users.updateCurrentUser, {});
  const otherId = await other.mutation(api.users.updateCurrentUser, {});
  await pending.mutation(api.users.updateCurrentUser, {});
  await owner.mutation(api.staff.setRole, { userId: agentId, role: "agent" });
  await owner.mutation(api.staff.setRole, { userId: otherId, role: "agent" });
  return { t, owner, agent, other, pending, agentId, otherId };
}

async function seedConnection(t: ReturnType<typeof convexTest>, userId: Id<"users">, access: string, refresh: string, expiresAt = Date.now() + 3600_000) {
  const accessToken = await encryptSecret(access);
  const refreshToken = await encryptSecret(refresh);
  return await t.run((ctx) =>
    ctx.db.insert("gmailConnections", {
      userId,
      googleEmail: `${access}@gmail.com`.toLowerCase(),
      scopes: `openid email ${GMAIL_SCOPE}`,
      status: "active",
      accessToken,
      refreshToken,
      accessTokenExpiresAt: expiresAt,
      connectedAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }),
  );
}

const googleToken: Handler = (url, init) => {
  if (url.pathname === "/token") {
    const body = new URLSearchParams(String(init.body));
    if (!body.get("code_verifier")) return json({ error: "invalid_grant" }, 400);
    return json({ access_token: "AT-new", refresh_token: "RT-new", expires_in: 3600, scope: `openid email ${GMAIL_SCOPE}`, id_token: idToken("person@gmail.com") });
  }
  if (url.pathname === "/revoke") return new Response(null, { status: 200 });
  return json({ error: "unmocked" }, 500);
};

function completionFrom(res: Response): string | null {
  const loc = new URL(res.headers.get("Location") ?? "https://x.invalid");
  expect(loc.search).toBe("");
  return new URLSearchParams(loc.hash.replace(/^#/, "")).get("gmail_complete");
}

describe("mime helpers", () => {
  it("handles subjects, threading and reply-all", () => {
    expect(replySubject("Quote")).toBe("Re: Quote");
    expect(replySubject("Fwd: Quote")).toBe("Re: Quote");
    expect(shouldKeepThread("reply", "Rooms", "Re: Rooms")).toBe(true);
    expect(shouldKeepThread("reply", "Rooms", "New topic")).toBe(false);
    const r = replyRecipients({ from: "Ann <ann@x.com>", to: "me@gmail.com, bob@x.com", cc: "me@gmail.com" }, "me@gmail.com", true);
    expect(r).toEqual({ to: ["ann@x.com"], cc: ["bob@x.com"] });
  });

  it("blocks header injection and encodes non-ASCII", () => {
    expect(headerSafe("Hi\r\nBcc: evil@x.com")).toBe("Hi Bcc: evil@x.com");
    const raw = buildRawMessage({ from: "me@gmail.com", to: ["a@x.com"], cc: [], bcc: [], subject: "Café\r\nBcc: e@x.com", text: "Olá", messageId: "<m@x>" });
    expect(raw).not.toMatch(/\r\nBcc:/);
    expect(raw).toContain("Subject: =?UTF-8?B?");
    expect(decodeBase64UrlText(raw.split("\r\n\r\n")[1].replace(/\r\n/g, ""))).toBe("Olá");
  });

  it("accepts only exact allowlisted return origins", () => {
    expect(isAllowedReturnOrigin(ORIGIN)).toBe(true);
    for (const bad of ["https://evil.onhercules.app", `${ORIGIN}/inbox`, "http://toor-test.onhercules.app", ""])
      expect(isAllowedReturnOrigin(bad)).toBe(false);
  });
});

describe("connecting Gmail (mocked Google)", () => {
  it("requires approved staff", async () => {
    const { pending } = await setup();
    await expect(pending.action(api.gmail.oauth.startConnect, { returnOrigin: ORIGIN })).rejects.toThrow(/not been approved/);
  });

  it("reports missing secrets instead of connecting", async () => {
    vi.stubEnv("GOOGLE_GMAIL_CLIENT_SECRET", "");
    const { agent } = await setup();
    const s = await agent.query(api.gmail.store.status, {});
    expect(s).toMatchObject({ configured: false, missingSecrets: ["GOOGLE_GMAIL_CLIENT_SECRET"] });
    await expect(agent.action(api.gmail.oauth.startConnect, { returnOrigin: ORIGIN })).rejects.toThrow(/not set up/);
  });

  it("uses PKCE, stores tokens encrypted and is single-use", async () => {
    handler = googleToken;
    const { t, agent, agentId } = await setup();
    const { url } = await agent.action(api.gmail.oauth.startConnect, { returnOrigin: ORIGIN });
    const google = new URL(url);
    expect(google.searchParams.get("code_challenge_method")).toBe("S256");
    const res = await t.fetch(`/gmail/oauth/callback?state=${google.searchParams.get("state")}&code=c`, { method: "GET" });
    expect(new URL(res.headers.get("Location")!).pathname).toBe("/inbox");
    const completion = completionFrom(res)!;
    expect(await agent.action(api.gmail.oauth.completeConnect, { completion })).toEqual({ ok: true, googleEmail: "person@gmail.com" });
    const conn = await t.run((ctx) => ctx.db.query("gmailConnections").withIndex("by_user", (q) => q.eq("userId", agentId)).unique());
    expect(conn?.refreshToken).not.toContain("RT-new");
    expect(await decryptSecret(conn!.refreshToken)).toBe("RT-new");
    expect(await agent.action(api.gmail.oauth.completeConnect, { completion })).toEqual({ ok: false, reason: "invalid" });
    // Replaying Google's callback does nothing.
    const replay = await t.fetch(`/gmail/oauth/callback?state=${google.searchParams.get("state")}&code=c`, { method: "GET" });
    expect(replay.status).toBe(400);
  });

  it("never hands a connection to a different staff member", async () => {
    handler = googleToken;
    const { t, agent, other } = await setup();
    const { url } = await agent.action(api.gmail.oauth.startConnect, { returnOrigin: ORIGIN });
    const res = await t.fetch(`/gmail/oauth/callback?state=${new URL(url).searchParams.get("state")}&code=c`, { method: "GET" });
    const completion = completionFrom(res)!;
    expect(await other.action(api.gmail.oauth.completeConnect, { completion })).toEqual({ ok: false, reason: "other_user" });
    expect(await agent.action(api.gmail.oauth.completeConnect, { completion })).toEqual({ ok: false, reason: "invalid" });
    expect(await t.run((ctx) => ctx.db.query("gmailConnections").collect())).toHaveLength(0);
  });
});

describe("mailbox privacy and tokens (mocked Gmail)", () => {
  const gmail = (tokens: Record<string, string>): Handler => (url, init) => {
    if (url.pathname === "/token") {
      const rt = new URLSearchParams(String(init.body)).get("refresh_token") ?? "";
      if (rt === "RT-revoked") return json({ error: "invalid_grant" }, 400);
      return json({ access_token: `AT-refreshed-${rt}`, expires_in: 3600 });
    }
    if (url.pathname === "/revoke") return new Response(null, { status: 200 });
    const auth = new Headers(init.headers).get("Authorization") ?? "";
    const owner = tokens[auth.replace("Bearer ", "")];
    if (!owner) return json({ error: { status: "UNAUTHENTICATED" } }, 401);
    if (url.pathname.endsWith("/threads")) return json({ threads: [{ id: `thread${owner}` }] });
    return json({ id: `thread${owner}`, messages: [{ id: "m1abcdef", threadId: `thread${owner}`, labelIds: ["INBOX", "UNREAD"], internalDate: "1700000000000", payload: { headers: [{ name: "Subject", value: `For ${owner}` }] } }] });
  };

  it("each staff member only sees their own mailbox, owners included", async () => {
    const { t, owner, agent, other, agentId, otherId } = await setup();
    await seedConnection(t, agentId, "AT-A", "RT-A");
    await seedConnection(t, otherId, "AT-B", "RT-B");
    handler = gmail({ "AT-A": "A", "AT-B": "B" });
    expect((await agent.action(api.gmail.mailbox.listThreads, { folder: "inbox" })).threads[0].subject).toBe("For A");
    expect((await other.action(api.gmail.mailbox.listThreads, { folder: "inbox" })).threads[0].subject).toBe("For B");
    await expect(owner.action(api.gmail.mailbox.listThreads, { folder: "inbox" })).rejects.toThrow(/Connect your Gmail/);
    expect(JSON.stringify(await agent.query(api.gmail.store.status, {}))).not.toContain("AT-A");
  });

  it("refreshes expiring tokens and flags revoked access", async () => {
    const { t, agent, other, agentId, otherId } = await setup();
    const a = await seedConnection(t, agentId, "AT-old", "RT-A", Date.now() + 10_000);
    const b = await seedConnection(t, otherId, "AT-old2", "RT-revoked", 0);
    handler = gmail({ "AT-refreshed-RT-A": "A" });
    expect((await agent.action(api.gmail.mailbox.listThreads, { folder: "inbox" })).threads).toHaveLength(1);
    expect(await decryptSecret((await t.run((ctx) => ctx.db.get("gmailConnections", a)))!.accessToken)).toBe("AT-refreshed-RT-A");
    await expect(other.action(api.gmail.mailbox.listThreads, { folder: "inbox" })).rejects.toThrow(/Reconnect/);
    expect((await t.run((ctx) => ctx.db.get("gmailConnections", b)))!.status).toBe("needs_reconnect");
  });

  it("disconnect revokes at Google and deletes tokens", async () => {
    const { t, agent, agentId } = await setup();
    await seedConnection(t, agentId, "AT-A", "RT-A");
    handler = gmail({});
    expect(await agent.action(api.gmail.oauth.disconnect, {})).toEqual({ revoked: true });
    expect(calls.find((c) => c.url.includes("/revoke"))?.body).toBe("token=RT-A");
    expect(await t.run((ctx) => ctx.db.query("gmailConnections").collect())).toHaveLength(0);
  });
});

describe("safe sends (mocked Gmail, nothing is really sent)", () => {
  const base = { mode: "new" as const, to: ["client@example.com"], cc: [], bcc: [], subject: "Hi", text: "Hello" };
  const sendMock = (outcome: () => Response) => {
    let sends = 0;
    const fn: Handler = (url) => {
      if (url.pathname.endsWith("/messages/send")) {
        sends++;
        return outcome();
      }
      if (url.pathname.endsWith("/messages")) return json({});
      return json({ error: "unmocked" }, 500);
    };
    return { fn, sends: () => sends };
  };

  it("sends once and de-duplicates a repeated request", async () => {
    const { t, agent, agentId } = await setup();
    await seedConnection(t, agentId, "AT", "RT");
    const m = sendMock(() => json({ id: "sent01", threadId: "threadN1" }));
    handler = m.fn;
    expect(await agent.action(api.gmail.mailbox.send, { requestId: REQ, ...base })).toEqual({ status: "sent", threadId: "threadN1" });
    expect(await agent.action(api.gmail.mailbox.send, { requestId: REQ, ...base })).toMatchObject({ status: "duplicate", previous: "sent" });
    expect(m.sends()).toBe(1);
    const row = JSON.stringify(await t.run((ctx) => ctx.db.query("gmailSendAttempts").first()));
    expect(row).not.toContain("client@example.com");
    expect(row).not.toContain("Hello");
  });

  it("keeps an uncertain send blocked and never auto-resends", async () => {
    const { t, agent, agentId } = await setup();
    await seedConnection(t, agentId, "AT", "RT");
    const m = sendMock(() => json({ error: { status: "INTERNAL" } }, 503));
    handler = m.fn;
    expect(await agent.action(api.gmail.mailbox.send, { requestId: REQ, ...base })).toEqual({ status: "uncertain" });
    expect(await agent.action(api.gmail.mailbox.checkSend, { requestId: REQ })).toEqual({ status: "uncertain" });
    expect(await agent.action(api.gmail.mailbox.send, { requestId: REQ, ...base })).toMatchObject({ status: "duplicate", previous: "uncertain" });
    expect(m.sends()).toBe(1);
  });

  it("rejects invalid recipients before recording anything", async () => {
    const { t, agent, agentId } = await setup();
    await seedConnection(t, agentId, "AT", "RT");
    const m = sendMock(() => json({ id: "s", threadId: "t" }));
    handler = m.fn;
    await expect(agent.action(api.gmail.mailbox.send, { requestId: REQ, ...base, to: ["nope"] })).rejects.toThrow(/valid email/);
    expect(m.sends()).toBe(0);
    expect(await t.run((ctx) => ctx.db.query("gmailSendAttempts").collect())).toHaveLength(0);
  });
});
