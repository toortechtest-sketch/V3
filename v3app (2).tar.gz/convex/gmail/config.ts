/** Gmail integration configuration. Secrets are read server-side only. */

export const SECRET_NAMES = {
  clientId: "GOOGLE_GMAIL_CLIENT_ID",
  clientSecret: "GOOGLE_GMAIL_CLIENT_SECRET",
  encryptionKey: "GMAIL_TOKEN_ENCRYPTION_KEY",
  allowedOrigins: "GMAIL_ALLOWED_APP_ORIGINS",
} as const;

export const CALLBACK_PATH = "/gmail/oauth/callback";
/** App page Google sends people back to. */
export const RETURN_PATH = "/inbox";

/** gmail.modify covers read, label and send, but not permanent delete. */
export const GMAIL_SCOPE = "https://www.googleapis.com/auth/gmail.modify";
export const REQUESTED_SCOPES = ["openid", "email", GMAIL_SCOPE] as const;

export const GOOGLE_AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth";
export const GOOGLE_TOKEN_URL = "https://oauth2.googleapis.com/token";
export const GOOGLE_REVOKE_URL = "https://oauth2.googleapis.com/revoke";
export const GMAIL_API = "https://gmail.googleapis.com/gmail/v1/users/me";

export const STATE_TTL_MS = 10 * 60 * 1000;
export const COMPLETION_TTL_MS = 10 * 60 * 1000;
export const MAX_OPEN_STATES = 5;

export function missingSecrets(): string[] {
  return Object.values(SECRET_NAMES).filter((name) =>
    name === SECRET_NAMES.allowedOrigins
      ? allowedOrigins().length === 0
      : !process.env[name],
  );
}

export function callbackUri(): string {
  const site = process.env.CONVEX_SITE_URL ?? "";
  return `${site.replace(/\/$/, "")}${CALLBACK_PATH}`;
}

export function oauthClient(): { clientId: string; clientSecret: string } {
  const clientId = process.env[SECRET_NAMES.clientId];
  const clientSecret = process.env[SECRET_NAMES.clientSecret];
  if (!clientId || !clientSecret) throw new Error("GMAIL_NOT_CONFIGURED");
  return { clientId, clientSecret };
}

const LOCAL_HOSTS = new Set(["localhost", "127.0.0.1", "[::1]"]);

/** Normalises one allowlist entry to a bare origin, or null if it isn't one. */
function exactOrigin(entry: string): string | null {
  let url: URL;
  try {
    url = new URL(entry);
  } catch {
    return null;
  }
  // Entries must be a bare origin: no path, query, fragment or credentials.
  if (url.origin === "null" || url.username || url.password) return null;
  if (url.pathname !== "/" || url.search || url.hash) return null;
  if (entry.replace(/\/$/, "") !== url.origin) return null;
  if (url.hostname.includes("*")) return null;
  // https everywhere; plain http only for local development hosts.
  if (
    url.protocol !== "https:" &&
    !(url.protocol === "http:" && LOCAL_HOSTS.has(url.hostname))
  )
    return null;
  return url.origin;
}

/**
 * The exact origins listed (comma separated) in GMAIL_ALLOWED_APP_ORIGINS.
 * Invalid or wildcard entries are ignored. Empty means nothing is allowed.
 */
export function allowedOrigins(): string[] {
  const raw = process.env[SECRET_NAMES.allowedOrigins] ?? "";
  const out = raw
    .split(",")
    .map((s) => exactOrigin(s.trim()))
    .filter((o): o is string => o !== null);
  return Array.from(new Set(out));
}

/**
 * Where the browser may be sent back to after Google. Exact match only, so
 * the callback can't become an open redirect. Fails closed when unset.
 */
export function isAllowedReturnOrigin(origin: string): boolean {
  return allowedOrigins().includes(origin);
}
