import type { ActionCtx } from "../_generated/server";
import type { Doc, Id } from "../_generated/dataModel";
import { internal } from "../_generated/api";
import { ConvexError } from "convex/values";
import { GMAIL_API, GOOGLE_REVOKE_URL, GOOGLE_TOKEN_URL, oauthClient } from "./config";
import { decryptSecret, encryptSecret } from "./crypto";

export class GmailApiError extends Error {
  constructor(
    public status: number,
    public reason: string,
  ) {
    super(`Gmail API ${status}: ${reason}`);
  }
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

/** Refresh access tokens a minute early to avoid racing expiry. */
const REFRESH_SKEW_MS = 60_000;

type GmailErrorCode =
  | "UNAUTHENTICATED"
  | "FORBIDDEN"
  | "NOT_FOUND"
  | "BAD_REQUEST"
  | "CONFLICT"
  | "EXTERNAL_SERVICE_ERROR";

export function gmailFail(code: GmailErrorCode, message: string): never {
  throw new ConvexError({ code, message });
}

export type TokenResponse = {
  access_token: string;
  expires_in: number;
  refresh_token?: string;
  scope?: string;
  id_token?: string;
};

function isTokenResponse(x: unknown): x is TokenResponse {
  return (
    typeof x === "object" &&
    x !== null &&
    "access_token" in x &&
    typeof x.access_token === "string" &&
    "expires_in" in x &&
    typeof x.expires_in === "number"
  );
}

export async function postToken(
  body: Record<string, string>,
): Promise<
  { ok: true; data: TokenResponse } | { ok: false; status: number; error: string }
> {
  const res = await fetch(GOOGLE_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(body).toString(),
  });
  const json: unknown = await res.json().catch(() => ({}));
  if (!res.ok || !isTokenResponse(json)) {
    const err =
      json && typeof json === "object" && "error" in json && typeof json.error === "string"
        ? json.error
        : "unknown";
    return { ok: false, status: res.status, error: err };
  }
  return { ok: true, data: json };
}

/** Best-effort token revocation at Google. */
export async function revokeToken(token: string): Promise<boolean> {
  try {
    const res = await fetch(GOOGLE_REVOKE_URL, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ token }).toString(),
    });
    return res.ok;
  } catch {
    return false;
  }
}

/** A per-request Gmail session for one mailbox owner. */
export class GmailSession {
  private accessToken: string | null = null;
  private expiresAt = 0;

  constructor(
    private ctx: ActionCtx,
    public userId: Id<"users">,
    private conn: Doc<"gmailConnections">,
  ) {}

  get googleEmail() {
    return this.conn.googleEmail;
  }

  private async markNeedsReconnect(reason: string) {
    await this.ctx.runMutation(internal.gmail.store.updateConnection, {
      connectionId: this.conn._id,
      status: "needs_reconnect",
      lastError: reason,
    });
  }

  async token(force = false): Promise<string> {
    if (this.conn.status !== "active")
      gmailFail("FORBIDDEN", "Your Gmail connection needs to be reconnected.");
    if (!force && this.accessToken && this.expiresAt - REFRESH_SKEW_MS > Date.now())
      return this.accessToken;
    if (
      !force &&
      !this.accessToken &&
      this.conn.accessTokenExpiresAt - REFRESH_SKEW_MS > Date.now()
    ) {
      this.accessToken = await decryptSecret(this.conn.accessToken);
      this.expiresAt = this.conn.accessTokenExpiresAt;
      return this.accessToken;
    }
    const { clientId, clientSecret } = oauthClient();
    const result = await postToken({
      client_id: clientId,
      client_secret: clientSecret,
      grant_type: "refresh_token",
      refresh_token: await decryptSecret(this.conn.refreshToken),
    });
    if (!result.ok) {
      if (result.error === "invalid_grant" || result.status === 400 || result.status === 401) {
        await this.markNeedsReconnect("Google access expired or was revoked");
        gmailFail("FORBIDDEN", "Google access expired or was revoked. Reconnect Gmail.");
      }
      gmailFail("EXTERNAL_SERVICE_ERROR", "Google sign-in service is unavailable. Try again shortly.");
    }
    this.accessToken = result.data.access_token;
    this.expiresAt = Date.now() + result.data.expires_in * 1000;
    await this.ctx.runMutation(internal.gmail.store.updateConnection, {
      connectionId: this.conn._id,
      accessToken: await encryptSecret(this.accessToken),
      // Google may rotate refresh tokens; keep the newest.
      refreshToken: result.data.refresh_token
        ? await encryptSecret(result.data.refresh_token)
        : undefined,
      accessTokenExpiresAt: this.expiresAt,
      lastError: null,
    });
    return this.accessToken;
  }

  /**
   * Calls Gmail with retry on 429/5xx (exponential backoff + jitter) and a
   * single token refresh on 401. `retry: false` is used for sends, which
   * must never be blindly repeated.
   */
  async request<T>(
    path: string,
    init: { method?: string; body?: unknown; retry?: boolean } = {},
  ): Promise<T> {
    const retry = init.retry ?? true;
    let refreshed = false;
    for (let attempt = 0; ; attempt++) {
      const token = await this.token();
      const res = await fetch(`${GMAIL_API}${path}`, {
        method: init.method ?? "GET",
        headers: {
          Authorization: `Bearer ${token}`,
          ...(init.body !== undefined ? { "Content-Type": "application/json" } : {}),
        },
        body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
      });
      if (res.ok) {
        // Gmail returns JSON for every endpoint we call; shapes are typed by the caller.
        if (res.status === 204) return JSON.parse("{}") as T;
        return (await res.json()) as T;
      }
      const reason = await errorReason(res);
      if (res.status === 401 && !refreshed) {
        refreshed = true;
        await this.token(true);
        continue;
      }
      if (res.status === 401) {
        await this.markNeedsReconnect("Google rejected the access token");
        throw new GmailApiError(401, reason);
      }
      if (res.status === 403 && /insufficient|scope/i.test(reason)) {
        await this.markNeedsReconnect("Mailbox permission was not granted");
        throw new GmailApiError(403, reason);
      }
      const retryable = res.status === 429 || res.status >= 500 || /rateLimit/i.test(reason);
      if (retry && retryable && attempt < 3) {
        const after = Number(res.headers.get("Retry-After"));
        await sleep(
          Number.isFinite(after) && after > 0
            ? Math.min(after, 8) * 1000
            : 400 * 2 ** attempt + Math.random() * 250,
        );
        continue;
      }
      throw new GmailApiError(res.status, reason);
    }
  }

  async touch() {
    await this.ctx.runMutation(internal.gmail.store.updateConnection, {
      connectionId: this.conn._id,
      touched: true,
    });
  }
}

async function errorReason(res: Response): Promise<string> {
  try {
    const j: unknown = await res.json();
    if (j && typeof j === "object" && "error" in j) {
      const e = j.error;
      if (e && typeof e === "object") {
        const errors = "errors" in e && Array.isArray(e.errors) ? e.errors : [];
        const first: unknown = errors[0];
        if (first && typeof first === "object" && "reason" in first && typeof first.reason === "string")
          return first.reason;
        if ("status" in e && typeof e.status === "string") return e.status;
      }
    }
  } catch {
    // ignore unreadable error bodies
  }
  return res.statusText || "error";
}

/** Runs async work over items with at most `limit` in flight. */
export async function mapLimit<T, R>(
  items: T[],
  limit: number,
  fn: (item: T) => Promise<R>,
): Promise<R[]> {
  const out = new Array<R>(items.length);
  let next = 0;
  const worker = async () => {
    while (next < items.length) {
      const i = next++;
      out[i] = await fn(items[i]);
    }
  };
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, worker));
  return out;
}

/** Opens a session for the signed-in staff member's own mailbox, or throws. */
export async function openSession(ctx: ActionCtx): Promise<GmailSession> {
  const { userId } = await ctx.runQuery(internal.gmail.store.actor, {});
  const conn = await ctx.runQuery(internal.gmail.store.connectionForUser, { userId });
  if (!conn) gmailFail("NOT_FOUND", "Connect your Gmail account first.");
  return new GmailSession(ctx, userId, conn);
}

/** Converts Gmail API errors into user-facing ConvexErrors. */
export function toUserError(e: unknown): never {
  if (e instanceof ConvexError) throw e;
  if (e instanceof GmailApiError) {
    if (e.status === 404) gmailFail("NOT_FOUND", "That message no longer exists in Gmail.");
    if (e.status === 401 || e.status === 403)
      gmailFail("FORBIDDEN", "Gmail refused access. Reconnect your account.");
    if (e.status === 429)
      gmailFail("EXTERNAL_SERVICE_ERROR", "Gmail rate limit reached. Wait a moment and try again.");
    gmailFail("EXTERNAL_SERVICE_ERROR", "Gmail is not responding right now. Try again shortly.");
  }
  if (e instanceof Error && e.message === "GMAIL_NOT_CONFIGURED")
    gmailFail("BAD_REQUEST", "Gmail is not set up yet. Ask an owner to add the Google secrets.");
  gmailFail("EXTERNAL_SERVICE_ERROR", "Unexpected Gmail error.");
}
