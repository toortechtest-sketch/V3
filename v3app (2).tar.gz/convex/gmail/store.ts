import { v } from "convex/values";
import type { Doc, Id } from "../_generated/dataModel";
import { internalMutation, internalQuery, query } from "../_generated/server";
import { fail, requireStaff } from "../lib/access";
import { connectionStatus, composeMode, sendStatus } from "../schema/gmail";
import {
  allowedOrigins,
  callbackUri,
  COMPLETION_TTL_MS,
  GMAIL_SCOPE,
  MAX_OPEN_STATES,
  missingSecrets,
} from "./config";

const nowIso = () => new Date().toISOString();

// ── Public: status ──────────────────────────────────────────────────────────

export type ConnectionSummary = {
  googleEmail: string;
  status: Doc<"gmailConnections">["status"];
  hasMailboxScope: boolean;
  connectedAt: string;
  lastUsedAt: string | null;
  lastError: string | null;
};

export type GmailStatus = {
  configured: boolean;
  missingSecrets: string[];
  callbackUri: string;
  /** Exact app origins allowed to start and finish a connection. Not secret. */
  allowedOrigins: string[];
  connection: ConnectionSummary | null;
};

/** The caller's own connection only. Managers can't see other mailboxes. */
export const status = query({
  args: {},
  handler: async (ctx): Promise<GmailStatus> => {
    const { user } = await requireStaff(ctx);
    const conn = await ctx.db
      .query("gmailConnections")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .unique();
    const missing = missingSecrets();
    return {
      configured: missing.length === 0,
      missingSecrets: missing,
      callbackUri: callbackUri(),
      allowedOrigins: allowedOrigins(),
      connection: conn
        ? {
            googleEmail: conn.googleEmail,
            status: conn.status,
            hasMailboxScope: conn.scopes.split(" ").includes(GMAIL_SCOPE),
            connectedAt: conn.connectedAt,
            lastUsedAt: conn.lastUsedAt ?? null,
            lastError: conn.lastError ?? null,
          }
        : null,
    };
  },
});

// ── Internal: used by actions / HTTP callback only ──────────────────────────

/** Resolves the caller (auth propagates from the calling action). */
export const actor = internalQuery({
  args: {},
  handler: async (ctx): Promise<{ userId: Id<"users"> }> => {
    const { user } = await requireStaff(ctx);
    return { userId: user._id };
  },
});

export const createState = internalMutation({
  args: {
    userId: v.id("users"),
    stateHash: v.string(),
    codeVerifier: v.string(),
    returnOrigin: v.string(),
    expiresAt: v.number(),
  },
  handler: async (ctx, args) => {
    const now = Date.now();
    const mine = await ctx.db
      .query("gmailOAuthStates")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .take(50);
    let open = 0;
    for (const s of mine) {
      if (s.expiresAt < now - COMPLETION_TTL_MS)
        await ctx.db.delete("gmailOAuthStates", s._id);
      else if (s.status === "started") open++;
    }
    if (open >= MAX_OPEN_STATES)
      fail(
        "CONFLICT",
        "Too many connection attempts in progress. Wait a few minutes and try again.",
      );
    await ctx.db.insert("gmailOAuthStates", {
      ...args,
      completionHash: `pending:${args.stateHash}`,
      status: "started",
      createdAt: nowIso(),
    });
    return null;
  },
});

/**
 * Atomically consumes a state. Returns null if unknown, expired or already
 * used, which makes callback replay a no-op.
 */
export const consumeState = internalMutation({
  args: { stateHash: v.string() },
  handler: async (ctx, args) => {
    const s = await ctx.db
      .query("gmailOAuthStates")
      .withIndex("by_state_hash", (q) => q.eq("stateHash", args.stateHash))
      .unique();
    if (!s || s.status !== "started") return null;
    if (s.expiresAt < Date.now()) {
      await ctx.db.patch("gmailOAuthStates", s._id, {
        status: "failed",
        failureReason: "expired",
      });
      return null;
    }
    await ctx.db.patch("gmailOAuthStates", s._id, {
      status: "awaiting_completion",
    });
    return {
      stateId: s._id,
      codeVerifier: s.codeVerifier,
      returnOrigin: s.returnOrigin,
    };
  },
});

export const failState = internalMutation({
  args: { stateId: v.id("gmailOAuthStates"), reason: v.string() },
  handler: async (ctx, args) => {
    const s = await ctx.db.get("gmailOAuthStates", args.stateId);
    if (s)
      await ctx.db.patch("gmailOAuthStates", s._id, {
        status: "failed",
        failureReason: args.reason,
      });
    return null;
  },
});

export const stashTokens = internalMutation({
  args: {
    stateId: v.id("gmailOAuthStates"),
    completionHash: v.string(),
    email: v.string(),
    scopes: v.string(),
    accessToken: v.string(),
    refreshToken: v.string(),
    expiresAt: v.number(),
  },
  handler: async (ctx, a) => {
    await ctx.db.patch("gmailOAuthStates", a.stateId, {
      completionHash: a.completionHash,
      pendingEmail: a.email,
      pendingScopes: a.scopes,
      pendingAccessToken: a.accessToken,
      pendingRefreshToken: a.refreshToken,
      pendingExpiresAt: a.expiresAt,
      // Fresh window for the browser to come back and claim it.
      expiresAt: Date.now() + COMPLETION_TTL_MS,
    });
    return null;
  },
});

export type CompletionResult =
  | { ok: true; googleEmail: string }
  | { ok: false; reason: "invalid" | "expired" | "other_user" };

/** The same signed-in staff member must claim the tokens the callback stashed. */
export const finalizeConnection = internalMutation({
  args: { completionHash: v.string() },
  handler: async (ctx, args): Promise<CompletionResult> => {
    const { user } = await requireStaff(ctx);
    const s = await ctx.db
      .query("gmailOAuthStates")
      .withIndex("by_completion_hash", (q) =>
        q.eq("completionHash", args.completionHash),
      )
      .unique();
    if (!s || s.status !== "awaiting_completion")
      return { ok: false, reason: "invalid" };
    if (s.userId !== user._id) {
      // Never hand tokens to someone else; burn the attempt.
      await ctx.db.delete("gmailOAuthStates", s._id);
      return { ok: false, reason: "other_user" };
    }
    if (
      s.expiresAt < Date.now() ||
      !s.pendingAccessToken ||
      !s.pendingRefreshToken ||
      !s.pendingEmail
    ) {
      await ctx.db.delete("gmailOAuthStates", s._id);
      return { ok: false, reason: "expired" };
    }
    const now = nowIso();
    const fields = {
      googleEmail: s.pendingEmail,
      scopes: s.pendingScopes ?? "",
      status: "active" as const,
      accessToken: s.pendingAccessToken,
      refreshToken: s.pendingRefreshToken,
      accessTokenExpiresAt: s.pendingExpiresAt ?? 0,
      lastError: undefined,
      connectedAt: now,
      updatedAt: now,
    };
    const existing = await ctx.db
      .query("gmailConnections")
      .withIndex("by_user", (q) => q.eq("userId", user._id))
      .unique();
    if (existing) await ctx.db.patch("gmailConnections", existing._id, fields);
    else await ctx.db.insert("gmailConnections", { userId: user._id, ...fields });
    await ctx.db.delete("gmailOAuthStates", s._id);
    console.log(`gmail.connect ok user=${user._id}`);
    return { ok: true, googleEmail: s.pendingEmail };
  },
});

export const connectionForUser = internalQuery({
  args: { userId: v.id("users") },
  handler: async (ctx, args) =>
    await ctx.db
      .query("gmailConnections")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique(),
});

export const updateConnection = internalMutation({
  args: {
    connectionId: v.id("gmailConnections"),
    accessToken: v.optional(v.string()),
    refreshToken: v.optional(v.string()),
    accessTokenExpiresAt: v.optional(v.number()),
    status: v.optional(connectionStatus),
    lastError: v.optional(v.union(v.string(), v.null())),
    touched: v.optional(v.boolean()),
  },
  handler: async (ctx, { connectionId, lastError, touched, ...rest }) => {
    const c = await ctx.db.get("gmailConnections", connectionId);
    if (!c) return null;
    const now = nowIso();
    await ctx.db.patch("gmailConnections", connectionId, {
      ...Object.fromEntries(
        Object.entries(rest).filter(([, val]) => val !== undefined),
      ),
      ...(lastError !== undefined ? { lastError: lastError ?? undefined } : {}),
      ...(touched ? { lastUsedAt: now } : {}),
      updatedAt: now,
    });
    return null;
  },
});

export const deleteConnection = internalMutation({
  args: { userId: v.id("users") },
  handler: async (ctx, args) => {
    const c = await ctx.db
      .query("gmailConnections")
      .withIndex("by_user", (q) => q.eq("userId", args.userId))
      .unique();
    if (c) await ctx.db.delete("gmailConnections", c._id);
    console.log(`gmail.disconnect user=${args.userId}`);
    return null;
  },
});

// ── Send idempotency ledger ─────────────────────────────────────────────────

export type BeginSend =
  | { proceed: true; messageIdHeader: string }
  | {
      proceed: false;
      status: Doc<"gmailSendAttempts">["status"];
      gmailThreadId: string | null;
    };

export const beginSend = internalMutation({
  args: {
    userId: v.id("users"),
    requestId: v.string(),
    messageIdHeader: v.string(),
    mode: composeMode,
    recipientCount: v.number(),
  },
  handler: async (ctx, a): Promise<BeginSend> => {
    if (!/^[A-Za-z0-9-]{16,64}$/.test(a.requestId))
      fail("BAD_REQUEST", "Invalid send request id.");
    const existing = await ctx.db
      .query("gmailSendAttempts")
      .withIndex("by_user_and_request", (q) =>
        q.eq("userId", a.userId).eq("requestId", a.requestId),
      )
      .unique();
    const now = nowIso();
    if (!existing) {
      await ctx.db.insert("gmailSendAttempts", {
        ...a,
        status: "pending",
        createdAt: now,
        updatedAt: now,
      });
      return { proceed: true, messageIdHeader: a.messageIdHeader };
    }
    // Only a definite, provider-confirmed rejection may be retried, and the
    // retry reuses the original Message-ID so it stays traceable.
    if (existing.status === "failed") {
      await ctx.db.patch("gmailSendAttempts", existing._id, {
        status: "pending",
        errorCode: undefined,
        updatedAt: now,
      });
      return { proceed: true, messageIdHeader: existing.messageIdHeader };
    }
    return {
      proceed: false,
      status: existing.status,
      gmailThreadId: existing.gmailThreadId ?? null,
    };
  },
});

export const finishSend = internalMutation({
  args: {
    userId: v.id("users"),
    requestId: v.string(),
    status: sendStatus,
    gmailMessageId: v.optional(v.string()),
    gmailThreadId: v.optional(v.string()),
    errorCode: v.optional(v.string()),
  },
  handler: async (ctx, { userId, requestId, ...rest }) => {
    const row = await ctx.db
      .query("gmailSendAttempts")
      .withIndex("by_user_and_request", (q) =>
        q.eq("userId", userId).eq("requestId", requestId),
      )
      .unique();
    // A confirmed send can never be downgraded.
    if (!row || row.status === "sent") return null;
    await ctx.db.patch("gmailSendAttempts", row._id, {
      ...rest,
      updatedAt: nowIso(),
    });
    return null;
  },
});

export const sendAttempt = internalQuery({
  args: { userId: v.id("users"), requestId: v.string() },
  handler: async (ctx, a) =>
    await ctx.db
      .query("gmailSendAttempts")
      .withIndex("by_user_and_request", (q) =>
        q.eq("userId", a.userId).eq("requestId", a.requestId),
      )
      .unique(),
});
