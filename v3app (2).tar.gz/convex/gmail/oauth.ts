import { v } from "convex/values";
import { action, httpAction } from "../_generated/server";
import { internal } from "../_generated/api";
import {
  callbackUri,
  GMAIL_SCOPE,
  GOOGLE_AUTH_URL,
  isAllowedReturnOrigin,
  missingSecrets,
  oauthClient,
  REQUESTED_SCOPES,
  RETURN_PATH,
  STATE_TTL_MS,
} from "./config";
import {
  decryptSecret,
  encryptSecret,
  fromBase64Url,
  pkceChallenge,
  randomToken,
  sha256,
} from "./crypto";
import { gmailFail, postToken, revokeToken } from "./client";
import type { CompletionResult } from "./store";

/** Step 1 (signed-in staff): create a single-use state + PKCE and return Google's URL. */
export const startConnect = action({
  args: { returnOrigin: v.string() },
  handler: async (ctx, args): Promise<{ url: string }> => {
    const { userId } = await ctx.runQuery(internal.gmail.store.actor, {});
    if (missingSecrets().length) gmailFail("BAD_REQUEST", "Gmail is not set up yet.");
    if (!isAllowedReturnOrigin(args.returnOrigin))
      gmailFail("BAD_REQUEST", "This app address is not allowed to connect Gmail.");
    const { clientId } = oauthClient();
    const state = randomToken(32);
    const codeVerifier = randomToken(48);
    await ctx.runMutation(internal.gmail.store.createState, {
      userId,
      stateHash: await sha256(state),
      codeVerifier: await encryptSecret(codeVerifier),
      returnOrigin: args.returnOrigin,
      expiresAt: Date.now() + STATE_TTL_MS,
    });
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: callbackUri(),
      response_type: "code",
      scope: REQUESTED_SCOPES.join(" "),
      access_type: "offline",
      include_granted_scopes: "false",
      // Always show the account chooser + consent so a refresh token is issued.
      prompt: "consent select_account",
      state,
      code_challenge: await pkceChallenge(codeVerifier),
      code_challenge_method: "S256",
    });
    return { url: `${GOOGLE_AUTH_URL}?${params.toString()}` };
  },
});

type IdClaims = {
  iss?: string;
  aud?: string;
  email?: string;
  email_verified?: boolean;
  exp?: number;
};

/**
 * Reads ID token claims. The token came straight from Google's token endpoint
 * over TLS (OIDC Core 3.1.3.7), so we validate issuer, audience, expiry and
 * verified email rather than the signature.
 */
export function validateIdToken(idToken: string | undefined, clientId: string): string | null {
  if (!idToken) return null;
  const part = idToken.split(".")[1];
  if (!part) return null;
  let claims: IdClaims;
  try {
    claims = JSON.parse(new TextDecoder().decode(fromBase64Url(part))) as IdClaims;
  } catch {
    return null;
  }
  const issOk = claims.iss === "https://accounts.google.com" || claims.iss === "accounts.google.com";
  if (!issOk || claims.aud !== clientId) return null;
  if (!claims.exp || claims.exp * 1000 < Date.now()) return null;
  if (!claims.email || claims.email_verified !== true) return null;
  return claims.email.toLowerCase();
}

function plainPage(title: string, message: string, status = 400) {
  const esc = (s: string) => s.replace(/[&<>"']/g, (c) => `&#${c.charCodeAt(0)};`);
  return new Response(
    `<!doctype html><meta charset="utf-8"><title>${esc(title)}</title><body style="font-family:sans-serif;max-width:32rem;margin:4rem auto;padding:0 1rem"><h1>${esc(title)}</h1><p>${esc(message)}</p><p>You can close this tab and return to Toor.</p></body>`,
    {
      status,
      headers: {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
        "Referrer-Policy": "no-referrer",
      },
    },
  );
}

/**
 * Sends the browser back to the app. Values go in the URL fragment, which
 * browsers never send to servers or in Referer headers.
 */
function redirect(origin: string, params: Record<string, string>) {
  // Re-checked: the allowlist may have changed since the attempt started.
  if (!isAllowedReturnOrigin(origin))
    return plainPage(
      "Connection blocked",
      "This app address is no longer on the allowed list. Ask an owner to check GMAIL_ALLOWED_APP_ORIGINS.",
    );
  const url = new URL(RETURN_PATH, origin);
  url.hash = new URLSearchParams(params).toString();
  return new Response(null, {
    status: 302,
    headers: {
      Location: url.toString(),
      "Cache-Control": "no-store",
      "Referrer-Policy": "no-referrer",
    },
  });
}

/** Step 2 (Google → backend): consume state, exchange code, validate, stash encrypted. */
export const oauthCallback = httpAction(async (ctx, request) => {
  const url = new URL(request.url);
  const state = url.searchParams.get("state");
  if (!state)
    return plainPage("Connection failed", "The Google response was missing its security check.");
  const consumed = await ctx.runMutation(internal.gmail.store.consumeState, {
    stateHash: await sha256(state),
  });
  if (!consumed)
    return plainPage(
      "Link expired",
      "This Gmail connection link has expired or was already used. Start again from Toor.",
    );
  const { stateId, returnOrigin } = consumed;
  if (!isAllowedReturnOrigin(returnOrigin)) {
    await ctx.runMutation(internal.gmail.store.failState, { stateId, reason: "origin_not_allowed" });
    return plainPage(
      "Connection blocked",
      "This app address is not on the allowed list. Ask an owner to check GMAIL_ALLOWED_APP_ORIGINS.",
    );
  }
  const fail = async (reason: string) => {
    await ctx.runMutation(internal.gmail.store.failState, { stateId, reason });
    console.log(`gmail.connect fail reason=${reason}`);
    return redirect(returnOrigin, { gmail_error: reason });
  };

  const googleError = url.searchParams.get("error");
  if (googleError) return await fail(googleError === "access_denied" ? "cancelled" : "google_error");
  const code = url.searchParams.get("code");
  if (!code) return await fail("google_error");

  let client: { clientId: string; clientSecret: string };
  try {
    client = oauthClient();
  } catch {
    return await fail("not_configured");
  }
  const token = await postToken({
    client_id: client.clientId,
    client_secret: client.clientSecret,
    code,
    code_verifier: await decryptSecret(consumed.codeVerifier),
    grant_type: "authorization_code",
    redirect_uri: callbackUri(),
  });
  if (!token.ok) return await fail("exchange_failed");

  const granted = (token.data.scope ?? "").split(" ");
  const email = validateIdToken(token.data.id_token, client.clientId);
  const refresh = token.data.refresh_token;
  if (!granted.includes(GMAIL_SCOPE) || !email || !refresh) {
    const problem = !granted.includes(GMAIL_SCOPE)
      ? "partial_consent"
      : !email
        ? "identity_invalid"
        : "no_refresh_token";
    // Don't keep half-granted access around.
    await revokeToken(refresh ?? token.data.access_token);
    return await fail(problem);
  }

  const completion = randomToken(32);
  await ctx.runMutation(internal.gmail.store.stashTokens, {
    stateId,
    completionHash: await sha256(completion),
    email,
    scopes: granted.join(" "),
    accessToken: await encryptSecret(token.data.access_token),
    refreshToken: await encryptSecret(refresh),
    expiresAt: Date.now() + token.data.expires_in * 1000,
  });
  return redirect(returnOrigin, { gmail_complete: completion });
});

/** Step 3 (browser, same signed-in staff member): claim the stashed connection. */
export const completeConnect = action({
  args: { completion: v.string() },
  handler: async (ctx, args): Promise<CompletionResult> => {
    if (!/^[A-Za-z0-9_-]{20,100}$/.test(args.completion)) return { ok: false, reason: "invalid" };
    return await ctx.runMutation(internal.gmail.store.finalizeConnection, {
      completionHash: await sha256(args.completion),
    });
  },
});

/** Revokes at Google (best effort) and always deletes the stored tokens. */
export const disconnect = action({
  args: {},
  handler: async (ctx): Promise<{ revoked: boolean }> => {
    const { userId } = await ctx.runQuery(internal.gmail.store.actor, {});
    const conn = await ctx.runQuery(internal.gmail.store.connectionForUser, { userId });
    let revoked = false;
    if (conn) {
      try {
        revoked = await revokeToken(await decryptSecret(conn.refreshToken));
      } catch {
        revoked = false;
      }
    }
    await ctx.runMutation(internal.gmail.store.deleteConnection, { userId });
    return { revoked };
  },
});
