import { v } from "convex/values";
import { action } from "../_generated/server";
import { internal } from "../_generated/api";
import { composeMode } from "../schema/gmail";
import {
  gmailFail,
  GmailApiError,
  mapLimit,
  openSession,
  toUserError,
  type GmailSession,
} from "./client";
import { randomToken, toBase64Url } from "./crypto";
import {
  buildRawMessage,
  gmailMessageUrl,
  header,
  MAX_BODY_CHARS,
  MAX_RECIPIENTS,
  MAX_SUBJECT_CHARS,
  parsePayload,
  replyReferences,
  shouldKeepThread,
  validateRecipients,
  type AttachmentMeta,
  type GmailPart,
} from "./mime";

type RawMessage = {
  id: string;
  threadId: string;
  labelIds?: string[];
  snippet?: string;
  internalDate?: string;
  payload?: GmailPart;
};

const GMAIL_ID = /^[A-Za-z0-9]{6,64}$/;
const checkId = (id: string, label = "id") => {
  if (!GMAIL_ID.test(id)) gmailFail("BAD_REQUEST", `Invalid ${label}.`);
  return id;
};

const FOLDERS = {
  inbox: "INBOX",
  sent: "SENT",
  starred: "STARRED",
  all: null,
  trash: "TRASH",
} as const;
const folder = v.union(
  v.literal("inbox"),
  v.literal("sent"),
  v.literal("starred"),
  v.literal("all"),
  v.literal("trash"),
);

export type ThreadSummary = {
  id: string;
  subject: string;
  from: string;
  snippet: string;
  date: string | null;
  messageCount: number;
  unread: boolean;
  starred: boolean;
};

const PAGE_SIZE = 20;
// Bounded concurrency keeps us well inside Gmail per-user quota bursts.
const CONCURRENCY = 5;
const MAX_THREAD_MESSAGES = 50;

const decodeEntities = (s: string) =>
  s
    .replace(/&#(\d+);/g, (_, n: string) => String.fromCharCode(Number(n)))
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&");

const isoDate = (internalDate: string | undefined) =>
  internalDate ? new Date(Number(internalDate)).toISOString() : null;

export const listThreads = action({
  args: { folder, query: v.optional(v.string()), pageToken: v.optional(v.string()) },
  handler: async (
    ctx,
    args,
  ): Promise<{ threads: ThreadSummary[]; nextPageToken: string | null }> => {
    const s = await openSession(ctx);
    const params = new URLSearchParams({ maxResults: String(PAGE_SIZE) });
    const label = FOLDERS[args.folder];
    if (label) params.set("labelIds", label);
    if (args.folder === "trash") params.set("includeSpamTrash", "true");
    const q = (args.query ?? "").trim();
    if (q.length > 300) gmailFail("BAD_REQUEST", "Search is too long.");
    if (q) params.set("q", q);
    if (args.pageToken) {
      if (!/^[A-Za-z0-9_-]{1,200}$/.test(args.pageToken)) gmailFail("BAD_REQUEST", "Invalid page.");
      params.set("pageToken", args.pageToken);
    }
    try {
      const list = await s.request<{ threads?: { id: string }[]; nextPageToken?: string }>(
        `/threads?${params}`,
      );
      const threads = await mapLimit(list.threads ?? [], CONCURRENCY, async ({ id }) => {
        const t = await s.request<{ id: string; messages?: RawMessage[] }>(
          `/threads/${checkId(id)}?format=metadata&metadataHeaders=Subject&metadataHeaders=From&metadataHeaders=Date`,
        );
        const msgs = t.messages ?? [];
        const first = msgs[0];
        const last = msgs[msgs.length - 1];
        return {
          id: t.id,
          subject: header(first?.payload?.headers, "Subject") || "(no subject)",
          from: header(last?.payload?.headers, "From") ?? "",
          snippet: decodeEntities(last?.snippet ?? ""),
          date: isoDate(last?.internalDate),
          messageCount: msgs.length,
          unread: msgs.some((m) => m.labelIds?.includes("UNREAD")),
          starred: msgs.some((m) => m.labelIds?.includes("STARRED")),
        } satisfies ThreadSummary;
      });
      await s.touch();
      return { threads, nextPageToken: list.nextPageToken ?? null };
    } catch (e) {
      toUserError(e);
    }
  },
});

export type ThreadMessage = {
  id: string;
  from: string;
  to: string;
  cc: string;
  replyTo: string;
  date: string | null;
  subject: string;
  text: string | null;
  html: string | null;
  attachments: AttachmentMeta[];
  /** Open in Gmail (attachments are opened there in this version). */
  gmailUrl: string;
  unread: boolean;
};

export type ThreadDetail = {
  id: string;
  ownAddress: string;
  labels: string[];
  messages: ThreadMessage[];
  truncated: boolean;
};

export const getThread = action({
  args: { threadId: v.string() },
  handler: async (ctx, args): Promise<ThreadDetail> => {
    const s = await openSession(ctx);
    try {
      // Gmail only returns threads in the token owner's mailbox.
      const t = await s.request<{ id: string; messages?: RawMessage[] }>(
        `/threads/${checkId(args.threadId, "thread")}?format=full`,
      );
      const all = t.messages ?? [];
      const msgs = all.slice(-MAX_THREAD_MESSAGES);
      await s.touch();
      return {
        id: t.id,
        ownAddress: s.googleEmail,
        labels: Array.from(new Set(all.flatMap((m) => m.labelIds ?? []))),
        truncated: all.length > msgs.length,
        messages: msgs.map((m) => {
          const h = m.payload?.headers;
          const body = parsePayload(m.payload);
          return {
            id: m.id,
            from: header(h, "From") ?? "",
            to: header(h, "To") ?? "",
            cc: header(h, "Cc") ?? "",
            replyTo: header(h, "Reply-To") ?? "",
            date: isoDate(m.internalDate),
            subject: header(h, "Subject") ?? "",
            text: body.text,
            html: body.html,
            attachments: body.attachments,
            gmailUrl: gmailMessageUrl(s.googleEmail, m.id),
            unread: m.labelIds?.includes("UNREAD") ?? false,
          };
        }),
      };
    } catch (e) {
      toUserError(e);
    }
  },
});

const THREAD_LABELS = {
  read: { removeLabelIds: ["UNREAD"] },
  unread: { addLabelIds: ["UNREAD"] },
  archive: { removeLabelIds: ["INBOX"] },
  unarchive: { addLabelIds: ["INBOX"] },
  star: { addLabelIds: ["STARRED"] },
  unstar: { removeLabelIds: ["STARRED"] },
} as const;

export const modifyThread = action({
  args: {
    threadId: v.string(),
    op: v.union(
      v.literal("read"),
      v.literal("unread"),
      v.literal("archive"),
      v.literal("unarchive"),
      v.literal("star"),
      v.literal("unstar"),
      v.literal("trash"),
      v.literal("untrash"),
    ),
  },
  handler: async (ctx, args): Promise<null> => {
    const s = await openSession(ctx);
    const id = checkId(args.threadId, "thread");
    try {
      if (args.op === "trash" || args.op === "untrash")
        await s.request(`/threads/${id}/${args.op}`, { method: "POST" });
      else
        await s.request(`/threads/${id}/modify`, {
          method: "POST",
          body: THREAD_LABELS[args.op],
        });
      return null;
    } catch (e) {
      toUserError(e);
    }
  },
});

// ── Sending ─────────────────────────────────────────────────────────────────

export type SendResult =
  | { status: "sent"; threadId: string | null }
  | { status: "uncertain" }
  | { status: "failed"; message: string }
  | {
      status: "duplicate";
      previous: "pending" | "sent" | "uncertain";
      threadId: string | null;
    };

/** Only explicit client-side rejections are definite failures. */
export function classifySendError(e: unknown): "failed" | "uncertain" {
  if (e instanceof GmailApiError) return e.status >= 400 && e.status < 500 ? "failed" : "uncertain";
  return "uncertain";
}

type Threading = { threadId?: string; inReplyTo?: string; references?: string };

/** Reply headers come from Gmail itself, never from the browser. */
async function resolveThreading(
  s: GmailSession,
  mode: "new" | "reply" | "forward",
  subject: string,
  replyToMessageId: string | undefined,
): Promise<Threading> {
  if (mode !== "reply") return {};
  if (!replyToMessageId) gmailFail("BAD_REQUEST", "Missing the message being replied to.");
  try {
    const parent = await s.request<RawMessage>(
      `/messages/${checkId(replyToMessageId, "message")}?format=metadata&metadataHeaders=Message-ID&metadataHeaders=References&metadataHeaders=Subject`,
    );
    const h = parent.payload?.headers;
    const parentMid = header(h, "Message-ID") ?? header(h, "Message-Id");
    return {
      inReplyTo: parentMid,
      references: replyReferences(header(h, "References"), parentMid),
      threadId: shouldKeepThread("reply", header(h, "Subject") ?? "", subject)
        ? parent.threadId
        : undefined,
    };
  } catch (e) {
    toUserError(e);
  }
}

function validateCompose(f: { to: string[]; cc: string[]; bcc: string[]; subject: string; text: string }) {
  let to: string[], cc: string[], bcc: string[];
  try {
    to = validateRecipients(f.to, "To");
    cc = validateRecipients(f.cc, "Cc");
    bcc = validateRecipients(f.bcc, "Bcc");
  } catch (e) {
    gmailFail("BAD_REQUEST", e instanceof Error ? e.message : "Invalid recipients.");
  }
  const count = to.length + cc.length + bcc.length;
  if (to.length === 0) gmailFail("BAD_REQUEST", "Add at least one recipient.");
  if (count > MAX_RECIPIENTS) gmailFail("BAD_REQUEST", `At most ${MAX_RECIPIENTS} recipients.`);
  if (f.subject.length > MAX_SUBJECT_CHARS) gmailFail("BAD_REQUEST", "Subject is too long.");
  if (f.text.length > MAX_BODY_CHARS) gmailFail("BAD_REQUEST", "Message is too long.");
  return { to, cc, bcc, count };
}

/**
 * The single safe send path: ledger first, one Gmail call with no automatic
 * retry, then a definite outcome or "uncertain" so nothing is sent twice.
 */
export const send = action({
  args: {
    requestId: v.string(),
    mode: composeMode,
    to: v.array(v.string()),
    cc: v.array(v.string()),
    bcc: v.array(v.string()),
    subject: v.string(),
    text: v.string(),
    replyToMessageId: v.optional(v.string()),
  },
  handler: async (ctx, args): Promise<SendResult> => {
    const s = await openSession(ctx);
    const { to, cc, bcc, count } = validateCompose(args);
    const prior = await ctx.runQuery(internal.gmail.store.sendAttempt, {
      userId: s.userId,
      requestId: args.requestId,
    });
    if (prior && prior.status !== "failed")
      return { status: "duplicate", previous: prior.status, threadId: prior.gmailThreadId ?? null };
    const threading = await resolveThreading(s, args.mode, args.subject, args.replyToMessageId);
    // Surface token problems before recording an attempt.
    try {
      await s.token();
    } catch (e) {
      toUserError(e);
    }
    const domain = s.googleEmail.split("@")[1] ?? "toor.local";
    const begin = await ctx.runMutation(internal.gmail.store.beginSend, {
      userId: s.userId,
      requestId: args.requestId,
      messageIdHeader: `<toor.${args.requestId}.${randomToken(6)}@${domain}>`,
      mode: args.mode,
      recipientCount: count,
    });
    if (!begin.proceed)
      return {
        status: "duplicate",
        previous: begin.status === "failed" ? "pending" : begin.status,
        threadId: begin.gmailThreadId,
      };

    const raw = buildRawMessage({
      from: s.googleEmail,
      to,
      cc,
      bcc,
      subject: args.subject.trim() || "(no subject)",
      text: args.text,
      messageId: begin.messageIdHeader,
      inReplyTo: threading.inReplyTo,
      references: threading.references,
    });
    const finish = (
      status: "sent" | "failed" | "uncertain",
      extra: { gmailMessageId?: string; gmailThreadId?: string; errorCode?: string } = {},
    ) =>
      ctx.runMutation(internal.gmail.store.finishSend, {
        userId: s.userId,
        requestId: args.requestId,
        status,
        ...extra,
      });

    try {
      const res = await s.request<{ id: string; threadId: string }>(`/messages/send`, {
        method: "POST",
        body: {
          raw: toBase64Url(new TextEncoder().encode(raw)),
          ...(threading.threadId ? { threadId: threading.threadId } : {}),
        },
        retry: false, // a send is never automatically repeated
      });
      await finish("sent", { gmailMessageId: res.id, gmailThreadId: res.threadId });
      return { status: "sent", threadId: res.threadId };
    } catch (e) {
      const outcome = classifySendError(e);
      const code = e instanceof GmailApiError ? `${e.status}` : "network";
      await finish(outcome, { errorCode: code });
      if (outcome === "uncertain") return { status: "uncertain" };
      return {
        status: "failed",
        message:
          e instanceof GmailApiError && e.status === 429
            ? "Gmail rate limit reached. Nothing was sent; try again shortly."
            : "Gmail rejected this message. Nothing was sent.",
      };
    }
  },
});

/**
 * Looks for an uncertain send in Sent by its Message-ID. Not finding it does
 * NOT make it failed: Gmail indexing can lag, so it stays uncertain.
 */
export const checkSend = action({
  args: { requestId: v.string() },
  handler: async (
    ctx,
    args,
  ): Promise<{ status: "sent" | "uncertain" | "failed" | "pending" | "unknown" }> => {
    const s = await openSession(ctx);
    const row = await ctx.runQuery(internal.gmail.store.sendAttempt, {
      userId: s.userId,
      requestId: args.requestId,
    });
    if (!row) return { status: "unknown" };
    if (row.status !== "uncertain") return { status: row.status };
    try {
      const q = `rfc822msgid:${row.messageIdHeader.replace(/[<>]/g, "")}`;
      const found = await s.request<{ messages?: { id: string; threadId: string }[] }>(
        `/messages?${new URLSearchParams({ q, maxResults: "1", includeSpamTrash: "true" })}`,
      );
      const hit = found.messages?.[0];
      if (!hit) return { status: "uncertain" };
      await ctx.runMutation(internal.gmail.store.finishSend, {
        userId: s.userId,
        requestId: args.requestId,
        status: "sent",
        gmailMessageId: hit.id,
        gmailThreadId: hit.threadId,
      });
      return { status: "sent" };
    } catch (e) {
      toUserError(e);
    }
  },
});
