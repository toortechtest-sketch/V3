/**
 * Pure RFC 5322 / Gmail payload helpers. No I/O, so they are shared with the
 * frontend (reply recipients, subjects) and unit-tested directly.
 */

export type ComposeMode = "new" | "reply" | "forward";

export type OutgoingMessage = {
  from: string;
  to: string[];
  cc: string[];
  bcc: string[];
  subject: string;
  text: string;
  messageId: string;
  inReplyTo?: string;
  references?: string;
};

const EMAIL_RE = /^[^\s@<>(),;:"[\]]+@[^\s@<>(),;:"[\]]+\.[^\s@<>(),;:"[\]]+$/;
export const MAX_RECIPIENTS = 50;
export const MAX_BODY_CHARS = 100_000;
export const MAX_SUBJECT_CHARS = 500;

/** Deep link to a message in Gmail web for the given account. */
export const gmailMessageUrl = (email: string, messageId: string) =>
  `https://mail.google.com/mail/u/?authuser=${encodeURIComponent(email)}#all/${encodeURIComponent(messageId)}`;

/** Strip CR/LF so user input can never inject extra headers. */
export const headerSafe = (value: string) => value.replace(/[\r\n]+/g, " ").trim();

/** Extract the bare address from `Name <a@b.c>` or `a@b.c`. */
export function bareAddress(value: string): string {
  const m = value.match(/<([^>]+)>/);
  return (m ? m[1] : value).trim().toLowerCase();
}

/** Split a header list like `A <a@x.com>, b@y.com` into addresses. */
export function splitAddressList(value: string | undefined): string[] {
  if (!value) return [];
  const out: string[] = [];
  let buf = "";
  let quoted = false;
  let angle = false;
  for (const ch of value) {
    if (ch === '"') quoted = !quoted;
    if (ch === "<") angle = true;
    if (ch === ">") angle = false;
    if ((ch === "," || ch === ";") && !quoted && !angle) {
      if (buf.trim()) out.push(buf.trim());
      buf = "";
    } else buf += ch;
  }
  if (buf.trim()) out.push(buf.trim());
  return out;
}

export function validateRecipients(list: string[], label: string): string[] {
  const clean = list.map((a) => bareAddress(headerSafe(a))).filter(Boolean);
  for (const a of clean)
    if (!EMAIL_RE.test(a))
      throw new Error(`${label}: "${a}" is not a valid email address.`);
  return Array.from(new Set(clean));
}

const PREFIX_RE = /^\s*((re|fw|fwd|aw|sv|wg)\s*(\[\d+\])?\s*:\s*)+/i;

/** Subject with any leading Re:/Fwd: prefixes removed, for thread comparison. */
export const baseSubject = (subject: string) =>
  subject.replace(PREFIX_RE, "").trim();

export function replySubject(original: string): string {
  const s = headerSafe(original);
  return /^\s*re\s*:/i.test(s) ? s : `Re: ${baseSubject(s) || s}`;
}

export function forwardSubject(original: string): string {
  const s = headerSafe(original);
  return /^\s*(fw|fwd)\s*:/i.test(s) ? s : `Fwd: ${baseSubject(s) || s}`;
}

/** References header for a reply: parent References + parent Message-ID. */
export function replyReferences(
  parentReferences: string | undefined,
  parentMessageId: string | undefined,
): string | undefined {
  const ids = (parentReferences ?? "").split(/\s+/).filter(Boolean);
  if (parentMessageId && !ids.includes(parentMessageId)) ids.push(parentMessageId);
  // Keep the header bounded; the first id anchors the thread, so keep it.
  const trimmed = ids.length > 20 ? [ids[0], ...ids.slice(-19)] : ids;
  return trimmed.length ? trimmed.join(" ") : undefined;
}

/**
 * Gmail threads a reply only when threadId is set AND the subject still
 * matches. If the user changed the subject we start a new conversation.
 */
export function shouldKeepThread(
  mode: ComposeMode,
  originalSubject: string,
  newSubject: string,
) {
  if (mode !== "reply") return false;
  return (
    baseSubject(originalSubject).toLowerCase() ===
    baseSubject(newSubject).toLowerCase()
  );
}

/** Recipients for reply / reply-all, excluding the mailbox owner. */
export function replyRecipients(
  headers: { from?: string; replyTo?: string; to?: string; cc?: string },
  ownAddress: string,
  all: boolean,
): { to: string[]; cc: string[] } {
  const own = ownAddress.toLowerCase();
  const primary = splitAddressList(headers.replyTo || headers.from).map(bareAddress);
  const fromSelf = primary.every((a) => a === own);
  // Replying to your own sent message goes back to the original recipients.
  const to = fromSelf ? splitAddressList(headers.to).map(bareAddress) : primary;
  const uniq = (xs: string[]) =>
    Array.from(new Set(xs.filter((a) => a && a !== own)));
  if (!all) return { to: uniq(to), cc: [] };
  const toSet = new Set(uniq(to));
  const cc = uniq([
    ...(fromSelf ? [] : splitAddressList(headers.to).map(bareAddress)),
    ...splitAddressList(headers.cc).map(bareAddress),
  ]).filter((a) => !toSet.has(a));
  return { to: Array.from(toSet), cc };
}

function encodeHeaderWord(value: string): string {
  // RFC 2047 encoded-word only when needed.
  if (/^[\x20-\x7e]*$/.test(value)) return value;
  const bytes = new TextEncoder().encode(value);
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return `=?UTF-8?B?${btoa(bin)}?=`;
}

function base64Lines(text: string): string {
  const bytes = new TextEncoder().encode(text);
  let bin = "";
  for (let i = 0; i < bytes.length; i += 0x8000)
    bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  return (btoa(bin).match(/.{1,76}/g) ?? []).join("\r\n");
}

/** Builds the raw RFC 5322 message (CRLF line endings, UTF-8 text body). */
export function buildRawMessage(m: OutgoingMessage): string {
  const headers = [
    `From: ${headerSafe(m.from)}`,
    m.to.length ? `To: ${m.to.map(headerSafe).join(", ")}` : null,
    m.cc.length ? `Cc: ${m.cc.map(headerSafe).join(", ")}` : null,
    m.bcc.length ? `Bcc: ${m.bcc.map(headerSafe).join(", ")}` : null,
    `Subject: ${encodeHeaderWord(headerSafe(m.subject))}`,
    `Message-ID: ${headerSafe(m.messageId)}`,
    m.inReplyTo ? `In-Reply-To: ${headerSafe(m.inReplyTo)}` : null,
    m.references ? `References: ${headerSafe(m.references)}` : null,
    `Date: ${new Date().toUTCString()}`,
    "MIME-Version: 1.0",
    'Content-Type: text/plain; charset="UTF-8"',
    "Content-Transfer-Encoding: base64",
  ].filter((h): h is string => h !== null);
  return `${headers.join("\r\n")}\r\n\r\n${base64Lines(m.text)}\r\n`;
}

// ── Gmail payload parsing ───────────────────────────────────────────────────

export type GmailHeader = { name: string; value: string };
export type GmailPart = {
  partId?: string;
  mimeType?: string;
  filename?: string;
  headers?: GmailHeader[];
  body?: { size?: number; data?: string; attachmentId?: string };
  parts?: GmailPart[];
};

export function header(
  headers: GmailHeader[] | undefined,
  name: string,
): string | undefined {
  const lower = name.toLowerCase();
  return headers?.find((h) => h.name.toLowerCase() === lower)?.value;
}

export function decodeBase64UrlText(data: string): string {
  const b64 = data.replace(/-/g, "+").replace(/_/g, "/").replace(/\s+/g, "");
  const bin = atob(b64 + "=".repeat((4 - (b64.length % 4)) % 4));
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return new TextDecoder().decode(bytes);
}

export type AttachmentMeta = { filename: string; mimeType: string; size: number };

export type ParsedBody = {
  text: string | null;
  html: string | null;
  attachments: AttachmentMeta[];
};

/** Walks the MIME tree, taking the first text/plain and text/html parts. */
export function parsePayload(
  payload: GmailPart | undefined,
  maxChars = 400_000,
): ParsedBody {
  const out: ParsedBody = { text: null, html: null, attachments: [] };
  const walk = (part: GmailPart) => {
    const type = (part.mimeType ?? "").toLowerCase();
    if (part.filename && (part.body?.attachmentId || part.body?.size)) {
      out.attachments.push({
        filename: part.filename,
        mimeType: part.mimeType ?? "application/octet-stream",
        size: part.body?.size ?? 0,
      });
      return;
    }
    if (part.body?.data) {
      if (type === "text/plain" && out.text === null)
        out.text = decodeBase64UrlText(part.body.data).slice(0, maxChars);
      else if (type === "text/html" && out.html === null)
        out.html = decodeBase64UrlText(part.body.data).slice(0, maxChars);
    }
    part.parts?.forEach(walk);
  };
  if (payload) walk(payload);
  return out;
}

/** Plain-text quote of the original for forwards. */
export function forwardQuote(o: {
  from?: string;
  date?: string;
  subject?: string;
  to?: string;
  text: string;
}) {
  return [
    "",
    "---------- Forwarded message ---------",
    `From: ${o.from ?? ""}`,
    `Date: ${o.date ?? ""}`,
    `Subject: ${o.subject ?? ""}`,
    `To: ${o.to ?? ""}`,
    "",
    o.text,
  ].join("\n");
}
