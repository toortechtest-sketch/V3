/**
 * Web Crypto helpers (Convex V8 runtime). Encryption only runs inside
 * actions / HTTP actions, so plaintext tokens never pass through queries or
 * mutations.
 */
import { SECRET_NAMES } from "./config";

const enc = new TextEncoder();
const dec = new TextDecoder();

export function toBase64Url(bytes: Uint8Array): string {
  let bin = "";
  for (const b of bytes) bin += String.fromCharCode(b);
  return btoa(bin).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

export function fromBase64Url(value: string): Uint8Array<ArrayBuffer> {
  const b64 = value.replace(/-/g, "+").replace(/_/g, "/");
  const bin = atob(b64 + "=".repeat((4 - (b64.length % 4)) % 4));
  const out = new Uint8Array(new ArrayBuffer(bin.length));
  for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
  return out;
}

export function randomToken(bytes = 32): string {
  return toBase64Url(crypto.getRandomValues(new Uint8Array(bytes)));
}

export async function sha256(value: string): Promise<string> {
  const digest = await crypto.subtle.digest("SHA-256", enc.encode(value));
  return toBase64Url(new Uint8Array(digest));
}

/** PKCE S256 code challenge. */
export const pkceChallenge = (verifier: string) => sha256(verifier);

async function key(): Promise<CryptoKey> {
  const raw = process.env[SECRET_NAMES.encryptionKey];
  if (!raw) throw new Error("GMAIL_NOT_CONFIGURED");
  const bytes = fromBase64Url(raw.trim());
  if (bytes.length !== 32)
    throw new Error(
      `${SECRET_NAMES.encryptionKey} must be 32 bytes, base64 encoded.`,
    );
  return await crypto.subtle.importKey("raw", bytes, "AES-GCM", false, [
    "encrypt",
    "decrypt",
  ]);
}

export async function encryptSecret(plain: string): Promise<string> {
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const ct = await crypto.subtle.encrypt(
    { name: "AES-GCM", iv },
    await key(),
    enc.encode(plain),
  );
  return `v1.${toBase64Url(iv)}.${toBase64Url(new Uint8Array(ct))}`;
}

export async function decryptSecret(sealed: string): Promise<string> {
  const [version, iv, ct] = sealed.split(".");
  if (version !== "v1" || !iv || !ct) throw new Error("Bad ciphertext format.");
  const plain = await crypto.subtle.decrypt(
    { name: "AES-GCM", iv: fromBase64Url(iv) },
    await key(),
    fromBase64Url(ct),
  );
  return dec.decode(plain);
}
