import { v } from "convex/values";
import { query } from "./_generated/server";
import type { Doc } from "./_generated/dataModel";
import { fail, isManagerRole, requireStaff } from "./lib/access";
import { ownerNames } from "./lib/owners";

const DAY_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
const DAY_MS = 86_400_000;
// A calendar view never spans more than ~6 weeks; cap it so reads stay bounded.
const MAX_RANGE_DAYS = 62;
// Bookings that started before the window but are still running are found by
// looking back this far. Longer bookings would be missed at the window start.
const CARRY_OVER_DAYS = 120;
const LIMIT = 300;

const dayToMs = (day: string) => Date.parse(`${day}T00:00:00Z`);
const shiftDay = (day: string, days: number) =>
  new Date(dayToMs(day) + days * DAY_MS).toISOString().slice(0, 10);

/**
 * Bookings whose dates overlap [from, to] (inclusive calendar days), soonest
 * first. Same visibility as the bookings list: managers see everyone's.
 */
export const calendar = query({
  args: {
    from: v.string(),
    to: v.string(),
    mineOnly: v.optional(v.boolean()),
    includeCancelled: v.optional(v.boolean()),
  },
  handler: async (ctx, args) => {
    const staff = await requireStaff(ctx);
    const { from, to } = args;
    if (!DAY_PATTERN.test(from) || !DAY_PATTERN.test(to) || to < from) {
      fail("BAD_REQUEST", "Pick a valid date range.");
    }
    if ((dayToMs(to) - dayToMs(from)) / DAY_MS > MAX_RANGE_DAYS) {
      fail("BAD_REQUEST", "Pick a range of two months or less.");
    }

    const all = isManagerRole(staff.role) && !args.mineOnly;
    const ownerId = staff.user._id;
    const byStart = (lower: string, upper: string, inclusiveUpper: boolean) =>
      all
        ? ctx.db
            .query("bookings")
            .withIndex("by_start_date", (q) => {
              const r = q.gte("startDate", lower);
              return inclusiveUpper ? r.lte("startDate", upper) : r.lt("startDate", upper);
            })
        : ctx.db
            .query("bookings")
            .withIndex("by_owner_and_start_date", (q) => {
              const r = q.eq("ownerId", ownerId).gte("startDate", lower);
              return inclusiveUpper ? r.lte("startDate", upper) : r.lt("startDate", upper);
            });

    const [starting, earlier] = await Promise.all([
      byStart(from, to, true).take(LIMIT + 1),
      // Closest earlier starts first: those are the likeliest to still be running.
      byStart(shiftDay(from, -CARRY_OVER_DAYS), from, false)
        .order("desc")
        .take(LIMIT + 1),
    ]);
    const running = earlier.filter((b) => b.endDate >= from);
    const truncated = starting.length > LIMIT || earlier.length > LIMIT;

    const keep = (b: Doc<"bookings">) =>
      args.includeCancelled || b.stage !== "cancelled";
    const rows = [...running.reverse(), ...starting.slice(0, LIMIT)].filter(keep);
    const names = await ownerNames(ctx, rows);

    return {
      truncated,
      bookings: rows.map((b) => ({
        _id: b._id,
        reference: b.reference,
        title: b.title,
        type: b.type,
        stage: b.stage,
        clientName: b.clientName,
        destination: b.destination,
        startDate: b.startDate,
        endDate: b.endDate,
        pax: b.pax,
        ownerName: names.get(b.ownerId) ?? null,
      })),
    };
  },
});
