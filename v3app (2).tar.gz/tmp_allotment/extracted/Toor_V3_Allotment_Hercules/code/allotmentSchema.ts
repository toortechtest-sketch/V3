// Copy to convex/schema/allotments.ts and register these tables in schema.ts.
import { defineTable } from 'convex/server';
import { v } from 'convex/values';
export const allotmentPools = defineTable({
  supplierId: v.id('suppliers'),
  productId: v.optional(v.id('supplierProducts')),
  roomTypeId: v.optional(v.id('supplierRoomTypes')),
  // Exactly one resource ID; enforce ownership in the manager mutation.
  name: v.string(),
  kind: v.union(v.literal('hotel_night'), v.literal('session')),
  category: v.string(),
  unit: v.string(), // explicit room / seat / vehicle / person / group / item
  timezone: v.string(), // IANA zone, never the browser's implicit timezone
  contractReference: v.string(),
  enabled: v.boolean(),
  createdById: v.id('users'),
  updatedAt: v.string(),
}).index('by_supplier', ['supplierId']);
export const allotmentSlots = defineTable({
  poolId: v.id('allotmentPools'),
  serviceDate: v.string(),
  serviceKey: v.string(), // hotel: YYYY-MM-DD; session: stable departure identifier
  capacity: v.number(),
  retired: v.number(),
  enabled: v.boolean(),
  stopSale: v.boolean(),
  releaseAt: v.number(), // explicit UTC epoch milliseconds
  replenishOnReturn: v.boolean(),
  updatedAt: v.string(),
}).index('by_pool_key', ['poolId','serviceKey']);
export const allotmentAllocations = defineTable({
  slotId: v.id('allotmentSlots'),
  reservationId: v.id('reservations'),
  quantity: v.number(),
  state: v.union(v.literal('hold'), v.literal('confirmed')),
  holdUntil: v.optional(v.number()),
}).index('by_slot', ['slotId']).index('by_reservation', ['reservationId']);
export const allotmentAudit = defineTable({
  reservationId: v.optional(v.id('reservations')),
  poolId: v.optional(v.id('allotmentPools')),
  actorId: v.optional(v.id('users')),
  source: v.string(),
  reason: v.string(),
  beforeJson: v.string(),
  afterJson: v.string(),
  createdAt: v.string(),
}).index('by_reservation', ['reservationId']);
