/** Copy to convex/lib/reconcileAllotment.ts, engine to convex/lib/allotmentEngine.ts.
 * INTERNAL helper, not a public endpoint. Caller MUST first authorize the booking
 * or validate the supplier response link, then call within its SAME mutation.
 * Requires schema fields documented in INTEGRATION.md and regenerated Convex types.
 */
import type { MutationCtx } from '../_generated/server';
import type { Doc, Id } from '../_generated/dataModel';
import { fail } from './access';
import { planChange, hotelNights, AllotmentError, type Target } from './allotmentEngine';

type Reservation = Doc<'reservations'> & {
  allotmentPoolId?: Id<'allotmentPools'>;
  allotmentSessionKey?: string;
  allotmentHoldUntil?: number;
};
export async function reconcileAllotment(
  ctx: MutationCtx, reservation: Reservation,
  actorId: Id<'users'> | undefined, source: string, deleting = false,
) {
  const now = Date.now();
  const oldRows = await ctx.db.query('allotmentAllocations')
    .withIndex('by_reservation',q=>q.eq('reservationId',reservation._id)).take(367);
  if (oldRows.length > 366) fail('CONFLICT','Too many inventory rows; reconciliation required.');
  const desiredSlots: Doc<'allotmentSlots'>[] = [];
  const targets: Target[] = [];
  if (!deleting && reservation.allotmentPoolId && (reservation.status === 'confirmed' || reservation.status === 'option')) {
    const pool = await ctx.db.get('allotmentPools',reservation.allotmentPoolId);
    if (!pool || pool.supplierId !== reservation.supplierId) fail('BAD_REQUEST','Allotment supplier mismatch.');
    if (pool.kind === 'hotel_night' && reservation.type !== 'hotel') fail('BAD_REQUEST','Hotel inventory requires a hotel reservation.');
    // Read the underlying resource too: reject broken or cross-supplier mappings.
    if (Boolean(pool.productId) === Boolean(pool.roomTypeId)) fail('CONFLICT','Pool must reference one resource.');
    const resource = pool.productId ? await ctx.db.get('supplierProducts',pool.productId)
      : await ctx.db.get('supplierRoomTypes',pool.roomTypeId!);
    if (!resource || resource.supplierId !== pool.supplierId) fail('CONFLICT','Invalid allotment resource.');
    let keys: string[];
    try { keys = pool.kind === 'hotel_night' ? hotelNights(reservation.startDate,reservation.endDate ?? '')
      : [reservation.allotmentSessionKey ?? '']; }
    catch { fail('BAD_REQUEST','A hotel allotment needs valid check-in and checkout dates.'); }
    for (const key of keys) {
      if (!key) fail('BAD_REQUEST','Select the dated departure or service.');
      const s = await ctx.db.query('allotmentSlots').withIndex('by_pool_key',q=>q.eq('poolId',pool._id).eq('serviceKey',key)).unique();
      if (!s || (pool.kind === 'session' && s.serviceDate !== reservation.startDate)) fail('CONFLICT','No allotment exists for the required date or departure.');
      desiredSlots.push({ ...s, enabled: s.enabled && pool.enabled });
      targets.push({slotId:s._id,quantity:reservation.units,
        state:reservation.status === 'option' ? 'hold' : 'confirmed',
        ...(reservation.status === 'option' ? {holdUntil:reservation.allotmentHoldUntil} : {})});
    }
  }
  // Missing link with no previous stock is legacy/on-request, not unlimited stock.
  // Backend must separately guard removal of a link from a confirmed reservation.
  const scope = new Map(desiredSlots.map(s=>[s._id,s]));
  for (const a of oldRows) {
    if (!scope.has(a.slotId)) {
      const s = await ctx.db.get('allotmentSlots',a.slotId);
      if (!s) fail('CONFLICT','Broken inventory reference.');
      scope.set(s._id,s);
    }
  }
  if (!scope.size) return;
  const allRows: Doc<'allotmentAllocations'>[] = [];
  for (const s of scope.values()) {
    const rows = await ctx.db.query('allotmentAllocations').withIndex('by_slot',q=>q.eq('slotId',s._id)).take(2001);
    if (rows.length > 2000) fail('CONFLICT','Inventory scope exceeds safe limit; no changes applied.');
    allRows.push(...rows);
  }
  // Overall bound: fail closed; never calculate capacity from a truncated subset.
  if (allRows.length > 5000) fail('CONFLICT','Inventory scope too large; no changes applied.');
  const slots = [...scope.values()].map(s=>({id:s._id,capacity:s.capacity,retired:s.retired,enabled:s.enabled,
    stopSale:s.stopSale,releaseAt:s.releaseAt,replenishOnReturn:s.replenishOnReturn}));
  const allocations = allRows.map(a=>({slotId:a.slotId,reservationId:a.reservationId,quantity:a.quantity,state:a.state,
    ...(a.holdUntil !== undefined ? {holdUntil:a.holdUntil} : {})}));
  let plan;
  try { plan = planChange(slots,allocations,reservation._id,targets,now); }
  catch (e) { if(e instanceof AllotmentError) fail('CONFLICT', `${e.code}: ${e.message}`); throw e; }
  const key = (a: {slotId:string;reservationId:string})=>JSON.stringify([a.slotId,a.reservationId]);
  const next = new Map(plan.allocations.map(a=>[key(a),a]));
  const beforeJson = JSON.stringify({slots,allocations});
  const afterJson = JSON.stringify(plan);
  let changed = false;
  for (const s of plan.slots) {
    const original = scope.get(s.id as Id<'allotmentSlots'>)!;
    if (s.retired !== original.retired) {
      await ctx.db.patch('allotmentSlots',original._id,{retired:s.retired,updatedAt:new Date(now).toISOString()}); changed=true;
    }
  }
  for (const old of allRows) {
    const replacement = next.get(key(old));
    if (!replacement) { await ctx.db.delete('allotmentAllocations',old._id); changed=true; }
    else {
      if (old.quantity !== replacement.quantity || old.state !== replacement.state || old.holdUntil !== replacement.holdUntil) {
        await ctx.db.patch('allotmentAllocations',old._id,{quantity:replacement.quantity,state:replacement.state,holdUntil:replacement.holdUntil}); changed=true;
      }
      next.delete(key(old));
    }
  }
  for (const a of next.values()) {
    await ctx.db.insert('allotmentAllocations',{...a,slotId:a.slotId as Id<'allotmentSlots'>,reservationId:a.reservationId as Id<'reservations'>}); changed=true;
  }
  if (changed) await ctx.db.insert('allotmentAudit',{
    reservationId:reservation._id,actorId,source,reason:'Reservation inventory reconciliation',
    beforeJson,afterJson,createdAt:new Date(now).toISOString(),
  });
}
