import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import zipfile
spec=importlib.util.spec_from_file_location('batch',Path(__file__).parents[1]/'batch/inspect_snapshot.py')
batch=importlib.util.module_from_spec(spec); spec.loader.exec_module(batch)
class BatchTests(unittest.TestCase):
    def archive(self, folder, overrides=None):
        path=Path(folder)/'input.zip'
        rows={f'{t}/documents.jsonl':'' for t in batch.TABLES}
        rows['suppliers/documents.jsonl']='{"_id":"s1","category":"hotel"}\n'
        rows.update(overrides or {})
        with zipfile.ZipFile(path,'w') as z:
            for name, body in rows.items(): z.writestr(name,body)
        return path
    def test_valid_source_unchanged_and_no_defaults_invented(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.archive(d,{'supplierRoomTypes/documents.jsonl':'{"_id":"r1","supplierId":"s1"}\n'}); before=p.read_bytes()
            batch.write_review(p,Path(d)/'out'); self.assertEqual(before,p.read_bytes())
            data=json.loads((Path(d)/'out/candidate_settings.REVIEW_ONLY.json').read_text())
            self.assertIsNone(data['candidates'][0]['capacity']); self.assertFalse(data['importReady'])
    def test_bad_json_fails_without_partial_output(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.archive(d,{'suppliers/documents.jsonl':'{broken\n'}); out=Path(d)/'out'
            with self.assertRaises(ValueError): batch.write_review(p,out)
            self.assertFalse(out.exists())
    def test_duplicate_keys_fail(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.archive(d,{'suppliers/documents.jsonl':'{"_id":"a","_id":"b"}\n'})
            with self.assertRaises(ValueError): batch.inspect(p)
    def test_orphan_fails(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.archive(d,{'supplierProducts/documents.jsonl':'{"_id":"p1","supplierId":"wrong"}\n'})
            with self.assertRaises(ValueError): batch.inspect(p)
    def test_existing_output_never_overwritten(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.archive(d); out=Path(d)/'out'; out.mkdir(); marker=out/'keep'; marker.write_text('safe')
            with self.assertRaises(ValueError): batch.write_review(p,out)
            self.assertEqual(marker.read_text(),'safe')
    def test_missing_table_fails(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'input.zip'
            with zipfile.ZipFile(p,'w') as z: z.writestr('suppliers/documents.jsonl','')
            with self.assertRaises(ValueError): batch.inspect(p)
    def test_id_field_is_not_silently_accepted(self):
        with tempfile.TemporaryDirectory() as d:
            p=self.archive(d,{'suppliers/documents.jsonl':'{"id":"a"}\n'})
            with self.assertRaises(ValueError): batch.inspect(p)
if __name__=='__main__': unittest.main()
