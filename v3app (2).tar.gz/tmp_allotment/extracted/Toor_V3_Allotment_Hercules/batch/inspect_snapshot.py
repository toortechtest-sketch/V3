#!/usr/bin/env python3
"""Read-only replacement for the destructive allotment batch. Python 3.10+.
Produces a new review directory atomically; never edits or imports source data.
Usage: python batch/inspect_snapshot.py SNAPSHOT.zip --out NEW_DIRECTORY
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import tempfile
import zipfile

TABLES = ('suppliers','supplierProducts','supplierRoomTypes','supplierCapabilities','supplierRates','reservations')
CATEGORIES = {'hotel','transport','restaurant','activity','venue','airline','guide','cruise','equipment_event','other'}
ALIASES = {'accommodation':'hotel','transfer':'transport','flight':'airline'}
MAX_BYTES = 128 * 1024 * 1024

def no_duplicates(pairs):
    record = {}
    for key, value in pairs:
        if key in record:
            raise ValueError('Duplicate JSON key: ' + key)
        record[key] = value
    return record

def inspect(snapshot):
    data = {}
    with zipfile.ZipFile(snapshot) as z:
        names = z.namelist()
        if len(names) != len(set(names)):
            raise ValueError('Duplicate archive paths')
        selected = [n for n in names if n in [f'{t}/documents.jsonl' for t in TABLES]]
        if sum(z.getinfo(n).file_size for n in selected) > MAX_BYTES:
            raise ValueError('Selected data exceeds safety limit')
        for table in TABLES:
            path = f'{table}/documents.jsonl'
            if path not in names:
                raise ValueError(f'Required table missing: {table}; no plan produced')
            records, ids = [], set()
            for number, line in enumerate(z.read(path).decode('utf-8-sig').splitlines(), 1):
                if not line.strip():
                    continue
                try:
                    item = json.loads(line, object_pairs_hook=no_duplicates,
                        parse_constant=lambda value: (_ for _ in ()).throw(ValueError('Non-finite JSON number')))
                    if not isinstance(item, dict) or not isinstance(item.get('_id'), str) or not item['_id']:
                        raise ValueError('Each document needs a nonempty _id')
                    if item['_id'] in ids:
                        raise ValueError('Duplicate document ID')
                    ids.add(item['_id'])
                    records.append(item)
                except (ValueError, TypeError) as error:
                    raise ValueError(f'{table}, line {number}: {error}') from error
            data[table] = records
    suppliers = {s['_id']:s for s in data['suppliers']}
    products = {p['_id']:p for p in data['supplierProducts']}
    for table in ('supplierProducts','supplierRoomTypes','supplierCapabilities','supplierRates'):
        for row in data[table]:
            if row.get('supplierId') not in suppliers:
                raise ValueError(f'{table}: unresolved supplierId')
            if table == 'supplierRates':
                product = products.get(row.get('productId'))
                if product is None or product['supplierId'] != row['supplierId']:
                    raise ValueError('supplierRates: missing product or supplier mismatch')
    for row in data['reservations']:
        if row.get('supplierId') is not None and row['supplierId'] not in suppliers:
            raise ValueError('reservations: unresolved supplierId')
    warnings, candidates = [], []
    for table in ('supplierProducts','supplierRoomTypes'):
        for row in data[table]:
            raw = 'hotel' if table == 'supplierRoomTypes' else row.get('category')
            category = ALIASES.get(raw, raw) if isinstance(raw,str) else None
            if category not in CATEGORIES:
                warnings.append({'table':table,'recordId':row['_id'],'reason':'Unknown category; no automatic mapping'})
                category = None
            candidates.append({'sourceTable':table,'sourceId':row['_id'],'supplierId':row['supplierId'],
                'category':category,'enabled':False,'capacity':None,'releaseAt':None,
                'overbookingAllowed':False,'replenishOnReturn':False,
                'reviewRequired':True})
    rate_claims = sum(r.get('availabilityStatus') == 'confirmed_allocation' for r in data['supplierRates'])
    if rate_claims:
        warnings.append({'reason':f'{rate_claims} rate rows say confirmed_allocation; these are not dated stock records'})
    report = {'format':'toor-allotment-review-v1','sourceSha256':hashlib.sha256(Path(snapshot).read_bytes()).hexdigest(),
        'counts':{t:len(data[t]) for t in TABLES},'candidateCount':len(candidates),'warnings':warnings,
        'databaseWrites':0,'importReady':False,
        'reason':'Review manifest only. Deploy and validate allotment schema and booking hooks before any stock import.',
        'unmappedReservations':len(data['reservations'])}
    return report, {'format':'toor-allotment-candidates-v1','importReady':False,'candidates':candidates}

def write_review(snapshot, destination):
    destination = Path(destination).absolute()
    if destination.exists():
        raise ValueError('Output already exists; choose a new directory')
    report, candidates = inspect(snapshot)
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = Path(tempfile.mkdtemp(prefix='.allotment-review-',dir=destination.parent))
    try:
        for name, value in [('snapshot_report.json', report),('candidate_settings.REVIEW_ONLY.json', candidates)]:
            with (temp/name).open('x',encoding='utf-8') as f:
                json.dump(value,f,ensure_ascii=False,indent=2,allow_nan=False)
                f.write('\n'); f.flush(); os.fsync(f.fileno())
        if destination.exists():
            raise ValueError('Output appeared during review; no files replaced')
        temp.rename(destination)
    except BaseException:
        shutil.rmtree(temp,ignore_errors=True)
        raise
    return report

if __name__ == '__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('snapshot',type=Path)
    parser.add_argument('--out',required=True,type=Path)
    args=parser.parse_args()
    try:
        result=write_review(args.snapshot,args.out)
        print(json.dumps({'status':'review_created','counts':result['counts'],'databaseWrites':0}))
    except (OSError, ValueError, zipfile.BadZipFile, UnicodeError) as error:
        parser.exit(1,f'FAILED — no source changes: {error}\n')
