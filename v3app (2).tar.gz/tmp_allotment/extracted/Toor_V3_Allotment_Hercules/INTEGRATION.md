# Integration contract for Hercules

## Evidence and delivery boundary

Latest user snapshot: 17 suppliers, 30 supplierRoomTypes, 1 supplierProducts,
1 supplierCapabilities, 1 supplierRates, 0 reservations. IDs are `_id`; foreign keys
are `supplierId`, `productId`. Supplier categories observed: hotel and other.
The generated_schema.jsonl entries say "uniform"; these are not application validators.
The separate earlier source archive contains React/TypeScript and Convex, with
legacy hotel/transfer/etc. categories and newer dynamic service categories.

Supplied, tested locally: pure inventory engine (20 tests) and non-destructive
snapshot checker (7 tests). Supplied for integration: Convex schema and internal
storage adapter. NOT yet compiled/tested in the deployed Hercules project: those
adapters, booking hooks, management APIs, UI and concurrent database behaviour.
Hercules must implement and test these remaining integration pieces before enabling
stock. The package contains no real contracted capacity and no production writes.

## Install additive code

1. Copy code/allotmentEngine.ts to convex/lib/allotmentEngine.ts.
2. Copy code/allotmentSchema.ts to convex/schema/allotments.ts. Import and register
   its four exports in convex/schema.ts, preserving every existing table.
3. Copy code/reconcileAllotment.ts to convex/lib/reconcileAllotment.ts.
4. Extend reservations schema, reservationFields validator, ReservationFields type
   and cleanReservation with OPTIONAL allotmentPoolId (v.id allotmentPools),
   allotmentSessionKey (string), allotmentHoldUntil (number). Extend dialog payloads.
   Existing reservations remain valid. No mandatory bulk migration.
5. Regenerate Convex types with the project's normal workflow. Do not manually edit
   generated API or data-model declarations. Adapt API syntax to installed version.

## Reservation lifecycle: all paths must reconcile atomically

Use existing requireBooking/requireReservation and finance checks. Inventory code
never replaces authorization. No public API should accept arbitrary allocation
rows or quantities detached from the authorized reservation.

- convex/reservations.ts create: insert the reservation, read it, reconcileAllotment,
  return ID in the SAME mutation. A failure rolls back insert and allocation.
- update: preserve optional allotment fields in db.replace; validate final values,
  replace, read final doc, reconcile in that mutation. A failure rolls back both.
- setStatus: patch, read final doc, reconcile. Same-status retries should still be
  coherent; do not clear holds or rebuild stock in a separate action.
- remove: after existing authorization and confirmation restrictions, reconcile
  with deleting=true BEFORE deleting the reservation in that same mutation.
- convex/lib/reservationChanges.ts applyChangeDecision: after confirmed change or
  cancellation is applied, read the final reservation and reconcile before returning.
  Apply finance-lock validation here too so all entry paths receive it. A capacity
  error must roll back the decision and leave the request pending; do not record an
  approval while leaving stock inconsistent. Preserve supplier-link validation.
- Search every other mutation touching reservations, booking deletion, imports,
  cloning and supplier responses. Route each through the same transactional hook.
  Prevent deleting suppliers/products/room types/pools/slots used by active stock.

Status mapping: option = hold with explicit future UTC expiry; confirmed = committed
stock; requested = no stock guarantee; cancelled/deleted = no allocation. Financial
cancellation fees are separate and must remain unchanged. A request for a confirmed
change does not alter stock until approved. A declined/withdrawn change does not
alter stock. Expired options retain history; confirmation must reacquire stock.
Never silently convert an expired option to a confirmed reservation.

The existing optionUntil is a calendar date. Do NOT infer midnight UTC or browser
local midnight. The new allotmentHoldUntil must be explicit, displayed in pool timezone,
and no later than releaseAt. Leave legacy optionUntil handling intact for unlinked
reservations. ReconcileAllotment deliberately refuses a linked option without a valid
future allotmentHoldUntil.

Allotment mode must be explicit in UI: On request / Contracted allotment. Legacy or
unlinked reservations remain on-request workflows, not unlimited availability.
Do not silently fallback to on-request when inventory fails. Protect link removal
and supplier/resource/date changes according to confirmed-change approvals.
For active linked pools, label resource and unit visibly so staff cannot book a
vehicle count as seats, or passenger count as rooms. Reservation.units is always
inventory units; passenger count remains separate. Validate pool category against
the reservation category, using existing serviceToLegacy mapping where appropriate.

## Resources and stock management

Implement authenticated list/availability APIs and owner/global-manager pool and slot
mutations using the observed requireManager helper. Agents can consume stock for
bookings they can access; they cannot change capacity, release dates or contracts.
The reviewed access model is deployment-wide; it has no tenant ID. If the current
project has gained tenant/agency scope, add that scope to every new table/index/read/
write and derive it server-side. Never treat createdById as a substitute for tenancy.

A pool references exactly ONE product or legacy room type belonging to supplierId.
Reject duplicates for a resource; do not automatically give both a hotel product
and a room-type row separate copies of the same stock. Multi-category suppliers use
product category. Pools require name, explicit unit, contractReference, IANA timezone
and kind. New pools disabled. Validate underlying resource ownership and category.
Hotel pools use room-night units. Session pools use explicit dated departure IDs,
which distinguish two departures on the same day. A private group or vehicle is one
unit only when the supplier contract explicitly uses that unit.

Management UI: supplier detail > Allotments. Select resource, contract reference,
timezone and units; date range or departures; contracted capacity; absolute release
date/time; stop-sale; replenishment rule. Manager must explicitly enable. Add daily
calendar/table with total, held, confirmed, retired, available and release deadline.
Allow bulk date entry as one validated transaction within a safe limit; reject the
whole request if any entry fails. Do not invent dates, capacity or release intervals.

Slot uniqueness = (poolId, serviceKey), checked transactionally. Hotel serviceKey
must equal serviceDate; serviceDate must be a real YYYY-MM-DD. Session serviceKey is
stable, never a translated display label. Validate safe integers, finite UTC timestamps,
real IANA zones and explicit time conversion; ambiguous DST times require an explicit
offset. Release is specified per slot (per hotel night in this version). Arrival-based
contract release rules require a separate extension; do not approximate them silently.

Capacity may be zero but cannot fall below held + confirmed + retired. Retired means
returned units that the contract does not permit reselling; only an audited manager
contract adjustment can restore them. Do not reset retired during ordinary edits.
Changing replenishment terms when allocations/expired holds exist requires an explicit
reconciliation of old terms before the new terms take effect. Disabling or stopping a
pool/slot stops NEW consumption but does not erase existing confirmations. Existing
valid holds may confirm without increasing quantity. The engine rejects overbooking.

## Transactions, expiry and consistency

The adapter reads every allocation for all old/new slots before computing a plan.
Do not substitute a truncated query or cache. Bounds deliberately fail closed. If a
scope exceeds limits, implement a safe counter/ledger design before raising them.
Capacity and allocation writes share the mutation transaction. Do not split across
actions/network calls; do not rely on client-side locking. Test actual concurrent
requests in the project's Convex test environment: only one last-unit confirmation
may succeed. The supplied sequential unit test is NOT a concurrency test.

Availability queries use engine availability() over a complete slot scope; they
logically ignore expired holds immediately. Add a bounded, idempotent scheduled
cleanup that uses the SAME expiry/retired rules from the engine, atomically persists
expired-row deletions, and audits system cleanup. Do not require the job to run before
availability becomes correct. Do not pass an active reservation ID with empty targets
for cleanup: that cancels it. Use a dedicated helper that only reconciles expired rows,
or adapt the pure prepare logic into an exported expiry planner and test it.

At releaseAt, available becomes zero; confirmed allocations remain. No new stock is
created. Do not delete allotment history at release. For multi-night changes, either
all dates succeed or none change. Retries after successful holds/confirmation/cancel
must not double debit or release; add request idempotency to reservation creation
where the current application lacks it (unique server-side request key + payload
fingerprint and stored result). Reusing a key with different inputs must fail.

Audit pool/slot edits and reservation inventory changes with actor or validated
supplier/system source, timestamp, reason, before/after; protect logs from client edits.
The provided adapter writes inventory audit; management APIs must add their own audit.
Do not expose other bookings' identities through the availability endpoint. Audit UI
is manager-only. Staff availability returns totals without guest information.

## UI and languages

Use the existing React component conventions; no new framework. Supplier Allotments
tab plus reservation selector and availability preview. Show remaining capacity per
night/departure, hold expiry, release, stop-sale and conflict messages. Refresh after
server rejection; never claim booking succeeded before the mutation returns.

Use stable translation keys under allotment.*. Provide English fallback strings and
connect the existing language switcher if present. Support future en/fr/da/de/es
catalogues without changing stored IDs, dates, category enums or JSON keys. No machine
translation dependency or mandatory AI service. Format dates/numbers for locale while
storing ISO dates and UTC epoch milliseconds. Translate error codes in UI; retain
server diagnostics. An initial English catalogue is supplied.

## Import and deployment

The Python batch is a read-only inspection/review tool; output is NOT Convex import
format. Candidate JSON lists disabled resource candidates with capacity=null because
no stock is known. Do not import null capacity into v.number fields. Existing data
needs no rewrite. Do not restore the user's database snapshot to enable a feature.

If a future contract CSV/JSON importer is added: authenticate manager, validate every
row and relation, preview changes first, show duplicates/conflicts, require explicit
apply, use an import key plus content hash for idempotency, preserve existing stock,
and reject unknown columns/IDs instead of fuzzy guessing. Apply a bounded batch in a
single mutation; larger imports require explicit checkpoint/rollback semantics.

Run core and checker tests, current project's existing reservation/supplier/response-
link tests, new backend integration tests, typecheck and build. Test in staging with
synthetic contracts only. Retain fresh export before deployment. Deploy additive
schema while disabled, verify UI and hooks, then let manager configure actual stock.
Rollback is to stop new consumption and revert code only when existing allocations
are accounted for. Never drop populated allotment tables to roll back.
