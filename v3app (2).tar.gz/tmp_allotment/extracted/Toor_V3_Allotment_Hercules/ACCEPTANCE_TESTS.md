# Hercules integration acceptance — must run before enabling real inventory

| Test | Expected result |
|---|---|
| Existing V3 data without allotment fields | Loads and books using existing on-request flow |
| Create disabled pool, no contract quantity | No sellable availability is invented |
| Agent attempts pool/capacity edit | Server rejects |
| Agent accesses another agent's restricted booking | Existing authorization rejects |
| Cross-supplier product/room/pool IDs | Server rejects |
| Multiple categories at one supplier | Each resource uses its own category and unit |
| Two simultaneous last-unit confirmations | Exactly one succeeds; other receives conflict |
| Three-night hotel stay; middle night full | Entire reservation/allocation transaction rolls back |
| Check-out date | No stock consumed on check-out night |
| Hold → confirmation retry | One reservation allocation, no double deduction |
| Duplicate reservation create request | Original ID returned, no second reservation/debit |
| Idempotency key reused for different request | Rejected |
| Expired option before cleanup runs | Capacity correct immediately; confirmation reacquires |
| Non-replenishing hold expiry/cancellation | Returned units retired exactly once |
| Option expiry beyond release | Rejected |
| Release boundary and stop-sale | New/increased consumption blocked; confirmed stock retained |
| Confirm valid held stock under stop-sale | Allowed without additional consumption |
| Pending change request | Existing stock unchanged |
| Staff-approved change with insufficient stock | Request remains pending; reservation and stock unchanged |
| Supplier-link approved change/cancellation | Same reconciliation and financial-lock controls |
| Cancellation retried | No duplicate release |
| Changing quantity, dates or departure | Old/new stock reconciled in one transaction |
| Capacity reduction below commitments | Rejected |
| Supplier/product/room/slot deletion with allocations | Rejected or explicit safe archival flow |
| Pool disabled with existing commitments | New sales blocked, historical allocations preserved |
| Query above bounded allocation limit | Fails closed; never reports inflated availability |
| Two departures on one date | Separate stock; correct service ID |
| Seats versus vehicle units | Quantity conversion cannot be implicit |
| Date/time around DST | Correct explicit offset and release boundary |
| Language switch | Labels change; IDs, amounts and stored dates do not |
| Malformed batch JSON / duplicate keys / missing table | No output import and no source changes |
| Multi-tenant current project, if present | Cross-tenant reads and writes blocked at server |
| Cleanup retry and deployment retry | No double retirement or double debit |
| Existing reservation, supplier and finance regressions | Existing test suites pass |

Local tests already run: 20 pure engine tests and 7 Python batch tests. This checklist
is for Hercules integration verification; it is not a claim those app tests ran here.
