# Toor V3 Allotment — Hercules upload package

Upload this ZIP to Hercules project chat as an attachment. Ask it to follow
START_HERE_HERCULES.md and complete INTEGRATION.md. Do not use database import.

This replaces the unsafe Python rewrite with a read-only snapshot checker and adds
real inventory calculation code. The package is an implementation handoff, not a
fully installed feature: Hercules still needs to connect the supplied server helper,
build management endpoints/UI and pass integration tests in the current project.

Contents:
- START_HERE_HERCULES.md: exact task for Hercules.
- INTEGRATION.md: verified V3 touchpoints, lifecycle rules and deployment criteria.
- code/: TypeScript inventory engine, additive Convex schema and storage adapter.
- batch/inspect_snapshot.py: safe replacement batch; never edits snapshot.
- review/latest/: actual review of the supplied latest snapshot; no invented stock.
- tests/: runnable local checks (Node 24 and Python 3.10+).
- ACCEPTANCE_TESTS.md: application acceptance gates for Hercules.
- code/allotment.en.json: initial translation keys.

From this directory:
  node --experimental-strip-types --test tests/engine.test.mjs
  python tests/batch_test.py
  python batch/inspect_snapshot.py /path/to/snapshot.zip --out /path/to/new-review

Do not upload your entire data snapshot again unless Hercules needs it; this package
contains only relevant IDs in a review manifest, aggregate counts, code and instructions.
No personal contact records, credentials, source archive or production database restore
is included. No new contracted stock, migration or deployment has been performed.
