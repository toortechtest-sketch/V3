# Implement Toor V3 allotments from this package

Treat this ZIP as a CODE IMPLEMENTATION PACKAGE, not a Convex database restore.
Read every file, especially INTEGRATION.md, before editing the project. The original
Python rewrite batch is superseded. Do not run convex import on this ZIP or import
candidate_settings.REVIEW_ONLY.json into an existing table.

Implement the complete feature in the CURRENT Hercules project. Reuse the supplied
TypeScript inventory engine, additive schema and internal reconciliation helper.
Finish the server endpoints, UI, reservation integration, tests and validation in
INTEGRATION.md. Do not stop after adding settings fields or displaying an allotment
tab. Availability must be enforced in the same server transaction as each booking
change, including supplier response links.

Inspect the current source first. The reviewed source was app.tar(3).gz; the latest
snapshot is snapshot_1791109115093477719.zip. The latter is data, not source code.
Preserve newer changes, existing permissions, financial locks, translations,
supplier capabilities and supplier-approved change workflows. Resolve any source
mismatch by adapting these additions to current code, never by overwriting the app
with the older source. Do not replace existing tables, IDs or auth files.

No stock quantities, contracts, release dates or replenishment permissions have
been provided. Start with no enabled pools and no stock. Let an owner/global manager
enter contracted quantities and explicit release deadlines before activation.
Use product category, not just supplier category. Default overbooking OFF and keep
it unsupported in this first implementation. Do not create a Python runtime in the
web app: the Python file is only a read-only export checker.

Deliver working management and booking UI, required APIs, meaningful automated
tests, successful typecheck/build, and a short list of anything not completed. Do
not describe the module as live or production ready until the integration acceptance
criteria pass. Do not import historical reservations or turn on real stock silently.
