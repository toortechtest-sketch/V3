import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import {
  AlertTriangle,
  Banknote,
  CircleDollarSign,
  FileClock,
  Lock,
  Wallet,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { STAGE_META } from "@/lib/bookings.ts";
import { todayKey } from "@/lib/finance.ts";
import { formatMoney } from "@/lib/quotes.ts";
import { cn } from "@/lib/utils.ts";

type Scope = "active" | "closed";
type Filter = "all" | "overdue" | "outstanding" | "locked";

const FILTERS: { value: Filter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "overdue", label: "Overdue" },
  { value: "outstanding", label: "Money due" },
  { value: "locked", label: "Locked" },
];

const day = (d: string) => format(parseISO(d), "d MMM yyyy");

function Stat({
  icon: Icon,
  label,
  value,
  hint,
  tone,
}: {
  icon: typeof Wallet;
  label: string;
  value: string;
  hint?: string;
  tone?: "warn";
}) {
  return (
    <Card className="gap-1 px-4 py-4">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Icon className={cn("size-4", tone === "warn" ? "text-destructive" : "text-primary")} />
        {label}
      </div>
      <p
        className={cn(
          "font-display text-2xl font-semibold tabular-nums",
          tone === "warn" && "text-destructive",
        )}
      >
        {value}
      </p>
      {hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}
    </Card>
  );
}

function Overview({ scope }: { scope: Scope }) {
  const data = useQuery(api.financeOverview.overview, { scope, today: todayKey() });
  const [filter, setFilter] = useState<Filter>("all");

  if (data === undefined) {
    return (
      <div className="space-y-4">
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-16" />
        ))}
      </div>
    );
  }

  const { totals } = data;
  const rows = data.rows
    .filter((r) =>
      filter === "overdue"
        ? r.overdue > 0
        : filter === "outstanding"
          ? r.outstanding > 0
          : filter === "locked"
            ? r.locked
            : true,
    )
    // Most urgent first: overdue, then money due, then by departure.
    .sort(
      (a, b) =>
        b.overdue * b.rateToBase - a.overdue * a.rateToBase ||
        b.outstanding * b.rateToBase - a.outstanding * a.rateToBase ||
        a.startDate.localeCompare(b.startDate),
    );

  return (
    <div className="space-y-5">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          icon={CircleDollarSign}
          label="Package value"
          value={formatMoney(totals.contractValue, "EUR")}
          hint={`${data.rows.length} booking${data.rows.length === 1 ? "" : "s"}`}
        />
        <Stat icon={Wallet} label="Received" value={formatMoney(totals.received, "EUR")} />
        <Stat
          icon={Banknote}
          label="Money due"
          value={formatMoney(totals.outstanding, "EUR")}
          hint={`${formatMoney(totals.toInvoice, "EUR")} still to invoice`}
        />
        <Stat
          icon={AlertTriangle}
          label="Overdue"
          value={formatMoney(totals.overdue, "EUR")}
          hint={
            totals.overdueBookings
              ? `${totals.overdueBookings} booking${totals.overdueBookings === 1 ? "" : "s"}`
              : "Nothing late"
          }
          tone={totals.overdue > 0 ? "warn" : undefined}
        />
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="inline-flex gap-1 rounded-lg bg-muted p-1">
          {FILTERS.map((f) => (
            <button
              key={f.value}
              type="button"
              onClick={() => setFilter(f.value)}
              className={cn(
                "cursor-pointer rounded-md px-3 py-1 text-sm whitespace-nowrap text-muted-foreground transition-colors hover:text-foreground",
                filter === f.value && "bg-background text-foreground shadow-sm",
              )}
            >
              {f.label}
            </button>
          ))}
        </div>
        <p className="text-xs text-muted-foreground">
          {data.seesAll ? "All bookings" : "Your bookings only"} · totals in EUR
        </p>
      </div>

      {rows.length === 0 ? (
        <Empty className="border bg-card">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Banknote />
            </EmptyMedia>
            <EmptyTitle>
              {data.rows.length === 0 ? "No bookings here yet" : "Nothing matches this filter"}
            </EmptyTitle>
            <EmptyDescription>
              {scope === "active"
                ? "Live bookings appear here with their money position."
                : "Closed bookings appear here once a booking is moved to Closed."}
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <Card className="divide-y gap-0 py-0">
          {rows.map((r) => (
            <Link
              key={r.bookingId}
              to={`/bookings/${r.bookingId}?tab=finance`}
              className="flex cursor-pointer flex-col gap-3 px-4 py-3 transition-colors hover:bg-muted/50 md:flex-row md:items-center"
            >
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs text-muted-foreground">{r.reference}</span>
                  <Badge className={cn("border-0", STAGE_META[r.stage].badge)}>
                    {STAGE_META[r.stage].label}
                  </Badge>
                  {r.locked ? (
                    <Badge variant="secondary" className="gap-1">
                      <Lock className="size-3" /> Locked
                    </Badge>
                  ) : null}
                </div>
                <p className="truncate font-medium">{r.title}</p>
                <p className="truncate text-sm text-muted-foreground">
                  {r.clientName} · departs {day(r.startDate)}
                </p>
              </div>
              <dl className="grid grid-cols-3 gap-4 text-sm md:w-[26rem] md:text-right">
                <div>
                  <dt className="text-xs text-muted-foreground">Package</dt>
                  <dd className="tabular-nums">{formatMoney(r.contractValue, r.currency)}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">Received</dt>
                  <dd className="tabular-nums">{formatMoney(r.received, r.currency)}</dd>
                </div>
                <div>
                  <dt className="text-xs text-muted-foreground">
                    {r.overdue > 0 ? "Overdue" : "Due"}
                  </dt>
                  <dd
                    className={cn(
                      "tabular-nums",
                      r.overdue > 0 && "font-medium text-destructive",
                    )}
                  >
                    {formatMoney(r.overdue > 0 ? r.overdue : Math.max(0, r.outstanding), r.currency)}
                  </dd>
                  {r.overdue <= 0 && r.nextDue ? (
                    <dd className="flex items-center gap-1 text-xs text-muted-foreground md:justify-end">
                      <FileClock className="size-3" /> {day(r.nextDue.date)}
                    </dd>
                  ) : null}
                </div>
              </dl>
            </Link>
          ))}
        </Card>
      )}
      {data.truncated ? (
        <p className="text-center text-xs text-muted-foreground">
          Showing the most recent bookings in each stage.
        </p>
      ) : null}
    </div>
  );
}

export default function BookingFinancePage() {
  const [scope, setScope] = useState<Scope>("active");
  return (
    <PageContainer>
      <PageHeader
        title="Booking finance"
        description="What each booking is worth, what's been paid, and what's due or late. Open a booking to invoice or record a payment."
      />
      <Tabs value={scope} onValueChange={(v) => setScope(v as Scope)}>
        <TabsList>
          <TabsTrigger value="active" className="cursor-pointer">Active bookings</TabsTrigger>
          <TabsTrigger value="closed" className="cursor-pointer">Closed</TabsTrigger>
        </TabsList>
      </Tabs>
      <Overview key={scope} scope={scope} />
    </PageContainer>
  );
}
