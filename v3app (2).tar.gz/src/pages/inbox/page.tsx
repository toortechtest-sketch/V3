import { useEffect, useRef, useState } from "react";
import { useAction, useQuery } from "convex/react";
import { Mail, Settings2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet.tsx";
import { cn } from "@/lib/utils.ts";
import { ConnectCard, ConnectionHealth, SetupRequired } from "./_components/connection.tsx";
import { FolderNav, ThreadList } from "./_components/thread-list.tsx";
import ThreadReader from "./_components/thread-reader.tsx";
import ComposeDialog, { type ComposeDraft } from "./_components/compose-dialog.tsx";
import { consumePendingOAuthReturn, type OAuthReturn } from "./_lib/oauth-return.ts";
import { type Folder, useInvalidateMail } from "./_lib/use-mail.ts";

const OAUTH_ERRORS: Record<string, string> = {
  invalid: "That connection link was malformed. Connect again.",
  cancelled: "Gmail connection cancelled. Nothing was connected.",
  partial_consent: "Gmail permission wasn't granted, so nothing was connected. Tick the Gmail box on Google's screen.",
  identity_invalid: "Google didn't confirm a verified email for that account.",
  no_refresh_token: "Google didn't grant ongoing access. Try connecting again.",
  exchange_failed: "Google rejected the connection. Check the redirect URI in Google Cloud and try again.",
  not_configured: "Gmail isn't set up on the server yet.",
  google_error: "Google returned an error. Try again.",
};

/** Finishes the Google redirect once, using the result captured at startup. */
function useOAuthReturn() {
  const complete = useAction(api.gmail.oauth.completeConnect);
  const [result] = useState<OAuthReturn>(consumePendingOAuthReturn);
  const handled = useRef(false);
  const [finishing, setFinishing] = useState(result?.kind === "complete");

  // Effect: a one-time call to the backend triggered by arriving from Google.
  useEffect(() => {
    if (handled.current || !result) return;
    handled.current = true;
    if (result.kind === "error") {
      toast.error(OAUTH_ERRORS[result.reason] ?? "Gmail connection failed.");
      return;
    }
    complete({ completion: result.completion })
      .then((r) => {
        if (r.ok) toast.success(`Connected ${r.googleEmail}`);
        else if (r.reason === "other_user")
          toast.error("You started connecting while signed in as someone else. Sign in with that account and connect again.");
        else toast.error("This connection link expired or was already used. Connect again.");
      })
      .catch(() => toast.error("Could not finish connecting Gmail."))
      .finally(() => setFinishing(false));
  }, [result, complete]);
  return finishing;
}

const EMPTY_DRAFT: ComposeDraft = { mode: "new", to: [], cc: [], subject: "", text: "" };

function Mailbox({ fromAddress }: { fromAddress: string }) {
  const [folder, setFolder] = useState<Folder>("inbox");
  const [threadId, setThreadId] = useState<string | null>(null);
  const [draft, setDraft] = useState<ComposeDraft | null>(null);
  // Key forces a fresh compose session (new duplicate-protection id) each time.
  const [draftKey, setDraftKey] = useState(0);
  const compose = (d: ComposeDraft) => {
    setDraftKey((k) => k + 1);
    setDraft(d);
  };

  return (
    <div className="grid gap-4 md:grid-cols-[170px_minmax(0,1fr)]">
      <FolderNav
        folder={folder}
        onChange={(f) => {
          setFolder(f);
          setThreadId(null);
        }}
        onCompose={() => compose(EMPTY_DRAFT)}
      />
      <div className="grid h-[calc(100dvh-13rem)] min-h-[480px] overflow-hidden rounded-xl border bg-card lg:grid-cols-[minmax(280px,360px)_minmax(0,1fr)]">
        <div className={cn("min-h-0 border-r", threadId && "hidden lg:block")}>
          <ThreadList key={folder} folder={folder} selected={threadId} onSelect={setThreadId} />
        </div>
        <div className={cn("min-h-0", !threadId && "hidden lg:block")}>
          {threadId ? (
            <ThreadReader key={threadId} threadId={threadId} onBack={() => setThreadId(null)} onCompose={compose} />
          ) : (
            <Empty className="h-full">
              <EmptyHeader>
                <EmptyMedia variant="icon"><Mail /></EmptyMedia>
                <EmptyTitle>Select a conversation</EmptyTitle>
                <EmptyDescription>Mail is read live from your Gmail and is never shared with teammates.</EmptyDescription>
              </EmptyHeader>
            </Empty>
          )}
        </div>
      </div>
      {draft && (
        <ComposeDialog key={draftKey} draft={draft} fromAddress={fromAddress} onClose={() => setDraft(null)} />
      )}
    </div>
  );
}

export default function InboxPage() {
  const finishing = useOAuthReturn();
  const status = useQuery(api.gmail.store.status, {});
  const invalidate = useInvalidateMail();
  const [settingsOpen, setSettingsOpen] = useState(false);

  if (status === undefined || finishing)
    return (
      <PageContainer>
        <Skeleton className="h-10 w-48" />
        {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
      </PageContainer>
    );

  const conn = status.connection;
  const ready = status.configured && conn?.status === "active";

  const body = !status.configured ? (
    <SetupRequired status={status} />
  ) : !conn ? (
    <ConnectCard status={status} />
  ) : !ready ? (
    <div className="max-w-2xl">
      <ConnectionHealth status={status} onDisconnected={() => void invalidate()} />
    </div>
  ) : (
    <Mailbox fromAddress={conn.googleEmail} />
  );

  return (
    <PageContainer className="max-w-7xl">
      <PageHeader
        title="Inbox"
        description={ready ? conn.googleEmail : "Your own Gmail inside Toor. Private to you."}
        actions={
          conn ? (
            <Button variant="secondary" size="sm" className="cursor-pointer" onClick={() => setSettingsOpen(true)}>
              <Settings2 className="size-4" /> Connection
            </Button>
          ) : null
        }
      />
      {body}
      <Sheet open={settingsOpen} onOpenChange={setSettingsOpen}>
        <SheetContent className="w-full overflow-y-auto sm:max-w-md">
          <SheetHeader>
            <SheetTitle>Email connection</SheetTitle>
          </SheetHeader>
          <div className="px-4 pb-6">
            <ConnectionHealth
              status={status}
              onDisconnected={() => {
                setSettingsOpen(false);
                void invalidate();
              }}
            />
          </div>
        </SheetContent>
      </Sheet>
    </PageContainer>
  );
}
