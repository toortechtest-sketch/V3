import { useAction } from "convex/react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/convex/_generated/api.js";

export type Folder = "inbox" | "starred" | "sent" | "all" | "trash";

/** Mail is read live from Gmail through actions, cached briefly per page. */
export function useThreadList(folder: Folder, query: string, pageToken: string | undefined) {
  const list = useAction(api.gmail.mailbox.listThreads);
  return useQuery({
    queryKey: ["gmail", "threads", folder, query, pageToken ?? ""],
    queryFn: () => list({ folder, query: query || undefined, pageToken }),
    staleTime: 30_000,
    retry: false,
  });
}

export function useThread(threadId: string) {
  const get = useAction(api.gmail.mailbox.getThread);
  return useQuery({
    queryKey: ["gmail", "thread", threadId],
    queryFn: () => get({ threadId }),
    staleTime: 30_000,
    retry: false,
  });
}

export function useInvalidateMail() {
  const qc = useQueryClient();
  return () => qc.invalidateQueries({ queryKey: ["gmail"] });
}

export const senderName = (from: string) =>
  from.replace(/<[^>]+>/, "").replace(/"/g, "").trim() || from;
