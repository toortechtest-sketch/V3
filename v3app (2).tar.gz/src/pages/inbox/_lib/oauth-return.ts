/**
 * Google returns the one-time completion secret in the URL fragment (never
 * the query string), so it isn't sent to servers or leaked through Referer.
 */
export type OAuthReturn =
  | { kind: "complete"; completion: string }
  | { kind: "error"; reason: string }
  | null;

const COMPLETION_RE = /^[A-Za-z0-9_-]{20,100}$/;
const REASON_RE = /^[a-z_]{1,40}$/;
const PENDING_KEY = "toor.gmailOAuthReturn";

/** Parses a location hash like `#gmail_complete=...` or `#gmail_error=...`. */
export function parseOAuthReturn(hash: string): OAuthReturn {
  const params = new URLSearchParams(hash.replace(/^#/, ""));
  const completion = params.get("gmail_complete");
  if (completion !== null)
    return COMPLETION_RE.test(completion)
      ? { kind: "complete", completion }
      : { kind: "error", reason: "invalid" };
  const reason = params.get("gmail_error");
  if (reason !== null)
    return { kind: "error", reason: REASON_RE.test(reason) ? reason : "google_error" };
  return null;
}

/**
 * Called once before the app renders. Google returns in a fresh tab that may
 * still need to sign in, so the result is moved from the address bar into
 * this tab's sessionStorage, where it survives the sign-in redirect. The
 * backend still requires the same staff member who clicked Connect.
 */
export function capturePendingOAuthReturn(): void {
  try {
    const result = parseOAuthReturn(window.location.hash);
    if (!result) return;
    window.sessionStorage.setItem(PENDING_KEY, window.location.hash);
    const { pathname, search } = window.location;
    window.history.replaceState(window.history.state, "", `${pathname}${search}`);
  } catch {
    // Storage unavailable: the user can simply connect again.
  }
}

/** Returns and clears the captured result (single use). */
export function consumePendingOAuthReturn(): OAuthReturn {
  try {
    const hash = window.sessionStorage.getItem(PENDING_KEY);
    if (!hash) return null;
    window.sessionStorage.removeItem(PENDING_KEY);
    return parseOAuthReturn(hash);
  } catch {
    return null;
  }
}
