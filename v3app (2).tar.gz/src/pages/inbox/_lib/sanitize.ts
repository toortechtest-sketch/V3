import DOMPurify from "dompurify";

const FORBID_TAGS = [
  "style", "script", "iframe", "object", "embed", "form", "input", "button",
  "link", "meta", "base", "svg", "math",
];

/**
 * Prepares untrusted email HTML for a sandboxed iframe (no scripts, no
 * same-origin). Remote images are stripped unless the reader allows them, and
 * a CSP blocks any remaining remote loads such as tracking pixels.
 */
export function sanitizeEmailHtml(
  html: string,
  allowRemoteImages: boolean,
): { html: string; blockedImages: number } {
  let blocked = 0;
  const purify = DOMPurify();
  purify.addHook("afterSanitizeAttributes", (node) => {
    if (node.tagName === "A") {
      node.setAttribute("target", "_blank");
      node.setAttribute("rel", "noopener noreferrer nofollow");
    }
    if (node.tagName === "IMG") {
      const src = node.getAttribute("src") ?? "";
      if (/^(https?:)?\/\//i.test(src) && !allowRemoteImages) {
        node.removeAttribute("src");
        node.setAttribute("alt", node.getAttribute("alt") || "[image blocked]");
        blocked++;
      }
    }
  });
  const clean = purify.sanitize(html, {
    FORBID_TAGS,
    FORBID_ATTR: ["style", "srcset", "background", "formaction", "ping"],
    ALLOW_DATA_ATTR: false,
  });
  return { html: clean, blockedImages: blocked };
}

export function emailFrameDocument(cleanHtml: string, allowRemoteImages: boolean, dark: boolean): string {
  const img = allowRemoteImages ? "https: data:" : "data:";
  const csp = `default-src 'none'; img-src ${img}; style-src 'unsafe-inline'; font-src 'none'; connect-src 'none'; form-action 'none'`;
  const fg = dark ? "#f2f5f9" : "#0b1b2b";
  const link = dark ? "#00bdeb" : "#0754ea";
  return `<!doctype html><html><head><meta charset="utf-8"><meta http-equiv="Content-Security-Policy" content="${csp}"><meta name="referrer" content="no-referrer"><style>body{margin:0;font:14px/1.55 system-ui,sans-serif;color:${fg};background:transparent;word-wrap:break-word}img{max-width:100%;height:auto}a{color:${link}}table{max-width:100%}blockquote{border-left:3px solid #8884;margin:0;padding-left:12px}</style></head><body>${cleanHtml}</body></html>`;
}
