import { useState } from "react";
import { useAction } from "convex/react";
import { formatDistanceToNow, parseISO } from "date-fns";
import {
  AlertTriangle,
  CheckCircle2,
  Copy,
  KeyRound,
  PlugZap,
  Unplug,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { GmailStatus } from "@/convex/gmail/store.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { errorMessage } from "@/lib/errors.ts";

function CopyLine({ value }: { value: string }) {
  return (
    <div className="flex items-center gap-2 rounded-md border bg-muted/50 px-3 py-2 font-mono text-xs">
      <span className="min-w-0 flex-1 break-all">{value}</span>
      <Button
        size="icon"
        variant="ghost"
        className="size-7 shrink-0 cursor-pointer"
        aria-label="Copy"
        onClick={() =>
          void navigator.clipboard.writeText(value).then(() => toast.success("Copied"))
        }
      >
        <Copy className="size-3.5" />
      </Button>
    </div>
  );
}

const Mono = ({ children }: { children: string }) => (
  <span className="font-mono text-foreground">{children}</span>
);

/** Step-by-step Google Cloud setup, shown while secrets are missing. */
export function SetupRequired({ status }: { status: GmailStatus }) {
  const origin = window.location.origin;
  const steps = [
    <>In Google Cloud Console, create (or pick) a project and enable the <b className="text-foreground">Gmail API</b>.</>,
    <>Google Auth Platform → Audience: choose <b className="text-foreground">External</b>, keep it in <b className="text-foreground">Testing</b>, and add each staff member's Gmail address under Test users. Test access expires every 7 days, so people reconnect weekly until the app is verified by Google.</>,
    <>Data access: add the scopes <Mono>openid</Mono>, <Mono>.../auth/userinfo.email</Mono> and <Mono>.../auth/gmail.modify</Mono>.</>,
    <>Clients → Create client → <b className="text-foreground">Web application</b>. Add this exact Authorized redirect URI:<div className="pt-2"><CopyLine value={status.callbackUri} /></div></>,
    <>Save the client ID as <Mono>GOOGLE_GMAIL_CLIENT_ID</Mono> and the client secret as <Mono>GOOGLE_GMAIL_CLIENT_SECRET</Mono>.</>,
    <>Create <Mono>GMAIL_TOKEN_ENCRYPTION_KEY</Mono>: 32 random bytes, base64 encoded (for example the output of <Mono>openssl rand -base64 32</Mono>). Keep it stable: changing it disconnects everyone.</>,
    <>Create <Mono>GMAIL_ALLOWED_APP_ORIGINS</Mono> with this app's exact address (comma separate several, no trailing slash, no wildcards). This page's address:<div className="pt-2"><CopyLine value={origin} /></div></>,
  ];
  return (
    <Card className="border-chart-3/60">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-display text-lg">
          <KeyRound className="size-5 text-chart-3" /> Gmail setup required
        </CardTitle>
        <CardDescription>
          The inbox is built, but an owner needs to add Google credentials before anyone can connect. Nobody's mail is read until they connect their own account.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-5 text-sm">
        <div className="space-y-2">
          <p className="font-medium">Missing secrets (Advanced → Secrets)</p>
          <div className="flex flex-wrap gap-2">
            {status.missingSecrets.map((s) => (
              <Badge key={s} variant="secondary" className="font-mono">{s}</Badge>
            ))}
          </div>
        </div>
        <ol className="list-decimal space-y-3 pl-5 text-muted-foreground">
          {steps.map((step, i) => <li key={i}>{step}</li>)}
        </ol>
      </CardContent>
    </Card>
  );
}

function useConnectGmail() {
  const start = useAction(api.gmail.oauth.startConnect);
  const [busy, setBusy] = useState(false);
  const connect = async () => {
    setBusy(true);
    try {
      const { url } = await start({ returnOrigin: window.location.origin });
      // Google's consent screen refuses to render in iframes, so open top-level.
      const opened = window.open(url, "_blank", "noopener");
      if (!opened) window.location.href = url;
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };
  return { connect, busy };
}

const PROMISES = [
  "Works with personal @gmail.com and Google Workspace accounts",
  "Read, label and send mail. No permanent delete",
  "Private to you. Managers can't open your mailbox",
  "Disconnect any time; access is revoked at Google",
];

export function ConnectCard({ status }: { status: GmailStatus }) {
  const { connect, busy } = useConnectGmail();
  const originAllowed = status.allowedOrigins.includes(window.location.origin);
  return (
    <Card className="max-w-2xl gap-0 overflow-hidden py-0">
      <div className="bg-sidebar px-6 py-8 text-sidebar-foreground">
        <p className="font-mono text-[11px] tracking-widest text-sidebar-primary uppercase">Inbox</p>
        <h2 className="pt-2 font-display text-2xl font-semibold text-white">Connect your Gmail</h2>
        <p className="max-w-lg pt-2 text-sm text-sidebar-foreground/70">
          Read, search and reply to your own mail without leaving Toor. You pick the Google account and approve access on Google's own screen.
        </p>
      </div>
      <CardContent className="space-y-4 py-6">
        <ul className="space-y-2 text-sm text-muted-foreground">
          {PROMISES.map((p) => (
            <li key={p} className="flex gap-2">
              <CheckCircle2 className="size-4 shrink-0 text-primary" /> {p}
            </li>
          ))}
        </ul>
        {!originAllowed && (
          <div className="space-y-2 rounded-md border border-chart-3/60 bg-chart-3/10 p-3 text-sm">
            <p className="font-medium">This address isn't allowed to connect Gmail yet.</p>
            <p className="text-xs text-muted-foreground">
              An owner must add it exactly to the <span className="font-mono">GMAIL_ALLOWED_APP_ORIGINS</span> secret.
            </p>
            <CopyLine value={window.location.origin} />
          </div>
        )}
        <Button className="cursor-pointer" onClick={() => void connect()} disabled={busy || !originAllowed}>
          {busy ? <Spinner /> : <PlugZap className="size-4" />} Connect Gmail
        </Button>
        <p className="text-xs text-muted-foreground">
          Google opens in a new tab. After approving, you'll land back here to finish.
        </p>
      </CardContent>
    </Card>
  );
}

export function ConnectionHealth({
  status,
  onDisconnected,
}: {
  status: GmailStatus;
  onDisconnected: () => void;
}) {
  const disconnect = useAction(api.gmail.oauth.disconnect);
  const { connect, busy: reconnecting } = useConnectGmail();
  const [busy, setBusy] = useState(false);
  const c = status.connection;
  if (!c) return null;
  const healthy = c.status === "active" && c.hasMailboxScope;

  const run = async () => {
    setBusy(true);
    try {
      const { revoked } = await disconnect({});
      toast.success(
        revoked
          ? "Gmail disconnected and access revoked"
          : "Gmail disconnected. You can also remove access at myaccount.google.com/permissions.",
      );
      onDisconnected();
    } catch (e) {
      toast.error(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-display text-base">
          {healthy ? (
            <CheckCircle2 className="size-4 text-primary" />
          ) : (
            <AlertTriangle className="size-4 text-chart-4" />
          )}
          Gmail connection
        </CardTitle>
        <CardDescription className="break-all">{c.googleEmail}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3 text-sm">
        <div className="flex flex-wrap gap-2">
          <Badge variant={healthy ? "secondary" : "destructive"}>
            {healthy ? "Healthy" : "Needs reconnect"}
          </Badge>
          <Badge variant="secondary">
            Connected {formatDistanceToNow(parseISO(c.connectedAt), { addSuffix: true })}
          </Badge>
          {c.lastUsedAt && (
            <Badge variant="secondary">
              Last used {formatDistanceToNow(parseISO(c.lastUsedAt), { addSuffix: true })}
            </Badge>
          )}
        </div>
        {c.lastError && <p className="text-xs text-muted-foreground">Last issue: {c.lastError}</p>}
        <div className="flex flex-wrap gap-2">
          <Button size="sm" variant="secondary" className="cursor-pointer" onClick={() => void connect()} disabled={reconnecting}>
            {reconnecting ? <Spinner /> : <PlugZap className="size-4" />} Reconnect
          </Button>
          <Button size="sm" variant="ghost" className="cursor-pointer text-destructive" onClick={() => void run()} disabled={busy}>
            {busy ? <Spinner /> : <Unplug className="size-4" />} Disconnect
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
