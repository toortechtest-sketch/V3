import { useMemo, useState } from "react";
import { useAction } from "convex/react";
import { format, parseISO } from "date-fns";
import { useTheme } from "next-themes";
import {
  Archive,
  ArrowLeft,
  ExternalLink,
  Forward,
  ImageOff,
  Inbox,
  MailOpen,
  Paperclip,
  Reply,
  ReplyAll,
  Star,
  Trash2,
  Undo2,
  type LucideIcon,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { ThreadMessage } from "@/convex/gmail/mailbox.ts";
import {
  forwardQuote,
  forwardSubject,
  replyRecipients,
  replySubject,
} from "@/convex/gmail/mime.ts";
import { Button } from "@/components/ui/button.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip.tsx";
import {
  ErrorState,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { emailFrameDocument, sanitizeEmailHtml } from "../_lib/sanitize.ts";
import { useInvalidateMail, useThread } from "../_lib/use-mail.ts";
import type { ComposeDraft } from "./compose-dialog.tsx";

const fileSize = (n: number) =>
  n > 1024 * 1024 ? `${(n / 1024 / 1024).toFixed(1)} MB` : `${Math.max(1, Math.round(n / 1024))} KB`;
const stamp = (date: string | null) => (date ? format(parseISO(date), "d MMM yyyy, HH:mm") : "");

function HtmlBody({ html }: { html: string }) {
  const [allow, setAllow] = useState(false);
  const { resolvedTheme } = useTheme();
  const { html: clean, blockedImages } = useMemo(() => sanitizeEmailHtml(html, allow), [html, allow]);
  const doc = emailFrameDocument(clean, allow, resolvedTheme === "dark");
  return (
    <div className="space-y-2">
      {blockedImages > 0 && !allow && (
        <div className="flex flex-wrap items-center gap-2 rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">
          <ImageOff className="size-3.5" /> {blockedImages} remote image{blockedImages > 1 ? "s" : ""} blocked to protect your privacy.
          <button type="button" className="cursor-pointer font-medium text-foreground underline-offset-2 hover:underline" onClick={() => setAllow(true)}>
            Show images
          </button>
        </div>
      )}
      {/* No allow-scripts / allow-same-origin: the email can't run code or read the app. */}
      <iframe
        title="Email content"
        sandbox="allow-popups allow-popups-to-escape-sandbox"
        srcDoc={doc}
        className="h-[55vh] min-h-64 w-full resize-y rounded-md border-0"
      />
    </div>
  );
}

function MessageCard({ m, defaultOpen }: { m: ThreadMessage; defaultOpen: boolean }) {
  const [open, setOpen] = useState(defaultOpen);
  const [plain, setPlain] = useState(false);
  return (
    <article className="rounded-lg border bg-card">
      <button
        type="button"
        onClick={() => setOpen((o) => !o)}
        className="flex w-full cursor-pointer flex-wrap items-start justify-between gap-2 p-4 text-left"
      >
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold">{m.from}</p>
          <p className="truncate text-xs text-muted-foreground">
            to {m.to}
            {m.cc && `, cc ${m.cc}`}
          </p>
        </div>
        <span className="shrink-0 font-mono text-xs text-muted-foreground">{stamp(m.date)}</span>
      </button>
      {open && (
        <div className="space-y-3 px-4 pb-4">
          {m.html && m.text && (
            <button type="button" className="cursor-pointer text-xs text-muted-foreground underline-offset-2 hover:underline" onClick={() => setPlain((p) => !p)}>
              {plain ? "Show formatted" : "Show plain text"}
            </button>
          )}
          {m.html && !plain ? (
            <HtmlBody html={m.html} />
          ) : (
            <pre className="font-sans text-sm break-words whitespace-pre-wrap">{m.text ?? "(No readable content)"}</pre>
          )}
          {m.attachments.length > 0 && (
            <div className="flex flex-wrap gap-2 border-t pt-3">
              {m.attachments.map((a, i) => (
                <Button key={`${a.filename}-${i}`} asChild size="sm" variant="secondary" className="h-7 max-w-full cursor-pointer gap-1 text-xs">
                  <a href={m.gmailUrl} target="_blank" rel="noopener noreferrer" title="Opens in Gmail">
                    <Paperclip className="size-3" />
                    <span className="truncate">{a.filename} · {fileSize(a.size)}</span>
                    <ExternalLink className="size-3" />
                  </a>
                </Button>
              ))}
            </div>
          )}
        </div>
      )}
    </article>
  );
}

type ThreadOp = "unread" | "archive" | "unarchive" | "trash" | "untrash" | "star" | "unstar";

export default function ThreadReader({
  threadId,
  onBack,
  onCompose,
}: {
  threadId: string;
  onBack: () => void;
  onCompose: (d: ComposeDraft) => void;
}) {
  const thread = useThread(threadId);
  const modify = useAction(api.gmail.mailbox.modifyThread);
  const invalidate = useInvalidateMail();

  const act = async (op: ThreadOp, doneMessage: string, leave = false) => {
    try {
      await modify({ threadId, op });
      toast.success(doneMessage);
      void invalidate();
      if (leave) onBack();
    } catch (e) {
      toast.error(errorMessage(e));
    }
  };

  if (thread.isPending)
    return (
      <div className="space-y-3 p-4">
        <Skeleton className="h-8 w-2/3" />
        {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-28 w-full" />)}
      </div>
    );
  if (thread.isError)
    return (
      <ErrorState className="m-4">
        <ErrorStateHeader>
          <ErrorStateTitle>Couldn't open this conversation</ErrorStateTitle>
          <ErrorStateDescription>{errorMessage(thread.error)}</ErrorStateDescription>
        </ErrorStateHeader>
      </ErrorState>
    );

  const t = thread.data;
  const last = t.messages[t.messages.length - 1];
  const subject = t.messages[0]?.subject || "(no subject)";
  const inInbox = t.labels.includes("INBOX");
  const inTrash = t.labels.includes("TRASH");
  const starred = t.labels.includes("STARRED");

  const reply = (all: boolean) => {
    if (!last) return;
    const r = replyRecipients({ from: last.from, replyTo: last.replyTo, to: last.to, cc: last.cc }, t.ownAddress, all);
    const quoted = (last.text ?? "").split("\n").map((l) => `> ${l}`).join("\n");
    onCompose({
      mode: "reply",
      to: r.to,
      cc: r.cc,
      subject: replySubject(last.subject || subject),
      text: `\n\nOn ${stamp(last.date)}, ${last.from} wrote:\n${quoted}`,
      replyToMessageId: last.id,
    });
  };
  const forward = () => {
    if (!last) return;
    onCompose({
      mode: "forward",
      to: [],
      cc: [],
      subject: forwardSubject(last.subject || subject),
      text: forwardQuote({ from: last.from, date: last.date ?? undefined, subject: last.subject, to: last.to, text: last.text ?? "" }),
    });
  };

  const tool = (label: string, Icon: LucideIcon, onClick: () => void) => (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button size="icon" variant="ghost" className="size-9 cursor-pointer" aria-label={label} onClick={onClick}>
          <Icon className="size-4" />
        </Button>
      </TooltipTrigger>
      <TooltipContent>{label}</TooltipContent>
    </Tooltip>
  );

  return (
    <div className="flex h-full flex-col">
      <div className="flex flex-wrap items-center gap-1 border-b px-2 py-1.5">
        <Button size="icon" variant="ghost" className="size-9 cursor-pointer lg:hidden" aria-label="Back" onClick={onBack}>
          <ArrowLeft className="size-4" />
        </Button>
        {inTrash
          ? tool("Restore from trash", Undo2, () => void act("untrash", "Restored", true))
          : inInbox
            ? tool("Archive", Archive, () => void act("archive", "Archived", true))
            : tool("Move to inbox", Inbox, () => void act("unarchive", "Moved to inbox"))}
        {!inTrash && tool("Move to trash", Trash2, () => void act("trash", "Moved to trash", true))}
        {tool("Mark as unread", MailOpen, () => void act("unread", "Marked unread", true))}
        {tool(starred ? "Unstar" : "Star", Star, () => void act(starred ? "unstar" : "star", starred ? "Unstarred" : "Starred"))}
      </div>
      <div className="flex-1 space-y-3 overflow-y-auto p-4">
        <h2 className="font-display text-xl font-semibold break-words">{subject}</h2>
        {t.truncated && (
          <p className="text-xs text-muted-foreground">
            Showing the latest {t.messages.length} messages. Open in Gmail for the full history.
          </p>
        )}
        {t.messages.map((m, i) => (
          <MessageCard key={m.id} m={m} defaultOpen={i === t.messages.length - 1 || m.unread} />
        ))}
        <div className="flex flex-wrap gap-2 pt-2">
          <Button variant="secondary" className="cursor-pointer" onClick={() => reply(false)}><Reply className="size-4" /> Reply</Button>
          <Button variant="secondary" className="cursor-pointer" onClick={() => reply(true)}><ReplyAll className="size-4" /> Reply all</Button>
          <Button variant="secondary" className="cursor-pointer" onClick={forward}><Forward className="size-4" /> Forward</Button>
        </div>
      </div>
    </div>
  );
}
