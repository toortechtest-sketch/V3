import { useState } from "react";
import { useAction } from "convex/react";
import { ConvexError } from "convex/values";
import { AlertTriangle, Send } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import { splitAddressList, type ComposeMode } from "@/convex/gmail/mime.ts";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { useInvalidateMail } from "../_lib/use-mail.ts";

export type ComposeDraft = {
  mode: ComposeMode;
  to: string[];
  cc: string[];
  subject: string;
  text: string;
  replyToMessageId?: string;
};

type Phase = "editing" | "sending" | "uncertain" | "checking";

const TITLES: Record<ComposeMode, string> = {
  new: "New message",
  reply: "Reply",
  forward: "Forward",
};

export default function ComposeDialog({
  draft,
  fromAddress,
  onClose,
}: {
  draft: ComposeDraft;
  fromAddress: string;
  onClose: () => void;
}) {
  const send = useAction(api.gmail.mailbox.send);
  const check = useAction(api.gmail.mailbox.checkSend);
  const invalidate = useInvalidateMail();
  // One id per compose window: retries reuse it so the server de-duplicates.
  const [requestId] = useState(() => crypto.randomUUID());
  const [to, setTo] = useState(draft.to.join(", "));
  const [cc, setCc] = useState(draft.cc.join(", "));
  const [bcc, setBcc] = useState("");
  const [showCc, setShowCc] = useState(draft.cc.length > 0);
  const [subject, setSubject] = useState(draft.subject);
  const [text, setText] = useState(draft.text);
  const [phase, setPhase] = useState<Phase>("editing");
  const locked = phase !== "editing";
  const uncertain = phase === "uncertain" || phase === "checking";

  const done = (message: string) => {
    toast.success(message);
    void invalidate();
    onClose();
  };

  const doSend = async () => {
    setPhase("sending");
    try {
      const r = await send({
        requestId,
        mode: draft.mode,
        to: splitAddressList(to),
        cc: splitAddressList(cc),
        bcc: splitAddressList(bcc),
        subject,
        text,
        replyToMessageId: draft.replyToMessageId,
      });
      if (r.status === "sent" || (r.status === "duplicate" && r.previous === "sent"))
        return done("Sent. It's in your Gmail Sent folder.");
      if (r.status === "failed") {
        toast.error(r.message);
        setPhase("editing");
        return;
      }
      setPhase("uncertain");
    } catch (e) {
      // Validation/auth errors are thrown before Gmail is called, so nothing
      // was sent. Anything else (network drop) is uncertain.
      if (e instanceof ConvexError) {
        toast.error(errorMessage(e));
        setPhase("editing");
      } else {
        toast.error("Connection problem while sending.");
        setPhase("uncertain");
      }
    }
  };

  const doCheck = async () => {
    setPhase("checking");
    try {
      const r = await check({ requestId });
      if (r.status === "sent") return done("Confirmed: the message is in your Sent folder.");
      if (r.status === "failed" || r.status === "unknown") {
        toast.info("Gmail confirmed this message was not sent. You can try again.");
        setPhase("editing");
        return;
      }
      toast.info("Not in Sent yet. Gmail can take a moment; check again shortly.");
    } catch (e) {
      toast.error(errorMessage(e));
    }
    setPhase("uncertain");
  };

  const busy = phase === "sending" || phase === "checking";

  return (
    <Dialog open onOpenChange={(o) => !o && !busy && onClose()}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display">{TITLES[draft.mode]}</DialogTitle>
          <DialogDescription className="break-all">From {fromAddress}</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label htmlFor="mail-to">To</Label>
              {!showCc && (
                <button type="button" className="cursor-pointer text-xs text-muted-foreground hover:text-foreground" onClick={() => setShowCc(true)}>
                  Cc / Bcc
                </button>
              )}
            </div>
            <Input id="mail-to" disabled={locked} placeholder="client@example.com, hotel@example.com" value={to} onChange={(e) => setTo(e.target.value)} />
          </div>
          {showCc && (
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <Label htmlFor="mail-cc">Cc</Label>
                <Input id="mail-cc" disabled={locked} value={cc} onChange={(e) => setCc(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="mail-bcc">Bcc</Label>
                <Input id="mail-bcc" disabled={locked} value={bcc} onChange={(e) => setBcc(e.target.value)} />
              </div>
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="mail-subject">Subject</Label>
            <Input id="mail-subject" disabled={locked} value={subject} onChange={(e) => setSubject(e.target.value)} />
          </div>
          {draft.mode === "reply" && (
            <p className="text-xs text-muted-foreground">Changing the subject starts a new conversation in Gmail.</p>
          )}
          <Textarea aria-label="Message" disabled={locked} rows={12} value={text} onChange={(e) => setText(e.target.value)} />
          {uncertain && (
            <div className="flex gap-3 rounded-md border border-chart-3/60 bg-chart-3/10 p-3 text-sm">
              <AlertTriangle className="size-4 shrink-0 text-chart-4" />
              <div className="space-y-1">
                <p className="font-medium">We couldn't confirm whether this was sent.</p>
                <p className="text-muted-foreground">
                  Sending again is blocked so the client doesn't get it twice. Check your Sent folder; if it isn't there yet, wait a minute and check again.
                </p>
              </div>
            </div>
          )}
        </div>
        <DialogFooter className="gap-2">
          <Button variant="ghost" className="cursor-pointer" onClick={onClose} disabled={busy}>
            {uncertain ? "Close" : "Discard"}
          </Button>
          {uncertain ? (
            <Button className="cursor-pointer" onClick={() => void doCheck()} disabled={phase === "checking"}>
              {phase === "checking" && <Spinner />} Check Sent folder
            </Button>
          ) : (
            <Button className="cursor-pointer" onClick={() => void doSend()} disabled={locked || !to.trim()}>
              {phase === "sending" ? <Spinner /> : <Send className="size-4" />} Send
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
