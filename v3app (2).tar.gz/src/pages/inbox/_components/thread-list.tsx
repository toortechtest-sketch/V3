import { useState } from "react";
import { useAction } from "convex/react";
import { formatDistanceToNowStrict, parseISO } from "date-fns";
import { Archive, Inbox, Mail, PenSquare, Search, Send, Star, Trash2 } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import {
  ErrorState,
  ErrorStateContent,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import { type Folder, senderName, useInvalidateMail, useThreadList } from "../_lib/use-mail.ts";

const FOLDERS: { id: Folder; label: string; icon: typeof Inbox }[] = [
  { id: "inbox", label: "Inbox", icon: Inbox },
  { id: "starred", label: "Starred", icon: Star },
  { id: "sent", label: "Sent", icon: Send },
  { id: "all", label: "All mail", icon: Archive },
  { id: "trash", label: "Trash", icon: Trash2 },
];

export function FolderNav({
  folder,
  onChange,
  onCompose,
}: {
  folder: Folder;
  onChange: (f: Folder) => void;
  onCompose: () => void;
}) {
  return (
    <div className="flex gap-1.5 overflow-x-auto md:flex-col">
      <Button className="shrink-0 cursor-pointer md:mb-2" onClick={onCompose}>
        <PenSquare className="size-4" /> Compose
      </Button>
      {FOLDERS.map((f) => (
        <button
          key={f.id}
          type="button"
          onClick={() => onChange(f.id)}
          className={cn(
            "flex shrink-0 cursor-pointer items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors",
            folder === f.id
              ? "bg-secondary font-medium text-primary dark:text-chart-2"
              : "text-muted-foreground hover:bg-muted hover:text-foreground",
          )}
        >
          <f.icon className="size-4" /> {f.label}
        </button>
      ))}
    </div>
  );
}

const ago = (date: string | null) => (date ? formatDistanceToNowStrict(parseISO(date)) : "");

export function ThreadList({
  folder,
  selected,
  onSelect,
}: {
  folder: Folder;
  selected: string | null;
  onSelect: (id: string) => void;
}) {
  const [search, setSearch] = useState("");
  const [query] = useDebounce(search.trim(), 400);
  // Gmail paging is cursor-based: a stack of page tokens where "Newer" pops.
  const [pages, setPages] = useState<(string | undefined)[]>([undefined]);
  const list = useThreadList(folder, query, pages[pages.length - 1]);
  const modify = useAction(api.gmail.mailbox.modifyThread);
  const invalidate = useInvalidateMail();
  const next = list.data?.nextPageToken;

  const open = (id: string, unread: boolean) => {
    onSelect(id);
    // Gmail's API doesn't mark read on fetch; mirror Gmail's behaviour on open.
    if (unread)
      void modify({ threadId: id, op: "read" }).then(() => invalidate()).catch(() => undefined);
  };

  return (
    <div className="flex h-full flex-col">
      <div className="border-b p-3">
        <div className="relative">
          <Search className="absolute top-2.5 left-2.5 size-4 text-muted-foreground" />
          <Input
            aria-label="Search mail"
            className="pl-8"
            placeholder="Search mail (Gmail search works)"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setPages([undefined]);
            }}
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto">
        {list.isPending ? (
          <div className="space-y-2 p-3">
            {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}
          </div>
        ) : list.isError ? (
          <ErrorState className="m-3">
            <ErrorStateHeader>
              <ErrorStateTitle>Couldn't load mail</ErrorStateTitle>
              <ErrorStateDescription>{errorMessage(list.error)}</ErrorStateDescription>
            </ErrorStateHeader>
            <ErrorStateContent>
              <Button size="sm" className="cursor-pointer" onClick={() => void list.refetch()}>Try again</Button>
            </ErrorStateContent>
          </ErrorState>
        ) : list.data.threads.length === 0 ? (
          <Empty className="py-16">
            <EmptyHeader>
              <EmptyMedia variant="icon"><Mail /></EmptyMedia>
              <EmptyTitle>{query ? "No matches" : "Nothing here"}</EmptyTitle>
              <EmptyDescription>{query ? "Try a different search." : "This folder is empty."}</EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <ul className="divide-y">
            {list.data.threads.map((t) => (
              <li key={t.id}>
                <button
                  type="button"
                  onClick={() => open(t.id, t.unread)}
                  className={cn(
                    "w-full cursor-pointer px-4 py-3 text-left transition-colors hover:bg-muted/70",
                    selected === t.id && "bg-secondary",
                  )}
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <span className={cn("truncate text-sm", t.unread ? "font-semibold" : "text-foreground/80")}>
                      {t.unread && <span className="mr-1.5 inline-block size-2 rounded-full bg-primary dark:bg-chart-2" />}
                      {senderName(t.from)}
                      {t.messageCount > 1 && (
                        <span className="pl-1 text-xs font-normal text-muted-foreground">{t.messageCount}</span>
                      )}
                    </span>
                    <span className="shrink-0 font-mono text-[11px] text-muted-foreground">{ago(t.date)}</span>
                  </div>
                  <p className={cn("truncate text-sm", t.unread && "font-medium")}>
                    {t.starred && <Star className="mr-1 inline size-3 fill-chart-3 text-chart-3" />}
                    {t.subject}
                  </p>
                  <p className="truncate text-xs text-muted-foreground">{t.snippet}</p>
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
      <div className="flex items-center justify-between border-t px-3 py-2 text-xs text-muted-foreground">
        <span>Page {pages.length}</span>
        <div className="flex gap-1">
          <Button size="sm" variant="ghost" className="cursor-pointer" disabled={pages.length === 1} onClick={() => setPages((p) => p.slice(0, -1))}>
            Newer
          </Button>
          <Button size="sm" variant="ghost" className="cursor-pointer" disabled={!next} onClick={() => next && setPages((p) => [...p, next])}>
            Older
          </Button>
        </div>
      </div>
    </div>
  );
}
