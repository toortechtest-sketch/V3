import { describe, expect, it } from "vitest";
import { layoutWeeks, monthGrid, shiftMonth } from "./calendar.ts";

const b = (id: string, startDate: string, endDate: string) => ({
  _id: id,
  startDate,
  endDate,
});

describe("monthGrid", () => {
  it("covers whole Monday-to-Sunday weeks", () => {
    const grid = monthGrid("2026-10"); // 1 Oct 2026 is a Thursday
    expect(grid.from).toBe("2026-09-28");
    expect(grid.to).toBe("2026-11-01");
    expect(grid.days).toHaveLength(35);
  });
});

describe("shiftMonth", () => {
  it("wraps across years", () => {
    expect(shiftMonth("2026-12", 1)).toBe("2027-01");
    expect(shiftMonth("2026-01", -1)).toBe("2025-12");
  });
});

describe("layoutWeeks", () => {
  const { days } = monthGrid("2026-10");

  it("splits a booking that crosses a week boundary", () => {
    const weeks = layoutWeeks(days, [b("x", "2026-10-03", "2026-10-06")]);
    const [w1, w2] = weeks;
    expect(w1.bars[0]).toMatchObject({ startCol: 5, endCol: 6, continuesAfter: true });
    expect(w2.bars[0]).toMatchObject({ startCol: 0, endCol: 1, continuesBefore: true });
  });

  it("stacks overlaps and reuses free lanes", () => {
    const weeks = layoutWeeks(days, [
      b("a", "2026-10-05", "2026-10-07"),
      b("b", "2026-10-06", "2026-10-08"),
      b("c", "2026-10-09", "2026-10-10"),
    ]);
    const lanes = Object.fromEntries(
      weeks[1].bars.map((bar) => [bar.booking._id, bar.lane]),
    );
    expect(lanes).toEqual({ a: 0, b: 1, c: 0 });
    expect(weeks[1].laneCount).toBe(2);
  });

  it("clips bookings that started before the visible grid", () => {
    const weeks = layoutWeeks(days, [b("old", "2026-08-01", "2026-09-29")]);
    expect(weeks[0].bars[0]).toMatchObject({ startCol: 0, endCol: 1 });
    expect(weeks[1].bars).toHaveLength(0);
  });
});
