import {
  addDays,
  endOfMonth,
  endOfWeek,
  format,
  parseISO,
  startOfMonth,
  startOfWeek,
} from "date-fns";

/** Minimum fields needed to place a booking on the calendar. */
export type CalendarBooking = {
  _id: string;
  startDate: string;
  endDate: string;
};

export type WeekBar<T extends CalendarBooking> = {
  booking: T;
  /** 0–6 column where the bar starts / ends within this week. */
  startCol: number;
  endCol: number;
  lane: number;
  /** True when the booking continues from the previous / into the next week. */
  continuesBefore: boolean;
  continuesAfter: boolean;
};

export type CalendarWeek<T extends CalendarBooking> = {
  days: string[];
  bars: WeekBar<T>[];
  laneCount: number;
};

const WEEK_OPTS = { weekStartsOn: 1 } as const;
const toDay = (d: Date) => format(d, "yyyy-MM-dd");

/** "2026-10" for a YYYY-MM-DD day. */
export const monthKey = (day: string) => day.slice(0, 7);

export function isMonthKey(value: string | null): value is string {
  return value !== null && /^\d{4}-(0[1-9]|1[0-2])$/.test(value);
}

/** Monday-to-Sunday days covering every week of the month. */
export function monthGrid(month: string) {
  const first = parseISO(`${month}-01`);
  const start = startOfWeek(startOfMonth(first), WEEK_OPTS);
  const end = endOfWeek(endOfMonth(first), WEEK_OPTS);
  const days: string[] = [];
  for (let d = start; d <= end; d = addDays(d, 1)) days.push(toDay(d));
  return { from: days[0], to: days[days.length - 1], days };
}

export function shiftMonth(month: string, delta: number) {
  const d = parseISO(`${month}-01`);
  return format(new Date(d.getFullYear(), d.getMonth() + delta, 1), "yyyy-MM");
}

/**
 * Splits bookings into per-week bars and stacks overlapping ones into lanes
 * (first free lane wins), so each week can be drawn as rows of bars.
 */
export function layoutWeeks<T extends CalendarBooking>(
  days: string[],
  bookings: T[],
): CalendarWeek<T>[] {
  const sorted = [...bookings].sort(
    (a, b) =>
      a.startDate.localeCompare(b.startDate) ||
      b.endDate.localeCompare(a.endDate) ||
      a._id.localeCompare(b._id),
  );
  const weeks: CalendarWeek<T>[] = [];
  for (let i = 0; i < days.length; i += 7) {
    const week = days.slice(i, i + 7);
    const first = week[0];
    const last = week[week.length - 1];
    // laneEnds[lane] = last column occupied in that lane
    const laneEnds: number[] = [];
    const bars: WeekBar<T>[] = [];
    for (const booking of sorted) {
      if (booking.endDate < first || booking.startDate > last) continue;
      const startCol =
        booking.startDate < first ? 0 : week.indexOf(booking.startDate);
      const endCol =
        booking.endDate > last ? week.length - 1 : week.indexOf(booking.endDate);
      let lane = laneEnds.findIndex((end) => end < startCol);
      if (lane === -1) lane = laneEnds.length;
      laneEnds[lane] = endCol;
      bars.push({
        booking,
        startCol,
        endCol,
        lane,
        continuesBefore: booking.startDate < first,
        continuesAfter: booking.endDate > last,
      });
    }
    weeks.push({ days: week, bars, laneCount: laneEnds.length });
  }
  return weeks;
}

/** Bookings on the road on a given day. */
export function bookingsOnDay<T extends CalendarBooking>(day: string, bookings: T[]) {
  return bookings.filter((b) => b.startDate <= day && b.endDate >= day);
}
