import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import {
  CalendarDays,
  ChevronLeft,
  ChevronRight,
  List,
  TriangleAlert,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { BOARD_STAGES, STAGE_META } from "@/lib/bookings.ts";
import { cn } from "@/lib/utils.ts";
import BookingRows from "./_components/booking-rows.tsx";
import MonthGrid from "./_components/month-grid.tsx";
import {
  bookingsOnDay,
  isMonthKey,
  monthGrid,
  monthKey,
  shiftMonth,
} from "./_lib/calendar.ts";

type View = "month" | "list";

const LEGEND_STAGES = [...BOARD_STAGES, "closed"] as const;

export default function DeparturesPage() {
  const { isManager } = useStaff();
  const [params, setParams] = useSearchParams();
  const today = format(new Date(), "yyyy-MM-dd");
  const monthParam = params.get("month");
  const month = isMonthKey(monthParam) ? monthParam : monthKey(today);
  const view: View = params.get("view") === "list" ? "list" : "month";
  const mineOnly = params.get("mine") === "1";
  const includeCancelled = params.get("cancelled") === "1";
  const [selectedDay, setSelectedDay] = useState<string | null>(null);

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(params);
    if (value === null) next.delete(key);
    else next.set(key, value);
    setParams(next, { replace: true });
  };

  const grid = monthGrid(month);
  const data = useQuery(api.departures.calendar, {
    from: grid.from,
    to: grid.to,
    mineOnly,
    includeCancelled,
  });
  const bookings = data?.bookings;
  const departing = bookings?.filter((b) => monthKey(b.startDate) === month);
  const departingPax = departing?.reduce((sum, b) => sum + b.pax, 0) ?? 0;
  const dayBookings =
    selectedDay && bookings ? bookingsOnDay(selectedDay, bookings) : [];
  const monthLabel = format(parseISO(`${month}-01`), "MMMM yyyy");

  return (
    <PageContainer className="max-w-[1400px]">
      <PageHeader
        title="Departures calendar"
        description={
          isManager
            ? "When every group is travelling, across the whole team."
            : "When the groups you're responsible for are travelling."
        }
      />

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="flex items-center gap-2">
          <Button
            variant="secondary"
            size="icon"
            className="cursor-pointer"
            aria-label="Previous month"
            onClick={() => setParam("month", shiftMonth(month, -1))}
          >
            <ChevronLeft className="size-4" />
          </Button>
          <Button
            variant="secondary"
            size="icon"
            className="cursor-pointer"
            aria-label="Next month"
            onClick={() => setParam("month", shiftMonth(month, 1))}
          >
            <ChevronRight className="size-4" />
          </Button>
          <h2 className="min-w-40 font-display text-xl font-semibold">
            {monthLabel}
          </h2>
          <Button
            variant="ghost"
            size="sm"
            className="cursor-pointer"
            disabled={month === monthKey(today)}
            onClick={() => setParam("month", null)}
          >
            Today
          </Button>
        </div>

        <div className="flex flex-1 flex-wrap items-center gap-x-5 gap-y-3 lg:justify-end">
          <Tabs
            value={view}
            onValueChange={(v) => setParam("view", v === "list" ? "list" : null)}
          >
            <TabsList>
              <TabsTrigger value="month" className="cursor-pointer">
                <CalendarDays className="size-4" /> Month
              </TabsTrigger>
              <TabsTrigger value="list" className="cursor-pointer">
                <List className="size-4" /> Departures
              </TabsTrigger>
            </TabsList>
          </Tabs>
          <div className="flex items-center gap-2">
            <Switch
              id="show-cancelled"
              checked={includeCancelled}
              onCheckedChange={(c) => setParam("cancelled", c ? "1" : null)}
              className="cursor-pointer"
            />
            <Label htmlFor="show-cancelled" className="cursor-pointer text-sm">
              Show cancelled
            </Label>
          </div>
          {isManager ? (
            <div className="flex items-center gap-2">
              <Switch
                id="mine-only"
                checked={mineOnly}
                onCheckedChange={(c) => setParam("mine", c ? "1" : null)}
                className="cursor-pointer"
              />
              <Label htmlFor="mine-only" className="cursor-pointer text-sm">
                Only mine
              </Label>
            </div>
          ) : null}
        </div>
      </div>

      <div className="flex flex-wrap items-center justify-between gap-3 text-sm">
        <div className="text-muted-foreground">
          {departing === undefined ? (
            <Skeleton className="h-4 w-56" />
          ) : (
            <>
              <span className="font-semibold text-foreground">
                {departing.length}
              </span>{" "}
              {departing.length === 1 ? "departure" : "departures"} in{" "}
              {format(parseISO(`${month}-01`), "MMMM")} ·{" "}
              <span className="font-semibold text-foreground">{departingPax}</span>{" "}
              travellers
            </>
          )}
        </div>
        <div className="flex flex-wrap items-center gap-3">
          {LEGEND_STAGES.map((s) => (
            <span
              key={s}
              className="flex items-center gap-1.5 text-xs text-muted-foreground"
            >
              <span className={cn("size-2 rounded-full", STAGE_META[s].dot)} />
              {STAGE_META[s].label}
            </span>
          ))}
        </div>
      </div>

      {data?.truncated ? (
        <p className="flex items-center gap-2 rounded-lg bg-[#FFB800]/15 px-3 py-2 text-sm text-[#8a6400] dark:text-[#FFB800]">
          <TriangleAlert className="size-4 shrink-0" />
          This month is very busy, so only the first 300 bookings are shown.
        </p>
      ) : null}

      {bookings === undefined ? (
        <Skeleton className="h-[560px] w-full rounded-xl" />
      ) : view === "month" ? (
        <>
          <div className="-mx-4 overflow-x-auto px-4 sm:mx-0 sm:px-0">
            <div className="min-w-[720px]">
              <MonthGrid
                month={month}
                days={grid.days}
                today={today}
                bookings={bookings}
                onSelectDay={setSelectedDay}
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">
            Click a day to see everyone travelling that day.
          </p>
        </>
      ) : (
        <BookingRows
          bookings={departing ?? []}
          emptyTitle={`No departures in ${monthLabel}`}
          emptyDescription="Bookings appear here once their start date falls in this month."
        />
      )}

      <Sheet
        open={selectedDay !== null}
        onOpenChange={(open) => !open && setSelectedDay(null)}
      >
        <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
          <SheetHeader>
            <SheetTitle className="font-display text-xl">
              {selectedDay ? format(parseISO(selectedDay), "EEEE d MMMM yyyy") : ""}
            </SheetTitle>
            <SheetDescription>
              {dayBookings.length}{" "}
              {dayBookings.length === 1 ? "booking" : "bookings"} travelling
            </SheetDescription>
          </SheetHeader>
          <div className="px-4 pb-6">
            {selectedDay ? (
              <BookingRows
                bookings={dayBookings}
                day={selectedDay}
                emptyTitle="Nobody travelling"
                emptyDescription="No bookings are on the road this day."
              />
            ) : null}
          </div>
        </SheetContent>
      </Sheet>
    </PageContainer>
  );
}
