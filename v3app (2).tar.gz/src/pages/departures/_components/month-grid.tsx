import { Link } from "react-router-dom";
import { cn } from "@/lib/utils.ts";
import { STAGE_META, type BookingStage } from "@/lib/bookings.ts";
import { layoutWeeks, type CalendarBooking } from "../_lib/calendar.ts";

export type DepartureBooking = CalendarBooking & {
  reference: string;
  title: string;
  stage: BookingStage;
  clientName: string;
  destination: string;
  pax: number;
  ownerName: string | null;
};

const WEEKDAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"] as const;
// Lanes drawn per week before collapsing the rest into "+N more".
const MAX_LANES = 4;

export default function MonthGrid({
  month,
  days,
  today,
  bookings,
  onSelectDay,
}: {
  month: string;
  days: string[];
  today: string;
  bookings: DepartureBooking[];
  onSelectDay: (day: string) => void;
}) {
  const weeks = layoutWeeks(days, bookings);

  return (
    <div className="overflow-hidden rounded-xl border bg-card">
      <div className="grid grid-cols-7 border-b bg-muted/50">
        {WEEKDAYS.map((d) => (
          <div
            key={d}
            className="px-2 py-2 font-mono text-[11px] tracking-wider text-muted-foreground uppercase"
          >
            {d}
          </div>
        ))}
      </div>

      {weeks.map((week) => {
        const shown = week.bars.filter((bar) => bar.lane < MAX_LANES);
        const lanes = Math.min(week.laneCount, MAX_LANES);
        return (
          <div key={week.days[0]} className="relative border-b last:border-b-0">
            {/* Day cells: background, numbers and click targets */}
            <div className="absolute inset-0 grid grid-cols-7">
              {week.days.map((day) => {
                const outside = !day.startsWith(month);
                return (
                  <button
                    key={day}
                    type="button"
                    onClick={() => onSelectDay(day)}
                    aria-label={`Show bookings on ${day}`}
                    className={cn(
                      "cursor-pointer border-r text-left transition-colors last:border-r-0 hover:bg-accent/60",
                      outside && "bg-muted/40",
                    )}
                  />
                );
              })}
            </div>

            <div
              className="pointer-events-none relative grid grid-cols-7 gap-y-1 pb-2"
              style={{ gridTemplateRows: `auto repeat(${lanes + 1}, auto)` }}
            >
              {week.days.map((day, col) => {
                const isToday = day === today;
                const outside = !day.startsWith(month);
                const hidden = week.bars.filter(
                  (bar) =>
                    bar.lane >= MAX_LANES && bar.startCol <= col && bar.endCol >= col,
                ).length;
                return (
                  <div
                    key={day}
                    className="flex items-center justify-between px-2 pt-1.5"
                    style={{ gridColumn: col + 1, gridRow: 1 }}
                  >
                    <span
                      className={cn(
                        "flex size-6 items-center justify-center rounded-full text-xs tabular-nums",
                        outside && "text-muted-foreground/60",
                        isToday && "bg-primary font-semibold text-primary-foreground",
                      )}
                    >
                      {Number(day.slice(8))}
                    </span>
                    {hidden > 0 ? (
                      <span className="text-[10px] font-medium text-muted-foreground">
                        +{hidden}
                      </span>
                    ) : null}
                  </div>
                );
              })}

              {shown.map((bar) => {
                const meta = STAGE_META[bar.booking.stage];
                return (
                  <Link
                    key={bar.booking._id}
                    to={`/bookings/${bar.booking._id}`}
                    title={`${bar.booking.reference} · ${bar.booking.title} · ${bar.booking.pax} pax`}
                    style={{
                      gridColumn: `${bar.startCol + 1} / ${bar.endCol + 2}`,
                      gridRow: bar.lane + 2,
                    }}
                    className={cn(
                      "pointer-events-auto mx-1 flex h-6 cursor-pointer items-center gap-1.5 truncate rounded-md px-2 text-xs font-medium transition hover:brightness-95 hover:ring-1 hover:ring-current/30",
                      meta.badge,
                      bar.continuesBefore && "-ml-px rounded-l-none",
                      bar.continuesAfter && "-mr-px rounded-r-none",
                      bar.booking.stage === "cancelled" && "line-through",
                    )}
                  >
                    {bar.continuesBefore ? null : (
                      <span className={cn("size-1.5 shrink-0 rounded-full", meta.dot)} />
                    )}
                    <span className="truncate">{bar.booking.title}</span>
                    <span className="ml-auto shrink-0 font-mono text-[10px] opacity-70">
                      {bar.booking.pax}
                    </span>
                  </Link>
                );
              })}

              {/* Keeps short weeks tall enough to click */}
              <div
                className={lanes === 0 ? "min-h-12" : "min-h-1"}
                style={{ gridColumn: 1, gridRow: lanes + 2 }}
              />
            </div>
          </div>
        );
      })}
    </div>
  );
}
