import { Link } from "react-router-dom";
import { format, parseISO } from "date-fns";
import { CalendarRange, PlaneLanding, PlaneTakeoff, Users } from "lucide-react";
import StageBadge from "@/components/bookings/stage-badge.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { formatDateRange } from "@/lib/bookings.ts";
import type { DepartureBooking } from "./month-grid.tsx";

/** Shows how a booking relates to a specific day (departing, returning, away). */
function DayRole({ booking, day }: { booking: DepartureBooking; day: string }) {
  if (booking.startDate === day) {
    return (
      <span className="flex items-center gap-1 text-xs font-medium text-primary">
        <PlaneTakeoff className="size-3.5" /> Departs
      </span>
    );
  }
  if (booking.endDate === day) {
    return (
      <span className="flex items-center gap-1 text-xs font-medium text-[#b05300] dark:text-[#ffa257]">
        <PlaneLanding className="size-3.5" /> Returns
      </span>
    );
  }
  return <span className="text-xs text-muted-foreground">On the road</span>;
}

export default function BookingRows({
  bookings,
  day,
  emptyTitle,
  emptyDescription,
}: {
  bookings: DepartureBooking[];
  /** When set, each row shows whether it departs, returns or runs that day. */
  day?: string;
  emptyTitle: string;
  emptyDescription: string;
}) {
  if (bookings.length === 0) {
    return (
      <Empty className="border bg-card">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <CalendarRange />
          </EmptyMedia>
          <EmptyTitle>{emptyTitle}</EmptyTitle>
          <EmptyDescription>{emptyDescription}</EmptyDescription>
        </EmptyHeader>
      </Empty>
    );
  }

  return (
    <ul className="divide-y overflow-hidden rounded-xl border bg-card">
      {bookings.map((b) => (
        <li key={b._id}>
          <Link
            to={`/bookings/${b._id}`}
            className="group flex cursor-pointer gap-4 px-4 py-3 transition-colors hover:bg-accent/50"
          >
            {day ? null : (
              <div className="w-12 shrink-0 text-center">
                <p className="font-mono text-[10px] text-muted-foreground uppercase">
                  {format(parseISO(b.startDate), "EEE")}
                </p>
                <p className="font-display text-2xl leading-none font-semibold">
                  {format(parseISO(b.startDate), "d")}
                </p>
                <p className="text-[11px] text-muted-foreground">
                  {format(parseISO(b.startDate), "MMM")}
                </p>
              </div>
            )}
            <div className="min-w-0 flex-1 space-y-1">
              <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
                <span className="font-mono text-[11px] text-muted-foreground">
                  {b.reference}
                </span>
                <StageBadge stage={b.stage} />
                {day ? <DayRole booking={b} day={day} /> : null}
              </div>
              <p className="truncate font-medium group-hover:text-primary">
                {b.title}
              </p>
              <p className="flex flex-wrap gap-x-3 text-xs text-muted-foreground">
                <span className="truncate">
                  {b.clientName} · {b.destination}
                </span>
                <span>{formatDateRange(b.startDate, b.endDate)}</span>
                <span className="flex items-center gap-1">
                  <Users className="size-3" /> {b.pax}
                </span>
                {b.ownerName ? <span>{b.ownerName}</span> : null}
              </p>
            </div>
          </Link>
        </li>
      ))}
    </ul>
  );
}
