import { useState } from "react";
import { useMutation } from "convex/react";
import { ConvexError } from "convex/values";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import { Check, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { AppPreference } from "@/convex/schema/connectedApps.ts";
import {
  STATUS_LABELS,
  type AppStatus,
  type ConnectedAppInfo,
} from "@/lib/connected-apps.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { cn } from "@/lib/utils.ts";

export type SavedPreference = {
  preference: AppPreference;
  updatedAt: string;
  updatedByName: string | null;
};

const STATUS_STYLES: Record<AppStatus, string> = {
  built_in: "bg-[#00BDEB]/15 text-[#006f8a] dark:text-[#00BDEB]",
  planned: "bg-[#FFB800]/15 text-[#8a6400] dark:text-[#FFB800]",
  not_connected: "bg-muted text-muted-foreground",
};

const CHOICES: { value: AppPreference; label: string; icon: typeof Check }[] = [
  { value: "needed", label: "We need this", icon: Check },
  { value: "not_needed", label: "Not needed", icon: X },
];

function errorMessage(error: unknown) {
  if (error instanceof ConvexError) {
    return (error.data as { message: string }).message;
  }
  return "Could not save. Please try again.";
}

export default function AppCard({
  app,
  saved,
}: {
  app: ConnectedAppInfo;
  saved: SavedPreference | undefined;
}) {
  const setPreference = useMutation(api.connectedApps.setPreference);
  const [busy, setBusy] = useState(false);
  const askable = app.status !== "built_in";

  const choose = async (value: AppPreference) => {
    // Clicking the active choice clears it.
    const next = saved?.preference === value ? null : value;
    setBusy(true);
    try {
      await setPreference({ appKey: app.key, preference: next });
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Card
      className={cn(
        "gap-0 py-0 transition-colors",
        saved?.preference === "needed" && "border-primary/50",
        saved?.preference === "not_needed" && "opacity-70",
      )}
    >
      <CardContent className="flex h-full flex-col gap-4 p-5">
        <div className="flex items-start gap-3">
          <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
            <app.icon className="size-5" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="font-medium">{app.name}</p>
              <Badge className={STATUS_STYLES[app.status]}>
                {STATUS_LABELS[app.status]}
              </Badge>
            </div>
            <p className="pt-1 text-sm text-muted-foreground">
              {app.description}
            </p>
          </div>
        </div>

        <p className="rounded-md bg-muted px-3 py-2 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">Setup: </span>
          {app.setup}
        </p>

        {askable ? (
          <div className="mt-auto space-y-2">
            <div className="flex gap-2">
              {CHOICES.map((choice) => {
                const active = saved?.preference === choice.value;
                return (
                  <Button
                    key={choice.value}
                    size="sm"
                    variant={active ? "default" : "secondary"}
                    disabled={busy}
                    aria-pressed={active}
                    className="flex-1 cursor-pointer"
                    onClick={() => void choose(choice.value)}
                  >
                    <choice.icon className="size-4" />
                    {choice.label}
                  </Button>
                );
              })}
            </div>
            {saved ? (
              <p className="text-xs text-muted-foreground">
                Marked by {saved.updatedByName ?? "a manager"}{" "}
                {formatDistanceToNow(new Date(saved.updatedAt), {
                  addSuffix: true,
                })}
              </p>
            ) : null}
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}
