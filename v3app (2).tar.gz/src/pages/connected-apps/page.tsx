import { useMemo } from "react";
import { useQuery } from "convex/react";
import { Plug } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { ConnectedAppKey } from "@/convex/schema/connectedApps.ts";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { APP_CATEGORIES, CONNECTED_APPS } from "@/lib/connected-apps.ts";
import { Card, CardContent } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import AppCard, { type SavedPreference } from "./_components/app-card.tsx";

function Summary({ needed, decided, total }: { needed: number; decided: number; total: number }) {
  const stats = [
    { label: "Needed by the team", value: needed },
    { label: "Still to decide", value: total - decided },
    { label: "Live connections", value: 0 },
  ];
  return (
    <Card className="gap-0 overflow-hidden py-0">
      <CardContent className="grid gap-px bg-border p-0 sm:grid-cols-3">
        {stats.map((stat) => (
          <div key={stat.label} className="space-y-1 bg-card p-5">
            <p className="font-display text-3xl font-semibold">{stat.value}</p>
            <p className="text-sm text-muted-foreground">{stat.label}</p>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}

function AppsDirectory() {
  const rows = useQuery(api.connectedApps.listPreferences, {});

  const saved = useMemo(() => {
    const map = new Map<ConnectedAppKey, SavedPreference>();
    for (const row of rows ?? []) map.set(row.appKey, row);
    return map;
  }, [rows]);

  if (rows === undefined) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-24 w-full" />
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-56 w-full" />
          ))}
        </div>
      </div>
    );
  }

  const askable = CONNECTED_APPS.filter((a) => a.status !== "built_in");
  const decided = askable.filter((a) => saved.has(a.key)).length;
  const needed = askable.filter(
    (a) => saved.get(a.key)?.preference === "needed",
  ).length;

  return (
    <div className="space-y-8">
      <Summary needed={needed} decided={decided} total={askable.length} />
      {APP_CATEGORIES.map((category) => (
        <section key={category} className="space-y-3">
          <h2 className="font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
            {category}
          </h2>
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {CONNECTED_APPS.filter((a) => a.category === category).map(
              (app) => (
                <AppCard key={app.key} app={app} saved={saved.get(app.key)} />
              ),
            )}
          </div>
        </section>
      ))}
    </div>
  );
}

export default function ConnectedAppsPage() {
  const { isManager, me } = useStaff();
  if (me !== undefined && !isManager) {
    return (
      <PageContainer>
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Plug />
            </EmptyMedia>
            <EmptyTitle>Managers only</EmptyTitle>
            <EmptyDescription>
              Only owners and global managers can manage connected apps.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      </PageContainer>
    );
  }
  return (
    <PageContainer>
      <PageHeader
        title="Connected apps"
        description="Everything V2 linked to, and where each one stands in V3. Mark what your team needs so the most useful connections are built first."
      />
      {isManager ? <AppsDirectory /> : null}
    </PageContainer>
  );
}
