import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { usePaginatedQuery } from "convex/react";
import { Building2, Mail, Phone, Plus, Search, Sparkles, User, Users } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import ClientFormDialog from "@/components/clients/client-form-dialog.tsx";
import ClientImportDialog from "@/components/clients/client-import-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { formatPlace, type ClientKind } from "@/lib/clients.ts";

const PAGE_SIZE = 30;
type Filter = "all" | ClientKind;

const FILTERS: { value: Filter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "company", label: "Companies" },
  { value: "individual", label: "People" },
];

function KindIcon({ kind }: { kind: ClientKind }) {
  const Icon = kind === "company" ? Building2 : User;
  return (
    <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
      <Icon className="size-4" />
    </div>
  );
}

function ClientRow({ client }: { client: Doc<"clients"> }) {
  const navigate = useNavigate();
  const place = formatPlace(client.city, client.country);
  return (
    <button
      type="button"
      onClick={() => navigate(`/clients/${client._id}`)}
      className="flex w-full cursor-pointer items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-muted/60"
    >
      <KindIcon kind={client.kind} />
      <div className="min-w-0 flex-1">
        <p className="truncate font-medium">{client.name}</p>
        <p className="truncate text-xs text-muted-foreground">
          {[client.contactName, place].filter(Boolean).join(" · ") ||
            (client.kind === "company" ? "Company" : "Person")}
        </p>
      </div>
      <div className="hidden min-w-0 flex-col items-end gap-0.5 text-xs text-muted-foreground sm:flex">
        {client.email ? (
          <span className="flex max-w-64 items-center gap-1.5 truncate">
            <Mail className="size-3 shrink-0" />
            {client.email}
          </span>
        ) : null}
        {client.phone ? (
          <span className="flex items-center gap-1.5">
            <Phone className="size-3 shrink-0" />
            {client.phone}
          </span>
        ) : null}
      </div>
    </button>
  );
}

function ClientList({
  kind,
  search,
  onCreate,
}: {
  kind: ClientKind | undefined;
  search: string;
  onCreate: () => void;
}) {
  const { results, status, loadMore } = usePaginatedQuery(
    api.clients.list,
    { kind, search: search || undefined },
    { initialNumItems: PAGE_SIZE },
  );

  if (status === "LoadingFirstPage") {
    return (
      <Card className="gap-0 divide-y py-0">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 px-4 py-3">
            <Skeleton className="size-9 rounded-lg" />
            <div className="flex-1 space-y-1.5">
              <Skeleton className="h-4 w-48" />
              <Skeleton className="h-3 w-32" />
            </div>
          </div>
        ))}
      </Card>
    );
  }

  if (results.length === 0 && status === "Exhausted") {
    const filtered = Boolean(kind || search);
    return (
      <Empty className="border bg-card">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <Users />
          </EmptyMedia>
          <EmptyTitle>
            {filtered ? "No matching clients" : "No clients yet"}
          </EmptyTitle>
          <EmptyDescription>
            {filtered
              ? "Try another filter or search term."
              : "Add the companies and people you organise trips for."}
          </EmptyDescription>
        </EmptyHeader>
        {filtered ? null : (
          <EmptyContent>
            <Button size="sm" className="cursor-pointer" onClick={onCreate}>
              Add client
            </Button>
          </EmptyContent>
        )}
      </Empty>
    );
  }

  return (
    <div className="space-y-3">
      <Card className="gap-0 divide-y overflow-hidden py-0">
        {results.map((c) => (
          <ClientRow key={c._id} client={c} />
        ))}
      </Card>
      {status === "CanLoadMore" || status === "LoadingMore" ? (
        <div className="flex justify-center">
          <Button
            variant="secondary"
            size="sm"
            className="cursor-pointer"
            disabled={status === "LoadingMore"}
            onClick={() => loadMore(PAGE_SIZE)}
          >
            {status === "LoadingMore" ? "Loading…" : "Load more"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}

export default function ClientsPage() {
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");
  const [term] = useDebounce(search.trim(), 300);
  const [creating, setCreating] = useState(false);
  const [importing, setImporting] = useState(false);

  return (
    <PageContainer>
      <PageHeader
        title="Clients"
        description="Companies and people you organise trips for, shared with the whole team."
        actions={
          <>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setImporting(true)}>
              <Sparkles className="size-4" /> Import with AI
            </Button>
            <Button className="cursor-pointer" onClick={() => setCreating(true)}>
              <Plus className="size-4" /> New client
            </Button>
          </>
        }
      />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)}>
          <TabsList>
            {FILTERS.map((f) => (
              <TabsTrigger
                key={f.value}
                value={f.value}
                className="cursor-pointer"
              >
                {f.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>
        <div className="relative sm:w-72">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, contact, email or city"
            className="pl-9"
          />
        </div>
      </div>

      <ClientList
        kind={filter === "all" ? undefined : filter}
        search={term}
        onCreate={() => setCreating(true)}
      />

      <ClientFormDialog open={creating} onOpenChange={setCreating} />
      <ClientImportDialog open={importing} onOpenChange={setImporting} />
    </PageContainer>
  );
}
