import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import {
  AlertTriangle,
  ArrowLeft,
  Building2,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Plus,
  ReceiptText,
  Trash2,
  User,
  UserRound,
  Users,
} from "lucide-react";
import { format } from "date-fns";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import ClientFormDialog from "@/components/clients/client-form-dialog.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import {
  ErrorState,
  ErrorStateContent,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateMedia,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { KIND_LABELS, formatPlace } from "@/lib/clients.ts";
import { errorMessage } from "@/lib/errors.ts";
import QueryErrorBoundary from "@/components/query-error-boundary.tsx";

// Convex IDs are short lowercase base32 strings; reject obviously bad URLs early.
const ID_PATTERN = /^[a-z0-9]{20,40}$/;

type Detail = NonNullable<ReturnType<typeof useClientDetail>>;

type IconType = React.ComponentType<{ className?: string }>;
type InfoItem = { icon: IconType; label: string; value: React.ReactNode };

function useClientDetail(id: Id<"clients">) {
  return useQuery(api.clients.get, { id });
}

function InfoRow({
  icon: Icon,
  label,
  children,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex gap-3">
      <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <div className="break-words text-sm">{children}</div>
      </div>
    </div>
  );
}

function ContactCard({ client }: { client: Detail }) {
  const place = [client.address, formatPlace(client.city, client.country)]
    .filter(Boolean)
    .join(", ");
  const link = (href: string, label: string) => (
    <a href={href} className="text-primary hover:underline">
      {label}
    </a>
  );
  const candidates: (InfoItem | null)[] = [
    client.contactName
      ? { icon: UserRound, label: "Main contact", value: client.contactName }
      : null,
    client.email
      ? {
          icon: Mail,
          label: "Email",
          value: link(`mailto:${client.email}`, client.email),
        }
      : null,
    client.phone
      ? {
          icon: Phone,
          label: "Phone",
          value: link(`tel:${client.phone}`, client.phone),
        }
      : null,
    place ? { icon: MapPin, label: "Address", value: place } : null,
    client.taxId
      ? { icon: ReceiptText, label: "Tax ID", value: client.taxId }
      : null,
  ];
  const rows = candidates.filter((r): r is InfoItem => r !== null);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-lg">Details</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {rows.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            No contact details yet. Use Edit to add them.
          </p>
        ) : (
          rows.map((r) => (
            <InfoRow key={r.label} icon={r.icon} label={r.label}>
              {r.value}
            </InfoRow>
          ))
        )}
        {client.notes ? (
          <div className="rounded-lg bg-muted p-3 text-sm whitespace-pre-wrap">
            {client.notes}
          </div>
        ) : null}
        <p className="border-t pt-3 text-xs text-muted-foreground">
          Added {format(client._creationTime, "d MMM yyyy")}
          {client.createdByName ? ` by ${client.createdByName}` : ""}
        </p>
      </CardContent>
    </Card>
  );
}

function PeopleCard({ client }: { client: Detail }) {
  const [adding, setAdding] = useState(false);
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2">
        <CardTitle className="font-display text-lg">People</CardTitle>
        <Button
          size="sm"
          variant="secondary"
          className="cursor-pointer"
          onClick={() => setAdding(true)}
        >
          <Plus className="size-4" /> Add person
        </Button>
      </CardHeader>
      <CardContent>
        {client.members.length === 0 ? (
          <Empty className="py-6">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <Users />
              </EmptyMedia>
              <EmptyTitle>No people yet</EmptyTitle>
              <EmptyDescription>
                Add the people you deal with at {client.name}.
              </EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="-mx-2 divide-y">
            {client.members.map((m) => (
              <Link
                key={m._id}
                to={`/clients/${m._id}`}
                className="flex items-center gap-3 rounded-md px-2 py-2.5 transition-colors hover:bg-muted/60"
              >
                <User className="size-4 shrink-0 text-muted-foreground" />
                <span className="min-w-0 flex-1 truncate text-sm font-medium">
                  {m.name}
                </span>
                <span className="hidden truncate text-xs text-muted-foreground sm:block">
                  {m.email ?? m.phone ?? ""}
                </span>
              </Link>
            ))}
          </div>
        )}
      </CardContent>
      <ClientFormDialog
        open={adding}
        onOpenChange={setAdding}
        defaultCompany={{ id: client._id, name: client.name }}
      />
    </Card>
  );
}

function DeleteButton({ client }: { client: Detail }) {
  const remove = useMutation(api.clients.remove);
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const onConfirm = async () => {
    setBusy(true);
    try {
      await remove({ id: client._id });
      toast.success(`${client.name} deleted`);
      navigate("/clients");
    } catch (error) {
      toast.error(errorMessage(error));
      setBusy(false);
    }
  };
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          variant="ghost"
          className="cursor-pointer text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="size-4" /> Delete
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {client.name}?</AlertDialogTitle>
          <AlertDialogDescription>
            This removes the client for the whole team. It can't be undone.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="cursor-pointer">Cancel</AlertDialogCancel>
          <AlertDialogAction
            disabled={busy}
            className="cursor-pointer bg-destructive text-white hover:bg-destructive/90"
            onClick={(e) => {
              e.preventDefault();
              void onConfirm();
            }}
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function ClientDetail({ id }: { id: Id<"clients"> }) {
  const client = useClientDetail(id);
  const { isManager } = useStaff();
  const [editing, setEditing] = useState(false);

  if (client === undefined) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-9 w-72" />
        <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <Skeleton className="h-64" />
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  const KindIcon = client.kind === "company" ? Building2 : User;
  return (
    <>
      <PageHeader
        title={client.name}
        description={
          <span className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary" className="gap-1">
              <KindIcon className="size-3" />
              {KIND_LABELS[client.kind]}
            </Badge>
            {client.parent ? (
              <span>
                at{" "}
                <Link
                  to={`/clients/${client.parent._id}`}
                  className="font-medium text-primary hover:underline"
                >
                  {client.parent.name}
                </Link>
              </span>
            ) : null}
          </span>
        }
        actions={
          <>
            {isManager ? <DeleteButton client={client} /> : null}
            <Button className="cursor-pointer" onClick={() => setEditing(true)}>
              <Pencil className="size-4" /> Edit
            </Button>
          </>
        }
      />
      <div className="grid items-start gap-6 lg:grid-cols-[1fr_1.2fr]">
        <ContactCard client={client} />
        {client.kind === "company" ? <PeopleCard client={client} /> : null}
      </div>
      <ClientFormDialog
        open={editing}
        onOpenChange={setEditing}
        client={client}
      />
    </>
  );
}

function NotFoundState() {
  return (
    <ErrorState className="border">
      <ErrorStateHeader>
        <ErrorStateMedia variant="icon">
          <AlertTriangle />
        </ErrorStateMedia>
        <ErrorStateTitle>Client not found</ErrorStateTitle>
        <ErrorStateDescription>
          It may have been deleted, or the link is wrong.
        </ErrorStateDescription>
      </ErrorStateHeader>
      <ErrorStateContent>
        <Button asChild size="sm" className="cursor-pointer">
          <Link to="/clients">Back to clients</Link>
        </Button>
      </ErrorStateContent>
    </ErrorState>
  );
}

export default function ClientDetailPage() {
  const { clientId } = useParams();
  return (
    <PageContainer>
      <Button
        asChild
        variant="ghost"
        size="sm"
        className="-ml-2 cursor-pointer text-muted-foreground"
      >
        <Link to="/clients">
          <ArrowLeft className="size-4" /> Clients
        </Link>
      </Button>
      {clientId && ID_PATTERN.test(clientId) ? (
        <QueryErrorBoundary key={clientId} fallback={<NotFoundState />}>
          <ClientDetail id={clientId as Id<"clients">} />
        </QueryErrorBoundary>
      ) : (
        <NotFoundState />
      )}
    </PageContainer>
  );
}
