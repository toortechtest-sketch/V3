import { useNavigate } from "react-router-dom";
import { usePaginatedQuery } from "convex/react";
import { BookOpenCheck, CalendarDays, MapPin, Users } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table.tsx";
import StageMenu from "@/components/bookings/stage-menu.tsx";
import {
  TYPE_LABELS,
  formatDateRange,
  type BookingStage,
} from "@/lib/bookings.ts";

const PAGE_SIZE = 25;

export default function BookingList({
  stage,
  search,
  mineOnly,
  onCreate,
}: {
  stage: BookingStage | undefined;
  search: string;
  mineOnly: boolean;
  onCreate: () => void;
}) {
  const navigate = useNavigate();
  const { results, status, loadMore } = usePaginatedQuery(
    api.bookings.list,
    { stage, search: search || undefined, mineOnly },
    { initialNumItems: PAGE_SIZE },
  );

  if (status === "LoadingFirstPage") {
    return (
      <Card className="gap-0 divide-y py-0">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center gap-4 px-4 py-4">
            <Skeleton className="h-4 w-24" />
            <Skeleton className="h-4 flex-1" />
            <Skeleton className="h-5 w-20 rounded-full" />
          </div>
        ))}
      </Card>
    );
  }

  if (results.length === 0 && status === "Exhausted") {
    const filtered = Boolean(stage || search);
    return (
      <Empty className="border bg-card">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <BookOpenCheck />
          </EmptyMedia>
          <EmptyTitle>
            {filtered ? "No matching bookings" : "No bookings yet"}
          </EmptyTitle>
          <EmptyDescription>
            {filtered
              ? "Try another stage or search term."
              : "Create your first booking to start the brief-to-reconcile flow."}
          </EmptyDescription>
        </EmptyHeader>
        {filtered ? null : (
          <EmptyContent>
            <Button size="sm" className="cursor-pointer" onClick={onCreate}>
              New booking
            </Button>
          </EmptyContent>
        )}
      </Empty>
    );
  }

  return (
    <div className="space-y-3">
      {/* Desktop table */}
      <Card className="hidden gap-0 overflow-hidden py-0 md:block">
        <Table>
          <TableHeader>
            <TableRow className="bg-muted/50 hover:bg-muted/50">
              <TableHead className="w-32 pl-4">Reference</TableHead>
              <TableHead>Booking</TableHead>
              <TableHead>Dates</TableHead>
              <TableHead className="text-right">Pax</TableHead>
              <TableHead>Owner</TableHead>
              <TableHead className="pr-4">Stage</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {results.map((b) => (
              <TableRow
                key={b._id}
                className="cursor-pointer"
                onClick={() => navigate(`/bookings/${b._id}`)}
              >
                <TableCell className="pl-4 font-mono text-xs text-muted-foreground">
                  {b.reference}
                </TableCell>
                <TableCell className="max-w-72">
                  <p className="truncate font-medium">{b.title}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    {b.clientName} · {b.destination} · {TYPE_LABELS[b.type]}
                  </p>
                </TableCell>
                <TableCell className="text-sm whitespace-nowrap">
                  {formatDateRange(b.startDate, b.endDate)}
                </TableCell>
                <TableCell className="text-right tabular-nums">{b.pax}</TableCell>
                <TableCell className="max-w-36 truncate text-sm text-muted-foreground">
                  {b.ownerName ?? "Unassigned"}
                </TableCell>
                <TableCell className="pr-4">
                  <StageMenu bookingId={b._id} stage={b.stage} />
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      {/* Mobile cards */}
      <div className="space-y-2 md:hidden">
        {results.map((b) => (
          <Card
            key={b._id}
            className="cursor-pointer gap-2 px-4 py-3"
            onClick={() => navigate(`/bookings/${b._id}`)}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="font-mono text-xs text-muted-foreground">
                {b.reference}
              </span>
              <StageMenu bookingId={b._id} stage={b.stage} />
            </div>
            <p className="font-medium">{b.title}</p>
            <div className="flex flex-wrap gap-x-3 gap-y-1 text-xs text-muted-foreground">
              <span className="flex items-center gap-1">
                <MapPin className="size-3" />
                {b.destination}
              </span>
              <span className="flex items-center gap-1">
                <CalendarDays className="size-3" />
                {formatDateRange(b.startDate, b.endDate)}
              </span>
              <span className="flex items-center gap-1">
                <Users className="size-3" />
                {b.pax}
              </span>
            </div>
          </Card>
        ))}
      </div>

      {status === "CanLoadMore" || status === "LoadingMore" ? (
        <div className="flex justify-center">
          <Button
            variant="secondary"
            size="sm"
            className="cursor-pointer"
            disabled={status === "LoadingMore"}
            onClick={() => loadMore(PAGE_SIZE)}
          >
            {status === "LoadingMore" ? "Loading…" : "Load more"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
