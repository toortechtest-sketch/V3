import { Link } from "react-router-dom";
import { useQuery } from "convex/react";
import { Users } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import StageMenu from "@/components/bookings/stage-menu.tsx";
import {
  BOARD_STAGES,
  STAGE_META,
  TYPE_LABELS,
  formatDateRange,
} from "@/lib/bookings.ts";
import { cn } from "@/lib/utils.ts";

const LOADING_COLUMNS = BOARD_STAGES.map((stage) => ({
  stage,
  bookings: null,
  hasMore: false,
}));

export default function BookingBoard({ mineOnly }: { mineOnly: boolean }) {
  const columns = useQuery(api.bookings.board, { mineOnly });

  return (
    <div className="space-y-2">
    <div className="-mx-4 overflow-x-auto px-4 pb-2 sm:-mx-6 sm:px-6 lg:-mx-8 lg:px-8">
      <div className="flex min-w-max gap-3">
        {(columns ?? LOADING_COLUMNS).map(
          (col) => (
            <section
              key={col.stage}
              className="flex w-72 shrink-0 flex-col rounded-xl border bg-muted/40"
            >
              <header className="flex items-center gap-2 border-b px-3 py-2.5">
                <span
                  className={cn("size-2 rounded-full", STAGE_META[col.stage].dot)}
                />
                <h2 className="text-sm font-semibold">
                  {STAGE_META[col.stage].label}
                </h2>
                <span className="ml-auto font-mono text-xs text-muted-foreground">
                  {col.bookings ? `${col.bookings.length}${col.hasMore ? "+" : ""}` : ""}
                </span>
              </header>
              <div className="flex max-h-[calc(100vh-280px)] min-h-32 flex-col gap-2 overflow-y-auto p-2">
                {col.bookings === null ? (
                  Array.from({ length: 2 }).map((_, i) => (
                    <Skeleton key={i} className="h-24 w-full rounded-lg" />
                  ))
                ) : col.bookings.length === 0 ? (
                  <p className="px-2 py-6 text-center text-xs text-muted-foreground">
                    {STAGE_META[col.stage].hint}
                  </p>
                ) : (
                  col.bookings.map((b) => (
                    <Link
                      key={b._id}
                      to={`/bookings/${b._id}`}
                      className="group block cursor-pointer space-y-2 rounded-lg border bg-card p-3 shadow-xs transition hover:-translate-y-px hover:border-primary/40 hover:shadow-sm"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-mono text-[11px] text-muted-foreground">
                          {b.reference}
                        </span>
                        <span className="text-[11px] text-muted-foreground">
                          {TYPE_LABELS[b.type]}
                        </span>
                      </div>
                      <p className="line-clamp-2 text-sm leading-snug font-medium group-hover:text-primary">
                        {b.title}
                      </p>
                      <p className="truncate text-xs text-muted-foreground">
                        {b.clientName} · {b.destination}
                      </p>
                      <div className="flex items-center justify-between gap-2 pt-1">
                        <span className="text-xs">
                          {formatDateRange(b.startDate, b.endDate)}
                        </span>
                        <span className="flex items-center gap-1 text-xs text-muted-foreground">
                          <Users className="size-3" />
                          {b.pax}
                        </span>
                      </div>
                      <div
                        onClick={(e) => e.preventDefault()}
                        className="pt-0.5"
                      >
                        <StageMenu bookingId={b._id} stage={b.stage} />
                      </div>
                    </Link>
                  ))
                )}
                {col.hasMore ? (
                  <p className="px-2 py-2 text-center text-xs text-muted-foreground">
                    Showing the first {col.bookings?.length}. Use the list view
                    to see all.
                  </p>
                ) : null}
              </div>
            </section>
          ),
        )}
      </div>
    </div>
    <p className="text-xs text-muted-foreground">
      Closed and cancelled bookings are in the list view.
    </p>
    </div>
  );
}
