import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { Columns3, List, Plus, Search } from "lucide-react";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import BookingFormDialog from "@/components/bookings/booking-form-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { useStaff } from "@/hooks/use-staff.ts";
import {
  BOOKING_STAGES,
  STAGE_META,
  type BookingStage,
} from "@/lib/bookings.ts";
import BookingBoard from "./_components/booking-board.tsx";
import BookingList from "./_components/booking-list.tsx";

type View = "list" | "board";

const isStage = (value: string | null): value is BookingStage =>
  BOOKING_STAGES.some((s) => s === value);

export default function BookingsPage() {
  const { isManager } = useStaff();
  const [params, setParams] = useSearchParams();
  const view: View = params.get("view") === "board" ? "board" : "list";
  const stageParam = params.get("stage");
  const stage = isStage(stageParam) ? stageParam : undefined;
  const mineOnly = params.get("mine") === "1";

  const [search, setSearch] = useState("");
  const [debouncedSearch] = useDebounce(search.trim(), 300);
  const [creating, setCreating] = useState(false);

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(params);
    if (value === null) next.delete(key);
    else next.set(key, value);
    setParams(next, { replace: true });
  };

  return (
    <PageContainer className="max-w-[1600px]">
      <PageHeader
        title="Bookings & events"
        description={
          isManager
            ? "Every booking across the team, from first enquiry to close."
            : "Bookings you're responsible for, from first enquiry to close."
        }
        actions={
          <Button className="cursor-pointer" onClick={() => setCreating(true)}>
            <Plus className="size-4" /> New booking
          </Button>
        }
      />

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <Tabs value={view} onValueChange={(v) => setParam("view", v === "board" ? "board" : null)}>
          <TabsList>
            <TabsTrigger value="list" className="cursor-pointer">
              <List className="size-4" /> List
            </TabsTrigger>
            <TabsTrigger value="board" className="cursor-pointer">
              <Columns3 className="size-4" /> Booking stages
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {view === "list" ? (
          <div className="flex flex-1 flex-col gap-3 sm:flex-row">
            <div className="relative flex-1 lg:max-w-sm">
              <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search reference, title, client, destination"
                className="pl-9"
              />
            </div>
            <Select
              value={stage ?? "all"}
              onValueChange={(v) => setParam("stage", v === "all" ? null : v)}
            >
              <SelectTrigger className="cursor-pointer sm:w-44">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all" className="cursor-pointer">
                  All stages
                </SelectItem>
                {BOOKING_STAGES.map((s) => (
                  <SelectItem key={s} value={s} className="cursor-pointer">
                    {STAGE_META[s].label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ) : (
          <div className="flex-1" />
        )}

        {isManager ? (
          <div className="flex items-center gap-2">
            <Switch
              id="mine-only"
              checked={mineOnly}
              onCheckedChange={(c) => setParam("mine", c ? "1" : null)}
              className="cursor-pointer"
            />
            <Label htmlFor="mine-only" className="cursor-pointer text-sm">
              Only mine
            </Label>
          </div>
        ) : null}
      </div>

      {view === "list" ? (
        <BookingList
          stage={stage}
          search={debouncedSearch}
          mineOnly={mineOnly}
          onCreate={() => setCreating(true)}
        />
      ) : (
        <BookingBoard mineOnly={mineOnly} />
      )}

      <BookingFormDialog open={creating} onOpenChange={setCreating} />
    </PageContainer>
  );
}
