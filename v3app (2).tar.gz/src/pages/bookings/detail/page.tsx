import { useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { formatDistanceToNow, parseISO } from "date-fns";
import {
  ArrowLeft,
  CalendarDays,
  Check,
  Mail,
  MapPin,
  Pencil,
  Phone,
  SearchX,
  UserRound,
  Users,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { PageContainer } from "@/components/page-header.tsx";
import BookingFormDialog from "@/components/bookings/booking-form-dialog.tsx";
import StageMenu from "@/components/bookings/stage-menu.tsx";
import ItineraryPanel from "@/components/itinerary/itinerary-panel.tsx";
import QuotePanel from "@/components/quotes/quote-panel.tsx";
import FinancePanel from "@/components/finance/finance-panel.tsx";
import ReservationsPanel from "@/components/reservations/reservations-panel.tsx";
import BookingTasksPanel from "@/components/tasks/booking-tasks-panel.tsx";
import TravellersPanel from "@/components/travellers/travellers-panel.tsx";
import ShareLinksPanel from "@/components/share-links/share-links-panel.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  BOOKING_STAGES,
  STAGE_META,
  TYPE_LABELS,
  formatDateRange,
  nightCount,
  type BookingStage,
} from "@/lib/bookings.ts";
import { cn } from "@/lib/utils.ts";

// Cancelled sits outside the happy path, so the tracker shows the rest.
const PATH: readonly BookingStage[] = BOOKING_STAGES.filter(
  (s) => s !== "cancelled",
);

function StageTracker({ stage }: { stage: BookingStage }) {
  const current = PATH.indexOf(stage);
  return (
    <ol className="grid grid-cols-5 gap-1">
      {PATH.map((s, i) => {
        const done = current >= 0 && i < current;
        const active = i === current;
        return (
          <li key={s} className="space-y-2">
            <div
              className={cn(
                "h-1.5 rounded-full bg-border",
                (done || active) && STAGE_META[s].dot,
                stage === "cancelled" && "bg-border",
              )}
            />
            <p
              className={cn(
                "flex items-center gap-1 text-xs",
                active ? "font-semibold text-foreground" : "text-muted-foreground",
              )}
            >
              {done ? <Check className="size-3" /> : null}
              <span className="truncate">{STAGE_META[s].label}</span>
            </p>
          </li>
        );
      })}
    </ol>
  );
}

function Fact({
  icon: Icon,
  label,
  children,
}: {
  icon: typeof MapPin;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-3">
      <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
        <Icon className="size-4" />
      </div>
      <div className="min-w-0">
        <p className="text-xs text-muted-foreground">{label}</p>
        <div className="truncate font-medium">{children}</div>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: React.ReactNode }) {
  return (
    <div className="flex items-baseline justify-between gap-4 py-2">
      <dt className="text-sm text-muted-foreground">{label}</dt>
      <dd className="text-right text-sm font-medium">{value}</dd>
    </div>
  );
}

function NotFoundState() {
  return (
    <PageContainer>
      <Empty className="border">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <SearchX />
          </EmptyMedia>
          <EmptyTitle>Booking not found</EmptyTitle>
          <EmptyDescription>
            It may have been removed, or it isn't assigned to you.
          </EmptyDescription>
        </EmptyHeader>
        <EmptyContent>
          <Button asChild size="sm" className="cursor-pointer">
            <Link to="/bookings">Back to bookings</Link>
          </Button>
        </EmptyContent>
      </Empty>
    </PageContainer>
  );
}

function Overview({ id }: { id: string }) {
  const booking = useQuery(api.bookings.get, { id });
  const [editing, setEditing] = useState(false);
  const [params, setParams] = useSearchParams();
  const tabParam = params.get("tab");
  const tab =
    tabParam === "itinerary" ||
    tabParam === "quote" ||
    tabParam === "tasks" ||
    tabParam === "travellers" ||
    tabParam === "reservations" ||
    tabParam === "links" ||
    tabParam === "finance"
      ? tabParam
      : "overview";
  const setTab = (next: string) =>
    setParams(next === "overview" ? {} : { tab: next }, { replace: true });

  if (booking === null) return <NotFoundState />;
  if (booking === undefined) {
    return (
      <PageContainer>
        <Skeleton className="h-5 w-32" />
        <Skeleton className="h-10 w-2/3" />
        <Skeleton className="h-24 w-full" />
        <div className="grid gap-4 lg:grid-cols-3">
          <Skeleton className="h-56 lg:col-span-2" />
          <Skeleton className="h-56" />
        </div>
      </PageContainer>
    );
  }

  const nights = nightCount(booking.startDate, booking.endDate);
  const { ownerName, createdByName, canReassign: _canReassign, ...doc } =
    booking;

  return (
    <PageContainer>
      <Link
        to="/bookings"
        className="inline-flex cursor-pointer items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="size-4" /> Bookings
      </Link>

      <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded bg-sidebar px-2 py-0.5 font-mono text-xs text-sidebar-primary">
              {booking.reference}
            </span>
            <span className="text-sm text-muted-foreground">
              {TYPE_LABELS[booking.type]}
            </span>
            <StageMenu bookingId={booking._id} stage={booking.stage} />
          </div>
          <h1 className="font-display text-2xl font-semibold tracking-tight text-balance sm:text-3xl">
            {booking.title}
          </h1>
          <p className="text-muted-foreground">{booking.clientName}</p>
        </div>
        <Button
          variant="secondary"
          className="cursor-pointer"
          onClick={() => setEditing(true)}
        >
          <Pencil className="size-4" /> Edit brief
        </Button>
      </div>

      <Tabs value={tab} onValueChange={setTab} className="gap-4">
        <TabsList className="max-w-full justify-start overflow-x-auto [scrollbar-width:none]">
          <TabsTrigger value="overview" className="cursor-pointer">Overview</TabsTrigger>
          <TabsTrigger value="itinerary" className="cursor-pointer">Itinerary</TabsTrigger>
          <TabsTrigger value="quote" className="cursor-pointer">Quote</TabsTrigger>
          <TabsTrigger value="reservations" className="cursor-pointer">Reservations</TabsTrigger>
          <TabsTrigger value="travellers" className="cursor-pointer">Travellers</TabsTrigger>
          <TabsTrigger value="finance" className="cursor-pointer">Finance</TabsTrigger>
          <TabsTrigger value="tasks" className="cursor-pointer">Tasks</TabsTrigger>
          <TabsTrigger value="links" className="cursor-pointer">Client links</TabsTrigger>
        </TabsList>
        <TabsContent value="finance">
          <FinancePanel bookingId={booking._id} />
        </TabsContent>
        <TabsContent value="links">
          <ShareLinksPanel bookingId={booking._id} />
        </TabsContent>
        <TabsContent value="reservations">
          <ReservationsPanel
            bookingId={booking._id}
            reference={booking.reference}
            startDate={booking.startDate}
          />
        </TabsContent>
        <TabsContent value="tasks">
          <BookingTasksPanel bookingId={booking._id} />
        </TabsContent>
        <TabsContent value="travellers">
          <TravellersPanel bookingId={booking._id} reference={booking.reference} />
        </TabsContent>
        <TabsContent value="itinerary">
          <ItineraryPanel bookingId={booking._id} />
        </TabsContent>
        <TabsContent value="quote">
          <QuotePanel bookingId={booking._id} />
        </TabsContent>
        <TabsContent value="overview" className="space-y-6">
      <Card>
        <CardContent className="space-y-5">
          <StageTracker stage={booking.stage} />
          {booking.stage === "cancelled" ? (
            <p className="text-sm text-muted-foreground">
              This booking was cancelled. Move it back to a stage to reopen it.
            </p>
          ) : null}
          <div className="grid gap-4 border-t pt-5 sm:grid-cols-2 lg:grid-cols-4">
            <Fact icon={MapPin} label="Destination">
              {booking.destination}
            </Fact>
            <Fact icon={CalendarDays} label="Dates">
              {formatDateRange(booking.startDate, booking.endDate)}
              <span className="ml-1 text-sm font-normal text-muted-foreground">
                {nights === 0 ? "day trip" : `${nights} night${nights === 1 ? "" : "s"}`}
              </span>
            </Fact>
            <Fact icon={Users} label="Travellers">
              {booking.pax}
            </Fact>
            <Fact icon={UserRound} label="Responsible">
              {ownerName ?? "Unassigned"}
            </Fact>
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-4 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="font-display text-lg">Brief notes</CardTitle>
          </CardHeader>
          <CardContent>
            {booking.notes ? (
              <p className="text-sm leading-relaxed whitespace-pre-wrap">
                {booking.notes}
              </p>
            ) : (
              <p className="text-sm text-muted-foreground">
                No notes yet. Add requirements, preferences or anything the
                team should know.
              </p>
            )}
          </CardContent>
        </Card>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="font-display text-lg">Client contact</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2 text-sm">
              <p className="font-medium">
                {booking.clientContactName ?? booking.clientName}
              </p>
              {booking.clientContactEmail ? (
                <a
                  href={`mailto:${booking.clientContactEmail}`}
                  className="flex cursor-pointer items-center gap-2 text-primary hover:underline"
                >
                  <Mail className="size-4" />
                  <span className="truncate">{booking.clientContactEmail}</span>
                </a>
              ) : null}
              {booking.clientContactPhone ? (
                <a
                  href={`tel:${booking.clientContactPhone}`}
                  className="flex cursor-pointer items-center gap-2 text-primary hover:underline"
                >
                  <Phone className="size-4" />
                  {booking.clientContactPhone}
                </a>
              ) : null}
              {!booking.clientContactEmail && !booking.clientContactPhone ? (
                <p className="text-muted-foreground">No contact details yet.</p>
              ) : null}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="font-display text-lg">Commercials</CardTitle>
            </CardHeader>
            <CardContent>
              <dl className="divide-y">
                <Row label="Currency" value={booking.currency} />
                <Row
                  label="Rate to EUR"
                  value={booking.exchangeRateToBase.toLocaleString(undefined, {
                    maximumFractionDigits: 6,
                  })}
                />
                <Row
                  label="Default markup"
                  value={
                    booking.markupPercent !== undefined
                      ? `${booking.markupPercent}%`
                      : "Not set"
                  }
                />
              </dl>
            </CardContent>
          </Card>
        </div>
      </div>

      <p className="text-xs text-muted-foreground">
        Created by {createdByName ?? "someone"} on{" "}
        {new Date(booking._creationTime).toLocaleDateString(undefined, {
          dateStyle: "medium",
        })}
        {" · "}updated{" "}
        {formatDistanceToNow(parseISO(booking.updatedAt), { addSuffix: true })}
      </p>
        </TabsContent>
      </Tabs>

      <BookingFormDialog open={editing} onOpenChange={setEditing} booking={doc} />
    </PageContainer>
  );
}

export default function BookingDetailPage() {
  const { bookingId } = useParams();
  if (!bookingId) return <NotFoundState />;
  // Keyed so switching bookings resets local UI state like the edit dialog.
  return <Overview key={bookingId} id={bookingId} />;
}
