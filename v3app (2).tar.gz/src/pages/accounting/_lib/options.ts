import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import type { PickerOption } from "@/components/search-picker.tsx";
import { formatPlace } from "@/lib/clients.ts";

const RESULT_COUNT = 20;
const page = { numItems: RESULT_COUNT, cursor: null };

// Each hook is passed to SearchPicker as `useOptions`; null term = closed, so skip.

export function useClientOptions(term: string | null): PickerOption<Id<"clients">>[] | undefined {
  const result = useQuery(
    api.clients.list,
    term === null ? "skip" : { paginationOpts: page, search: term || undefined },
  );
  return result?.page.map((c) => ({
    id: c._id,
    label: c.name,
    hint: formatPlace(c.city, c.country) || undefined,
  }));
}

export function useSupplierOptions(term: string | null): PickerOption<Id<"suppliers">>[] | undefined {
  const result = useQuery(
    api.suppliers.list,
    term === null ? "skip" : { paginationOpts: page, search: term || undefined },
  );
  return result?.page.map((s) => ({ id: s._id, label: s.name, hint: s.city }));
}

export function useBookingOptions(term: string | null): PickerOption<Id<"bookings">>[] | undefined {
  const result = useQuery(
    api.bookings.list,
    term === null ? "skip" : { paginationOpts: page, search: term || undefined },
  );
  return result?.page.map((b) => ({ id: b._id, label: b.reference, hint: b.title }));
}
