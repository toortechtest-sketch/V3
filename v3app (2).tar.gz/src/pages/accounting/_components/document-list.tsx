import { usePaginatedQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import { FileSpreadsheet } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  KIND_META,
  PAYMENT_STATUS_META,
  formatMinor,
  localToday,
  paymentStatus,
  type DocumentKind,
  type DocumentState,
} from "@/lib/accounting.ts";
import { cn } from "@/lib/utils.ts";

const PAGE_SIZE = 30;

export default function DocumentList({
  kind,
  state,
  onOpen,
  onCreate,
}: {
  kind: DocumentKind | undefined;
  state: DocumentState | undefined;
  onOpen: (id: Id<"accountingDocuments">) => void;
  onCreate: () => void;
}) {
  const { results, status, loadMore } = usePaginatedQuery(
    api.accounting.documents.list,
    { kind, state },
    { initialNumItems: PAGE_SIZE },
  );
  const today = localToday();

  if (status === "LoadingFirstPage") {
    return (
      <Card className="gap-0 divide-y py-0">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 px-4 py-3">
            <div className="flex-1 space-y-1.5">
              <Skeleton className="h-4 w-48" />
              <Skeleton className="h-3 w-32" />
            </div>
            <Skeleton className="h-5 w-20" />
          </div>
        ))}
      </Card>
    );
  }

  if (results.length === 0 && status === "Exhausted") {
    const filtered = Boolean(kind || state);
    return (
      <Empty className="border bg-card">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <FileSpreadsheet />
          </EmptyMedia>
          <EmptyTitle>{filtered ? "Nothing matches" : "No documents yet"}</EmptyTitle>
          <EmptyDescription>
            {filtered
              ? "Try another filter."
              : "Create a client invoice or a supplier bill. It starts as a draft you can check before posting."}
          </EmptyDescription>
        </EmptyHeader>
        {filtered ? null : (
          <EmptyContent>
            <Button size="sm" className="cursor-pointer" onClick={onCreate}>
              New document
            </Button>
          </EmptyContent>
        )}
      </Empty>
    );
  }

  return (
    <div className="space-y-3">
      <Card className="gap-0 divide-y overflow-hidden py-0">
        {results.map((d) => {
          const s = PAYMENT_STATUS_META[paymentStatus(d, today)];
          const outstanding = d.state === "posted" ? d.totalMinor - d.paidMinor : 0;
          return (
            <button
              key={d._id}
              type="button"
              onClick={() => onOpen(d._id)}
              className="flex w-full cursor-pointer items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-muted/60"
            >
              <div
                className={cn(
                  "w-1 self-stretch rounded-full",
                  d.kind === "invoice" ? "bg-primary" : "bg-[#F47A12]",
                )}
              />
              <div className="min-w-0 flex-1">
                <p className="flex items-center gap-2 truncate font-medium">
                  <span className="font-mono text-sm">{d.number ?? "Draft"}</span>
                  <span className="truncate">{d.partyName}</span>
                </p>
                <p className="truncate text-xs text-muted-foreground">
                  {KIND_META[d.kind].label} · {format(parseISO(d.issueDate), "d MMM yyyy")} ·{" "}
                  {d.reference}
                  {d.bookingReference ? ` · ${d.bookingReference}` : ""}
                </p>
              </div>
              <div className="flex shrink-0 flex-col items-end gap-1">
                <span className="font-mono text-sm font-medium">{formatMinor(d.totalMinor, d.currency)}</span>
                <div className="flex items-center gap-2">
                  {outstanding > 0 && outstanding < d.totalMinor ? (
                    <span className="hidden font-mono text-xs text-muted-foreground sm:inline">
                      {formatMinor(outstanding, d.currency)} due
                    </span>
                  ) : null}
                  <Badge className={cn("border-0", s.badge)}>{s.label}</Badge>
                </div>
              </div>
            </button>
          );
        })}
      </Card>
      {status === "CanLoadMore" || status === "LoadingMore" ? (
        <div className="flex justify-center">
          <Button
            variant="secondary"
            size="sm"
            className="cursor-pointer"
            disabled={status === "LoadingMore"}
            onClick={() => loadMore(PAGE_SIZE)}
          >
            {status === "LoadingMore" ? "Loading…" : "Load more"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}
