import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { formatMinor, localToday, minorToInput, parseMinor } from "@/lib/accounting.ts";
import { errorMessage } from "@/lib/errors.ts";

type Mode = "payment" | "reverse";

/** Record a payment against, or reverse, a posted document. */
export default function DocumentActionDialog({
  doc,
  mode,
  onClose,
}: {
  doc: Doc<"accountingDocuments">;
  mode: Mode | null;
  onClose: () => void;
}) {
  const outstanding = doc.totalMinor - doc.paidMinor;
  const [amount, setAmount] = useState(minorToInput(outstanding));
  const [date, setDate] = useState(localToday());
  const [text, setText] = useState("");
  const [saving, setSaving] = useState(false);
  const pay = useMutation(api.accounting.documents.recordPayment);
  const reverse = useMutation(api.accounting.documents.reverse);

  const isPayment = mode === "payment";
  const amountMinor = parseMinor(amount);
  const invalid =
    !date || !text.trim() || (isPayment && (amountMinor === null || amountMinor <= 0 || amountMinor > outstanding));

  const submit = async () => {
    setSaving(true);
    try {
      if (isPayment) {
        await pay({ id: doc._id, amountMinor: amountMinor ?? 0, date, reference: text });
        toast.success(doc.kind === "invoice" ? "Payment received recorded" : "Payment made recorded");
      } else {
        await reverse({ id: doc._id, date, reason: text });
        toast.success(`${doc.number ?? "Document"} reversed`);
      }
      onClose();
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={mode !== null} onOpenChange={(o) => (o ? null : onClose())}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {isPayment
              ? doc.kind === "invoice"
                ? "Record money received"
                : "Record money paid"
              : `Reverse ${doc.number}`}
          </DialogTitle>
          <DialogDescription>
            {isPayment
              ? `Outstanding: ${formatMinor(outstanding, doc.currency)}. This records the payment in the ledger; it doesn't move money.`
              : "Writes an equal and opposite entry so the document no longer counts. It stays on file for the audit trail."}
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4">
          {isPayment ? (
            <div className="space-y-2">
              <Label htmlFor="pay-amount">Amount ({doc.currency})</Label>
              <Input
                id="pay-amount"
                inputMode="decimal"
                className="font-mono"
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
              />
            </div>
          ) : null}
          <div className="space-y-2">
            <Label htmlFor="action-date">{isPayment ? "Paid on" : "Reversal date"}</Label>
            <Input id="action-date" type="date" value={date} onChange={(e) => setDate(e.target.value)} />
          </div>
          <div className="space-y-2">
            <Label htmlFor="action-text">{isPayment ? "Bank reference" : "Reason"}</Label>
            <Input
              id="action-text"
              value={text}
              maxLength={isPayment ? 200 : 500}
              placeholder={isPayment ? "SEPA transfer 4471" : "Duplicate of INV-0000012"}
              onChange={(e) => setText(e.target.value)}
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" className="cursor-pointer" onClick={onClose}>
            Cancel
          </Button>
          <Button
            variant={isPayment ? "default" : "destructive"}
            disabled={saving || invalid}
            className="cursor-pointer"
            onClick={submit}
          >
            {saving ? <Spinner /> : null}
            {isPayment ? "Record payment" : "Reverse document"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
