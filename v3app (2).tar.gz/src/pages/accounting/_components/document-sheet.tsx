import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import { ArrowUpRight, Banknote, Pencil, Send, Trash2, Undo2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Separator } from "@/components/ui/separator.tsx";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import {
  KIND_META,
  PAYMENT_STATUS_META,
  formatMinor,
  localToday,
  paymentStatus,
} from "@/lib/accounting.ts";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import DocumentActionDialog from "./document-action-dialog.tsx";
import DocumentDialog from "./document-dialog.tsx";

const day = (d: string) => format(parseISO(d), "d MMM yyyy");
const EVENT_LABELS = { issue: "Posted", payment: "Payment", reversal: "Reversal" } as const;

function Body({ id }: { id: Id<"accountingDocuments"> }) {
  const doc = useQuery(api.accounting.documents.get, { id });
  const post = useMutation(api.accounting.documents.post);
  const remove = useMutation(api.accounting.documents.deleteDraft);
  const [busy, setBusy] = useState(false);
  const [editing, setEditing] = useState(false);
  const [action, setAction] = useState<"payment" | "reverse" | null>(null);

  if (doc === undefined) {
    return (
      <div className="space-y-3 p-4">
        <Skeleton className="h-6 w-40" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-24 w-full" />
      </div>
    );
  }
  if (doc === null) {
    return <p className="p-4 text-sm text-muted-foreground">This document was deleted.</p>;
  }

  const meta = KIND_META[doc.kind];
  const status = PAYMENT_STATUS_META[paymentStatus(doc, localToday())];
  const outstanding = doc.totalMinor - doc.paidMinor;
  const money = (n: number) => formatMinor(n, doc.currency);

  const run = async (fn: () => Promise<unknown>, success: string) => {
    setBusy(true);
    try {
      await fn();
      toast.success(success);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <>
      <SheetHeader className="border-b">
        <div className="flex items-center gap-2">
          <Badge className={cn("border-0", status.badge)}>{status.label}</Badge>
          <span className="text-xs text-muted-foreground">{meta.label}</span>
        </div>
        <SheetTitle className="font-display text-2xl">{doc.number ?? "Draft"}</SheetTitle>
        <SheetDescription className="truncate">
          {doc.partyName} · {doc.reference}
        </SheetDescription>
      </SheetHeader>

      <div className="flex-1 space-y-5 overflow-y-auto px-4">
        <dl className="grid grid-cols-2 gap-3 text-sm">
          <div>
            <dt className="text-xs text-muted-foreground">Issued</dt>
            <dd className="font-medium">{day(doc.issueDate)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">Due</dt>
            <dd className="font-medium">{day(doc.dueDate)}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">Account</dt>
            <dd className="font-mono font-medium">{doc.accountCode}</dd>
          </div>
          <div>
            <dt className="text-xs text-muted-foreground">Booking</dt>
            <dd className="font-medium">
              {doc.bookingId && doc.bookingReference ? (
                <Link
                  to={`/bookings/${doc.bookingId}`}
                  className="inline-flex items-center gap-0.5 text-primary hover:underline"
                >
                  {doc.bookingReference} <ArrowUpRight className="size-3" />
                </Link>
              ) : (
                "–"
              )}
            </dd>
          </div>
        </dl>

        <div className="space-y-2">
          {doc.items.map((item, i) => (
            <div key={i} className="flex items-start justify-between gap-3 text-sm">
              <span className="min-w-0 break-words">{item.description}</span>
              <span className="shrink-0 font-mono">{money(item.netMinor + item.taxMinor)}</span>
            </div>
          ))}
          <Separator />
          <dl className="space-y-1 font-mono text-sm">
            <div className="flex justify-between text-muted-foreground">
              <dt>Net</dt>
              <dd>{money(doc.netMinor)}</dd>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <dt>Tax</dt>
              <dd>{money(doc.taxMinor)}</dd>
            </div>
            <div className="flex justify-between font-semibold">
              <dt>Total</dt>
              <dd>{money(doc.totalMinor)}</dd>
            </div>
            {doc.state === "posted" ? (
              <div className="flex justify-between font-semibold text-primary">
                <dt>Outstanding</dt>
                <dd>{money(outstanding)}</dd>
              </div>
            ) : null}
          </dl>
        </div>

        {doc.reversalReason ? (
          <p className="rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
            Reversed: {doc.reversalReason}
          </p>
        ) : null}

        {doc.payments.length ? (
          <div className="space-y-2">
            <p className="text-xs font-medium tracking-wider text-muted-foreground uppercase">Payments</p>
            {doc.payments.map((p) => (
              <div key={p._id} className="flex justify-between gap-3 text-sm">
                <span className="min-w-0 truncate">
                  {day(p.date)} · {p.reference}
                </span>
                <span className="shrink-0 font-mono">{money(p.amountMinor)}</span>
              </div>
            ))}
          </div>
        ) : null}

        {doc.journals.length ? (
          <div className="space-y-2">
            <p className="text-xs font-medium tracking-wider text-muted-foreground uppercase">
              Ledger entries
            </p>
            {doc.journals.map((j) => (
              <div key={j._id} className="rounded-lg border p-3 text-xs">
                <p className="pb-1.5 font-medium">
                  {EVENT_LABELS[j.event]} · {day(j.date)}
                </p>
                <div className="space-y-0.5 font-mono">
                  {j.entries.map((e, i) => (
                    <div key={i} className="grid grid-cols-[3rem_1fr_1fr] gap-2">
                      <span>{e.account}</span>
                      <span className="text-right">{e.debit ? money(e.debit) : ""}</span>
                      <span className="text-right text-muted-foreground">
                        {e.credit ? money(e.credit) : ""}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : null}
      </div>

      <div className="flex flex-wrap gap-2 border-t p-4">
        {doc.state === "draft" ? (
          <>
            <Button
              className="cursor-pointer"
              disabled={busy}
              onClick={() => run(() => post({ id: doc._id }), `${meta.label} posted`)}
            >
              {busy ? <Spinner /> : <Send className="size-4" />} Post to ledger
            </Button>
            <Button variant="secondary" className="cursor-pointer" onClick={() => setEditing(true)}>
              <Pencil className="size-4" /> Edit
            </Button>
            <Button
              variant="ghost"
              className="cursor-pointer text-destructive"
              disabled={busy}
              onClick={() => run(() => remove({ id: doc._id }), "Draft deleted")}
            >
              <Trash2 className="size-4" /> Delete
            </Button>
          </>
        ) : null}
        {doc.state === "posted" && outstanding > 0 ? (
          <Button className="cursor-pointer" onClick={() => setAction("payment")}>
            <Banknote className="size-4" /> Record payment
          </Button>
        ) : null}
        {doc.state === "posted" && doc.paidMinor === 0 ? (
          <Button variant="ghost" className="cursor-pointer text-destructive" onClick={() => setAction("reverse")}>
            <Undo2 className="size-4" /> Reverse
          </Button>
        ) : null}
      </div>

      {editing ? (
        <DocumentDialog open onOpenChange={setEditing} currency={doc.currency} doc={doc} />
      ) : null}
      {action ? <DocumentActionDialog doc={doc} mode={action} onClose={() => setAction(null)} /> : null}
    </>
  );
}

export default function DocumentSheet({
  id,
  onClose,
}: {
  id: Id<"accountingDocuments"> | null;
  onClose: () => void;
}) {
  return (
    <Sheet open={id !== null} onOpenChange={(o) => (o ? null : onClose())}>
      <SheetContent className="w-full gap-0 sm:max-w-md">{id ? <Body key={id} id={id} /> : null}</SheetContent>
    </Sheet>
  );
}
