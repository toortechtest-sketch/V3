import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import { Lock, Plus } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { ACCOUNT_TYPES, ACCOUNT_TYPE_LABELS, localToday, type AccountType } from "@/lib/accounting.ts";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";

function AddAccount() {
  const create = useMutation(api.accounting.setup.createAccount);
  const [code, setCode] = useState("");
  const [name, setName] = useState("");
  const [type, setType] = useState<AccountType>("expense");
  const [saving, setSaving] = useState(false);
  const valid = /^\d{4}$/.test(code.trim()) && name.trim().length > 0;

  const submit = async () => {
    setSaving(true);
    try {
      await create({ code, name, type });
      toast.success(`Account ${code.trim()} added`);
      setCode("");
      setName("");
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="grid gap-2 rounded-lg bg-muted/50 p-3 sm:grid-cols-[5rem_1fr_9rem_auto] sm:items-end">
      <div className="space-y-1">
        <Label htmlFor="acc-code" className="text-xs">Code</Label>
        <Input
          id="acc-code"
          inputMode="numeric"
          maxLength={4}
          placeholder="5100"
          className="font-mono"
          value={code}
          onChange={(e) => setCode(e.target.value)}
        />
      </div>
      <div className="space-y-1">
        <Label htmlFor="acc-name" className="text-xs">Name</Label>
        <Input
          id="acc-name"
          maxLength={80}
          placeholder="Hotel costs"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
      </div>
      <div className="space-y-1">
        <Label className="text-xs">Type</Label>
        <Select value={type} onValueChange={(v) => setType(v as AccountType)}>
          <SelectTrigger className="w-full cursor-pointer">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {ACCOUNT_TYPES.map((t) => (
              <SelectItem key={t} value={t} className="cursor-pointer">
                {ACCOUNT_TYPE_LABELS[t]}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Button className="cursor-pointer" disabled={!valid || saving} onClick={submit}>
        {saving ? <Spinner /> : <Plus className="size-4" />} Add
      </Button>
    </div>
  );
}

function AccountRow({ account }: { account: Doc<"accountingAccounts"> }) {
  const setActive = useMutation(api.accounting.setup.setAccountActive);
  return (
    <div className={cn("flex items-center gap-3 py-2.5", !account.active && "opacity-55")}>
      <span className="w-12 shrink-0 font-mono text-sm text-muted-foreground">{account.code}</span>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">{account.name}</p>
        <p className="text-xs text-muted-foreground">{ACCOUNT_TYPE_LABELS[account.type]}</p>
      </div>
      {account.system ? (
        <Badge variant="secondary" className="shrink-0 text-[10px]">Automatic</Badge>
      ) : (
        <Switch
          aria-label={`${account.name} active`}
          className="cursor-pointer"
          checked={account.active}
          onCheckedChange={(active) =>
            setActive({ id: account._id, active }).catch((e: unknown) => toast.error(errorMessage(e)))
          }
        />
      )}
    </div>
  );
}

export function ChartOfAccounts() {
  const accounts = useQuery(api.accounting.setup.listAccounts, {});
  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-lg">Chart of accounts</CardTitle>
        <CardDescription>
          Automatic accounts are posted to by invoices, bills and payments. Add your own for
          finer revenue and cost reporting.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <AddAccount />
        {accounts === undefined ? (
          <div className="space-y-2">
            {Array.from({ length: 5 }).map((_, i) => (
              <Skeleton key={i} className="h-10 w-full" />
            ))}
          </div>
        ) : (
          <div className="divide-y">
            {accounts.map((a) => (
              <AccountRow key={a._id} account={a} />
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

export function PeriodClose({ closedThrough }: { closedThrough: string | undefined }) {
  const close = useMutation(api.accounting.setup.closePeriod);
  const [through, setThrough] = useState("");
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    setSaving(true);
    try {
      await close({ through });
      toast.success(`Books closed through ${format(parseISO(through), "d MMM yyyy")}`);
      setThrough("");
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2 font-display text-lg">
          <Lock className="size-4 text-primary" /> Close a period
        </CardTitle>
        <CardDescription>
          {closedThrough
            ? `Books are closed through ${format(parseISO(closedThrough), "d MMMM yyyy")}. `
            : "No period is closed yet. "}
          Closing locks every day up to the date you choose, so reported figures can&apos;t change.
          This can&apos;t be undone.
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-2 sm:flex-row sm:items-end">
        <div className="space-y-1">
          <Label htmlFor="close-through" className="text-xs">Close through</Label>
          <Input
            id="close-through"
            type="date"
            max={localToday()}
            min={closedThrough}
            value={through}
            onChange={(e) => setThrough(e.target.value)}
          />
        </div>
        <Button variant="secondary" className="cursor-pointer" disabled={!through || saving} onClick={submit}>
          {saving ? <Spinner /> : <Lock className="size-4" />} Close books
        </Button>
      </CardContent>
    </Card>
  );
}
