import { useState } from "react";
import { useQuery } from "convex/react";
import { AlertTriangle, Scale } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  ErrorState,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateMedia,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table.tsx";
import QueryErrorBoundary from "@/components/query-error-boundary.tsx";
import { ACCOUNT_TYPE_LABELS, formatMinor, localToday, naturalBalance } from "@/lib/accounting.ts";
import { cn } from "@/lib/utils.ts";

const startOfYear = () => `${localToday().slice(0, 4)}-01-01`;

function Stat({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-lg bg-muted/60 p-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={cn("font-mono text-lg font-semibold", tone)}>{value}</p>
    </div>
  );
}

function Report({ from, through }: { from: string; through: string }) {
  const report = useQuery(api.accounting.reports.trialBalance, {
    from: from || undefined,
    through,
  });
  if (report === undefined) {
    return (
      <div className="space-y-2">
        {Array.from({ length: 6 }).map((_, i) => (
          <Skeleton key={i} className="h-8 w-full" />
        ))}
      </div>
    );
  }
  const money = (n: number) => formatMinor(n, report.currency);
  const profit = report.totals.revenue - report.totals.expenses;
  const balanced = report.totals.debit === report.totals.credit;
  const rows = report.rows.filter((r) => r.debit || r.credit);

  return (
    <div className="space-y-4">
      <div className="grid gap-3 sm:grid-cols-3">
        <Stat label="Revenue" value={money(report.totals.revenue)} />
        <Stat label="Costs" value={money(report.totals.expenses)} />
        <Stat
          label="Gross profit"
          value={money(profit)}
          tone={profit < 0 ? "text-destructive" : "text-emerald-600 dark:text-emerald-400"}
        />
      </div>
      {rows.length === 0 ? (
        <p className="rounded-lg border border-dashed p-6 text-center text-sm text-muted-foreground">
          No ledger entries in this period yet.
        </p>
      ) : (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Account</TableHead>
              <TableHead className="text-right">Debits</TableHead>
              <TableHead className="text-right">Credits</TableHead>
              <TableHead className="hidden text-right sm:table-cell">Balance</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {rows.map((r) => (
              <TableRow key={r.code}>
                <TableCell className="max-w-48">
                  <p className="truncate font-medium">
                    <span className="font-mono text-muted-foreground">{r.code}</span> {r.name}
                  </p>
                  <p className="text-xs text-muted-foreground">{ACCOUNT_TYPE_LABELS[r.type]}</p>
                </TableCell>
                <TableCell className="text-right font-mono">{r.debit ? money(r.debit) : "–"}</TableCell>
                <TableCell className="text-right font-mono">{r.credit ? money(r.credit) : "–"}</TableCell>
                <TableCell className="hidden text-right font-mono font-medium sm:table-cell">
                  {money(naturalBalance(r))}
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
          <TableFooter>
            <TableRow>
              <TableCell className="font-semibold">Total</TableCell>
              <TableCell className="text-right font-mono font-semibold">{money(report.totals.debit)}</TableCell>
              <TableCell className="text-right font-mono font-semibold">{money(report.totals.credit)}</TableCell>
              <TableCell className="hidden text-right sm:table-cell">
                <span
                  className={cn(
                    "inline-flex items-center gap-1 text-xs",
                    balanced ? "text-emerald-600 dark:text-emerald-400" : "text-destructive",
                  )}
                >
                  <Scale className="size-3" /> {balanced ? "Balanced" : "Out of balance"}
                </span>
              </TableCell>
            </TableRow>
          </TableFooter>
        </Table>
      )}
    </div>
  );
}

function ReportError() {
  return (
    <ErrorState>
      <ErrorStateHeader>
        <ErrorStateMedia variant="icon">
          <AlertTriangle />
        </ErrorStateMedia>
        <ErrorStateTitle>Report couldn&apos;t load</ErrorStateTitle>
        <ErrorStateDescription>Check the dates, or choose a shorter period.</ErrorStateDescription>
      </ErrorStateHeader>
    </ErrorState>
  );
}

export default function TrialBalance() {
  const [from, setFrom] = useState(startOfYear);
  const [through, setThrough] = useState(localToday);
  return (
    <Card>
      <CardHeader className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <CardTitle className="font-display text-lg">Trial balance</CardTitle>
        <div className="flex gap-2">
          <div className="space-y-1">
            <Label htmlFor="tb-from" className="text-xs">From</Label>
            <Input id="tb-from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </div>
          <div className="space-y-1">
            <Label htmlFor="tb-to" className="text-xs">Through</Label>
            <Input
              id="tb-to"
              type="date"
              value={through}
              onChange={(e) => e.target.value && setThrough(e.target.value)}
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <QueryErrorBoundary key={`${from}-${through}`} fallback={<ReportError />}>
          <Report from={from} through={through} />
        </QueryErrorBoundary>
      </CardContent>
    </Card>
  );
}
