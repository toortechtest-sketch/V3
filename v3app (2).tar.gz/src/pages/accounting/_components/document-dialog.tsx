import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { BookOpenCheck, Building2, Plus, Store, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import SearchPicker, { type PickerOption } from "@/components/search-picker.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group.tsx";
import {
  KIND_META,
  addDays,
  formatMinor,
  localToday,
  minorToInput,
  parseMinor,
  type DocumentKind,
} from "@/lib/accounting.ts";
import { errorMessage } from "@/lib/errors.ts";
import { useBookingOptions, useClientOptions, useSupplierOptions } from "../_lib/options.ts";

type Line = { key: number; description: string; net: string; tax: string };
type Party = PickerOption<Id<"clients">> | PickerOption<Id<"suppliers">>;

type State = {
  kind: DocumentKind;
  client: PickerOption<Id<"clients">> | null;
  supplier: PickerOption<Id<"suppliers">> | null;
  booking: PickerOption<Id<"bookings">> | null;
  accountCode: string;
  issueDate: string;
  dueDate: string;
  reference: string;
  lines: Line[];
};

let lineKey = 0;
const blankLine = (): Line => ({ key: ++lineKey, description: "", net: "", tax: "0" });

function initialState(kind: DocumentKind, doc?: Doc<"accountingDocuments">): State {
  if (!doc) {
    const today = localToday();
    return {
      kind,
      client: null,
      supplier: null,
      booking: null,
      accountCode: kind === "invoice" ? "4000" : "5000",
      issueDate: today,
      dueDate: addDays(today, 30),
      reference: "",
      lines: [blankLine()],
    };
  }
  return {
    kind: doc.kind,
    client: doc.clientId ? { id: doc.clientId, label: doc.partyName } : null,
    supplier: doc.supplierId ? { id: doc.supplierId, label: doc.partyName } : null,
    booking:
      doc.bookingId && doc.bookingReference
        ? { id: doc.bookingId, label: doc.bookingReference }
        : null,
    accountCode: doc.accountCode,
    issueDate: doc.issueDate,
    dueDate: doc.dueDate,
    reference: doc.reference,
    lines: doc.items.map((i) => ({
      key: ++lineKey,
      description: i.description,
      net: minorToInput(i.netMinor),
      tax: minorToInput(i.taxMinor),
    })),
  };
}

/** Mount only while open so each opening starts from fresh state. */
export default function DocumentDialog({
  open,
  onOpenChange,
  currency,
  defaultKind = "invoice",
  doc,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  currency: string;
  defaultKind?: DocumentKind;
  /** Pass a draft to edit it. */
  doc?: Doc<"accountingDocuments">;
}) {
  const [state, setState] = useState(() => initialState(defaultKind, doc));
  const [saving, setSaving] = useState(false);
  const [showErrors, setShowErrors] = useState(false);
  const accounts = useQuery(api.accounting.setup.listAccounts, open ? {} : "skip");
  const create = useMutation(api.accounting.documents.createDraft);
  const update = useMutation(api.accounting.documents.updateDraft);

  const set = (patch: Partial<State>) => setState((s) => ({ ...s, ...patch }));
  const setLine = (key: number, patch: Partial<Line>) =>
    set({ lines: state.lines.map((l) => (l.key === key ? { ...l, ...patch } : l)) });

  const meta = KIND_META[state.kind];
  const party: Party | null = state.kind === "invoice" ? state.client : state.supplier;
  const accountOptions = (accounts ?? []).filter(
    (a) => a.type === meta.accountType && (a.active || a.code === state.accountCode),
  );
  const parsed = state.lines.map((l) => ({
    description: l.description.trim(),
    netMinor: parseMinor(l.net),
    taxMinor: parseMinor(l.tax || "0"),
  }));
  const net = parsed.reduce((s, l) => s + (l.netMinor ?? 0), 0);
  const tax = parsed.reduce((s, l) => s + (l.taxMinor ?? 0), 0);

  const problems = [
    !party && `Choose the ${meta.party.toLowerCase()}.`,
    !state.reference.trim() && "Add a reference.",
    (!state.issueDate || !state.dueDate) && "Add both dates.",
    state.dueDate < state.issueDate && "The due date can't be before the issue date.",
    parsed.some((l) => !l.description) && "Every line needs a description.",
    parsed.some((l) => l.netMinor === null || l.taxMinor === null) &&
      "Enter amounts like 1200 or 1200.50.",
    net <= 0 && "The net total must be above zero.",
  ].filter((p): p is string => typeof p === "string");

  const handleOpenChange = (next: boolean) => {
    if (!next) setShowErrors(false);
    onOpenChange(next);
  };

  const submit = async () => {
    if (problems.length) {
      setShowErrors(true);
      return;
    }
    setSaving(true);
    const args = {
      kind: state.kind,
      clientId: state.kind === "invoice" ? state.client?.id : undefined,
      supplierId: state.kind === "bill" ? state.supplier?.id : undefined,
      bookingId: state.booking?.id,
      accountCode: state.accountCode,
      issueDate: state.issueDate,
      dueDate: state.dueDate,
      reference: state.reference,
      items: parsed.map((l) => ({
        description: l.description,
        netMinor: l.netMinor ?? 0,
        taxMinor: l.taxMinor ?? 0,
      })),
    };
    try {
      if (doc) {
        await update({ id: doc._id, ...args });
        toast.success("Draft saved");
      } else {
        await create(args);
        toast.success(`${meta.label} draft created`);
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {doc ? `Edit ${meta.label.toLowerCase()} draft` : "New accounting document"}
          </DialogTitle>
          <DialogDescription>
            Saved as a draft. Nothing reaches the ledger until you post it.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-2">
          {doc ? null : (
            <div className="space-y-2 sm:col-span-2">
              <Label>Type</Label>
              <ToggleGroup
                type="single"
                variant="outline"
                value={state.kind}
                onValueChange={(v) => {
                  if (v === "invoice" || v === "bill") {
                    set({ kind: v, accountCode: v === "invoice" ? "4000" : "5000" });
                  }
                }}
                className="w-full"
              >
                <ToggleGroupItem value="invoice" className="flex-1 cursor-pointer">
                  Client invoice
                </ToggleGroupItem>
                <ToggleGroupItem value="bill" className="flex-1 cursor-pointer">
                  Supplier bill
                </ToggleGroupItem>
              </ToggleGroup>
            </div>
          )}

          <div className="space-y-2">
            <Label>{meta.party}</Label>
            {state.kind === "invoice" ? (
              <SearchPicker
                value={state.client}
                onChange={(client) => set({ client })}
                useOptions={useClientOptions}
                icon={Building2}
                placeholder="Choose a client"
                searchPlaceholder="Search clients"
                emptyText="No clients found."
              />
            ) : (
              <SearchPicker
                value={state.supplier}
                onChange={(supplier) => set({ supplier })}
                useOptions={useSupplierOptions}
                icon={Store}
                placeholder="Choose a supplier"
                searchPlaceholder="Search suppliers"
                emptyText="No suppliers found."
              />
            )}
          </div>

          <div className="space-y-2">
            <Label>Booking</Label>
            <SearchPicker
              value={state.booking}
              onChange={(booking) => set({ booking })}
              useOptions={useBookingOptions}
              icon={BookOpenCheck}
              placeholder="Link a booking (optional)"
              searchPlaceholder="Search bookings"
              emptyText="No bookings found."
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="doc-reference">Reference</Label>
            <Input
              id="doc-reference"
              value={state.reference}
              maxLength={200}
              placeholder={state.kind === "invoice" ? "Deposit, Barcelona incentive" : "Supplier invoice 2026-118"}
              onChange={(e) => set({ reference: e.target.value })}
            />
          </div>

          <div className="space-y-2">
            <Label>{meta.accountType === "revenue" ? "Revenue account" : "Expense account"}</Label>
            <Select value={state.accountCode} onValueChange={(accountCode) => set({ accountCode })}>
              <SelectTrigger className="w-full cursor-pointer">
                <SelectValue placeholder="Loading…" />
              </SelectTrigger>
              <SelectContent>
                {accountOptions.map((a) => (
                  <SelectItem key={a.code} value={a.code} className="cursor-pointer">
                    {a.code} · {a.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="doc-issue">Issue date</Label>
            <Input
              id="doc-issue"
              type="date"
              value={state.issueDate}
              onChange={(e) => set({ issueDate: e.target.value })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="doc-due">Due date</Label>
            <Input
              id="doc-due"
              type="date"
              value={state.dueDate}
              onChange={(e) => set({ dueDate: e.target.value })}
            />
          </div>
        </div>

        <div className="space-y-2">
          <div className="hidden grid-cols-[1fr_7rem_7rem_2.25rem] gap-2 px-1 text-xs text-muted-foreground sm:grid">
            <span>Description</span>
            <span>Net ({currency})</span>
            <span>Tax ({currency})</span>
          </div>
          {state.lines.map((line) => (
            <div
              key={line.key}
              className="grid grid-cols-[1fr_1fr_2.25rem] gap-2 rounded-lg bg-muted/50 p-2 sm:grid-cols-[1fr_7rem_7rem_2.25rem] sm:bg-transparent sm:p-0"
            >
              <Input
                aria-label="Description"
                value={line.description}
                maxLength={500}
                placeholder="Group programme, 24 guests"
                className="col-span-3 sm:col-span-1"
                onChange={(e) => setLine(line.key, { description: e.target.value })}
              />
              <Input
                aria-label="Net amount"
                inputMode="decimal"
                value={line.net}
                placeholder="Net"
                className="font-mono"
                onChange={(e) => setLine(line.key, { net: e.target.value })}
              />
              <Input
                aria-label="Tax amount"
                inputMode="decimal"
                value={line.tax}
                placeholder="Tax"
                className="font-mono"
                onChange={(e) => setLine(line.key, { tax: e.target.value })}
              />
              <Button
                type="button"
                variant="ghost"
                size="icon"
                aria-label="Remove line"
                className="cursor-pointer"
                disabled={state.lines.length === 1}
                onClick={() => set({ lines: state.lines.filter((l) => l.key !== line.key) })}
              >
                <Trash2 className="size-4" />
              </Button>
            </div>
          ))}
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="cursor-pointer"
            disabled={state.lines.length >= 100}
            onClick={() => set({ lines: [...state.lines, blankLine()] })}
          >
            <Plus className="size-4" /> Add line
          </Button>
        </div>

        <dl className="ml-auto w-full max-w-xs space-y-1 rounded-lg bg-muted/60 p-3 font-mono text-sm">
          <div className="flex justify-between">
            <dt className="text-muted-foreground">Net</dt>
            <dd>{formatMinor(net, currency)}</dd>
          </div>
          <div className="flex justify-between">
            <dt className="text-muted-foreground">Tax</dt>
            <dd>{formatMinor(tax, currency)}</dd>
          </div>
          <div className="flex justify-between border-t pt-1 font-semibold">
            <dt>Total</dt>
            <dd>{formatMinor(net + tax, currency)}</dd>
          </div>
        </dl>

        {showErrors && problems.length ? (
          <ul className="space-y-1 rounded-lg bg-destructive/10 p-3 text-sm text-destructive">
            {problems.map((p) => (
              <li key={p}>{p}</li>
            ))}
          </ul>
        ) : null}

        <DialogFooter>
          <Button type="button" variant="ghost" className="cursor-pointer" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button type="button" disabled={saving} className="cursor-pointer" onClick={submit}>
            {saving ? <Spinner /> : null}
            {doc ? "Save draft" : "Create draft"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
