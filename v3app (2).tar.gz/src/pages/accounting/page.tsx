import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { FileSpreadsheet, Lock, Plus, ShieldAlert } from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { CURRENCIES, type Currency } from "@/lib/bookings.ts";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import DocumentDialog from "./_components/document-dialog.tsx";
import DocumentList from "./_components/document-list.tsx";
import DocumentSheet from "./_components/document-sheet.tsx";
import { ChartOfAccounts, PeriodClose } from "./_components/ledger-settings.tsx";
import TrialBalance from "./_components/trial-balance.tsx";
import type { DocumentKind, DocumentState } from "@/lib/accounting.ts";

type KindFilter = "all" | DocumentKind;
type StateFilter = "all" | DocumentState;

const KIND_FILTERS: { value: KindFilter; label: string }[] = [
  { value: "all", label: "All" },
  { value: "invoice", label: "Invoices" },
  { value: "bill", label: "Bills" },
];
const STATE_FILTERS: { value: StateFilter; label: string }[] = [
  { value: "all", label: "Any status" },
  { value: "draft", label: "Drafts" },
  { value: "posted", label: "Posted" },
  { value: "reversed", label: "Reversed" },
];

function SetUp({ canSetUp }: { canSetUp: boolean }) {
  const setUp = useMutation(api.accounting.setup.setUp);
  const [currency, setCurrency] = useState<Currency>("EUR");
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    setSaving(true);
    try {
      await setUp({ currency });
      toast.success("Company accounting is ready");
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Empty className="border bg-card">
      <EmptyHeader>
        <EmptyMedia variant="icon">
          <FileSpreadsheet />
        </EmptyMedia>
        <EmptyTitle>Set up company accounting</EmptyTitle>
        <EmptyDescription>
          {canSetUp
            ? "Choose the company's base currency. It's used for every invoice and bill and can't be changed later."
            : "Ask the owner to set up company accounting first."}
        </EmptyDescription>
      </EmptyHeader>
      {canSetUp ? (
        <EmptyContent className="flex-row justify-center">
          <Select value={currency} onValueChange={(v) => setCurrency(v as Currency)}>
            <SelectTrigger className="w-28 cursor-pointer">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {CURRENCIES.map((c) => (
                <SelectItem key={c} value={c} className="cursor-pointer">
                  {c}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button className="cursor-pointer" disabled={saving} onClick={submit}>
            {saving ? <Spinner /> : null} Set up ledger
          </Button>
        </EmptyContent>
      ) : null}
    </Empty>
  );
}

function Pills<T extends string>({
  options,
  value,
  onChange,
}: {
  options: { value: T; label: string }[];
  value: T;
  onChange: (value: T) => void;
}) {
  return (
    <div className="inline-flex gap-1 rounded-lg bg-muted p-1">
      {options.map((o) => (
        <button
          key={o.value}
          type="button"
          onClick={() => onChange(o.value)}
          className={cn(
            "cursor-pointer rounded-md px-3 py-1 text-sm whitespace-nowrap text-muted-foreground transition-colors hover:text-foreground",
            value === o.value && "bg-background text-foreground shadow-sm",
          )}
        >
          {o.label}
        </button>
      ))}
    </div>
  );
}

function Workspace({ settings }: { settings: Doc<"accountingSettings"> }) {
  const [kind, setKind] = useState<KindFilter>("all");
  const [state, setState] = useState<StateFilter>("all");
  const [creating, setCreating] = useState(false);
  const [openId, setOpenId] = useState<Id<"accountingDocuments"> | null>(null);

  return (
    <>
      <PageHeader
        title="Company accounting"
        description={
          <span className="inline-flex flex-wrap items-center gap-x-2">
            <span>Invoices, bills and the company ledger in {settings.currency}.</span>
            {settings.closedThrough ? (
              <span className="inline-flex items-center gap-1 text-xs">
                <Lock className="size-3" /> Closed through {settings.closedThrough}
              </span>
            ) : null}
          </span>
        }
        actions={
          <Button className="cursor-pointer" onClick={() => setCreating(true)}>
            <Plus className="size-4" /> New document
          </Button>
        }
      />

      <Tabs defaultValue="documents" className="gap-5">
        <TabsList>
          <TabsTrigger value="documents" className="cursor-pointer">Documents</TabsTrigger>
          <TabsTrigger value="reports" className="cursor-pointer">Trial balance</TabsTrigger>
          <TabsTrigger value="settings" className="cursor-pointer">Accounts &amp; periods</TabsTrigger>
        </TabsList>

        <TabsContent value="documents" className="space-y-4">
          <div className="-mx-4 flex gap-2 overflow-x-auto px-4 [scrollbar-width:none] sm:mx-0 sm:px-0">
            <Pills options={KIND_FILTERS} value={kind} onChange={setKind} />
            <Pills options={STATE_FILTERS} value={state} onChange={setState} />
          </div>
          <DocumentList
            kind={kind === "all" ? undefined : kind}
            state={state === "all" ? undefined : state}
            onOpen={setOpenId}
            onCreate={() => setCreating(true)}
          />
        </TabsContent>

        <TabsContent value="reports">
          <TrialBalance />
        </TabsContent>

        <TabsContent value="settings" className="space-y-6">
          <PeriodClose closedThrough={settings.closedThrough} />
          <ChartOfAccounts />
        </TabsContent>
      </Tabs>

      {creating ? (
        <DocumentDialog
          open
          onOpenChange={setCreating}
          currency={settings.currency}
          defaultKind={kind === "bill" ? "bill" : "invoice"}
        />
      ) : null}
      <DocumentSheet id={openId} onClose={() => setOpenId(null)} />
    </>
  );
}

export default function AccountingPage() {
  const status = useQuery(api.accounting.setup.status, {});

  if (status === undefined) {
    return (
      <PageContainer>
        <Skeleton className="h-9 w-64" />
        <Skeleton className="h-64 w-full" />
      </PageContainer>
    );
  }

  if (!status.allowed) {
    return (
      <PageContainer>
        <Empty className="border bg-card">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <ShieldAlert />
            </EmptyMedia>
            <EmptyTitle>Managers only</EmptyTitle>
            <EmptyDescription>
              Company accounting is available to owners and global managers.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      {status.settings ? (
        <Workspace settings={status.settings} />
      ) : (
        <>
          <PageHeader title="Company accounting" />
          <SetUp canSetUp={status.canSetUp} />
        </>
      )}
    </PageContainer>
  );
}
