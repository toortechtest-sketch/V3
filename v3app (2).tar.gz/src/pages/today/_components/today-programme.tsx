import { Link } from "react-router-dom";
import { CalendarClock } from "lucide-react";
import { Card } from "@/components/ui/card.tsx";
import { cn } from "@/lib/utils.ts";
import {
  ITEM_TYPE_META,
  formatTimeRange,
  type ItineraryItemType,
} from "@/lib/itinerary.ts";

export type ProgrammeItem = {
  _id: string;
  type: ItineraryItemType;
  title: string;
  startTime?: string;
  endTime?: string;
  location?: string;
  bookingId: string;
  bookingReference: string;
  bookingTitle: string;
};

/** Today's itinerary items across every booking that is on the road. */
export default function TodayProgramme({ items }: { items: ProgrammeItem[] }) {
  return (
    <Card className="gap-0 overflow-hidden py-0">
      <div className="flex items-center gap-2 bg-sidebar px-4 py-3 text-sidebar-foreground">
        <CalendarClock className="size-4 text-sidebar-primary" />
        <h2 className="font-display text-base font-semibold">On the programme today</h2>
        <span className="ml-auto font-mono text-[11px] text-sidebar-foreground/60">
          {items.length} {items.length === 1 ? "item" : "items"}
        </span>
      </div>
      {items.length === 0 ? (
        <p className="px-4 py-6 text-center text-sm text-muted-foreground">
          Nothing planned in the itinerary for today.
        </p>
      ) : (
        <ol className="max-h-96 divide-y overflow-y-auto">
          {items.map((item) => {
            const meta = ITEM_TYPE_META[item.type];
            const time = formatTimeRange(item.startTime, item.endTime);
            return (
              <li key={item._id}>
                <Link
                  to={`/bookings/${item.bookingId}?tab=itinerary`}
                  className="flex cursor-pointer items-center gap-3 px-4 py-3 transition-colors hover:bg-muted/60"
                >
                  <span className="w-24 shrink-0 font-mono text-xs text-muted-foreground tabular-nums">
                    {time ?? "Any time"}
                  </span>
                  <span
                    className={cn(
                      "flex size-8 shrink-0 items-center justify-center rounded-md",
                      meta.tone,
                    )}
                  >
                    <meta.icon className="size-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{item.title}</p>
                    <p className="truncate text-xs text-muted-foreground">
                      <span className="font-mono">{item.bookingReference}</span> ·{" "}
                      {item.bookingTitle}
                      {item.location ? ` · ${item.location}` : ""}
                    </p>
                  </div>
                </Link>
              </li>
            );
          })}
        </ol>
      )}
    </Card>
  );
}
