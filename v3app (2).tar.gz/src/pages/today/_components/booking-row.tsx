import { Link } from "react-router-dom";
import { ChevronRight } from "lucide-react";
import StageBadge from "@/components/bookings/stage-badge.tsx";
import { formatDateRange, type BookingStage } from "@/lib/bookings.ts";

export type BookingSummary = {
  _id: string;
  reference: string;
  title: string;
  clientName: string;
  destination: string;
  startDate: string;
  endDate: string;
  pax: number;
  stage: BookingStage;
  ownerName: string | null;
};

/** Compact, clickable booking line used in every Today section. */
export default function BookingRow({
  booking,
  hint,
  hintTone = "muted",
  showOwner,
}: {
  booking: BookingSummary;
  hint?: string;
  hintTone?: "muted" | "warn" | "alert";
  showOwner: boolean;
}) {
  const tone = {
    muted: "text-muted-foreground",
    warn: "text-[#8a6400] dark:text-[#FFB800]",
    alert: "text-destructive",
  }[hintTone];

  return (
    <Link
      to={`/bookings/${booking._id}`}
      className="group flex cursor-pointer items-center gap-3 px-4 py-3 transition-colors hover:bg-muted/60"
    >
      <div className="min-w-0 flex-1 space-y-0.5">
        <div className="flex items-center gap-2">
          <span className="font-mono text-[11px] text-muted-foreground">
            {booking.reference}
          </span>
          <StageBadge stage={booking.stage} className="px-2 text-[10px]" />
        </div>
        <p className="truncate text-sm font-medium">{booking.title}</p>
        <p className="truncate text-xs text-muted-foreground">
          {booking.clientName} · {booking.destination} ·{" "}
          {formatDateRange(booking.startDate, booking.endDate)} · {booking.pax} pax
          {showOwner && booking.ownerName ? ` · ${booking.ownerName}` : ""}
        </p>
      </div>
      {hint ? (
        <span className={`shrink-0 text-right text-xs font-medium ${tone}`}>
          {hint}
        </span>
      ) : null}
      <ChevronRight className="size-4 shrink-0 text-muted-foreground/50 transition-transform group-hover:translate-x-0.5" />
    </Link>
  );
}
