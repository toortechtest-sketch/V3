import type { LucideIcon } from "lucide-react";
import { Card } from "@/components/ui/card.tsx";

/** Card with an icon header and a divided list; shows a calm line when empty. */
export default function TodaySection({
  icon: Icon,
  title,
  count,
  emptyText,
  footer,
  children,
}: {
  icon: LucideIcon;
  title: string;
  count: number;
  emptyText: string;
  footer?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <Card className="gap-0 overflow-hidden py-0">
      <div className="flex items-center gap-2 border-b px-4 py-3">
        <Icon className="size-4 text-primary" />
        <h2 className="font-display text-base font-semibold">{title}</h2>
        <span className="ml-auto rounded-full bg-muted px-2 py-0.5 font-mono text-[11px] text-muted-foreground">
          {count}
        </span>
      </div>
      {count === 0 ? (
        <p className="px-4 py-6 text-center text-sm text-muted-foreground">
          {emptyText}
        </p>
      ) : (
        <div className="max-h-96 divide-y overflow-y-auto">{children}</div>
      )}
      {footer}
    </Card>
  );
}
