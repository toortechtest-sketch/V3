import { differenceInCalendarDays, parseISO } from "date-fns";

/** "today", "tomorrow", "in 3 days", "yesterday", "4 days ago". */
export function relativeDay(day: string, today: string) {
  const diff = differenceInCalendarDays(parseISO(day), parseISO(today));
  if (diff === 0) return "today";
  if (diff === 1) return "tomorrow";
  if (diff === -1) return "yesterday";
  return diff > 0 ? `in ${diff} days` : `${-diff} days ago`;
}

/** "Day 2 of 5" for a booking that is under way. */
export function tripDay(start: string, end: string, today: string) {
  const day = differenceInCalendarDays(parseISO(today), parseISO(start)) + 1;
  const total = differenceInCalendarDays(parseISO(end), parseISO(start)) + 1;
  return `Day ${day} of ${total}`;
}

export function greeting(hour: number) {
  if (hour < 12) return "Good morning";
  if (hour < 18) return "Good afternoon";
  return "Good evening";
}
