import { useEffect, useRef } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import { CalendarDays, LinkIcon, MapPin, Route, Users } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import BrandLogo from "@/components/brand-logo.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { formatDateRange } from "@/lib/bookings.ts";
import ClientItinerary from "./_components/client-itinerary.tsx";
import ClientOffer from "./_components/client-offer.tsx";
import ClientConfirmation from "./_components/client-confirmation.tsx";
import HotelResponse from "./_components/hotel-response.tsx";
import PaymentStatus from "./_components/payment-status.tsx";

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-10 border-b bg-card/95 backdrop-blur-sm">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3.5 sm:px-6">
          <BrandLogo />
        </div>
      </header>
      <main className="mx-auto max-w-3xl space-y-7 px-4 py-6 sm:px-6 sm:py-10">{children}</main>
      <footer className="mx-auto max-w-3xl px-4 pb-10 text-xs text-muted-foreground sm:px-6">
        © {new Date().getFullYear()} Toor.tech
      </footer>
    </div>
  );
}

/** Counts one view per page load (not per reactive update). */
function useRecordView(token: string, ready: boolean) {
  const record = useMutation(api.clientLinks.recordView);
  const done = useRef(false);
  useEffect(() => {
    if (!ready || done.current) return;
    done.current = true;
    void record({ token }).catch(() => undefined);
  }, [ready, record, token]);
}

function TripHeader({
  eyebrow,
  booking,
}: {
  eyebrow: string;
  booking: { reference: string; title: string; clientName: string; destination: string; startDate: string; endDate: string; pax: number };
}) {
  return (
    <div className="space-y-3">
      <p className="font-mono text-xs tracking-widest text-primary uppercase">
        {eyebrow} · {booking.reference}
      </p>
      <h1 className="font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
        {booking.title}
      </h1>
      <p className="text-muted-foreground">Prepared for {booking.clientName}</p>
      <div className="flex flex-wrap gap-x-5 gap-y-2 pt-2 text-sm">
        <span className="inline-flex items-center gap-1.5">
          <MapPin className="size-4 text-primary" /> {booking.destination}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <CalendarDays className="size-4 text-primary" /> {formatDateRange(booking.startDate, booking.endDate)}
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Users className="size-4 text-primary" /> {booking.pax} travellers
        </span>
      </div>
    </div>
  );
}

function SharedView({ token }: { token: string }) {
  const view = useQuery(api.clientLinks.view, { token });
  useRecordView(token, view?.status === "ok");

  if (view === undefined) {
    return (
      <Shell>
        <Skeleton className="h-10 w-2/3" />
        <Skeleton className="h-24 w-full" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </Shell>
    );
  }

  if (view.status === "unavailable") {
    return (
      <Shell>
        <Empty className="border bg-card">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <LinkIcon />
            </EmptyMedia>
            <EmptyTitle>This link is no longer available</EmptyTitle>
            <EmptyDescription>
              It may have expired or been replaced. Ask your travel contact for a new link.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      </Shell>
    );
  }

  if (view.kind === "hotel_response") {
    return (
      <Shell>
        <div className="space-y-3">
          <p className="font-mono text-xs tracking-widest text-primary uppercase">
            Change request · {view.booking.reference}
          </p>
          <h1 className="font-display text-3xl font-semibold tracking-tight text-balance sm:text-4xl">
            {view.reservation.supplierName}
          </h1>
          <p className="text-muted-foreground">
            We'd like to change a confirmed reservation for {view.booking.title}. Please approve or
            decline below.
          </p>
        </div>
        <HotelResponse token={token} view={view} />
        <ValidUntil expiresAt={view.expiresAt} />
      </Shell>
    );
  }

  const { booking } = view;

  if (view.kind === "itinerary") {
    return (
      <Shell>
        <TripHeader eyebrow="Your itinerary" booking={booking} />
        <section className="space-y-3">
          <h2 className="font-display text-xl font-semibold">Day by day</h2>
          <ClientItinerary days={view.days} />
        </section>
        <ValidUntil expiresAt={view.expiresAt} />
      </Shell>
    );
  }

  const eyebrow = view.kind === "offer" ? "Your offer" : "Your trip";
  return (
    <Shell>
      <TripHeader eyebrow={eyebrow} booking={booking} />

      <Tabs defaultValue={view.kind === "offer" ? "offer" : "trip"}>
        <TabsList className="w-full sm:w-auto">
          {view.kind === "offer" ? (
            <TabsTrigger value="offer" className="cursor-pointer">
              Offer
            </TabsTrigger>
          ) : (
            <TabsTrigger value="trip" className="cursor-pointer">
              Your trip
            </TabsTrigger>
          )}
          <TabsTrigger value="itinerary" className="cursor-pointer">
            <Route className="size-3.5" /> Itinerary
          </TabsTrigger>
          {view.kind === "confirmation" ? (
            <TabsTrigger value="payment" className="cursor-pointer">
              Payment
            </TabsTrigger>
          ) : null}
        </TabsList>

        {view.kind === "offer" ? (
          <TabsContent value="offer" className="pt-5">
            <ClientOffer token={token} view={view} />
          </TabsContent>
        ) : (
          <TabsContent value="trip" className="pt-5">
            <ClientConfirmation token={token} view={view} />
          </TabsContent>
        )}

        <TabsContent value="itinerary" className="space-y-3 pt-5">
          <h2 className="font-display text-xl font-semibold">Day by day</h2>
          <ClientItinerary days={view.days} />
        </TabsContent>

        {view.kind === "confirmation" ? (
          <TabsContent value="payment" className="pt-5">
            <PaymentStatus payment={view.payment} />
          </TabsContent>
        ) : null}
      </Tabs>

      <ValidUntil expiresAt={view.expiresAt} />
    </Shell>
  );
}

function ValidUntil({ expiresAt }: { expiresAt: string }) {
  return (
    <p className="text-xs text-muted-foreground">
      This private link is valid until {format(parseISO(expiresAt), "d MMMM yyyy")}.
    </p>
  );
}

export default function SharePage() {
  const { token } = useParams();
  return <SharedView key={token} token={token ?? ""} />;
}
