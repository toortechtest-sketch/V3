import { format, parseISO } from "date-fns";
import type { FunctionReturnType } from "convex/server";
import { CalendarClock, CheckCircle2, PiggyBank } from "lucide-react";
import type { api } from "@/convex/_generated/api.js";
import { Progress } from "@/components/ui/progress.tsx";
import { formatMoney } from "@/lib/quotes.ts";

type View = Extract<
  FunctionReturnType<typeof api.clientLinks.view>,
  { status: "ok"; kind: "confirmation" }
>;
export type PaymentStatusData = View["payment"];

export default function PaymentStatus({ payment }: { payment: PaymentStatusData }) {
  if (payment.total <= 0) {
    return (
      <div className="rounded-xl border bg-card p-5">
        <p className="flex items-center gap-2 font-display text-lg font-semibold">
          <PiggyBank className="size-5 text-primary" /> Payment status
        </p>
        <p className="mt-1 text-sm text-muted-foreground">
          Your travel team hasn't set a package value yet. Check back here once it's agreed.
        </p>
      </div>
    );
  }

  const percentPaid = Math.min(100, Math.round((payment.received / payment.total) * 100));

  return (
    <div className="space-y-4 rounded-xl border bg-card p-5">
      <div className="flex items-start justify-between gap-3">
        <p className="flex items-center gap-2 font-display text-lg font-semibold">
          <PiggyBank className="size-5 text-primary" /> Payment status
        </p>
        {payment.isPaidInFull ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-emerald-500/15 px-2.5 py-1 text-xs font-medium text-emerald-700 dark:text-emerald-400">
            <CheckCircle2 className="size-3.5" /> Paid in full
          </span>
        ) : null}
      </div>

      <div className="space-y-2">
        <Progress value={percentPaid} />
        <div className="flex items-baseline justify-between text-sm">
          <span className="text-muted-foreground">
            {formatMoney(payment.received, payment.currency)} received
          </span>
          <span className="font-medium">{formatMoney(payment.total, payment.currency)} total</span>
        </div>
      </div>

      {!payment.isPaidInFull && payment.outstanding > 0 ? (
        <div className="flex items-center justify-between gap-3 rounded-lg bg-muted/60 px-4 py-3">
          <span className="text-sm text-muted-foreground">Outstanding balance</span>
          <span className="font-mono text-sm font-medium">
            {formatMoney(payment.outstanding, payment.currency)}
          </span>
        </div>
      ) : null}

      {payment.nextDue ? (
        <div className="flex items-start gap-3 rounded-lg border border-[#FFB800]/40 bg-[#FFB800]/10 px-4 py-3">
          <CalendarClock className="mt-0.5 size-4 shrink-0 text-[#8a6400] dark:text-[#FFB800]" />
          <div className="min-w-0 text-sm">
            <p className="font-medium">
              {payment.nextDue.label} due {format(parseISO(payment.nextDue.dueDate), "d MMMM yyyy")}
            </p>
            <p className="text-muted-foreground">{formatMoney(payment.nextDue.amount, payment.currency)}</p>
          </div>
        </div>
      ) : null}
    </div>
  );
}
