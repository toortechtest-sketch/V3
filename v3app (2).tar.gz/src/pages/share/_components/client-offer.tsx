import { useState } from "react";
import { useMutation } from "convex/react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { CheckCircle2, XCircle } from "lucide-react";
import type { FunctionReturnType } from "convex/server";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { SECTION_META, formatMoney } from "@/lib/quotes.ts";
import { cn } from "@/lib/utils.ts";

type View = Extract<
  FunctionReturnType<typeof api.clientLinks.view>,
  { status: "ok"; kind: "offer" }
>;

function Price({ offer }: { offer: View["offer"] }) {
  return (
    <div className="rounded-xl bg-sidebar p-6 text-sidebar-foreground">
      <p className="font-mono text-[11px] tracking-widest text-sidebar-primary uppercase">
        Total price
      </p>
      <p className="mt-1 font-display text-4xl font-semibold text-white">
        {formatMoney(offer.total, offer.currency)}
      </p>
      {offer.perPayingGuest !== null ? (
        <p className="mt-1 text-sm text-sidebar-foreground/75">
          {formatMoney(offer.perPayingGuest, offer.currency)} per person, based on{" "}
          {offer.payingPax} paying guest{offer.payingPax === 1 ? "" : "s"}
          {offer.freePlaces > 0 ? ` and ${offer.freePlaces} free place${offer.freePlaces === 1 ? "" : "s"}` : ""}
        </p>
      ) : null}
      {offer.validUntil ? (
        <p className="mt-3 text-xs text-sidebar-foreground/60">
          Offer valid until {format(parseISO(offer.validUntil), "d MMMM yyyy")}
        </p>
      ) : null}
    </div>
  );
}

function Inclusions({ offer }: { offer: View["offer"] }) {
  if (offer.sections.length === 0) return null;
  return (
    <div className="divide-y rounded-xl border bg-card">
      {offer.sections.map((s) => {
        const meta = SECTION_META[s.section];
        return (
          <div key={s.section} className="flex gap-4 p-5">
            <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
              <meta.icon className="size-4" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-baseline justify-between gap-3">
                <p className="font-medium">{meta.label}</p>
                <p className="font-mono text-sm">{formatMoney(s.sell, offer.currency)}</p>
              </div>
              <ul className="mt-1 list-disc space-y-0.5 pl-4 text-sm text-muted-foreground">
                {s.inclusions.map((text, i) => (
                  <li key={i}>{text}</li>
                ))}
              </ul>
            </div>
          </div>
        );
      })}
    </div>
  );
}

function Response({ token, response }: { token: string; response: View["response"] }) {
  const respond = useMutation(api.clientLinks.respondToOffer);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState<"accepted" | "declined" | null>(null);

  if (response) {
    const accepted = response.decision === "accepted";
    return (
      <div
        className={cn(
          "flex items-start gap-3 rounded-xl border p-5",
          accepted ? "border-emerald-500/30 bg-emerald-500/5" : "border-destructive/30 bg-destructive/5",
        )}
      >
        {accepted ? (
          <CheckCircle2 className="mt-0.5 size-5 text-emerald-600 dark:text-emerald-400" />
        ) : (
          <XCircle className="mt-0.5 size-5 text-destructive" />
        )}
        <div>
          <p className="font-medium">
            {accepted ? "Offer accepted" : "Offer declined"} by {response.name}
          </p>
          <p className="text-sm text-muted-foreground">
            {format(parseISO(response.respondedAt), "d MMMM yyyy, HH:mm")}. Your
            travel team has been notified and will be in touch.
          </p>
        </div>
      </div>
    );
  }

  const send = async (decision: "accepted" | "declined") => {
    if (!name.trim()) {
      toast.error("Add your name first.");
      return;
    }
    setBusy(decision);
    try {
      await respond({ token, decision, name, message: message || undefined });
      toast.success(decision === "accepted" ? "Thank you, offer accepted" : "Response sent");
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-4 rounded-xl border bg-card p-5">
      <div>
        <p className="font-display text-lg font-semibold">Your response</p>
        <p className="text-sm text-muted-foreground">Let us know if you'd like to go ahead.</p>
      </div>
      <div className="space-y-2">
        <Label htmlFor="resp-name">Your name</Label>
        <Input id="resp-name" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} placeholder="John Smith" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="resp-msg">Message (optional)</Label>
        <Textarea
          id="resp-msg"
          rows={3}
          maxLength={2000}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="Any changes or questions"
        />
      </div>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Button className="cursor-pointer" disabled={busy !== null} onClick={() => send("accepted")}>
          {busy === "accepted" ? <Spinner /> : <CheckCircle2 className="size-4" />} Accept offer
        </Button>
        <Button variant="ghost" className="cursor-pointer" disabled={busy !== null} onClick={() => send("declined")}>
          {busy === "declined" ? <Spinner /> : <XCircle className="size-4" />} Decline
        </Button>
      </div>
    </div>
  );
}

export default function ClientOffer({ token, view }: { token: string; view: View }) {
  const { offer } = view;
  return (
    <div className="space-y-6">
      <Price offer={offer} />
      <section className="space-y-3">
        <h2 className="font-display text-xl font-semibold">What's included</h2>
        {offer.sections.length === 0 ? (
          <p className="text-sm text-muted-foreground">Details to follow.</p>
        ) : (
          <Inclusions offer={offer} />
        )}
      </section>
      {offer.terms ? (
        <section className="space-y-2">
          <h2 className="font-display text-xl font-semibold">Terms</h2>
          <p className="text-sm whitespace-pre-wrap text-muted-foreground">{offer.terms}</p>
        </section>
      ) : null}
      <Response token={token} response={view.response} />
    </div>
  );
}
