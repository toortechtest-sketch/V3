import { format, parseISO } from "date-fns";
import { MapPin } from "lucide-react";
import type { FunctionReturnType } from "convex/server";
import type { api } from "@/convex/_generated/api.js";
import { ITEM_TYPE_META, formatTimeRange } from "@/lib/itinerary.ts";
import { cn } from "@/lib/utils.ts";

type View = Extract<
  FunctionReturnType<typeof api.clientLinks.view>,
  { status: "ok"; days: unknown }
>;
export type ClientDay = View["days"][number];

export default function ClientItinerary({ days }: { days: ClientDay[] }) {
  return (
    <ol className="space-y-4">
      {days.map((day, index) => (
        <li key={day.date} className="overflow-hidden rounded-xl border bg-card">
          <div className="flex items-baseline gap-3 border-b bg-muted/50 px-5 py-3">
            <span className="font-mono text-xs text-primary">Day {index + 1}</span>
            <span className="font-display text-lg font-semibold">
              {format(parseISO(day.date), "EEEE d MMMM")}
            </span>
          </div>
          <div className="space-y-3 px-5 py-4">
            {day.title ? <p className="font-medium">{day.title}</p> : null}
            {day.notes ? (
              <p className="text-sm whitespace-pre-wrap text-muted-foreground">{day.notes}</p>
            ) : null}
            {day.items.length === 0 && !day.title && !day.notes ? (
              <p className="text-sm text-muted-foreground">Programme to follow.</p>
            ) : null}
            {day.items.map((item) => {
              const meta = ITEM_TYPE_META[item.type];
              return (
                <div key={item.key} className="flex gap-3 border-t pt-3 first:border-t-0 first:pt-0">
                  <div className="w-20 shrink-0 pt-1 font-mono text-xs text-muted-foreground">
                    {formatTimeRange(item.startTime ?? undefined, item.endTime ?? undefined) ?? ""}
                  </div>
                  <div className={cn("mt-0.5 flex size-7 shrink-0 items-center justify-center rounded-md", meta.tone)}>
                    <meta.icon className="size-3.5" />
                  </div>
                  <div className="min-w-0 space-y-0.5">
                    <p className="font-medium">{item.title}</p>
                    {item.description ? (
                      <p className="text-sm whitespace-pre-wrap text-muted-foreground">{item.description}</p>
                    ) : null}
                    {item.location || item.supplierName ? (
                      <p className="flex items-center gap-1 text-xs text-muted-foreground">
                        <MapPin className="size-3" />
                        {[item.supplierName, item.location].filter(Boolean).join(" · ")}
                      </p>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>
        </li>
      ))}
    </ol>
  );
}
