import { useState } from "react";
import { useMutation } from "convex/react";
import type { FunctionReturnType } from "convex/server";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { BadgeCheck, CheckCircle2, Clock, MessageSquare, Send } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { dateSpan } from "@/lib/reservations.ts";
import { BOARD_LABELS, CATEGORY_META } from "@/lib/suppliers.ts";
import { cn } from "@/lib/utils.ts";

type View = Extract<
  FunctionReturnType<typeof api.clientLinks.view>,
  { status: "ok"; kind: "confirmation" }
>;

function Services({ reservations }: { reservations: View["reservations"] }) {
  if (reservations.length === 0) {
    return <p className="text-sm text-muted-foreground">Your services are being arranged. Details to follow.</p>;
  }
  return (
    <ul className="divide-y rounded-xl border bg-card">
      {reservations.map((r) => {
        const meta = CATEGORY_META[r.type];
        const confirmed = r.status === "confirmed";
        return (
          <li key={r.key} className="flex gap-4 p-5">
            <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
              <meta.icon className="size-4" />
            </div>
            <div className="min-w-0 flex-1 space-y-1">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <p className="font-medium break-words">{r.supplierName}</p>
                <span
                  className={cn(
                    "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-xs font-medium",
                    confirmed
                      ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
                      : "bg-[#FFB800]/18 text-[#8a6400] dark:text-[#FFB800]",
                  )}
                >
                  {confirmed ? <BadgeCheck className="size-3.5" /> : <Clock className="size-3.5" />}
                  {confirmed ? "Confirmed" : "Being confirmed"}
                </span>
              </div>
              <p className="text-sm break-words text-muted-foreground">{r.description}</p>
              <p className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                <span>{dateSpan(r.startDate, r.endDate ?? undefined)}</span>
                <span className="font-medium text-foreground">
                  {r.units} {r.unitLabel ?? "units"}
                </span>
                {r.board ? <span>{BOARD_LABELS[r.board]}</span> : null}
                {r.confirmationNumber ? <span className="font-mono">Conf. {r.confirmationNumber}</span> : null}
              </p>
            </div>
          </li>
        );
      })}
    </ul>
  );
}

function ChangeForm({ token }: { token: string }) {
  const send = useMutation(api.clientLinks.requestChange);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    if (!name.trim() || !message.trim()) {
      toast.error("Add your name and what you'd like to change.");
      return;
    }
    setBusy(true);
    try {
      await send({ token, name, message });
      setMessage("");
      toast.success("Request sent to your travel team");
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-4 rounded-xl border bg-card p-5">
      <div>
        <p className="font-display text-lg font-semibold">Need a change?</p>
        <p className="text-sm text-muted-foreground">
          Tell us what you'd like to change. Your travel team will check with the suppliers and
          confirm back to you.
        </p>
      </div>
      <div className="space-y-2">
        <Label htmlFor="chg-name">Your name</Label>
        <Input id="chg-name" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} placeholder="John Smith" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="chg-msg">What would you like to change?</Label>
        <Textarea
          id="chg-msg"
          rows={3}
          maxLength={2000}
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          placeholder="We'd like 2 more rooms on 3 November"
        />
      </div>
      <Button className="cursor-pointer" disabled={busy} onClick={() => void submit()}>
        {busy ? <Spinner /> : <Send className="size-4" />} Send request
      </Button>
    </div>
  );
}

function SentRequests({ requests }: { requests: View["requests"] }) {
  if (requests.length === 0) return null;
  return (
    <ul className="space-y-2">
      {requests.map((r) => (
        <li key={r.key} className="flex gap-3 rounded-xl border bg-card p-4 text-sm">
          {r.handled ? (
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-emerald-600 dark:text-emerald-400" />
          ) : (
            <MessageSquare className="mt-0.5 size-4 shrink-0 text-primary" />
          )}
          <div className="min-w-0 space-y-0.5">
            <p className="font-medium">
              {r.handled ? "Handled" : "Received"}
              <span className="font-normal text-muted-foreground">
                {" "}· {r.name}, {format(parseISO(r.createdAt), "d MMM yyyy, HH:mm")}
              </span>
            </p>
            <p className="break-words whitespace-pre-wrap text-muted-foreground">{r.message}</p>
          </div>
        </li>
      ))}
    </ul>
  );
}

export default function ClientConfirmation({ token, view }: { token: string; view: View }) {
  return (
    <div className="space-y-6">
      <section className="space-y-3">
        <h2 className="font-display text-xl font-semibold">Your services</h2>
        <Services reservations={view.reservations} />
      </section>
      <section className="space-y-3">
        <ChangeForm token={token} />
        <SentRequests requests={view.requests} />
      </section>
    </div>
  );
}
