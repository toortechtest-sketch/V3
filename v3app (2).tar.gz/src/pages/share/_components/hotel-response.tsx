import { useState } from "react";
import { useMutation } from "convex/react";
import type { FunctionReturnType } from "convex/server";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { ArrowRight, CalendarDays, CheckCircle2, Undo2, XCircle } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { dateSpan, describeChange } from "@/lib/reservations.ts";
import { BOARD_LABELS, CATEGORY_META } from "@/lib/suppliers.ts";
import { cn } from "@/lib/utils.ts";

type View = Extract<
  FunctionReturnType<typeof api.clientLinks.view>,
  { status: "ok"; kind: "hotel_response" }
>;
type Decision = "approved" | "declined";

function Reservation({ reservation: r }: { reservation: View["reservation"] }) {
  const meta = CATEGORY_META[r.type];
  return (
    <div className="flex gap-4 rounded-xl border bg-card p-5">
      <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
        <meta.icon className="size-5" />
      </div>
      <div className="min-w-0 space-y-1">
        <p className="font-medium break-words">{r.supplierName}</p>
        <p className="text-sm break-words text-muted-foreground">{r.description}</p>
        <p className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
          <span className="inline-flex items-center gap-1">
            <CalendarDays className="size-3.5" /> {dateSpan(r.startDate, r.endDate ?? undefined)}
          </span>
          <span className="font-medium text-foreground">
            {r.units} {r.unitLabel ?? "units"}
          </span>
          {r.board ? <span>{BOARD_LABELS[r.board]}</span> : null}
          {r.supplierRef ? <span className="font-mono">Your ref {r.supplierRef}</span> : null}
        </p>
      </div>
    </div>
  );
}

function Answered({ change }: { change: View["change"] }) {
  if (change.status === "withdrawn") {
    return (
      <div className="flex items-start gap-3 rounded-xl border bg-card p-5">
        <Undo2 className="mt-0.5 size-5 text-muted-foreground" />
        <div>
          <p className="font-medium">This request was withdrawn</p>
          <p className="text-sm text-muted-foreground">No action is needed. The reservation stays as confirmed.</p>
        </div>
      </div>
    );
  }
  const approved = change.status === "approved";
  return (
    <div
      className={cn(
        "flex items-start gap-3 rounded-xl border p-5",
        approved ? "border-emerald-500/30 bg-emerald-500/5" : "border-destructive/30 bg-destructive/5",
      )}
    >
      {approved ? (
        <CheckCircle2 className="mt-0.5 size-5 text-emerald-600 dark:text-emerald-400" />
      ) : (
        <XCircle className="mt-0.5 size-5 text-destructive" />
      )}
      <div>
        <p className="font-medium">{approved ? "Change approved" : "Change declined"}</p>
        <p className="text-sm text-muted-foreground">
          {change.respondedAt ? `${format(parseISO(change.respondedAt), "d MMMM yyyy, HH:mm")}. ` : ""}
          Thank you, the travel team has been updated.
        </p>
      </div>
    </div>
  );
}

function ResponseForm({ token }: { token: string }) {
  const respond = useMutation(api.clientLinks.respondAsHotel);
  const [name, setName] = useState("");
  const [note, setNote] = useState("");
  const [busy, setBusy] = useState<Decision | null>(null);

  const send = async (decision: Decision) => {
    if (!name.trim()) {
      toast.error("Add your name first.");
      return;
    }
    setBusy(decision);
    try {
      await respond({ token, decision, name, note: note || undefined });
      toast.success(decision === "approved" ? "Change approved" : "Response sent");
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="space-y-4 rounded-xl border bg-card p-5">
      <div>
        <p className="font-display text-lg font-semibold">Your answer</p>
        <p className="text-sm text-muted-foreground">
          Approving confirms the change on your side. Declining keeps the reservation as it is.
        </p>
      </div>
      <div className="space-y-2">
        <Label htmlFor="hotel-name">Your name</Label>
        <Input id="hotel-name" value={name} maxLength={120} onChange={(e) => setName(e.target.value)} placeholder="Maria Lopez, Reservations" />
      </div>
      <div className="space-y-2">
        <Label htmlFor="hotel-note">Note (optional)</Label>
        <Textarea
          id="hotel-note"
          rows={3}
          maxLength={1000}
          value={note}
          onChange={(e) => setNote(e.target.value)}
          placeholder="New confirmation number, conditions or reason"
        />
      </div>
      <div className="flex flex-col gap-2 sm:flex-row">
        <Button className="cursor-pointer" disabled={busy !== null} onClick={() => void send("approved")}>
          {busy === "approved" ? <Spinner /> : <CheckCircle2 className="size-4" />} Approve change
        </Button>
        <Button variant="ghost" className="cursor-pointer" disabled={busy !== null} onClick={() => void send("declined")}>
          {busy === "declined" ? <Spinner /> : <XCircle className="size-4" />} Decline
        </Button>
      </div>
    </div>
  );
}

export default function HotelResponse({ token, view }: { token: string; view: View }) {
  const { change, reservation } = view;
  const lines = describeChange(change, reservation.unitLabel ?? "units");
  return (
    <div className="space-y-6">
      <section className="space-y-3">
        <h2 className="font-display text-xl font-semibold">Confirmed reservation</h2>
        <Reservation reservation={reservation} />
      </section>
      <section className="space-y-3">
        <h2 className="font-display text-xl font-semibold">Requested change</h2>
        <div className="space-y-2 rounded-xl border border-[#FFB800]/40 bg-[#FFB800]/10 p-5">
          <ul className="space-y-1">
            {lines.map((line) => (
              <li key={line} className="flex items-center gap-2 font-medium">
                <ArrowRight className="size-4 shrink-0 text-[#8a6400] dark:text-[#FFB800]" />
                <span className="break-words">{line}</span>
              </li>
            ))}
          </ul>
          {change.message ? (
            <p className="text-sm whitespace-pre-wrap text-muted-foreground">"{change.message}"</p>
          ) : null}
          <p className="text-xs text-muted-foreground">
            Requested {format(parseISO(change.requestedAt), "d MMMM yyyy")}
          </p>
        </div>
      </section>
      {change.status === "pending" ? <ResponseForm token={token} /> : <Answered change={change} />}
    </div>
  );
}
