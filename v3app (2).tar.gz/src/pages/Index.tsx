import { Link, useSearchParams } from "react-router-dom";
import { useQuery } from "convex/react";
import { format } from "date-fns";
import {
  ArrowRight,
  FileClock,
  FilePen,
  PlaneTakeoff,
  Receipt,
  Route,
  UsersRound,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import BookingRow from "./today/_components/booking-row.tsx";
import TodayProgramme from "./today/_components/today-programme.tsx";
import TodaySection from "./today/_components/today-section.tsx";
import { greeting, relativeDay, tripDay } from "./today/_lib/dates.ts";

function TodaySkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full" />
        ))}
      </div>
      <Skeleton className="h-48 w-full" />
      <div className="grid gap-6 lg:grid-cols-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-56 w-full" />
        ))}
      </div>
    </div>
  );
}

function InviteTeamCard() {
  return (
    <Card>
      <CardContent className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-start gap-3">
          <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
            <UsersRound className="size-5" />
          </div>
          <div>
            <p className="font-medium">Invite your team</p>
            <p className="text-sm text-muted-foreground">
              Staff sign in once, then you approve them and choose their role.
            </p>
          </div>
        </div>
        <Button asChild className="cursor-pointer">
          <Link to="/team">
            Manage team <ArrowRight className="size-4" />
          </Link>
        </Button>
      </CardContent>
    </Card>
  );
}

export default function Index() {
  const { me, isManager } = useStaff();
  const [params, setParams] = useSearchParams();
  const mineOnly = params.get("mine") === "1";
  const now = new Date();
  // Calendar day in the user's own timezone
  const today = format(now, "yyyy-MM-dd");
  const data = useQuery(api.today.overview, { today, mineOnly });

  const firstName = me?.status === "active" ? (me.name ?? "").split(" ")[0] : "";
  const showOwner = data?.seesAll ?? false;

  const setMine = (on: boolean) => {
    const next = new URLSearchParams(params);
    if (on) next.set("mine", "1");
    else next.delete("mine");
    setParams(next, { replace: true });
  };

  const stats = data
    ? [
        { label: "Travelling now", value: data.travelling.length, icon: Route },
        { label: "Departing in 14 days", value: data.departing.length, icon: PlaneTakeoff },
        { label: "Enquiries to quote", value: data.needsQuote.length, icon: FilePen },
        { label: "To reconcile", value: data.toReconcile.length, icon: Receipt },
      ]
    : [];

  return (
    <PageContainer>
      <PageHeader
        title={`${greeting(now.getHours())}${firstName ? `, ${firstName}` : ""}`}
        description={`${format(now, "EEEE d MMMM yyyy")} · ${
          showOwner ? "Across the whole team" : "Your bookings"
        }`}
        actions={
          isManager ? (
            <div className="flex items-center gap-2">
              <Switch
                id="today-mine"
                checked={mineOnly}
                onCheckedChange={setMine}
                className="cursor-pointer"
              />
              <Label htmlFor="today-mine" className="cursor-pointer text-sm">
                Only mine
              </Label>
            </div>
          ) : null
        }
      />

      {data === undefined ? (
        <TodaySkeleton />
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            {stats.map((s) => (
              <Card key={s.label} className="gap-2 px-4 py-4">
                <s.icon className="size-4 text-primary" />
                <p className="font-display text-3xl font-semibold tabular-nums">
                  {s.value}
                </p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </Card>
            ))}
          </div>

          <TodayProgramme items={data.programme} />

          <div className="grid gap-6 lg:grid-cols-2">
            <TodaySection
              icon={Route}
              title="Travelling now"
              count={data.travelling.length}
              emptyText="No groups on the road today."
            >
              {data.travelling.map((b) => (
                <BookingRow
                  key={b._id}
                  booking={b}
                  showOwner={showOwner}
                  hint={tripDay(b.startDate, b.endDate, today)}
                />
              ))}
            </TodaySection>

            <TodaySection
              icon={PlaneTakeoff}
              title="Departing soon"
              count={data.departing.length}
              emptyText="No departures in the next 14 days."
            >
              {data.departing.map((b) => (
                <BookingRow
                  key={b._id}
                  booking={b}
                  showOwner={showOwner}
                  hint={`Departs ${relativeDay(b.startDate, today)}`}
                  hintTone={b.stage === "quoted" ? "alert" : "muted"}
                />
              ))}
            </TodaySection>

            <TodaySection
              icon={FilePen}
              title="Enquiries to quote"
              count={data.needsQuote.length}
              emptyText="Every enquiry has a quote. Nice work."
              footer={
                data.needsQuoteHasMore ? (
                  <Link
                    to="/bookings?stage=enquiry"
                    className="block cursor-pointer border-t px-4 py-2.5 text-center text-xs font-medium text-primary hover:bg-muted/60"
                  >
                    See all enquiries
                  </Link>
                ) : null
              }
            >
              {data.needsQuote.map((b) => {
                const late = b.startDate < today;
                return (
                  <BookingRow
                    key={b._id}
                    booking={b}
                    showOwner={showOwner}
                    hint={late ? "Dates passed" : `Departs ${relativeDay(b.startDate, today)}`}
                    hintTone={late ? "alert" : "muted"}
                  />
                );
              })}
            </TodaySection>

            <TodaySection
              icon={FileClock}
              title="Quotes expiring"
              count={data.expiringQuotes.length}
              emptyText="No open quotes expire this week."
            >
              {data.expiringQuotes.map((b) => {
                const expired = b.validUntil < today;
                return (
                  <BookingRow
                    key={b._id}
                    booking={b}
                    showOwner={showOwner}
                    hint={
                      expired
                        ? `Expired ${relativeDay(b.validUntil, today)}`
                        : `Expires ${relativeDay(b.validUntil, today)}`
                    }
                    hintTone={expired ? "alert" : "warn"}
                  />
                );
              })}
            </TodaySection>

            <TodaySection
              icon={Receipt}
              title="Back home, to reconcile"
              count={data.toReconcile.length}
              emptyText="Nothing waiting to be closed."
            >
              {data.toReconcile.map((b) => (
                <BookingRow
                  key={b._id}
                  booking={b}
                  showOwner={showOwner}
                  hint={`Ended ${relativeDay(b.endDate, today)}`}
                  hintTone="warn"
                />
              ))}
            </TodaySection>
          </div>
        </>
      )}

      {isManager ? <InviteTeamCard /> : null}
    </PageContainer>
  );
}
