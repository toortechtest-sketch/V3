import { useMemo, useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { ConvexError } from "convex/values";
import { toast } from "sonner";
import { Search, UserX, UsersRound } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import type { StaffRole } from "@/convex/schema/staff.ts";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { ROLE_LABELS, ROLE_OPTIONS, initials } from "@/lib/roles.ts";
import { Avatar, AvatarFallback } from "@/components/ui/avatar.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import InviteDialog from "./_components/invite-dialog.tsx";
import PendingInvites from "./_components/pending-invites.tsx";
import TeamActivity from "./_components/team-activity.tsx";

type Filter = "all" | "pending" | "active";

function errorMessage(error: unknown) {
  if (error instanceof ConvexError) {
    return (error.data as { message: string }).message;
  }
  return "Something went wrong. Please try again.";
}

function MemberRow({
  member,
  isSelf,
  canTouchOwner,
}: {
  member: {
    userId: Id<"users">;
    name: string | null;
    email: string | null;
    role: StaffRole | null;
  };
  isSelf: boolean;
  canTouchOwner: boolean;
}) {
  const setRole = useMutation(api.staff.setRole);
  const revoke = useMutation(api.staff.revokeAccess);
  const [busy, setBusy] = useState(false);
  const locked = isSelf || (member.role === "owner" && !canTouchOwner);

  const run = async (action: () => Promise<null>, success: string) => {
    setBusy(true);
    try {
      await action();
      toast.success(success);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  const label = member.name ?? member.email ?? "Unnamed";
  return (
    <div className="flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center">
      <div className="flex min-w-0 flex-1 items-center gap-3">
        <Avatar className="size-9">
          <AvatarFallback className="bg-secondary text-xs font-semibold uppercase text-secondary-foreground">
            {initials(label)}
          </AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <p className="flex items-center gap-2 truncate font-medium">
            {label}
            {isSelf ? (
              <span className="text-xs font-normal text-muted-foreground">
                (you)
              </span>
            ) : null}
          </p>
          <p className="truncate text-sm text-muted-foreground">
            {member.email ?? "No email"}
          </p>
        </div>
      </div>
      <div className="flex items-center gap-2">
        {member.role === null ? (
          <Badge className="bg-[#FFB800]/15 text-[#8a6400] dark:text-[#FFB800]">
            Awaiting approval
          </Badge>
        ) : null}
        <Select
          value={member.role ?? undefined}
          disabled={locked || busy}
          onValueChange={(value) =>
            void run(
              () =>
                setRole({ userId: member.userId, role: value as StaffRole }),
              `${label} is now ${ROLE_LABELS[value as StaffRole]}`,
            )
          }
        >
          <SelectTrigger className="w-44 cursor-pointer">
            <SelectValue placeholder="Approve as…">
              {member.role ? ROLE_LABELS[member.role] : undefined}
            </SelectValue>
          </SelectTrigger>
          <SelectContent>
            {ROLE_OPTIONS.filter(
              (o) => o.value !== "owner" || canTouchOwner,
            ).map((option) => (
              <SelectItem
                key={option.value}
                value={option.value}
                className="cursor-pointer"
              >
                <div className="flex flex-col">
                  <span>{option.label}</span>
                  <span className="text-xs text-muted-foreground">
                    {option.description}
                  </span>
                </div>
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {member.role !== null && !locked ? (
          <Button
            variant="ghost"
            size="icon"
            disabled={busy}
            aria-label={`Remove access for ${label}`}
            className="cursor-pointer text-muted-foreground hover:text-destructive"
            onClick={() =>
              void run(
                () => revoke({ userId: member.userId }),
                `Access removed for ${label}`,
              )
            }
          >
            <UserX className="size-4" />
          </Button>
        ) : (
          <span className="size-9" />
        )}
      </div>
    </div>
  );
}

function TeamList() {
  const team = useQuery(api.staff.listTeam, {});
  const { me, role } = useStaff();
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");

  const visible = useMemo(() => {
    const term = search.trim().toLowerCase();
    return (team ?? [])
      .filter((m) =>
        filter === "all"
          ? true
          : filter === "pending"
            ? m.role === null
            : m.role !== null,
      )
      .filter(
        (m) =>
          !term ||
          (m.name ?? "").toLowerCase().includes(term) ||
          (m.email ?? "").toLowerCase().includes(term),
      )
      .sort((a, b) => Number(a.role !== null) - Number(b.role !== null));
  }, [team, filter, search]);

  if (team === undefined) {
    return (
      <Card className="divide-y py-0">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 px-4 py-3">
            <Skeleton className="size-9 rounded-full" />
            <div className="flex-1 space-y-1.5">
              <Skeleton className="h-4 w-40" />
              <Skeleton className="h-3 w-56" />
            </div>
            <Skeleton className="h-9 w-44" />
          </div>
        ))}
      </Card>
    );
  }

  const pendingCount = team.filter((m) => m.role === null).length;
  const selfId = me?.status === "active" ? me.userId : null;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <Tabs value={filter} onValueChange={(v) => setFilter(v as Filter)}>
          <TabsList>
            <TabsTrigger value="all" className="cursor-pointer">
              Everyone
            </TabsTrigger>
            <TabsTrigger value="pending" className="cursor-pointer">
              Awaiting approval
              {pendingCount ? (
                <span className="rounded-full bg-[#FFB800] px-1.5 text-[10px] font-semibold text-[#0B1B2B]">
                  {pendingCount}
                </span>
              ) : null}
            </TabsTrigger>
            <TabsTrigger value="active" className="cursor-pointer">
              Active
            </TabsTrigger>
          </TabsList>
        </Tabs>
        <div className="relative sm:w-64">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name or email"
            className="pl-9"
          />
        </div>
      </div>

      {visible.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <UsersRound />
            </EmptyMedia>
            <EmptyTitle>
              {filter === "pending" ? "No one is waiting" : "No team members"}
            </EmptyTitle>
            <EmptyDescription>
              New staff appear here after they sign in, or invite them first.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : (
        <Card className="divide-y py-0">
          {visible.map((member) => (
            <MemberRow
              key={member.userId}
              member={member}
              isSelf={member.userId === selfId}
              canTouchOwner={role === "owner"}
            />
          ))}
        </Card>
      )}
    </div>
  );
}

export default function TeamPage() {
  const { isManager, me, role } = useStaff();
  if (me !== undefined && !isManager) {
    return (
      <PageContainer>
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <UsersRound />
            </EmptyMedia>
            <EmptyTitle>Managers only</EmptyTitle>
            <EmptyDescription>
              Only owners and global managers can manage the team.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      </PageContainer>
    );
  }
  return (
    <PageContainer>
      <PageHeader
        title="Team"
        description="Invite staff or approve people who signed in, and choose what they can do. Anyone without a role can't see any data."
        actions={isManager ? <InviteDialog canInviteOwner={role === "owner"} /> : null}
      />
      {isManager ? (
        <Tabs defaultValue="members">
          <TabsList>
            <TabsTrigger value="members" className="cursor-pointer">Members</TabsTrigger>
            <TabsTrigger value="activity" className="cursor-pointer">Activity</TabsTrigger>
          </TabsList>
          <TabsContent value="members" className="space-y-6">
            <PendingInvites canTouchOwner={role === "owner"} />
            <TeamList />
          </TabsContent>
          <TabsContent value="activity">
            <TeamActivity />
          </TabsContent>
        </Tabs>
      ) : null}
    </PageContainer>
  );
}
