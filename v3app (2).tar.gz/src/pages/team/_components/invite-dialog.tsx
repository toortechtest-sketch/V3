import { useState } from "react";
import { useMutation } from "convex/react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { toast } from "sonner";
import { UserPlus } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { StaffRole } from "@/convex/schema/staff.ts";
import { errorMessage } from "@/lib/errors.ts";
import { ROLE_LABELS, ROLE_OPTIONS } from "@/lib/roles.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";

const ROLE_VALUES = ["owner", "global_manager", "agency_manager", "agent"] as const;

const schema = z.object({
  email: z.string().trim().email("Enter a valid email"),
  role: z.enum(ROLE_VALUES),
});
type Values = z.infer<typeof schema>;

export default function InviteDialog({ canInviteOwner }: { canInviteOwner: boolean }) {
  const [open, setOpen] = useState(false);
  const create = useMutation(api.invites.create);
  const form = useForm<Values>({
    resolver: zodResolver(schema),
    defaultValues: { email: "", role: "agent" },
  });

  const onSubmit = async (values: Values) => {
    try {
      const result = await create(values);
      const roleLabel = ROLE_LABELS[values.role satisfies StaffRole];
      toast.success(
        result.status === "approved"
          ? `${values.email} was already waiting and is now ${roleLabel}`
          : `Invited ${values.email} as ${roleLabel}`,
      );
      form.reset({ email: "", role: values.role });
      setOpen(false);
    } catch (error) {
      toast.error(errorMessage(error));
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="cursor-pointer">
          <UserPlus className="size-4" /> Invite member
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Invite a team member</DialogTitle>
          <DialogDescription>
            They get this role automatically the first time they sign in with this email. Send
            them the app link yourself.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email</FormLabel>
                  <FormControl>
                    <Input type="email" placeholder="anna@toor.tech" autoFocus {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="role"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Role</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ROLE_OPTIONS.filter((o) => o.value !== "owner" || canInviteOwner).map(
                        (option) => (
                          <SelectItem
                            key={option.value}
                            value={option.value}
                            className="cursor-pointer"
                          >
                            <div className="flex flex-col">
                              <span>{option.label}</span>
                              <span className="text-xs text-muted-foreground">
                                {option.description}
                              </span>
                            </div>
                          </SelectItem>
                        ),
                      )}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => setOpen(false)}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={form.formState.isSubmitting}
                className="cursor-pointer"
              >
                Send invite
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
