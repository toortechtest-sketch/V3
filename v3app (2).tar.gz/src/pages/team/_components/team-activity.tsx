import { useState } from "react";
import { useQuery } from "convex/react";
import { Activity, Circle, History } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Avatar, AvatarFallback } from "@/components/ui/avatar.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Empty, EmptyDescription, EmptyHeader, EmptyMedia, EmptyTitle } from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { formatDuration, formatLastSeen } from "@/lib/activity.ts";
import { ROLE_LABELS, initials } from "@/lib/roles.ts";
import { cn } from "@/lib/utils.ts";

function MemberDetail({ userId, onClose }: { userId: Id<"users">; onClose: () => void }) {
  const stats = useQuery(api.activity.memberStats, { userId });
  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <History className="size-4" /> Recent sessions
          </DialogTitle>
          <DialogDescription>Active time this person has spent in Toor.</DialogDescription>
        </DialogHeader>
        {stats === undefined ? (
          <Skeleton className="h-40 w-full" />
        ) : stats.recentSessions.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted-foreground">No activity recorded yet.</p>
        ) : (
          <div className="max-h-72 divide-y overflow-y-auto">
            {stats.recentSessions.map((s, i) => {
              const date = new Date(s.startedAt);
              return (
                <div key={i} className="flex items-center justify-between py-1.5 text-sm">
                  <span className="text-muted-foreground">
                    {date.toLocaleDateString(undefined, { day: "numeric", month: "short" })}
                    {" · "}
                    {date.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
                  </span>
                  <span className="font-medium tabular-nums">{formatDuration(s.durationMs)}</span>
                </div>
              );
            })}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}

export default function TeamActivity() {
  const rows = useQuery(api.activity.teamStats, {});
  const [selected, setSelected] = useState<Id<"users"> | null>(null);

  if (rows === undefined) {
    return (
      <Card className="divide-y py-0">
        {Array.from({ length: 4 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 px-4 py-3">
            <Skeleton className="size-9 rounded-full" />
            <Skeleton className="h-4 w-40" />
          </div>
        ))}
      </Card>
    );
  }

  if (rows.length === 0) {
    return (
      <Empty className="border">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <Activity />
          </EmptyMedia>
          <EmptyTitle>No activity yet</EmptyTitle>
          <EmptyDescription>Usage time appears here once staff start using Toor.</EmptyDescription>
        </EmptyHeader>
      </Empty>
    );
  }

  return (
    <>
      <Card className="divide-y py-0">
        {rows.map((m) => {
          const label = m.name ?? m.email ?? "Unnamed";
          return (
            <button
              key={m.userId}
              type="button"
              onClick={() => setSelected(m.userId)}
              className="flex w-full cursor-pointer flex-col gap-3 px-4 py-3 text-left transition-colors hover:bg-muted/50 sm:flex-row sm:items-center"
            >
              <div className="flex min-w-0 flex-1 items-center gap-3">
                <Avatar className="size-9">
                  <AvatarFallback className="bg-secondary text-xs font-semibold uppercase text-secondary-foreground">
                    {initials(label)}
                  </AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="flex items-center gap-1.5 truncate font-medium">
                    {label}
                    {m.online ? (
                      <Circle className="size-2 fill-emerald-500 text-emerald-500" />
                    ) : null}
                  </p>
                  <p className="truncate text-sm text-muted-foreground">
                    {ROLE_LABELS[m.role]} · {formatLastSeen(m.lastSeenAt)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-4 text-sm sm:gap-6">
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Today</p>
                  <p className="font-medium tabular-nums">{formatDuration(m.todayMs)}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">This week</p>
                  <p className="font-medium tabular-nums">{formatDuration(m.weekMs)}</p>
                </div>
                {m.online ? (
                  <Badge className={cn("border-0 bg-emerald-500/15 text-emerald-700 dark:text-emerald-400")}>
                    Online
                  </Badge>
                ) : (
                  <span className="w-[52px]" />
                )}
              </div>
            </button>
          );
        })}
      </Card>
      {selected ? <MemberDetail userId={selected} onClose={() => setSelected(null)} /> : null}
    </>
  );
}
