import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { formatDistanceToNow } from "date-fns";
import { toast } from "sonner";
import { MailPlus, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { errorMessage } from "@/lib/errors.ts";
import { ROLE_LABELS } from "@/lib/roles.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";

/** Invites not yet claimed. Hidden entirely when there are none. */
export default function PendingInvites({ canTouchOwner }: { canTouchOwner: boolean }) {
  const invites = useQuery(api.invites.list, {});
  const cancel = useMutation(api.invites.cancel);
  const [busyId, setBusyId] = useState<Id<"staffInvites"> | null>(null);

  if (!invites || invites.length === 0) return null;

  const onCancel = async (inviteId: Id<"staffInvites">, email: string) => {
    setBusyId(inviteId);
    try {
      await cancel({ inviteId });
      toast.success(`Invite for ${email} cancelled`);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusyId(null);
    }
  };

  return (
    <section className="space-y-2">
      <h2 className="text-sm font-medium text-muted-foreground">
        Invited, not signed in yet ({invites.length})
      </h2>
      <Card className="divide-y py-0">
        {invites.map((invite) => (
          <div key={invite.inviteId} className="flex items-center gap-3 px-4 py-3">
            <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-accent text-accent-foreground">
              <MailPlus className="size-4" />
            </div>
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">{invite.email}</p>
              <p className="text-sm text-muted-foreground">
                Invited {formatDistanceToNow(new Date(invite.invitedAt), { addSuffix: true })}
              </p>
            </div>
            <Badge variant="secondary">{ROLE_LABELS[invite.role]}</Badge>
            <Button
              variant="ghost"
              size="icon"
              disabled={busyId === invite.inviteId || (invite.role === "owner" && !canTouchOwner)}
              aria-label={`Cancel invite for ${invite.email}`}
              className="cursor-pointer text-muted-foreground hover:text-destructive"
              onClick={() => void onCancel(invite.inviteId, invite.email)}
            >
              <X className="size-4" />
            </Button>
          </div>
        ))}
      </Card>
    </section>
  );
}
