import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation } from "convex/react";
import { usePaginatedQuery } from "convex/react";
import {
  AlertTriangle,
  ArrowLeft,
  CheckCircle2,
  CircleDashed,
  HelpCircle,
  ShieldAlert,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import { SERVICE_CATEGORY_LABELS } from "@/convex/schema/supplierCategories.ts";

const PAGE_SIZE = 50;

const STATUS_META: Record<
  "mapped" | "ambiguous" | "skipped",
  { label: string; badge: string; icon: typeof CheckCircle2 }
> = {
  mapped: {
    label: "Will map",
    badge: "bg-primary/12 text-primary dark:text-[#7fa6ff]",
    icon: CheckCircle2,
  },
  ambiguous: {
    label: "Needs review",
    badge: "bg-[#FFB800]/18 text-[#8a6400] dark:text-[#FFB800]",
    icon: HelpCircle,
  },
  skipped: {
    label: "No change needed",
    badge: "bg-muted text-muted-foreground",
    icon: CircleDashed,
  },
};

function PreviewList() {
  const { results, status, loadMore } = usePaginatedQuery(
    api.suppliers.migration.preview,
    {},
    { initialNumItems: PAGE_SIZE },
  );

  if (status === "LoadingFirstPage") {
    return (
      <Card className="gap-0 divide-y py-0">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 px-4 py-3">
            <Skeleton className="h-4 w-48" />
            <Skeleton className="ml-auto h-5 w-24" />
          </div>
        ))}
      </Card>
    );
  }

  if (results.length === 0 && status === "Exhausted") {
    return (
      <Empty className="border bg-card">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            <CircleDashed />
          </EmptyMedia>
          <EmptyTitle>No suppliers yet</EmptyTitle>
          <EmptyDescription>
            Add suppliers before running the migration preview.
          </EmptyDescription>
        </EmptyHeader>
      </Empty>
    );
  }

  return (
    <div className="space-y-3">
      <Card className="gap-0 divide-y overflow-hidden py-0">
        {results.map((row) => {
          const meta = STATUS_META[row.status];
          return (
            <div key={row.supplierId} className="flex items-center gap-3 px-4 py-3">
              <meta.icon
                className={cn(
                  "size-4 shrink-0",
                  row.status === "mapped" && "text-primary",
                  row.status === "ambiguous" && "text-[#8a6400] dark:text-[#FFB800]",
                  row.status === "skipped" && "text-muted-foreground",
                )}
              />
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium">{row.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  Legacy: {row.legacyCategory}
                  {row.mappedPrimaryType
                    ? ` → ${SERVICE_CATEGORY_LABELS[row.mappedPrimaryType]}`
                    : ""}
                  {row.note ? ` · ${row.note}` : ""}
                  {row.alreadyProcessed ? " · already processed" : ""}
                </p>
              </div>
              <Badge className={cn("shrink-0 border-0", meta.badge)}>{meta.label}</Badge>
            </div>
          );
        })}
      </Card>
      {status === "CanLoadMore" || status === "LoadingMore" ? (
        <div className="flex justify-center">
          <Button
            variant="secondary"
            size="sm"
            className="cursor-pointer"
            disabled={status === "LoadingMore"}
            onClick={() => loadMore(PAGE_SIZE)}
          >
            {status === "LoadingMore" ? "Loading…" : "Load more"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}

type RunTotals = { mapped: number; ambiguous: number; skipped: number; alreadyMigrated: number };

function RunBackfillCard() {
  const run = useMutation(api.suppliers.migration.runBackfill);
  const [running, setRunning] = useState(false);
  const [totals, setTotals] = useState<RunTotals | null>(null);

  const runAll = async (dryRun: boolean) => {
    setRunning(true);
    setTotals(null);
    const combined: RunTotals = { mapped: 0, ambiguous: 0, skipped: 0, alreadyMigrated: 0 };
    try {
      let cursor: string | null = null;
      let isDone = false;
      while (!isDone) {
        const result: {
          mapped: number;
          ambiguous: number;
          skipped: number;
          alreadyMigrated: number;
          isDone: boolean;
          continueCursor: string;
        } = await run({
          paginationOpts: { numItems: 50, cursor },
          dryRun,
        });
        combined.mapped += result.mapped;
        combined.ambiguous += result.ambiguous;
        combined.skipped += result.skipped;
        combined.alreadyMigrated += result.alreadyMigrated;
        isDone = result.isDone;
        cursor = result.continueCursor;
      }
      setTotals(combined);
      toast.success(dryRun ? "Dry run complete" : "Backfill complete");
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setRunning(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-lg">Run the backfill</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          A dry run tallies what would happen without writing anything, and can
          be run as many times as you like. Running for real sets each
          supplier's primary type, enables its matching service, and — for
          hotels — carries room types over as products, then logs the
          supplier so a rerun never reprocesses or duplicates it.
        </p>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="secondary"
            className="cursor-pointer"
            disabled={running}
            onClick={() => void runAll(true)}
          >
            {running ? <Spinner /> : null}
            Dry run (no changes)
          </Button>
          <Button
            className="cursor-pointer"
            disabled={running}
            onClick={() => void runAll(false)}
          >
            {running ? <Spinner /> : null}
            Run backfill for real
          </Button>
        </div>
        {totals ? (
          <div className="grid grid-cols-2 gap-px overflow-hidden rounded-lg bg-border sm:grid-cols-4">
            {(
              [
                { label: "Mapped", value: totals.mapped },
                { label: "Needs review", value: totals.ambiguous },
                { label: "No change needed", value: totals.skipped },
                { label: "Already processed", value: totals.alreadyMigrated },
              ] as const
            ).map((stat) => (
              <div key={stat.label} className="space-y-1 bg-card p-4">
                <p className="font-display text-2xl font-semibold">{stat.value}</p>
                <p className="text-xs text-muted-foreground">{stat.label}</p>
              </div>
            ))}
          </div>
        ) : null}
      </CardContent>
    </Card>
  );
}

function ManagersOnly() {
  return (
    <Empty className="border">
      <EmptyHeader>
        <EmptyMedia variant="icon">
          <ShieldAlert />
        </EmptyMedia>
        <EmptyTitle>Managers only</EmptyTitle>
        <EmptyDescription>
          Only owners and global managers can run the supplier migration tooling.
        </EmptyDescription>
      </EmptyHeader>
    </Empty>
  );
}

export default function SupplierMigrationPage() {
  const { isManager, me } = useStaff();

  return (
    <PageContainer>
      <Button
        asChild
        variant="ghost"
        size="sm"
        className="-ml-2 cursor-pointer text-muted-foreground"
      >
        <Link to="/suppliers">
          <ArrowLeft className="size-4" /> Suppliers & hotels
        </Link>
      </Button>
      <PageHeader
        title="Legacy migration"
        description="Preview and run the one-time move from the old supplier category onto the new primary type and service model. Nothing here is run automatically."
      />
      {me === undefined ? (
        <div className="space-y-6">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      ) : !isManager ? (
        <ManagersOnly />
      ) : (
        <>
          <RunBackfillCard />
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="size-4 text-muted-foreground" />
              <h2 className="font-display text-lg font-semibold">Preview</h2>
            </div>
            <PreviewList />
          </div>
        </>
      )}
    </PageContainer>
  );
}
