import type { FieldDef } from "@/lib/supplier-categories.ts";

/** Form-friendly attribute value: booleans stay booleans, everything else is a string. */
export type AttributeFormValue = string | boolean;
export type AttributeFormValues = Record<string, AttributeFormValue>;

/** Raw attribute value as stored/returned by the backend. */
export type StoredAttributeValue = string | number | boolean | string[];
export type StoredAttributes = Record<string, StoredAttributeValue>;

/** Converts stored attributes into form state defaults for the given fields. */
export function attributesToForm(
  fields: readonly FieldDef[],
  attributes: StoredAttributes | undefined,
): AttributeFormValues {
  const out: AttributeFormValues = {};
  for (const field of fields) {
    const value = attributes?.[field.key];
    if (field.type === "boolean") {
      out[field.key] = Boolean(value);
    } else if (Array.isArray(value)) {
      out[field.key] = value.join(", ");
    } else if (value === undefined || value === null) {
      out[field.key] = "";
    } else {
      out[field.key] = String(value);
    }
  }
  return out;
}

/** A short summary of filled-in attributes for a compact list row. */
export function summarizeAttributes(
  fields: readonly FieldDef[],
  attributes: StoredAttributes,
  max = 3,
): string {
  const parts: string[] = [];
  for (const field of fields) {
    const value = attributes[field.key];
    if (value === undefined || value === null || value === "") continue;
    if (field.type === "boolean") {
      if (value) parts.push(field.label);
    } else if (Array.isArray(value)) {
      parts.push(`${field.label}: ${value.join(", ")}`);
    } else {
      parts.push(`${field.label}: ${value}`);
    }
    if (parts.length >= max) break;
  }
  return parts.join(" · ");
}
