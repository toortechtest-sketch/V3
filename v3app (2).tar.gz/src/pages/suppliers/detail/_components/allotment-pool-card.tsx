import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { format } from "date-fns";
import {
  CalendarPlus,
  Trash2,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
  EmptyContent,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { formatInZone } from "@/lib/allotments.ts";
import BulkSlotDialog from "./bulk-slot-dialog.tsx";

function RemoveSlotButton({ slotId, label }: { slotId: Doc<"allotmentSlots">["_id"]; label: string }) {
  const remove = useMutation(api.suppliers.allotments.removeSlot);
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          size="icon"
          variant="ghost"
          aria-label={`Remove ${label}`}
          className="size-7 cursor-pointer text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="size-3.5" />
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Remove {label}?</AlertDialogTitle>
          <AlertDialogDescription>
            This removes the date from the pool. Dates with reservations attached
            can't be removed.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="cursor-pointer">Cancel</AlertDialogCancel>
          <AlertDialogAction
            className="cursor-pointer bg-destructive text-white hover:bg-destructive/90"
            onClick={() => {
              remove({ id: slotId }).then(
                () => toast.success("Date removed"),
                (error: unknown) => toast.error(errorMessage(error)),
              );
            }}
          >
            Remove
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function RemovePoolButton({ pool }: { pool: Doc<"allotmentPools"> }) {
  const remove = useMutation(api.suppliers.allotments.removePool);
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          variant="ghost"
          size="sm"
          className="cursor-pointer text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="size-4" /> Delete pool
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {pool.name}?</AlertDialogTitle>
          <AlertDialogDescription>
            This removes the pool and all its dates. Pools with existing
            reservations can't be deleted.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="cursor-pointer">Cancel</AlertDialogCancel>
          <AlertDialogAction
            className="cursor-pointer bg-destructive text-white hover:bg-destructive/90"
            onClick={() => {
              remove({ id: pool._id }).then(
                () => toast.success("Pool deleted"),
                (error: unknown) => toast.error(errorMessage(error)),
              );
            }}
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function EnabledToggle({ pool }: { pool: Doc<"allotmentPools"> }) {
  const setEnabled = useMutation(api.suppliers.allotments.setPoolEnabled);
  const [busy, setBusy] = useState(false);
  const toggle = async () => {
    setBusy(true);
    try {
      await setEnabled({ id: pool._id, enabled: !pool.enabled });
      toast.success(pool.enabled ? "Pool disabled" : "Pool enabled");
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };
  return (
    <Button
      size="sm"
      variant={pool.enabled ? "secondary" : "default"}
      disabled={busy}
      className="cursor-pointer"
      onClick={() => void toggle()}
    >
      {pool.enabled ? "Disable" : "Enable"}
    </Button>
  );
}

export default function AllotmentPoolCard({
  pool,
  resourceName,
}: {
  pool: Doc<"allotmentPools">;
  resourceName: string;
}) {
  const [bulkOpen, setBulkOpen] = useState(false);
  const availability = useQuery(api.suppliers.allotments.availability, { poolId: pool._id });

  return (
    <div className="space-y-4 rounded-xl border bg-card p-4">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h3 className="font-display text-lg font-semibold">{pool.name}</h3>
            <Badge variant={pool.enabled ? "default" : "secondary"} className={pool.enabled ? "" : "bg-muted text-muted-foreground"}>
              {pool.enabled ? "Enabled" : "Disabled"}
            </Badge>
          </div>
          <p className="text-sm text-muted-foreground">
            {resourceName} · {pool.unit}s · {pool.contractReference} · {pool.timezone}
          </p>
        </div>
        <div className="flex shrink-0 flex-wrap gap-2">
          <EnabledToggle pool={pool} />
          <Button size="sm" className="cursor-pointer" onClick={() => setBulkOpen(true)}>
            <CalendarPlus className="size-4" /> Add dates
          </Button>
          <RemovePoolButton pool={pool} />
        </div>
      </div>

      {availability === undefined ? (
        <Skeleton className="h-32 w-full" />
      ) : availability.length === 0 ? (
        <Empty className="py-6">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <CalendarPlus />
            </EmptyMedia>
            <EmptyTitle>No dates yet</EmptyTitle>
            <EmptyDescription>
              Add contracted dates with capacity and a release deadline before this
              pool can be used on a booking.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" className="cursor-pointer" onClick={() => setBulkOpen(true)}>
              Add dates
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <div className="overflow-hidden rounded-lg border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>{pool.kind === "hotel_night" ? "Night" : "Departure"}</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="text-right">Held</TableHead>
                <TableHead className="text-right">Confirmed</TableHead>
                <TableHead className="text-right">Retired</TableHead>
                <TableHead className="text-right">Available</TableHead>
                <TableHead>Release</TableHead>
                <TableHead />
              </TableRow>
            </TableHeader>
            <TableBody>
              {availability.map((slot) => (
                <TableRow key={slot._id}>
                  <TableCell className="font-medium">
                    {format(new Date(`${slot.serviceDate}T00:00:00`), "d MMM yyyy")}
                    {pool.kind === "session" && slot.serviceKey !== slot.serviceDate ? (
                      <span className="ml-1.5 text-xs text-muted-foreground">({slot.serviceKey})</span>
                    ) : null}
                    {slot.stopSale ? (
                      <Badge variant="destructive" className="ml-2">
                        Stop sale
                      </Badge>
                    ) : !slot.enabled ? (
                      <Badge variant="secondary" className="ml-2 bg-muted text-muted-foreground">
                        Disabled
                      </Badge>
                    ) : null}
                  </TableCell>
                  <TableCell className="text-right">{slot.capacity}</TableCell>
                  <TableCell className="text-right">{slot.held}</TableCell>
                  <TableCell className="text-right">{slot.confirmed}</TableCell>
                  <TableCell className="text-right">{slot.retired}</TableCell>
                  <TableCell className="text-right font-medium">{slot.available}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {formatInZone(slot.releaseAt, pool.timezone)}
                  </TableCell>
                  <TableCell>
                    <RemoveSlotButton
                      slotId={slot._id}
                      label={format(new Date(`${slot.serviceDate}T00:00:00`), "d MMM yyyy")}
                    />
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
      <BulkSlotDialog open={bulkOpen} onOpenChange={setBulkOpen} pool={pool} />
    </div>
  );
}
