import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import type { FieldDef } from "@/lib/supplier-categories.ts";
import type { AttributeFormValue, AttributeFormValues } from "../_lib/attributes.ts";

/**
 * Renders one input per field in the category registry, backed by a plain
 * controlled values object (not react-hook-form/zod) since the field set
 * changes per category and types mix text/number/boolean/list/enum.
 */
export default function DynamicFields({
  fields,
  values,
  onChange,
}: {
  fields: readonly FieldDef[];
  values: AttributeFormValues;
  onChange: (key: string, value: AttributeFormValue) => void;
}) {
  if (fields.length === 0) return null;
  return (
    <div className="grid gap-4 sm:grid-cols-2">
      {fields.map((field) => {
        const value = values[field.key] ?? (field.type === "boolean" ? false : "");
        if (field.type === "boolean") {
          return (
            <label
              key={field.key}
              className="flex items-center gap-2 self-end pb-1.5"
            >
              <Checkbox
                checked={Boolean(value)}
                onCheckedChange={(v) => onChange(field.key, v === true)}
                className="cursor-pointer"
              />
              <span className="text-sm">{field.label}</span>
            </label>
          );
        }
        if (field.type === "enum") {
          return (
            <div key={field.key} className="space-y-2">
              <Label>{field.label}</Label>
              <Select
                value={String(value) || undefined}
                onValueChange={(v) => onChange(field.key, v)}
              >
                <SelectTrigger className="w-full cursor-pointer">
                  <SelectValue placeholder="Not set" />
                </SelectTrigger>
                <SelectContent>
                  {field.options?.map((opt) => (
                    <SelectItem key={opt} value={opt} className="cursor-pointer">
                      {opt.replaceAll("_", " ")}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          );
        }
        return (
          <div key={field.key} className="space-y-2">
            <Label>
              {field.label}
              {field.type === "list" ? (
                <span className="font-normal text-muted-foreground"> (comma separated)</span>
              ) : null}
            </Label>
            <Input
              type={field.type === "number" ? "number" : "text"}
              inputMode={field.type === "number" ? "numeric" : undefined}
              placeholder={field.placeholder}
              value={String(value)}
              onChange={(e) => onChange(field.key, e.target.value)}
            />
          </div>
        );
      })}
    </div>
  );
}
