import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { ALLOTMENT_KIND_LABELS, COMMON_TIMEZONES, isValidTimezone } from "@/lib/allotments.ts";

const schema = z.object({
  resourceKey: z.string().min(1, "Pick a resource"),
  name: z.string().trim().min(1, "Add a name").max(200),
  kind: z.enum(["hotel_night", "session"]),
  unit: z.string().trim().min(1, "Add a unit").max(60),
  timezone: z.string().trim().refine(isValidTimezone, { message: "Use a valid IANA time zone" }),
  contractReference: z.string().trim().min(1, "Add a contract reference").max(200),
});

type FormValues = z.infer<typeof schema>;

/** resourceKey encodes which table + id the pool should reference. */
function parseResourceKey(key: string): { productId?: Id<"supplierProducts">; roomTypeId?: Id<"supplierRoomTypes"> } {
  const [kind, id] = key.split(":");
  return kind === "product" ? { productId: id as Id<"supplierProducts"> } : { roomTypeId: id as Id<"supplierRoomTypes"> };
}

export default function AllotmentPoolDialog({
  open,
  onOpenChange,
  supplierId,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  supplierId: Id<"suppliers">;
}) {
  const resources = useQuery(
    api.suppliers.allotments.listPoolableResources,
    open ? { supplierId } : "skip",
  );
  const createPool = useMutation(api.suppliers.allotments.createPool);
  const [saving, setSaving] = useState(false);

  const defaults = (): FormValues => ({
    resourceKey: "",
    name: "",
    kind: "hotel_night",
    unit: "room",
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || "UTC",
    contractReference: "",
  });
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaults(),
  });
  const resourceKey = useWatch({ control: form.control, name: "resourceKey" });

  const handleOpenChange = (next: boolean) => {
    if (next) form.reset(defaults());
    onOpenChange(next);
  };

  const options = resources
    ? [
        ...resources.roomTypes.map((r) => ({
          key: `room:${r._id}`,
          label: `${r.name} (room type)`,
          kind: "hotel_night" as const,
        })),
        ...resources.products.map((p) => ({
          key: `product:${p._id}`,
          label: `${p.name} (${p.category})`,
          kind: "session" as const,
        })),
      ]
    : [];

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      const resource = parseResourceKey(values.resourceKey);
      const option = options.find((o) => o.key === values.resourceKey);
      await createPool({
        supplierId,
        ...resource,
        name: values.name,
        kind: option?.kind ?? values.kind,
        unit: values.unit,
        timezone: values.timezone,
        contractReference: values.contractReference,
      });
      toast.success("Allotment pool created");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">New allotment pool</DialogTitle>
          <DialogDescription>
            Tracks contracted stock for one product or room type. It starts disabled
            with no dates, so nothing is sellable until you add capacity.
          </DialogDescription>
        </DialogHeader>

        {resources === undefined ? (
          <Skeleton className="h-48 w-full" />
        ) : options.length === 0 ? (
          <p className="rounded-lg bg-muted p-3 text-sm text-muted-foreground">
            Every product and room type already has a pool, or this supplier has none
            yet. Add a product or room type first.
          </p>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="resourceKey"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Resource</FormLabel>
                    <Select
                      value={field.value}
                      onValueChange={(v) => {
                        field.onChange(v);
                        const opt = options.find((o) => o.key === v);
                        if (opt) form.setValue("kind", opt.kind);
                      }}
                    >
                      <FormControl>
                        <SelectTrigger className="w-full cursor-pointer">
                          <SelectValue placeholder="Choose a product or room type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {options.map((o) => (
                          <SelectItem key={o.key} value={o.key} className="cursor-pointer">
                            {o.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              {resourceKey ? (
                <p className="text-xs text-muted-foreground">
                  Tracked as{" "}
                  {ALLOTMENT_KIND_LABELS[options.find((o) => o.key === resourceKey)?.kind ?? "hotel_night"]}.
                </p>
              ) : null}
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Pool name</FormLabel>
                    <FormControl>
                      <Input placeholder="Deluxe sea view double – contracted block" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <div className="grid gap-4 sm:grid-cols-2">
                <FormField
                  control={form.control}
                  name="unit"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Inventory unit</FormLabel>
                      <FormControl>
                        <Input placeholder="room, seat, vehicle…" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="contractReference"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Contract reference</FormLabel>
                      <FormControl>
                        <Input placeholder="PO-2026-114" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              <FormField
                control={form.control}
                name="timezone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Time zone</FormLabel>
                    <div className="flex gap-2">
                      <Select
                        value={COMMON_TIMEZONES.includes(field.value as (typeof COMMON_TIMEZONES)[number]) ? field.value : "custom"}
                        onValueChange={(v) => v !== "custom" && field.onChange(v)}
                      >
                        <FormControl>
                          <SelectTrigger className="w-full cursor-pointer">
                            <SelectValue />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {COMMON_TIMEZONES.map((tz) => (
                            <SelectItem key={tz} value={tz} className="cursor-pointer">
                              {tz}
                            </SelectItem>
                          ))}
                          <SelectItem value="custom" className="cursor-pointer">
                            Custom…
                          </SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <FormControl>
                      <Input placeholder="Europe/Lisbon" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <DialogFooter>
                <Button type="button" variant="ghost" className="cursor-pointer" onClick={() => onOpenChange(false)}>
                  Cancel
                </Button>
                <Button type="submit" disabled={saving} className="cursor-pointer">
                  {saving ? <Spinner /> : null}
                  Create pool
                </Button>
              </DialogFooter>
            </form>
          </Form>
        )}
      </DialogContent>
    </Dialog>
  );
}
