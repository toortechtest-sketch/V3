import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { hotelNights } from "@/convex/lib/allotmentEngine.ts";
import { zonedTimeToUtcMs } from "@/lib/allotments.ts";

/** Bulk add/edit dated slots for one pool, as a single validated transaction. */
export default function BulkSlotDialog({
  open,
  onOpenChange,
  pool,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  pool: Doc<"allotmentPools">;
}) {
  const bulkUpsert = useMutation(api.suppliers.allotments.bulkUpsertSlots);
  const [saving, setSaving] = useState(false);

  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [sessionKey, setSessionKey] = useState("");
  const [capacity, setCapacity] = useState("10");
  const [releaseDate, setReleaseDate] = useState("");
  const [releaseTime, setReleaseTime] = useState("18:00");
  const [enabled, setEnabled] = useState(true);
  const [stopSale, setStopSale] = useState(false);
  const [replenishOnReturn, setReplenishOnReturn] = useState(false);

  const reset = () => {
    setStartDate("");
    setEndDate("");
    setSessionKey("");
    setCapacity("10");
    setReleaseDate("");
    setReleaseTime("18:00");
    setEnabled(true);
    setStopSale(false);
    setReplenishOnReturn(false);
  };

  const handleOpenChange = (next: boolean) => {
    if (next) reset();
    onOpenChange(next);
  };

  const onSubmit = async () => {
    const cap = Number(capacity);
    if (!Number.isInteger(cap) || cap < 0) {
      toast.error("Capacity must be a whole number of zero or more.");
      return;
    }
    if (!releaseDate) {
      toast.error("Pick a release deadline.");
      return;
    }
    let releaseAt: number;
    try {
      releaseAt = zonedTimeToUtcMs(releaseDate, releaseTime, pool.timezone);
    } catch {
      toast.error("Invalid release date or time.");
      return;
    }

    let dates: string[];
    if (pool.kind === "hotel_night") {
      if (!startDate || !endDate) {
        toast.error("Pick a start and end date.");
        return;
      }
      try {
        dates = hotelNights(startDate, endDate);
      } catch {
        toast.error("Pick a valid date range.");
        return;
      }
    } else {
      if (!startDate) {
        toast.error("Pick the departure date.");
        return;
      }
      if (!sessionKey.trim()) {
        toast.error("Add a departure identifier.");
        return;
      }
      dates = [startDate];
    }

    setSaving(true);
    try {
      await bulkUpsert({
        poolId: pool._id,
        entries: dates.map((date) => ({
          serviceDate: date,
          serviceKey: pool.kind === "hotel_night" ? date : sessionKey.trim(),
          capacity: cap,
          releaseAt,
          enabled,
          stopSale,
          replenishOnReturn,
        })),
      });
      toast.success(`${dates.length} date${dates.length === 1 ? "" : "s"} saved`);
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Add or update dates</DialogTitle>
          <DialogDescription>
            {pool.kind === "hotel_night"
              ? "Sets the same capacity and release deadline across every night in the range. Existing dates in range are updated, not duplicated."
              : "Adds or updates one dated departure. Give it a stable identifier if there can be two departures on the same day."}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>{pool.kind === "hotel_night" ? "Check-in" : "Departure date"}</Label>
              <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
            </div>
            {pool.kind === "hotel_night" ? (
              <div className="space-y-2">
                <Label>Check-out</Label>
                <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
              </div>
            ) : (
              <div className="space-y-2">
                <Label>Departure ID</Label>
                <Input
                  placeholder="morning-tour, 09:00…"
                  value={sessionKey}
                  onChange={(e) => setSessionKey(e.target.value)}
                />
              </div>
            )}
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label>Capacity ({pool.unit}s)</Label>
              <Input
                type="number"
                inputMode="numeric"
                min={0}
                value={capacity}
                onChange={(e) => setCapacity(e.target.value)}
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label>Release deadline, in {pool.timezone}</Label>
            <div className="grid gap-2 sm:grid-cols-2">
              <Input type="date" value={releaseDate} onChange={(e) => setReleaseDate(e.target.value)} />
              <Input type="time" value={releaseTime} onChange={(e) => setReleaseTime(e.target.value)} />
            </div>
            <p className="text-xs text-muted-foreground">
              After this moment the dates stop selling. Confirmed stock stays confirmed.
            </p>
          </div>
          <div className="space-y-2 rounded-lg border p-3">
            <label className="flex items-center gap-2">
              <Checkbox checked={enabled} onCheckedChange={(v) => setEnabled(v === true)} className="cursor-pointer" />
              <span className="text-sm">Enabled (can be sold while within the pool and release window)</span>
            </label>
            <label className="flex items-center gap-2">
              <Checkbox checked={stopSale} onCheckedChange={(v) => setStopSale(v === true)} className="cursor-pointer" />
              <span className="text-sm">Stop sale (temporarily block new bookings)</span>
            </label>
            <label className="flex items-center gap-2">
              <Checkbox
                checked={replenishOnReturn}
                onCheckedChange={(v) => setReplenishOnReturn(v === true)}
                className="cursor-pointer"
              />
              <span className="text-sm">Returned units go back on sale (contract allows resale)</span>
            </label>
          </div>
        </div>
        <DialogFooter>
          <Button type="button" variant="ghost" className="cursor-pointer" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button type="button" disabled={saving} className="cursor-pointer" onClick={() => void onSubmit()}>
            {saving ? <Spinner /> : null}
            Save dates
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
