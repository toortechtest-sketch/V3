import { useState } from "react";
import { useQuery } from "convex/react";
import { Plus, Warehouse } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import AllotmentPoolCard from "./allotment-pool-card.tsx";
import AllotmentPoolDialog from "./allotment-pool-dialog.tsx";

export default function AllotmentsTab({
  supplierId,
  isManager,
}: {
  supplierId: Id<"suppliers">;
  isManager: boolean;
}) {
  const [creating, setCreating] = useState(false);
  const pools = useQuery(api.suppliers.allotments.listPools, { supplierId });

  if (pools === undefined) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <p className="max-w-2xl text-sm text-muted-foreground">
          Contracted stock for this supplier, tracked per date or departure. Nothing
          here is sellable until a pool is enabled with real dates and capacity.
        </p>
        {isManager ? (
          <Button className="cursor-pointer" onClick={() => setCreating(true)}>
            <Plus className="size-4" /> New pool
          </Button>
        ) : null}
      </div>

      {pools.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Warehouse />
            </EmptyMedia>
            <EmptyTitle>No allotment pools yet</EmptyTitle>
            <EmptyDescription>
              {isManager
                ? "Create a pool for a product or room type to track contracted stock, like a block of rooms held for a group."
                : "Only owners and global managers can set up contracted allotments."}
            </EmptyDescription>
          </EmptyHeader>
          {isManager ? (
            <EmptyContent>
              <Button size="sm" className="cursor-pointer" onClick={() => setCreating(true)}>
                New pool
              </Button>
            </EmptyContent>
          ) : null}
        </Empty>
      ) : (
        <div className="space-y-4">
          {pools.map((pool) => (
            <AllotmentPoolCard key={pool._id} pool={pool} resourceName={pool.resourceName} />
          ))}
        </div>
      )}

      {isManager ? (
        <AllotmentPoolDialog open={creating} onOpenChange={setCreating} supplierId={supplierId} />
      ) : null}
    </div>
  );
}
