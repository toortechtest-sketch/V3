import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { format } from "date-fns";
import {
  AlertTriangle,
  ArrowLeft,
  BedDouble,
  Building,
  Coins,
  Globe,
  Mail,
  MapPin,
  Pencil,
  Phone,
  Plus,
  Presentation,
  Trash2,
  UserRound,
  Users,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import QueryErrorBoundary from "@/components/query-error-boundary.tsx";
import SupplierFormDialog from "@/components/suppliers/supplier-form-dialog.tsx";
import RoomTypeDialog from "@/components/suppliers/room-type-dialog.tsx";
import AllotmentsTab from "./_components/allotments-tab.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import {
  ErrorState,
  ErrorStateContent,
  ErrorStateDescription,
  ErrorStateHeader,
  ErrorStateMedia,
  ErrorStateTitle,
} from "@/components/ui/error-state.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { formatPlace } from "@/lib/clients.ts";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import {
  BOARD_LABELS,
  CATEGORY_META,
  HOTEL_CLASS_LABELS,
  STATUS_META,
  websiteHref,
} from "@/lib/suppliers.ts";

// Convex IDs are short lowercase base32 strings; reject obviously bad URLs early.
const ID_PATTERN = /^[a-z0-9]{20,40}$/;

type Detail = NonNullable<ReturnType<typeof useSupplierDetail>>;
type InfoItem = {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: React.ReactNode;
};

function useSupplierDetail(id: Id<"suppliers">) {
  return useQuery(api.suppliers.get, { id });
}

const linkClass = "text-primary hover:underline";

function InfoList({ items }: { items: (InfoItem | null)[] }) {
  const rows = items.filter((r): r is InfoItem => r !== null);
  if (rows.length === 0) return null;
  return (
    <div className="space-y-4">
      {rows.map(({ icon: Icon, label, value }) => (
        <div key={label} className="flex gap-3">
          <Icon className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
          <div className="min-w-0">
            <p className="text-xs text-muted-foreground">{label}</p>
            <div className="text-sm break-words">{value}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

function DetailsCard({ supplier }: { supplier: Detail }) {
  const place = [supplier.address, formatPlace(supplier.city, supplier.country)]
    .filter(Boolean)
    .join(", ");
  const items: (InfoItem | null)[] = [
    supplier.contactName
      ? { icon: UserRound, label: "Contact person", value: supplier.contactName }
      : null,
    supplier.email
      ? {
          icon: Mail,
          label: "Email",
          value: (
            <a href={`mailto:${supplier.email}`} className={linkClass}>
              {supplier.email}
            </a>
          ),
        }
      : null,
    supplier.phone
      ? {
          icon: Phone,
          label: "Phone",
          value: (
            <a href={`tel:${supplier.phone}`} className={linkClass}>
              {supplier.phone}
            </a>
          ),
        }
      : null,
    supplier.website
      ? {
          icon: Globe,
          label: "Website",
          value: (
            <a
              href={websiteHref(supplier.website)}
              target="_blank"
              rel="noreferrer"
              className={linkClass}
            >
              {supplier.website}
            </a>
          ),
        }
      : null,
    place ? { icon: MapPin, label: "Address", value: place } : null,
    supplier.currency
      ? { icon: Coins, label: "Contract currency", value: supplier.currency }
      : null,
  ];
  const hasAny = items.some(Boolean);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="font-display text-lg">Details</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {hasAny ? (
          <InfoList items={items} />
        ) : (
          <p className="text-sm text-muted-foreground">
            No contact details yet. Use Edit to add them.
          </p>
        )}
        {supplier.notes ? (
          <div className="rounded-lg bg-muted p-3 text-sm whitespace-pre-wrap">
            {supplier.notes}
          </div>
        ) : null}
        <p className="border-t pt-3 text-xs text-muted-foreground">
          Added {format(supplier._creationTime, "d MMM yyyy")}
          {supplier.createdByName ? ` by ${supplier.createdByName}` : ""}
        </p>
      </CardContent>
    </Card>
  );
}

function HotelFacts({ supplier }: { supplier: Detail }) {
  const facts = [
    { icon: BedDouble, label: "Rooms", value: supplier.totalRooms },
    { icon: Presentation, label: "Meeting rooms", value: supplier.meetingRooms },
    {
      icon: Users,
      label: "Largest room",
      value: supplier.largestMeetingCapacity,
      suffix: " guests",
    },
  ];
  return (
    <Card className="gap-0 py-0">
      <div className="grid grid-cols-3 divide-x">
        {facts.map((f) => (
          <div key={f.label} className="space-y-1 p-4">
            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <f.icon className="size-3.5" /> {f.label}
            </p>
            <p className="font-display text-xl font-semibold">
              {f.value === undefined ? (
                <span className="text-muted-foreground">–</span>
              ) : (
                `${f.value.toLocaleString()}${f.suffix ?? ""}`
              )}
            </p>
          </div>
        ))}
      </div>
    </Card>
  );
}

function RemoveRoomButton({ room }: { room: Doc<"supplierRoomTypes"> }) {
  const remove = useMutation(api.suppliers.removeRoomType);
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          size="icon"
          variant="ghost"
          aria-label={`Remove ${room.name}`}
          className="size-8 cursor-pointer text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="size-4" />
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Remove {room.name}?</AlertDialogTitle>
          <AlertDialogDescription>
            This removes the room type from this hotel.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="cursor-pointer">Cancel</AlertDialogCancel>
          <AlertDialogAction
            className="cursor-pointer bg-destructive text-white hover:bg-destructive/90"
            onClick={() => {
              remove({ id: room._id }).then(
                () => toast.success("Room type removed"),
                (error: unknown) => toast.error(errorMessage(error)),
              );
            }}
          >
            Remove
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function RoomTypesCard({ supplier }: { supplier: Detail }) {
  const [adding, setAdding] = useState(false);
  const [editing, setEditing] = useState<Doc<"supplierRoomTypes"> | null>(null);
  const money = (n: number) =>
    supplier.currency
      ? new Intl.NumberFormat(undefined, {
          style: "currency",
          currency: supplier.currency,
          maximumFractionDigits: 2,
        }).format(n)
      : n.toLocaleString();

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2">
        <CardTitle className="font-display text-lg">Room types</CardTitle>
        <Button
          size="sm"
          variant="secondary"
          className="cursor-pointer"
          onClick={() => setAdding(true)}
        >
          <Plus className="size-4" /> Add room type
        </Button>
      </CardHeader>
      <CardContent>
        {supplier.roomTypes.length === 0 ? (
          <Empty className="py-6">
            <EmptyHeader>
              <EmptyMedia variant="icon">
                <BedDouble />
              </EmptyMedia>
              <EmptyTitle>No room types yet</EmptyTitle>
              <EmptyDescription>
                Add the rooms you usually book here, with how many they sleep
                and an indicative rate.
              </EmptyDescription>
            </EmptyHeader>
          </Empty>
        ) : (
          <div className="-mx-2 divide-y">
            {supplier.roomTypes.map((room) => (
              <div key={room._id} className="flex items-center gap-3 px-2 py-2.5">
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-medium">{room.name}</p>
                  <p className="truncate text-xs text-muted-foreground">
                    Sleeps {room.occupancy} · {BOARD_LABELS[room.board]}
                    {room.notes ? ` · ${room.notes}` : ""}
                  </p>
                </div>
                <p className="shrink-0 text-right text-sm">
                  {room.nightlyRate === undefined ? (
                    <span className="text-muted-foreground">No rate</span>
                  ) : (
                    <>
                      <span className="font-medium">{money(room.nightlyRate)}</span>
                      <span className="text-xs text-muted-foreground"> /night</span>
                    </>
                  )}
                </p>
                <div className="flex shrink-0">
                  <Button
                    size="icon"
                    variant="ghost"
                    aria-label={`Edit ${room.name}`}
                    className="size-8 cursor-pointer text-muted-foreground"
                    onClick={() => setEditing(room)}
                  >
                    <Pencil className="size-4" />
                  </Button>
                  <RemoveRoomButton room={room} />
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      <RoomTypeDialog
        open={adding}
        onOpenChange={setAdding}
        supplierId={supplier._id}
        currency={supplier.currency}
      />
      {editing ? (
        <RoomTypeDialog
          key={editing._id}
          open
          onOpenChange={(open) => !open && setEditing(null)}
          supplierId={supplier._id}
          currency={supplier.currency}
          room={editing}
        />
      ) : null}
    </Card>
  );
}

function DeleteButton({ supplier }: { supplier: Detail }) {
  const remove = useMutation(api.suppliers.remove);
  const navigate = useNavigate();
  const [busy, setBusy] = useState(false);
  const onConfirm = async () => {
    setBusy(true);
    try {
      await remove({ id: supplier._id });
      toast.success(`${supplier.name} deleted`);
      navigate("/suppliers");
    } catch (error) {
      toast.error(errorMessage(error));
      setBusy(false);
    }
  };
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          variant="ghost"
          className="cursor-pointer text-muted-foreground hover:text-destructive"
        >
          <Trash2 className="size-4" /> Delete
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Delete {supplier.name}?</AlertDialogTitle>
          <AlertDialogDescription>
            This removes the supplier and its room types for the whole team.
            To keep it for reference, set its status to Archived instead.
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel className="cursor-pointer">Cancel</AlertDialogCancel>
          <AlertDialogAction
            disabled={busy}
            className="cursor-pointer bg-destructive text-white hover:bg-destructive/90"
            onClick={(e) => {
              e.preventDefault();
              void onConfirm();
            }}
          >
            Delete
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

function SupplierDetail({ id }: { id: Id<"suppliers"> }) {
  const supplier = useSupplierDetail(id);
  const { isManager } = useStaff();
  const [editing, setEditing] = useState(false);

  if (supplier === undefined) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-9 w-72" />
        <div className="grid gap-6 lg:grid-cols-[1fr_1.2fr]">
          <Skeleton className="h-64" />
          <Skeleton className="h-64" />
        </div>
      </div>
    );
  }

  const meta = CATEGORY_META[supplier.category];
  const status = STATUS_META[supplier.status];
  const isHotel = supplier.category === "hotel";
  return (
    <>
      <PageHeader
        title={supplier.name}
        description={
          <span className="flex flex-wrap items-center gap-2">
            <Badge variant="secondary" className="gap-1">
              <meta.icon className="size-3" />
              {meta.label}
            </Badge>
            <Badge className={cn("border-0", status.badge)}>{status.label}</Badge>
            {supplier.hotelClass ? (
              <span className="flex items-center gap-1">
                <Building className="size-3.5" />
                {HOTEL_CLASS_LABELS[supplier.hotelClass]}
              </span>
            ) : null}
          </span>
        }
        actions={
          <>
            {isManager ? <DeleteButton supplier={supplier} /> : null}
            <Button className="cursor-pointer" onClick={() => setEditing(true)}>
              <Pencil className="size-4" /> Edit
            </Button>
          </>
        }
      />
      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview" className="cursor-pointer">
            Overview
          </TabsTrigger>
          <TabsTrigger value="allotments" className="cursor-pointer">
            Allotments
          </TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
          {isHotel ? (
            <div className="grid items-start gap-6 lg:grid-cols-[1fr_1.2fr]">
              <DetailsCard supplier={supplier} />
              <div className="space-y-6">
                <HotelFacts supplier={supplier} />
                <RoomTypesCard supplier={supplier} />
              </div>
            </div>
          ) : (
            <div className="max-w-2xl">
              <DetailsCard supplier={supplier} />
            </div>
          )}
        </TabsContent>
        <TabsContent value="allotments">
          <AllotmentsTab supplierId={supplier._id} isManager={isManager} />
        </TabsContent>
      </Tabs>
      <SupplierFormDialog
        open={editing}
        onOpenChange={setEditing}
        supplier={supplier}
      />
    </>
  );
}

function NotFoundState() {
  return (
    <ErrorState className="border">
      <ErrorStateHeader>
        <ErrorStateMedia variant="icon">
          <AlertTriangle />
        </ErrorStateMedia>
        <ErrorStateTitle>Supplier not found</ErrorStateTitle>
        <ErrorStateDescription>
          It may have been deleted, or the link is wrong.
        </ErrorStateDescription>
      </ErrorStateHeader>
      <ErrorStateContent>
        <Button asChild size="sm" className="cursor-pointer">
          <Link to="/suppliers">Back to suppliers</Link>
        </Button>
      </ErrorStateContent>
    </ErrorState>
  );
}

export default function SupplierDetailPage() {
  const { supplierId } = useParams();
  return (
    <PageContainer>
      <Button
        asChild
        variant="ghost"
        size="sm"
        className="-ml-2 cursor-pointer text-muted-foreground"
      >
        <Link to="/suppliers">
          <ArrowLeft className="size-4" /> Suppliers & hotels
        </Link>
      </Button>
      {supplierId && ID_PATTERN.test(supplierId) ? (
        <QueryErrorBoundary key={supplierId} fallback={<NotFoundState />}>
          <SupplierDetail id={supplierId as Id<"suppliers">} />
        </QueryErrorBoundary>
      ) : (
        <NotFoundState />
      )}
    </PageContainer>
  );
}
