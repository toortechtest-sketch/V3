import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { usePaginatedQuery } from "convex/react";
import { BedDouble, Mail, Phone, Plus, Search, Sparkles, Store, Wand2 } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import SupplierFormDialog from "@/components/suppliers/supplier-form-dialog.tsx";
import SupplierImportDialog from "@/components/suppliers/supplier-import-dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { useStaff } from "@/hooks/use-staff.ts";
import { formatPlace } from "@/lib/clients.ts";
import { cn } from "@/lib/utils.ts";
import {
  CATEGORY_META,
  HOTEL_CLASS_LABELS,
  STATUS_META,
  SUPPLIER_CATEGORIES,
  type SupplierCategory,
} from "@/lib/suppliers.ts";

const PAGE_SIZE = 30;
type Filter = "all" | SupplierCategory;

const FILTERS: { value: Filter; label: string }[] = [
  { value: "all", label: "All" },
  ...SUPPLIER_CATEGORIES.map((c) => ({ value: c, label: CATEGORY_META[c].plural })),
];

function SupplierRow({ supplier }: { supplier: Doc<"suppliers"> }) {
  const navigate = useNavigate();
  const meta = CATEGORY_META[supplier.category];
  const place = formatPlace(supplier.city, supplier.country);
  const subtitle = [
    supplier.hotelClass ? HOTEL_CLASS_LABELS[supplier.hotelClass] : meta.label,
    place,
    supplier.contactName,
  ]
    .filter(Boolean)
    .join(" · ");
  const status = STATUS_META[supplier.status];
  return (
    <button
      type="button"
      onClick={() => navigate(`/suppliers/${supplier._id}`)}
      className={cn(
        "flex w-full cursor-pointer items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-muted/60",
        supplier.status === "archived" && "opacity-60",
      )}
    >
      <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
        <meta.icon className="size-4" />
      </div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-2">
          <p className="truncate font-medium">{supplier.name}</p>
          {supplier.status !== "active" ? (
            <Badge className={cn("shrink-0 border-0", status.badge)}>{status.label}</Badge>
          ) : null}
        </div>
        <p className="truncate text-xs text-muted-foreground">{subtitle}</p>
      </div>
      <div className="hidden min-w-0 flex-col items-end gap-0.5 text-xs text-muted-foreground sm:flex">
        {supplier.email ? (
          <span className="flex max-w-64 items-center gap-1.5 truncate">
            <Mail className="size-3 shrink-0" />
            {supplier.email}
          </span>
        ) : null}
        {supplier.phone ? (
          <span className="flex items-center gap-1.5">
            <Phone className="size-3 shrink-0" />
            {supplier.phone}
          </span>
        ) : null}
      </div>
    </button>
  );
}

function SupplierList({
  category,
  search,
  onCreate,
}: {
  category: SupplierCategory | undefined;
  search: string;
  onCreate: () => void;
}) {
  const { results, status, loadMore } = usePaginatedQuery(
    api.suppliers.list,
    { category, search: search || undefined },
    { initialNumItems: PAGE_SIZE },
  );

  if (status === "LoadingFirstPage") {
    return (
      <Card className="gap-0 divide-y py-0">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="flex items-center gap-3 px-4 py-3">
            <Skeleton className="size-9 rounded-lg" />
            <div className="flex-1 space-y-1.5">
              <Skeleton className="h-4 w-48" />
              <Skeleton className="h-3 w-32" />
            </div>
          </div>
        ))}
      </Card>
    );
  }

  if (results.length === 0 && status === "Exhausted") {
    const filtered = Boolean(category || search);
    return (
      <Empty className="border bg-card">
        <EmptyHeader>
          <EmptyMedia variant="icon">
            {category === "hotel" ? <BedDouble /> : <Store />}
          </EmptyMedia>
          <EmptyTitle>
            {filtered ? "No matching suppliers" : "No suppliers yet"}
          </EmptyTitle>
          <EmptyDescription>
            {filtered
              ? "Try another type or search term."
              : "Add the hotels, venues, transfer companies and other partners you book with."}
          </EmptyDescription>
        </EmptyHeader>
        {filtered ? null : (
          <EmptyContent>
            <Button size="sm" className="cursor-pointer" onClick={onCreate}>
              Add supplier
            </Button>
          </EmptyContent>
        )}
      </Empty>
    );
  }

  return (
    <div className="space-y-3">
      <Card className="gap-0 divide-y overflow-hidden py-0">
        {results.map((s) => (
          <SupplierRow key={s._id} supplier={s} />
        ))}
      </Card>
      {status === "CanLoadMore" || status === "LoadingMore" ? (
        <div className="flex justify-center">
          <Button
            variant="secondary"
            size="sm"
            className="cursor-pointer"
            disabled={status === "LoadingMore"}
            onClick={() => loadMore(PAGE_SIZE)}
          >
            {status === "LoadingMore" ? "Loading…" : "Load more"}
          </Button>
        </div>
      ) : null}
    </div>
  );
}

export default function SuppliersPage() {
  const [filter, setFilter] = useState<Filter>("all");
  const [search, setSearch] = useState("");
  const [term] = useDebounce(search.trim(), 300);
  const [creating, setCreating] = useState(false);
  const [importing, setImporting] = useState(false);
  const { isManager } = useStaff();

  return (
    <PageContainer>
      <PageHeader
        title="Suppliers & hotels"
        description="Hotels, venues and every partner you book with, shared with the whole team."
        actions={
          <>
            {isManager ? (
              <Button asChild variant="ghost" className="cursor-pointer text-muted-foreground">
                <Link to="/suppliers/migration">
                  <Wand2 className="size-4" /> Legacy migration
                </Link>
              </Button>
            ) : null}
            <Button variant="secondary" className="cursor-pointer" onClick={() => setImporting(true)}>
              <Sparkles className="size-4" /> Import with AI
            </Button>
            <Button className="cursor-pointer" onClick={() => setCreating(true)}>
              <Plus className="size-4" /> New supplier
            </Button>
          </>
        }
      />

      <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
        {/* Scrolls sideways on small screens instead of wrapping */}
        <div className="-mx-4 overflow-x-auto px-4 [scrollbar-width:none] sm:mx-0 sm:px-0">
          <div className="inline-flex gap-1 rounded-lg bg-muted p-1">
            {FILTERS.map((f) => (
              <button
                key={f.value}
                type="button"
                onClick={() => setFilter(f.value)}
                className={cn(
                  "cursor-pointer rounded-md px-3 py-1 text-sm whitespace-nowrap text-muted-foreground transition-colors hover:text-foreground",
                  filter === f.value && "bg-background text-foreground shadow-sm",
                )}
              >
                {f.label}
              </button>
            ))}
          </div>
        </div>
        <div className="relative lg:w-72">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search name, contact, email or city"
            className="pl-9"
          />
        </div>
      </div>

      <SupplierList
        category={filter === "all" ? undefined : filter}
        search={term}
        onCreate={() => setCreating(true)}
      />

      <SupplierFormDialog open={creating} onOpenChange={setCreating} />
      <SupplierImportDialog open={importing} onOpenChange={setImporting} />
    </PageContainer>
  );
}
