import { useQuery } from "convex/react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  XAxis,
  YAxis,
} from "recharts";
import {
  BarChart3,
  Percent,
  TrendingUp,
  Trophy,
  Users,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card.tsx";
import {
  ChartContainer,
  ChartTooltip,
  ChartTooltipContent,
  type ChartConfig,
} from "@/components/ui/chart.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { STAGE_META } from "@/lib/bookings.ts";
import { todayKey } from "@/lib/finance.ts";
import { formatMoney } from "@/lib/quotes.ts";

const trendConfig = {
  received: { label: "Received", color: "var(--chart-1)" },
  invoiced: { label: "Invoiced", color: "var(--chart-2)" },
} satisfies ChartConfig;

const pipelineConfig = {
  value: { label: "Package value", color: "var(--chart-3)" },
} satisfies ChartConfig;

function monthLabel(key: string) {
  const [y, m] = key.split("-").map(Number);
  return new Date(y, m - 1, 1).toLocaleDateString(undefined, { month: "short" });
}

function Stat({
  icon: Icon,
  label,
  value,
  hint,
}: {
  icon: typeof TrendingUp;
  label: string;
  value: string;
  hint?: string;
}) {
  return (
    <Card className="gap-1 px-4 py-4">
      <div className="flex items-center gap-2 text-sm text-muted-foreground">
        <Icon className="size-4 text-primary" />
        {label}
      </div>
      <p className="font-display text-2xl font-semibold tabular-nums">{value}</p>
      {hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}
    </Card>
  );
}

function AnalyticsSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full" />
        ))}
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-72 w-full" />
        ))}
      </div>
    </div>
  );
}

function AnalyticsDashboard() {
  const data = useQuery(api.analytics.overview, { today: todayKey() });

  if (data === undefined) return <AnalyticsSkeleton />;

  const openBookings = data.pipeline
    .filter((p) => p.stage !== "closed" && p.stage !== "cancelled")
    .reduce((s, p) => s + p.count, 0);
  const openValue = data.pipeline
    .filter((p) => p.stage !== "closed" && p.stage !== "cancelled")
    .reduce((s, p) => s + p.value, 0);
  const totalReceived = data.monthlyTrend.reduce((s, m) => s + m.received, 0);
  const hasPipeline = data.pipeline.some((p) => p.count > 0);
  const hasTrend = data.monthlyTrend.some((m) => m.received > 0 || m.invoiced > 0);

  return (
    <div className="space-y-6">
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        <Stat
          icon={BarChart3}
          label="Open pipeline"
          value={formatMoney(openValue, "EUR")}
          hint={`${openBookings} booking${openBookings === 1 ? "" : "s"} in progress`}
        />
        <Stat
          icon={TrendingUp}
          label="Received, last 6 months"
          value={formatMoney(totalReceived, "EUR")}
        />
        <Stat
          icon={Percent}
          label="Enquiry to confirmed"
          value={
            data.conversion.rate === null
              ? "–"
              : `${data.conversion.rate.toLocaleString(undefined, { maximumFractionDigits: 1 })}%`
          }
          hint={`${data.conversion.won} won of ${data.conversion.decided} decided`}
        />
        <Stat
          icon={Users}
          label="Top client, received"
          value={
            data.topClients[0]
              ? formatMoney(data.topClients[0].received, "EUR")
              : formatMoney(0, "EUR")
          }
          hint={data.topClients[0]?.clientName ?? "No payments yet"}
        />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Revenue trend</CardTitle>
            <CardDescription>Received and invoiced amounts, totals in EUR</CardDescription>
          </CardHeader>
          <CardContent>
            {hasTrend ? (
              <ChartContainer config={trendConfig} className="aspect-auto h-64 w-full">
                <LineChart data={data.monthlyTrend} margin={{ left: 4, right: 4 }}>
                  <CartesianGrid vertical={false} />
                  <XAxis
                    dataKey="month"
                    tickFormatter={monthLabel}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis tickLine={false} axisLine={false} width={48} />
                  <ChartTooltip
                    content={<ChartTooltipContent labelFormatter={(v) => monthLabel(String(v))} />}
                  />
                  <Line
                    type="monotone"
                    dataKey="received"
                    stroke="var(--color-received)"
                    strokeWidth={2}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="invoiced"
                    stroke="var(--color-invoiced)"
                    strokeWidth={2}
                    strokeDasharray="4 4"
                    dot={false}
                  />
                </LineChart>
              </ChartContainer>
            ) : (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <TrendingUp />
                  </EmptyMedia>
                  <EmptyTitle>No money movement yet</EmptyTitle>
                  <EmptyDescription>
                    Invoices and payments will show up here once recorded.
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Booking pipeline</CardTitle>
            <CardDescription>Package value by stage, in EUR</CardDescription>
          </CardHeader>
          <CardContent>
            {hasPipeline ? (
              <ChartContainer config={pipelineConfig} className="aspect-auto h-64 w-full">
                <BarChart data={data.pipeline} margin={{ left: 4, right: 4 }}>
                  <CartesianGrid vertical={false} />
                  <XAxis
                    dataKey="stage"
                    tickFormatter={(s: string) => STAGE_META[s as keyof typeof STAGE_META].label}
                    tickLine={false}
                    axisLine={false}
                  />
                  <YAxis tickLine={false} axisLine={false} width={48} />
                  <ChartTooltip
                    content={
                      <ChartTooltipContent
                        labelFormatter={(s) => STAGE_META[s as keyof typeof STAGE_META].label}
                      />
                    }
                  />
                  <Bar dataKey="value" fill="var(--color-value)" radius={4} />
                </BarChart>
              </ChartContainer>
            ) : (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <BarChart3 />
                  </EmptyMedia>
                  <EmptyTitle>No bookings yet</EmptyTitle>
                  <EmptyDescription>
                    Bookings will appear here as they move through stages.
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top clients</CardTitle>
            <CardDescription>By money received, in EUR</CardDescription>
          </CardHeader>
          <CardContent>
            {data.topClients.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <Trophy />
                  </EmptyMedia>
                  <EmptyTitle>No payments recorded</EmptyTitle>
                  <EmptyDescription>
                    Top clients appear once payments are recorded on bookings.
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            ) : (
              <ul className="space-y-3">
                {data.topClients.map((c, i) => (
                  <li key={c.clientName} className="flex items-center gap-3">
                    <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-medium text-secondary-foreground">
                      {i + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{c.clientName}</p>
                      <p className="text-xs text-muted-foreground">
                        {c.bookingCount} booking{c.bookingCount === 1 ? "" : "s"}
                      </p>
                    </div>
                    <span className="shrink-0 text-sm font-medium tabular-nums">
                      {formatMoney(c.received, "EUR")}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Top suppliers</CardTitle>
            <CardDescription>By cost on confirmed reservations, in EUR</CardDescription>
          </CardHeader>
          <CardContent>
            {data.topSuppliers.length === 0 ? (
              <Empty>
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <Trophy />
                  </EmptyMedia>
                  <EmptyTitle>No supplier costs yet</EmptyTitle>
                  <EmptyDescription>
                    Top suppliers appear once reservations have a cost per unit.
                  </EmptyDescription>
                </EmptyHeader>
              </Empty>
            ) : (
              <ul className="space-y-3">
                {data.topSuppliers.map((s, i) => (
                  <li key={s.supplierName} className="flex items-center gap-3">
                    <span className="flex size-6 shrink-0 items-center justify-center rounded-full bg-secondary text-xs font-medium text-secondary-foreground">
                      {i + 1}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-medium">{s.supplierName}</p>
                      <p className="text-xs text-muted-foreground">
                        {s.reservationCount} reservation{s.reservationCount === 1 ? "" : "s"}
                      </p>
                    </div>
                    <span className="shrink-0 text-sm font-medium tabular-nums">
                      {formatMoney(s.cost, "EUR")}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </CardContent>
        </Card>
      </div>

      {data.truncated ? (
        <p className="text-center text-xs text-muted-foreground">
          Based on the most recent bookings in each stage.
        </p>
      ) : null}
    </div>
  );
}

export default function AnalyticsPage() {
  const { isManager, me } = useStaff();

  if (me !== undefined && !isManager) {
    return (
      <PageContainer>
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <BarChart3 />
            </EmptyMedia>
            <EmptyTitle>Managers only</EmptyTitle>
            <EmptyDescription>
              Only owners and global managers can see the analytics dashboard.
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      </PageContainer>
    );
  }

  return (
    <PageContainer>
      <PageHeader
        title="Analytics"
        description="Business performance across the pipeline, revenue, and your busiest clients and suppliers."
      />
      {isManager ? <AnalyticsDashboard /> : null}
    </PageContainer>
  );
}
