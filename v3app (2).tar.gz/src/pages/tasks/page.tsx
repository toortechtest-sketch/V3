import { usePaginatedQuery } from "convex/react";
import { useSearchParams } from "react-router-dom";
import { CheckCheck, ListChecks } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import PageHeader, { PageContainer } from "@/components/page-header.tsx";
import TaskRow, { type TaskRowData } from "@/components/tasks/task-row.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { dueState, todayKey, type DueState } from "@/lib/tasks.ts";

const PAGE_SIZE = 30;

const GROUPS: { key: DueState; label: string }[] = [
  { key: "overdue", label: "Overdue" },
  { key: "today", label: "Today" },
  { key: "upcoming", label: "Coming up" },
  { key: "none", label: "No due date" },
];

function TaskGroup({ label, tasks }: { label: string; tasks: TaskRowData[] }) {
  if (tasks.length === 0) return null;
  return (
    <Card className="gap-2">
      <CardHeader>
        <CardTitle className="font-display text-base">
          {label}{" "}
          <span className="font-mono text-sm font-normal text-muted-foreground">
            {tasks.length}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="divide-y">
        {tasks.map((t) => (
          <TaskRow key={t._id} task={t} showBooking />
        ))}
      </CardContent>
    </Card>
  );
}

export default function TasksPage() {
  const { isManager } = useStaff();
  const [params, setParams] = useSearchParams();
  const scope = isManager && params.get("scope") === "everyone" ? "everyone" : "mine";
  const done = params.get("show") === "done";

  const setParam = (key: string, value: string | null) => {
    const next = new URLSearchParams(params);
    if (value === null) next.delete(key);
    else next.set(key, value);
    setParams(next, { replace: true });
  };

  const { results, status, loadMore } = usePaginatedQuery(
    api.tasks.list,
    { scope, done },
    { initialNumItems: PAGE_SIZE },
  );

  // Grouping only splits the already-ordered page; nothing is filtered out.
  const today = todayKey();
  const grouped = GROUPS.map((g) => ({
    ...g,
    tasks: results.filter((t) => dueState(t.dueDate, today) === g.key),
  }));

  return (
    <PageContainer className="max-w-4xl">
      <PageHeader
        title="Tasks & follow-ups"
        description={
          scope === "everyone"
            ? "Everyone's work across all bookings."
            : "Work assigned to you across your bookings. Add tasks from a booking."
        }
      />

      <div className="flex flex-wrap items-center gap-3">
        <Tabs value={done ? "done" : "open"} onValueChange={(v) => setParam("show", v === "done" ? "done" : null)}>
          <TabsList>
            <TabsTrigger value="open" className="cursor-pointer">Open</TabsTrigger>
            <TabsTrigger value="done" className="cursor-pointer">Done</TabsTrigger>
          </TabsList>
        </Tabs>
        {isManager ? (
          <Tabs
            value={scope}
            onValueChange={(v) => setParam("scope", v === "everyone" ? "everyone" : null)}
          >
            <TabsList>
              <TabsTrigger value="mine" className="cursor-pointer">Mine</TabsTrigger>
              <TabsTrigger value="everyone" className="cursor-pointer">Everyone</TabsTrigger>
            </TabsList>
          </Tabs>
        ) : null}
      </div>

      {status === "LoadingFirstPage" ? (
        <Card>
          <CardContent className="space-y-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </CardContent>
        </Card>
      ) : results.length === 0 && status === "Exhausted" ? (
        <Empty className="border bg-card">
          <EmptyHeader>
            <EmptyMedia variant="icon">{done ? <ListChecks /> : <CheckCheck />}</EmptyMedia>
            <EmptyTitle>{done ? "Nothing completed yet" : "You're all caught up"}</EmptyTitle>
            <EmptyDescription>
              {done
                ? "Finished tasks will show up here."
                : "New tasks are added from a booking's Tasks tab."}
            </EmptyDescription>
          </EmptyHeader>
        </Empty>
      ) : done ? (
        <Card>
          <CardContent className="divide-y">
            {results.map((t) => (
              <TaskRow key={t._id} task={t} showBooking />
            ))}
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {grouped.map((g) => (
            <TaskGroup key={g.key} label={g.label} tasks={g.tasks} />
          ))}
        </div>
      )}

      {status === "CanLoadMore" || status === "LoadingMore" ? (
        <div className="flex justify-center">
          <Button
            variant="secondary"
            size="sm"
            className="cursor-pointer"
            disabled={status === "LoadingMore"}
            onClick={() => loadMore(PAGE_SIZE)}
          >
            {status === "LoadingMore" ? "Loading…" : "Load more"}
          </Button>
        </div>
      ) : null}
    </PageContainer>
  );
}
