import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import { capturePendingOAuthReturn } from "./pages/inbox/_lib/oauth-return.ts";

// Move a Gmail connection result out of the address bar before anything else
// runs, so it survives a sign-in redirect and never lingers in history.
capturePendingOAuthReturn();

createRoot(document.getElementById("root")!).render(<App />);
