import { useEffect } from "react";
import { useMutation } from "convex/react";
import { api } from "@/convex/_generated/api.js";

const HEARTBEAT_INTERVAL_MS = 60 * 1000;

/**
 * Sends a heartbeat while the tab is open and visible, so the backend can
 * build up each staff member's active time. Call once near the root of the
 * authenticated app.
 */
export function useActivityHeartbeat(enabled: boolean) {
  const heartbeat = useMutation(api.activity.heartbeat);

  useEffect(() => {
    if (!enabled) return;
    const beat = () => {
      if (document.visibilityState === "visible") void heartbeat({});
    };
    beat();
    const interval = setInterval(beat, HEARTBEAT_INTERVAL_MS);
    document.addEventListener("visibilitychange", beat);
    return () => {
      clearInterval(interval);
      document.removeEventListener("visibilitychange", beat);
    };
  }, [heartbeat, enabled]);
}
