import { useQuery } from "convex/react";
import { api } from "@/convex/_generated/api.js";
import { isManagerRole } from "@/lib/roles.ts";

/** Current staff status. Only call inside <Authenticated>. */
export function useStaff() {
  const me = useQuery(api.staff.me, {});
  const role = me?.status === "active" ? me.role : null;
  return { me, role, isManager: isManagerRole(role) };
}
