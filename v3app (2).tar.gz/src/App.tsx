import { BrowserRouter, Route, Routes } from "react-router-dom";
import { DefaultProviders } from "./components/providers/default.tsx";
import AppLayout from "./components/layout/app-layout.tsx";
import AuthCallback from "./pages/auth/Callback.tsx";
import Index from "./pages/Index.tsx";
import TeamPage from "./pages/team/page.tsx";
import ClientsPage from "./pages/clients/page.tsx";
import ClientDetailPage from "./pages/clients/detail/page.tsx";
import SuppliersPage from "./pages/suppliers/page.tsx";
import SupplierDetailPage from "./pages/suppliers/detail/page.tsx";
import SupplierMigrationPage from "./pages/suppliers/migration/page.tsx";
import DeparturesPage from "./pages/departures/page.tsx";
import TasksPage from "./pages/tasks/page.tsx";
import InboxPage from "./pages/inbox/page.tsx";
import BookingsPage from "./pages/bookings/page.tsx";
import BookingDetailPage from "./pages/bookings/detail/page.tsx";
import NotFound from "./pages/NotFound.tsx";
import ConnectedAppsPage from "./pages/connected-apps/page.tsx";
import SharePage from "./pages/share/page.tsx";
import AccountingPage from "./pages/accounting/page.tsx";
import BookingFinancePage from "./pages/finance/page.tsx";
import AnalyticsPage from "./pages/analytics/page.tsx";

export default function App() {
  return (
    <DefaultProviders>
      <BrowserRouter>
        <Routes>
          <Route path="/auth/callback" element={<AuthCallback />} />
          {/* Client-facing, no sign-in: opened by a secure expiring token */}
          <Route path="/share/:token" element={<SharePage />} />
          <Route element={<AppLayout />}>
            <Route path="/" element={<Index />} />
            <Route path="/team" element={<TeamPage />} />
            <Route path="/bookings" element={<BookingsPage />} />
            <Route path="/bookings/:bookingId" element={<BookingDetailPage />} />
            <Route path="/clients" element={<ClientsPage />} />
            <Route path="/clients/:clientId" element={<ClientDetailPage />} />
            <Route path="/suppliers" element={<SuppliersPage />} />
            <Route path="/suppliers/migration" element={<SupplierMigrationPage />} />
            <Route path="/suppliers/:supplierId" element={<SupplierDetailPage />} />
            <Route path="/connected-apps" element={<ConnectedAppsPage />} />
            <Route path="/departures" element={<DeparturesPage />} />
            <Route path="/tasks" element={<TasksPage />} />
            <Route path="/inbox" element={<InboxPage />} />
            <Route path="/accounting" element={<AccountingPage />} />
            <Route path="/finance" element={<BookingFinancePage />} />
            <Route path="/analytics" element={<AnalyticsPage />} />
          </Route>
          {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </DefaultProviders>
  );
}
