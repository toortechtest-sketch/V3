import {
  BedDouble,
  Bus,
  Building2,
  CircleDot,
  Ticket,
  UserRoundCog,
  UtensilsCrossed,
  type LucideIcon,
} from "lucide-react";
import type { QuoteSection } from "@/convex/schema/quotes.ts";
import type { QuoteBasis } from "@/convex/lib/quoteMath.ts";

export { QUOTE_BASES, QUOTE_SECTIONS } from "@/convex/schema/quotes.ts";
export { priceLine, quoteTotals } from "@/convex/lib/quoteMath.ts";
export type { QuoteBasis, QuoteSection };

export const SECTION_META: Record<QuoteSection, { label: string; icon: LucideIcon }> = {
  accommodation: { label: "Accommodation", icon: BedDouble },
  transport: { label: "Transport", icon: Bus },
  meals: { label: "Meals", icon: UtensilsCrossed },
  activities: { label: "Activities", icon: Ticket },
  venue: { label: "Venue & AV", icon: Building2 },
  staff: { label: "Guides & staff", icon: UserRoundCog },
  other: { label: "Other", icon: CircleDot },
};

export const BASIS_META: Record<QuoteBasis, { label: string; hint: string }> = {
  per_person: { label: "Per person", hint: "Unit cost × travellers" },
  per_unit: { label: "Per unit", hint: "Rooms, vehicles, guides…" },
  fixed: { label: "Fixed", hint: "One price for the group" },
};

export function formatMoney(amount: number, currency: string) {
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export const formatPercent = (n: number | null) =>
  n === null ? "–" : `${n.toLocaleString(undefined, { maximumFractionDigits: 1 })}%`;

/** "10 × 3 × €100" style breakdown of how a line cost was reached. */
export function lineFormula(
  line: { basis: QuoteBasis; times: number; unitCost: number },
  units: number,
  currency: string,
) {
  const parts: string[] = [];
  if (line.basis !== "fixed") parts.push(`${units} ${line.basis === "per_person" ? "pax" : "units"}`);
  if (line.times !== 1) parts.push(`${line.times}×`);
  parts.push(formatMoney(line.unitCost, currency));
  return parts.join(" · ");
}
