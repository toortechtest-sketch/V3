import type { PaymentMethod } from "@/convex/schema/finance.ts";

export { PAYMENT_METHODS } from "@/convex/schema/finance.ts";
export { isOverdue } from "@/convex/lib/financeMath.ts";
export type { PaymentMethod };

export const METHOD_LABELS: Record<PaymentMethod, string> = {
  bank_transfer: "Bank transfer",
  card: "Card",
  cash: "Cash",
  other: "Other",
};

/** Today as a local calendar day, YYYY-MM-DD. */
export function todayKey() {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

/** Positive money amount typed into a form. */
export const isPositiveAmount = (v: string) => v.trim() !== "" && Number(v) > 0 && Number(v) <= 1e9;
