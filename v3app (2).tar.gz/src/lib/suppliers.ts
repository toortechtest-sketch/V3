import {
  BedDouble,
  Bus,
  Landmark,
  Plane,
  Store,
  Ticket,
  UtensilsCrossed,
  type LucideIcon,
} from "lucide-react";
import type {
  BoardType,
  HotelClass,
  SupplierCategory,
  SupplierStatus,
} from "@/convex/schema/suppliers.ts";

export {
  BOARD_TYPES,
  HOTEL_CLASSES,
  SUPPLIER_CATEGORIES,
  SUPPLIER_STATUSES,
} from "@/convex/schema/suppliers.ts";
export type { BoardType, HotelClass, SupplierCategory, SupplierStatus };

export const CATEGORY_META: Record<
  SupplierCategory,
  { label: string; plural: string; icon: LucideIcon }
> = {
  hotel: { label: "Hotel", plural: "Hotels", icon: BedDouble },
  venue: { label: "Venue", plural: "Venues", icon: Landmark },
  transfer: { label: "Transfer", plural: "Transfers", icon: Bus },
  restaurant: { label: "Restaurant", plural: "Restaurants", icon: UtensilsCrossed },
  activity: { label: "Activity", plural: "Activities", icon: Ticket },
  flight: { label: "Flight", plural: "Flights", icon: Plane },
  other: { label: "Other", plural: "Other", icon: Store },
};

export const STATUS_META: Record<SupplierStatus, { label: string; badge: string }> = {
  preferred: {
    label: "Preferred",
    badge: "bg-[#FFB800]/18 text-[#8a6400] dark:text-[#FFB800]",
  },
  active: { label: "Active", badge: "bg-primary/12 text-primary dark:text-[#7fa6ff]" },
  archived: { label: "Archived", badge: "bg-muted text-muted-foreground" },
};

export const HOTEL_CLASS_LABELS: Record<HotelClass, string> = {
  "5-star-luxury": "5-star luxury",
  "5-star": "5-star",
  "4-star-superior": "4-star superior",
  "4-star": "4-star",
  "3-star": "3-star",
  boutique: "Boutique",
  resort: "Resort",
  apartment: "Apartment",
  venue: "Venue hotel",
};

export const BOARD_LABELS: Record<BoardType, string> = {
  "room-only": "Room only",
  breakfast: "Bed & breakfast",
  "half-board": "Half board",
  "full-board": "Full board",
  "all-inclusive": "All inclusive",
};

/** Adds https:// when staff paste a bare domain. */
export function websiteHref(website: string) {
  return /^https?:\/\//i.test(website) ? website : `https://${website}`;
}
