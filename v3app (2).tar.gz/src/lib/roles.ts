import type { StaffRole } from "@/convex/schema/staff.ts";

export const ROLE_OPTIONS: readonly {
  value: StaffRole;
  label: string;
  description: string;
}[] = [
  {
    value: "owner",
    label: "Owner",
    description: "Full access, including granting owner access",
  },
  {
    value: "global_manager",
    label: "Global manager",
    description: "Sees every booking and manages the team",
  },
  {
    value: "agency_manager",
    label: "Agency manager",
    description: "Works on their own bookings",
  },
  {
    value: "agent",
    label: "Agent",
    description: "Works on bookings assigned to them",
  },
];

export const ROLE_LABELS: Record<StaffRole, string> = {
  owner: "Owner",
  global_manager: "Global manager",
  agency_manager: "Agency manager",
  agent: "Agent",
};

export function initials(name: string | null | undefined) {
  const parts = (name ?? "").trim().split(/\s+/).filter(Boolean);
  return (parts[0]?.[0] ?? "?") + (parts[1]?.[0] ?? "");
}

export const isManagerRole = (role: StaffRole | null | undefined) =>
  role === "owner" || role === "global_manager";
