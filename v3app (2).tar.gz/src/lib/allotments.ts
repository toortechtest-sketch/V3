import type { Id } from "@/convex/_generated/dataModel.d.ts";

export type AllotmentKind = "hotel_night" | "session";

export const ALLOTMENT_KIND_LABELS: Record<AllotmentKind, string> = {
  hotel_night: "Hotel nights",
  session: "Dated departures",
};

/** A handful of common IANA zones shown as quick picks; any valid zone works. */
export const COMMON_TIMEZONES = [
  "Europe/London",
  "Europe/Lisbon",
  "Europe/Madrid",
  "Europe/Paris",
  "Europe/Berlin",
  "Europe/Rome",
  "Europe/Athens",
  "America/New_York",
  "America/Los_Angeles",
  "America/Chicago",
  "Asia/Dubai",
  "Asia/Bangkok",
  "Asia/Singapore",
  "Asia/Tokyo",
  "Australia/Sydney",
  "UTC",
] as const;

export function isValidTimezone(timezone: string): boolean {
  try {
    new Intl.DateTimeFormat("en-US", { timeZone: timezone });
    return true;
  } catch {
    return false;
  }
}

/** Formats a UTC epoch ms instant in the pool's own timezone, for staff clarity. */
export function formatInZone(epochMs: number, timezone: string): string {
  try {
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: "medium",
      timeStyle: "short",
      timeZone: timezone,
    }).format(new Date(epochMs));
  } catch {
    return new Date(epochMs).toLocaleString();
  }
}

/** Offset (ms) between UTC and the wall-clock time `instant` shows in `timeZone`. */
function offsetMsAt(timeZone: string, instant: Date): number {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  }).formatToParts(instant);
  const get = (type: string) => Number(parts.find((p) => p.type === type)?.value ?? 0);
  const asUtc = Date.UTC(get("year"), get("month") - 1, get("day"), get("hour"), get("minute"), get("second"));
  return asUtc - instant.getTime();
}

/** Converts a date + time picked in `timeZone` into a UTC epoch ms instant. */
export function zonedTimeToUtcMs(dateStr: string, timeStr: string, timeZone: string): number {
  const naiveUtc = Date.parse(`${dateStr}T${timeStr}:00.000Z`);
  const offset = offsetMsAt(timeZone, new Date(naiveUtc));
  return naiveUtc - offset;
}

/** Splits a UTC epoch ms instant into the date + time it shows in `timeZone`. */
export function utcMsToZonedParts(epochMs: number, timeZone: string): { date: string; time: string } {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone,
    hourCycle: "h23",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  }).formatToParts(new Date(epochMs));
  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "00";
  return {
    date: `${get("year")}-${get("month")}-${get("day")}`,
    time: `${get("hour")}:${get("minute")}`,
  };
}

export type SlotRow = {
  _id: Id<"allotmentSlots">;
  poolId: Id<"allotmentPools">;
  serviceDate: string;
  serviceKey: string;
  capacity: number;
  retired: number;
  enabled: boolean;
  stopSale: boolean;
  releaseAt: number;
  replenishOnReturn: boolean;
};

export type AvailabilityRow = SlotRow & { held: number; confirmed: number; available: number };
