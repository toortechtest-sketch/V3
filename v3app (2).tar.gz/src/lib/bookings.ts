import { differenceInCalendarDays, format, parseISO } from "date-fns";
import type {
  BookingStage,
  BookingType,
  Currency,
} from "@/convex/schema/bookings.ts";

export {
  BOARD_STAGES,
  BOOKING_STAGES,
  BOOKING_TYPES,
  CURRENCIES,
} from "@/convex/schema/bookings.ts";
export type { BookingStage, BookingType, Currency };

export const STAGE_META: Record<
  BookingStage,
  { label: string; hint: string; dot: string; badge: string }
> = {
  enquiry: {
    label: "Enquiry",
    hint: "Brief received",
    dot: "bg-[#00BDEB]",
    badge: "bg-[#00BDEB]/15 text-[#00708c] dark:text-[#5fd8f5]",
  },
  quoted: {
    label: "Quoted",
    hint: "Offer with the client",
    dot: "bg-[#FFB800]",
    badge: "bg-[#FFB800]/18 text-[#8a6400] dark:text-[#FFB800]",
  },
  confirmed: {
    label: "Confirmed",
    hint: "Client said yes",
    dot: "bg-primary",
    badge: "bg-primary/12 text-primary dark:text-[#7fa6ff]",
  },
  operating: {
    label: "Operating",
    hint: "Travelling now or soon",
    dot: "bg-[#F47A12]",
    badge: "bg-[#F47A12]/15 text-[#b05300] dark:text-[#ffa257]",
  },
  closed: {
    label: "Closed",
    hint: "Delivered and reconciled",
    dot: "bg-emerald-500",
    badge: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
  },
  cancelled: {
    label: "Cancelled",
    hint: "Did not go ahead",
    dot: "bg-muted-foreground/50",
    badge: "bg-muted text-muted-foreground",
  },
};

export const TYPE_LABELS: Record<BookingType, string> = {
  group: "Group",
  meeting: "Meeting",
  incentive: "Incentive",
  conference: "Conference",
  event: "Event",
};

/** "2 – 7 Dec 2026" style range for YYYY-MM-DD calendar days. */
export function formatDateRange(start: string, end: string) {
  const s = parseISO(start);
  const e = parseISO(end);
  if (start === end) return format(s, "d MMM yyyy");
  if (s.getFullYear() !== e.getFullYear()) {
    return `${format(s, "d MMM yyyy")} – ${format(e, "d MMM yyyy")}`;
  }
  if (s.getMonth() !== e.getMonth()) {
    return `${format(s, "d MMM")} – ${format(e, "d MMM yyyy")}`;
  }
  return `${format(s, "d")} – ${format(e, "d MMM yyyy")}`;
}

export function nightCount(start: string, end: string) {
  return differenceInCalendarDays(parseISO(end), parseISO(start));
}
