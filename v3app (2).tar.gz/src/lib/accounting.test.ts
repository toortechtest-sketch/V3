import { describe, expect, it } from "vitest";
import { parseMinor, paymentStatus } from "./accounting.ts";

describe("parseMinor", () => {
  it("converts typed amounts to cents without float drift", () => {
    expect(parseMinor("1234.5")).toBe(123450);
    expect(parseMinor("0,10")).toBe(10);
    expect(parseMinor("19.99")).toBe(1999);
    expect(parseMinor(" 1 000 ")).toBe(100000);
  });

  it("rejects anything that isn't a plain amount", () => {
    expect(parseMinor("")).toBeNull();
    expect(parseMinor("-5")).toBeNull();
    expect(parseMinor("1.234")).toBeNull();
    expect(parseMinor("abc")).toBeNull();
  });
});

describe("paymentStatus", () => {
  const base = { state: "posted" as const, totalMinor: 1000, dueDate: "2026-05-01" };
  it("tracks collection status from payments and due date", () => {
    expect(paymentStatus({ ...base, paidMinor: 0 }, "2026-04-01")).toBe("unpaid");
    expect(paymentStatus({ ...base, paidMinor: 400 }, "2026-04-01")).toBe("partial");
    expect(paymentStatus({ ...base, paidMinor: 400 }, "2026-05-02")).toBe("overdue");
    expect(paymentStatus({ ...base, paidMinor: 1000 }, "2026-05-02")).toBe("paid");
    expect(paymentStatus({ ...base, state: "draft", paidMinor: 0 }, "2026-05-02")).toBe("draft");
  });
});
