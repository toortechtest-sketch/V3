import { describe, expect, it } from "vitest";
import { parseTravellerList } from "./travellers.ts";

describe("parseTravellerList", () => {
  it("splits single name columns and skips blank lines", () => {
    expect(parseTravellerList("Ana María Ruiz\n\n  Bob  ", "twin")).toEqual([
      { firstName: "Ana", lastName: "María Ruiz", email: undefined, roomPreference: "twin" },
      { firstName: "Bob", lastName: "", email: undefined, roomPreference: "twin" },
    ]);
  });

  it("reads spreadsheet columns for email and room type in any order", () => {
    expect(parseTravellerList("Ana\tRuiz\tANA@acme.com\tSingle", "twin")).toEqual([
      { firstName: "Ana", lastName: "Ruiz", email: "ana@acme.com", roomPreference: "single" },
    ]);
    expect(parseTravellerList("double; Lee; Kim", "twin")[0]).toMatchObject({
      firstName: "Lee",
      lastName: "Kim",
      roomPreference: "double",
    });
  });
});
