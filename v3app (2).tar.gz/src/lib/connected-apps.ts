import {
  Bot,
  Calendar,
  Contact,
  FolderOpen,
  Hash,
  Landmark,
  Mail,
  MessageCircle,
  MonitorSmartphone,
  ReceiptText,
  Wallet,
  type LucideIcon,
} from "lucide-react";
import type { ConnectedAppKey } from "@/convex/schema/connectedApps.ts";

/** Live state of each integration in V3 today. */
export type AppStatus = "built_in" | "planned" | "not_connected";

export type AppCategory = "Email & files" | "Messaging" | "Accounting" | "Toor platform";

export type ConnectedAppInfo = {
  key: ConnectedAppKey;
  name: string;
  category: AppCategory;
  icon: LucideIcon;
  description: string;
  status: AppStatus;
  /** What the owner has to set up with the provider before it can connect. */
  setup: string;
};

export const STATUS_LABELS: Record<AppStatus, string> = {
  built_in: "Built in",
  planned: "Planned",
  not_connected: "Not connected",
};

export const CONNECTED_APPS: ConnectedAppInfo[] = [
  {
    key: "gmail",
    name: "Gmail",
    category: "Email & files",
    icon: Mail,
    description: "Each person's inbox inside Toor, linked to bookings and clients.",
    status: "planned",
    setup: "Personal Google sign-in per staff member. Coming with the Inbox.",
  },
  {
    key: "google_calendar",
    name: "Google Calendar",
    category: "Email & files",
    icon: Calendar,
    description: "Send booking dates and task due dates to your calendar.",
    status: "not_connected",
    setup: "Personal Google sign-in with calendar access.",
  },
  {
    key: "google_drive",
    name: "Google Drive",
    category: "Email & files",
    icon: FolderOpen,
    description: "Attach Drive documents to bookings and upload files to Drive.",
    status: "not_connected",
    setup: "Personal Google sign-in with file access.",
  },
  {
    key: "google_contacts",
    name: "Google Contacts",
    category: "Email & files",
    icon: Contact,
    description: "Import contacts into Clients. Nothing is written back to Google.",
    status: "not_connected",
    setup: "Personal Google sign-in with read-only contacts access.",
  },
  {
    key: "microsoft_365",
    name: "Microsoft 365",
    category: "Email & files",
    icon: MonitorSmartphone,
    description: "Outlook mail, calendar, contacts and OneDrive files.",
    status: "not_connected",
    setup: "Microsoft work account and admin consent for your organisation.",
  },
  {
    key: "slack",
    name: "Slack",
    category: "Messaging",
    icon: Hash,
    description: "Post task and booking updates to your team channels.",
    status: "not_connected",
    setup: "One workspace connection, then invite the Toor bot to channels.",
  },
  {
    key: "whatsapp",
    name: "WhatsApp Business",
    category: "Messaging",
    icon: MessageCircle,
    description: "Message travellers and clients with approved templates.",
    status: "not_connected",
    setup: "Verified Meta business account and phone number. Meta charges per message.",
  },
  {
    key: "xero",
    name: "Xero",
    category: "Accounting",
    icon: Landmark,
    description: "Send invoices and bills as drafts, and match payments.",
    status: "not_connected",
    setup: "One Xero organisation per connection. Drafts are approved in Xero.",
  },
  {
    key: "quickbooks",
    name: "QuickBooks Online",
    category: "Accounting",
    icon: ReceiptText,
    description: "Customers, invoices, bills and payments.",
    status: "not_connected",
    setup: "Test in a QuickBooks sandbox company first.",
  },
  {
    key: "sage",
    name: "Sage Accounting",
    category: "Accounting",
    icon: Wallet,
    description: "Contacts, invoices, bills and payments (UK and Ireland).",
    status: "not_connected",
    setup: "Sage Business Cloud Accounting only. Sage 50 is not supported.",
  },
  {
    key: "ai",
    name: "AI assistant",
    category: "Toor platform",
    icon: Bot,
    description: "Reads documents and suggests what to create. You always review first.",
    status: "built_in",
    setup: "Included with Toor. No setup needed.",
  },
];

export const APP_CATEGORIES: AppCategory[] = [
  "Email & files",
  "Messaging",
  "Accounting",
  "Toor platform",
];
