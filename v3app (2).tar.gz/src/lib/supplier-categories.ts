import {
  BedDouble,
  Bus,
  Compass,
  Landmark,
  Package,
  Plane,
  Ship,
  Store,
  Ticket,
  UtensilsCrossed,
  type LucideIcon,
} from "lucide-react";
import type { ServiceCategory } from "@/convex/schema/supplierCategories.ts";

export {
  ALL_RATE_UNITS,
  CATEGORY_REGISTRY,
  SERVICE_CATEGORIES,
  SERVICE_CATEGORY_LABELS,
  legacyToService,
  serviceToLegacy,
} from "@/convex/schema/supplierCategories.ts";
export type {
  CategoryRegistryEntry,
  FieldDef,
  FieldType,
  ServiceCategory,
} from "@/convex/schema/supplierCategories.ts";

export const SERVICE_CATEGORY_ICONS: Record<ServiceCategory, LucideIcon> = {
  hotel: BedDouble,
  transport: Bus,
  restaurant: UtensilsCrossed,
  activity: Ticket,
  venue: Landmark,
  airline: Plane,
  guide: Compass,
  cruise: Ship,
  equipment_event: Package,
  other: Store,
};
