import { BadgeCheck, FileText, Hotel, Route, type LucideIcon } from "lucide-react";
import type { ShareLinkKind } from "@/convex/schema/shareLinks.ts";

export type { ShareLinkKind };

export const LINK_KIND_META: Record<
  ShareLinkKind,
  { label: string; hint: string; icon: LucideIcon }
> = {
  offer: {
    label: "Offer",
    hint: "Programme, inclusions and price. The client can accept or decline.",
    icon: FileText,
  },
  itinerary: {
    label: "Itinerary",
    hint: "Day-by-day programme only, no prices.",
    icon: Route,
  },
  confirmation: {
    label: "Confirmation",
    hint: "Confirmed services and programme. The client can request changes.",
    icon: BadgeCheck,
  },
  hotel_response: {
    label: "Hotel response",
    hint: "The supplier approves or declines one change request.",
    icon: Hotel,
  },
};

/** Kinds staff create from the Client links tab. Hotel links start from a change request. */
export const CLIENT_LINK_KINDS = ["offer", "itinerary", "confirmation"] as const satisfies readonly ShareLinkKind[];

export const LINK_DURATIONS = [
  { days: 7, label: "1 week" },
  { days: 14, label: "2 weeks" },
  { days: 30, label: "30 days" },
  { days: 90, label: "90 days" },
] as const;

export function shareUrl(token: string) {
  return `${window.location.origin}/share/${token}`;
}

export async function copyShareLink(token: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(shareUrl(token));
    return true;
  } catch {
    return false;
  }
}
