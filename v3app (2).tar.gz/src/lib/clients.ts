import type { ClientKind } from "@/convex/schema/clients.ts";

export { CLIENT_KINDS } from "@/convex/schema/clients.ts";
export type { ClientKind };

export const KIND_LABELS: Record<ClientKind, string> = {
  company: "Company",
  individual: "Person",
};

/** "Barcelona, Spain" from whichever parts are present. */
export function formatPlace(city?: string | null, country?: string | null) {
  return [city, country].filter(Boolean).join(", ");
}
