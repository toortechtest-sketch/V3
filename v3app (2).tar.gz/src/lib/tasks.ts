import { format, isToday, isTomorrow, isYesterday, parseISO } from "date-fns";
import type { TaskKind, TaskStatus } from "@/convex/schema/tasks.ts";

export { TASK_KINDS, TASK_STATUSES } from "@/convex/schema/tasks.ts";
export type { TaskKind, TaskStatus };

export const KIND_LABELS: Record<TaskKind, string> = {
  task: "Task",
  follow_up: "Follow-up",
};

export const STATUS_LABELS: Record<TaskStatus, string> = {
  open: "To do",
  in_progress: "In progress",
  done: "Done",
};

/** Today in the user's timezone as YYYY-MM-DD, matching stored due dates. */
export function todayKey(now = new Date()) {
  return format(now, "yyyy-MM-dd");
}

export type DueState = "overdue" | "today" | "upcoming" | "none";

export function dueState(dueDate: string | undefined, today = todayKey()): DueState {
  if (!dueDate) return "none";
  if (dueDate < today) return "overdue";
  if (dueDate === today) return "today";
  return "upcoming";
}

/** "Today", "Tomorrow", "Yesterday", or "3 Dec" (with year if not this year). */
export function formatDue(dueDate: string) {
  const d = parseISO(dueDate);
  if (isToday(d)) return "Today";
  if (isTomorrow(d)) return "Tomorrow";
  if (isYesterday(d)) return "Yesterday";
  return format(d, d.getFullYear() === new Date().getFullYear() ? "d MMM" : "d MMM yyyy");
}
