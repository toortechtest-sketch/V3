export const LANGUAGES = [
  { code: "en", name: "English", locale: "en-GB" },
  { code: "fr", name: "Français", locale: "fr-FR" },
  { code: "da", name: "Dansk", locale: "da-DK" },
  { code: "de", name: "Deutsch", locale: "de-DE" },
  { code: "es", name: "Español", locale: "es-ES" },
] as const;

export type LanguageCode = (typeof LANGUAGES)[number]["code"];

/** Languages whose translation file has been added. Others show as "Coming soon". */
export const AVAILABLE_LANGUAGES: readonly LanguageCode[] = ["en"];

export const DEFAULT_LANGUAGE: LanguageCode = "en";

export function isAvailableLanguage(value: unknown): value is LanguageCode {
  return AVAILABLE_LANGUAGES.some((code) => code === value);
}
