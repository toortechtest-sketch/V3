import { createContext } from "react";
import type { LanguageCode } from "./languages.ts";

export type LanguageContextValue = {
  language: LanguageCode;
  /** BCP 47 locale for formatting dates and money, e.g. "da-DK". */
  locale: string;
  setLanguage: (language: LanguageCode) => void;
};

export const LanguageContext = createContext<LanguageContextValue | null>(null);
