export {
  RATE_AVAILABILITY_STATUSES,
  RATE_BASES,
  SUPPLIER_DOCUMENT_TYPES,
  SUPPLIER_PRODUCT_STATUSES,
  TAX_MODES,
} from "@/convex/schema/supplierProfiles.ts";
export type {
  RateAvailabilityStatus,
  RateBasis,
  SupplierDocumentType,
  SupplierProductStatus,
  TaxMode,
} from "@/convex/schema/supplierProfiles.ts";

export const DOCUMENT_TYPE_LABELS: Record<
  "contract" | "rate_sheet" | "menu" | "licence" | "insurance" | "floor_plan" | "other",
  string
> = {
  contract: "Contract",
  rate_sheet: "Rate sheet",
  menu: "Menu",
  licence: "Licence",
  insurance: "Insurance",
  floor_plan: "Floor plan",
  other: "Other",
};

export const TAX_MODE_LABELS: Record<"included" | "excluded" | "unknown", string> = {
  included: "Tax included",
  excluded: "Tax excluded",
  unknown: "Tax unknown",
};

export const RATE_BASIS_LABELS: Record<"net" | "gross" | "unknown", string> = {
  net: "Net",
  gross: "Gross",
  unknown: "Unknown",
};

export const AVAILABILITY_LABELS: Record<
  "on_request" | "confirmed_allocation" | "other",
  string
> = {
  on_request: "On request",
  confirmed_allocation: "Confirmed allocation",
  other: "Other",
};

export const PRODUCT_STATUS_LABELS: Record<"active" | "archived", string> = {
  active: "Active",
  archived: "Archived",
};
