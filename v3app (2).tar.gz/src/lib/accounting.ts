import type {
  AccountType,
  DocumentKind,
  DocumentState,
} from "@/convex/schema/accounting.ts";

export { ACCOUNT_TYPES } from "@/convex/schema/accounting.ts";
export { naturalBalance } from "@/convex/lib/ledger.ts";
export type { AccountType, DocumentKind, DocumentState };

/** Formats integer cents in the ledger currency. */
export function formatMinor(minor: number, currency: string) {
  return new Intl.NumberFormat(undefined, {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(minor / 100);
}

const AMOUNT_PATTERN = /^\d{1,10}([.,]\d{1,2})?$/;

/** "1234.5" -> 123450. Returns null for anything that isn't a plain amount. */
export function parseMinor(input: string): number | null {
  const value = input.trim().replace(/[\s']/g, "");
  if (!AMOUNT_PATTERN.test(value)) return null;
  const [whole, fraction = ""] = value.replace(",", ".").split(".");
  return Number(whole) * 100 + Number(fraction.padEnd(2, "0"));
}

/** 123450 -> "1234.50" for editing in an input. */
export const minorToInput = (minor: number) => (minor / 100).toFixed(2);

export const isAmount = (input: string) => parseMinor(input) !== null;

export const KIND_META: Record<
  DocumentKind,
  { label: string; plural: string; party: string; accountType: AccountType }
> = {
  invoice: { label: "Invoice", plural: "Invoices", party: "Client", accountType: "revenue" },
  bill: { label: "Bill", plural: "Bills", party: "Supplier", accountType: "expense" },
};

export const STATE_META: Record<DocumentState, { label: string; badge: string }> = {
  draft: { label: "Draft", badge: "bg-muted text-muted-foreground" },
  posted: { label: "Posted", badge: "bg-primary/12 text-primary dark:text-[#7fa6ff]" },
  reversed: {
    label: "Reversed",
    badge: "bg-destructive/12 text-destructive",
  },
};

export const ACCOUNT_TYPE_LABELS: Record<AccountType, string> = {
  asset: "Asset",
  liability: "Liability",
  equity: "Equity",
  revenue: "Revenue",
  expense: "Expense",
};

export type PaymentStatus = "draft" | "reversed" | "unpaid" | "partial" | "paid" | "overdue";

/** Collection status a person cares about, derived from state, payments and due date. */
export function paymentStatus(
  doc: { state: DocumentState; totalMinor: number; paidMinor: number; dueDate: string },
  today: string,
): PaymentStatus {
  if (doc.state !== "posted") return doc.state;
  if (doc.paidMinor >= doc.totalMinor) return "paid";
  if (doc.dueDate < today) return "overdue";
  return doc.paidMinor > 0 ? "partial" : "unpaid";
}

export const PAYMENT_STATUS_META: Record<PaymentStatus, { label: string; badge: string }> = {
  draft: STATE_META.draft,
  reversed: STATE_META.reversed,
  unpaid: { label: "Unpaid", badge: "bg-[#FFB800]/18 text-[#8a6400] dark:text-[#FFB800]" },
  partial: { label: "Part paid", badge: "bg-[#00BDEB]/15 text-[#00708c] dark:text-[#5fd8f5]" },
  paid: { label: "Paid", badge: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400" },
  overdue: { label: "Overdue", badge: "bg-[#F47A12]/15 text-[#b05300] dark:text-[#ffa257]" },
};

/** Local calendar day, YYYY-MM-DD. */
export function localToday() {
  const d = new Date();
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

export function addDays(day: string, days: number) {
  const d = new Date(`${day}T00:00:00Z`);
  d.setUTCDate(d.getUTCDate() + days);
  return d.toISOString().slice(0, 10);
}
