/** "2h 15m", "45m", or "<1m" for a duration in milliseconds. */
export function formatDuration(ms: number) {
  if (ms < 60_000) return "<1m";
  const totalMinutes = Math.round(ms / 60_000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  if (hours === 0) return `${minutes}m`;
  return minutes === 0 ? `${hours}h` : `${hours}h ${minutes}m`;
}

/** "Online now", "5m ago", "Yesterday", or a date for anything older. */
export function formatLastSeen(iso: string | null, nowMs = Date.now()) {
  if (!iso) return "Never signed in";
  const diffMs = nowMs - new Date(iso).getTime();
  if (diffMs < 2 * 60 * 1000) return "Online now";
  if (diffMs < 60 * 60 * 1000) return `${Math.round(diffMs / 60_000)}m ago`;
  if (diffMs < 24 * 60 * 60 * 1000) return `${Math.round(diffMs / 3_600_000)}h ago`;
  const days = Math.round(diffMs / 86_400_000);
  if (days === 1) return "Yesterday";
  if (days < 7) return `${days}d ago`;
  return new Date(iso).toLocaleDateString(undefined, { day: "numeric", month: "short" });
}
