import {
  BedDouble,
  Bus,
  CircleDot,
  Plane,
  PlaneLanding,
  PlaneTakeoff,
  Presentation,
  Sun,
  Ticket,
  UtensilsCrossed,
  type LucideIcon,
} from "lucide-react";
import type { ItineraryItemType } from "@/convex/schema/itinerary.ts";

export { ITINERARY_ITEM_TYPES } from "@/convex/schema/itinerary.ts";
export type { ItineraryItemType };

export const ITEM_TYPE_META: Record<
  ItineraryItemType,
  { label: string; icon: LucideIcon; tone: string }
> = {
  arrival: { label: "Arrival", icon: PlaneLanding, tone: "bg-[#00BDEB]/15 text-[#00708c] dark:text-[#5fd8f5]" },
  departure: { label: "Departure", icon: PlaneTakeoff, tone: "bg-[#00BDEB]/15 text-[#00708c] dark:text-[#5fd8f5]" },
  flight: { label: "Flight", icon: Plane, tone: "bg-[#00BDEB]/15 text-[#00708c] dark:text-[#5fd8f5]" },
  transfer: { label: "Transfer", icon: Bus, tone: "bg-secondary text-primary" },
  hotel: { label: "Hotel", icon: BedDouble, tone: "bg-primary/12 text-primary dark:text-[#7fa6ff]" },
  meal: { label: "Meal", icon: UtensilsCrossed, tone: "bg-[#F47A12]/15 text-[#b05300] dark:text-[#ffa257]" },
  activity: { label: "Activity", icon: Ticket, tone: "bg-[#FFB800]/18 text-[#8a6400] dark:text-[#FFB800]" },
  meeting: { label: "Meeting", icon: Presentation, tone: "bg-primary/12 text-primary dark:text-[#7fa6ff]" },
  "free-time": { label: "Free time", icon: Sun, tone: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400" },
  other: { label: "Other", icon: CircleDot, tone: "bg-muted text-muted-foreground" },
};

/** "09:30 – 11:00", "09:30" or null. */
export function formatTimeRange(start?: string, end?: string) {
  if (!start) return null;
  return end ? `${start} – ${end}` : start;
}
