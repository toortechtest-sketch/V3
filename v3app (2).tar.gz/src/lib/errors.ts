import { ConvexError } from "convex/values";

/** Readable message from a backend error, with a safe fallback. */
export function errorMessage(error: unknown) {
  if (error instanceof ConvexError) {
    const data = error.data as { message?: string };
    if (data.message) {
      // Reconciliation wraps allotment-engine errors as "CODE: message" for an
      // internal audit trail; strip the code so staff see a plain sentence.
      return data.message.replace(/^[A-Z][A-Z_]*:\s*/, "");
    }
  }
  return "Something went wrong. Please try again.";
}
