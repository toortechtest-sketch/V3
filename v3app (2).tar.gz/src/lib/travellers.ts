import Papa from "papaparse";
import { ROOM_TYPES, type RoomType } from "@/convex/schema/travellers.ts";

export { ROOM_TYPES, ROOM_STATUSES } from "@/convex/schema/travellers.ts";
export type { RoomType, RoomStatus } from "@/convex/schema/travellers.ts";

export const ROOM_TYPE_LABELS: Record<RoomType, string> = {
  single: "Single",
  double: "Double",
  twin: "Twin",
  triple: "Triple",
  suite: "Suite",
};

/** Mirrors `DEFAULT_CAPACITY` in convex/travellers.ts. */
export const DEFAULT_CAPACITY: Record<RoomType, number> = {
  single: 1,
  double: 2,
  twin: 2,
  triple: 3,
  suite: 2,
};

export type PastedTraveller = {
  firstName: string;
  lastName: string;
  email?: string;
  roomPreference: RoomType;
};

const isRoomType = (s: string): s is RoomType =>
  (ROOM_TYPES as readonly string[]).includes(s.toLowerCase());

/**
 * Turns a pasted list (one traveller per line, e.g. copied from a spreadsheet)
 * into travellers. Columns may be separated by tabs, commas or semicolons.
 * A single name column is split into first word + the rest. Any column with
 * "@" is the email; a column like "twin" sets the room preference.
 */
export function parseTravellerList(text: string, fallbackRoom: RoomType): PastedTraveller[] {
  return text.split(/\r?\n/).flatMap((line) => {
    const parts = line
      .split(/[\t;,]/)
      .map((p) => p.trim())
      .filter(Boolean);
    const email = parts.find((p) => p.includes("@"));
    const room = parts.find(isRoomType);
    const names = parts.filter((p) => p !== email && p !== room);
    if (names.length === 0) return [];
    const [firstName, ...rest] =
      names.length === 1 ? names[0].split(/\s+/) : [names[0], names[1]];
    return [
      {
        firstName,
        lastName: rest.join(" "),
        email: email?.toLowerCase(),
        roomPreference: room ? (room.toLowerCase() as RoomType) : fallbackRoom,
      },
    ];
  });
}

export const fullName = (t: { firstName: string; lastName: string }) =>
  `${t.firstName} ${t.lastName}`.trim();

/** Saves rows as a UTF-8 CSV that opens cleanly in Excel. */
export function downloadCsv(filename: string, rows: Record<string, string | number>[]) {
  const csv = Papa.unparse(rows);
  const blob = new Blob(["\ufeff" + csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
