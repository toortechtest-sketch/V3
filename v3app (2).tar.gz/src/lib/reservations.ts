import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import type { ReservationStatus } from "@/convex/schema/reservations.ts";
import { format, parseISO } from "date-fns";
import { BOARD_LABELS } from "@/lib/suppliers.ts";

export { RESERVATION_STATUSES } from "@/convex/schema/reservations.ts";
export type { ReservationStatus };

type ChangeLike = Pick<Doc<"reservationChanges">, "kind" | "changes" | "previous">;

export const day = (d: string) => format(parseISO(d), "d MMM yyyy");

export function dateSpan(start: string, end?: string) {
  return end && end !== start ? `${day(start)} – ${day(end)}` : day(start);
}

/** "10 → 12 rooms", "Bed & breakfast → Half board" lines for a change. */
export function describeChange(change: ChangeLike, unitLabel: string): string[] {
  if (change.kind === "cancel") return ["Cancel the reservation"];
  const { changes: next, previous: prev } = change;
  const lines: string[] = [];
  const pair = (a: string | undefined, b: string) => `${a ?? "not set"} → ${b}`;
  if (next.units !== undefined) lines.push(`${pair(String(prev.units), String(next.units))} ${unitLabel}`);
  if (next.startDate) lines.push(`From ${pair(prev.startDate && day(prev.startDate), day(next.startDate))}`);
  if (next.endDate) lines.push(`To ${pair(prev.endDate && day(prev.endDate), day(next.endDate))}`);
  if (next.board) lines.push(pair(prev.board && BOARD_LABELS[prev.board], BOARD_LABELS[next.board]));
  if (next.description) lines.push(`Service: ${pair(prev.description, next.description)}`);
  return lines;
}

export const RESERVATION_STATUS_META: Record<
  ReservationStatus,
  { label: string; hint: string; badge: string }
> = {
  option: {
    label: "Option",
    hint: "Held, not yet requested",
    badge: "bg-[#00BDEB]/15 text-[#00708c] dark:text-[#5fd8f5]",
  },
  requested: {
    label: "Requested",
    hint: "Waiting on the supplier",
    badge: "bg-[#FFB800]/18 text-[#8a6400] dark:text-[#FFB800]",
  },
  confirmed: {
    label: "Confirmed",
    hint: "Changes need supplier approval",
    badge: "bg-primary/12 text-primary dark:text-[#7fa6ff]",
  },
  cancelled: {
    label: "Cancelled",
    hint: "No longer held",
    badge: "bg-muted text-muted-foreground line-through",
  },
};

/** Default quantity wording per service type. */
export const DEFAULT_UNIT_LABEL: Record<string, string> = {
  hotel: "rooms",
  transfer: "vehicles",
  restaurant: "covers",
  activity: "pax",
  venue: "rooms",
  flight: "seats",
  other: "units",
};
