import { useState } from "react";
import { Check, ChevronsUpDown, X, type LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command.tsx";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { cn } from "@/lib/utils.ts";

export type PickerOption<T extends string> = { id: T; label: string; hint?: string };

/**
 * Server-searched combobox. `useOptions` runs a Convex query and must return
 * undefined while loading; it receives null while the popover is closed so
 * nothing is subscribed.
 */
export default function SearchPicker<T extends string>({
  value,
  onChange,
  useOptions,
  icon: Icon,
  placeholder,
  searchPlaceholder,
  emptyText,
}: {
  value: PickerOption<T> | null;
  onChange: (value: PickerOption<T> | null) => void;
  useOptions: (term: string | null) => PickerOption<T>[] | undefined;
  icon: LucideIcon;
  placeholder: string;
  searchPlaceholder: string;
  emptyText: string;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [term] = useDebounce(search.trim(), 250);
  const options = useOptions(open ? term : null);

  return (
    <div className="flex gap-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="secondary"
            role="combobox"
            aria-expanded={open}
            className="min-w-0 flex-1 cursor-pointer justify-between font-normal"
          >
            <span className={cn("flex min-w-0 items-center gap-2", !value && "text-muted-foreground")}>
              <Icon className="size-4 shrink-0" />
              <span className="truncate">{value?.label ?? placeholder}</span>
            </span>
            <ChevronsUpDown className="size-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-(--radix-popover-trigger-width) min-w-64 p-0" align="start">
          <Command shouldFilter={false}>
            <CommandInput value={search} onValueChange={setSearch} placeholder={searchPlaceholder} />
            <CommandList>
              {options === undefined ? (
                <div className="flex justify-center py-6">
                  <Spinner />
                </div>
              ) : (
                <>
                  <CommandEmpty>{emptyText}</CommandEmpty>
                  <CommandGroup>
                    {options.map((o) => (
                      <CommandItem
                        key={o.id}
                        value={o.id}
                        className="cursor-pointer"
                        onSelect={() => {
                          onChange(o);
                          setOpen(false);
                        }}
                      >
                        <span className="min-w-0 flex-1 truncate">{o.label}</span>
                        {o.hint ? (
                          <span className="truncate text-xs text-muted-foreground">{o.hint}</span>
                        ) : null}
                        {value?.id === o.id ? <Check className="text-primary" /> : null}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </>
              )}
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      {value ? (
        <Button
          type="button"
          size="icon"
          variant="ghost"
          aria-label="Clear"
          className="shrink-0 cursor-pointer"
          onClick={() => onChange(null)}
        >
          <X className="size-4" />
        </Button>
      ) : null}
    </div>
  );
}
