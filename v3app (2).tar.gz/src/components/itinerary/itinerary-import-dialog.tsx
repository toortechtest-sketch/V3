import { useState } from "react";
import { useAction, useMutation } from "convex/react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import type { ItineraryDraftDay, ItineraryDraftItem } from "@/convex/ai/normalize.ts";
import ImportDialog from "@/components/ai-import/import-dialog.tsx";
import SourceStep from "@/components/ai-import/source-step.tsx";
import { DraftField, ReviewCard, ReviewToolbar } from "@/components/ai-import/review.tsx";
import { useDraftList } from "@/components/ai-import/use-draft-list.ts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { ITEM_TYPE_META, ITINERARY_ITEM_TYPES, type ItineraryItemType } from "@/lib/itinerary.ts";
import { cn } from "@/lib/utils.ts";

const NO_DAY = "none";
const TIME_PATTERN = /^([01]\d|2[0-3]):[0-5]\d$/;

function itemProblem(item: ItineraryDraftItem): string | undefined {
  if (!item.date) return "Pick the day this belongs to.";
  if (!item.title.trim()) return "Add a title.";
  for (const t of [item.startTime, item.endTime]) {
    if (t && !TIME_PATTERN.test(t)) return "Use 24-hour times like 09:30.";
  }
  if (item.endTime && (!item.startTime || item.endTime < item.startTime)) {
    return "The end time must be after the start time.";
  }
  return undefined;
}

function dayLabel(days: string[], date: string) {
  return `Day ${days.indexOf(date) + 1} · ${format(parseISO(date), "EEE d MMM")}`;
}

export default function ItineraryImportDialog({
  open,
  onOpenChange,
  bookingId,
  days,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  /** The booking's calendar days, YYYY-MM-DD. */
  days: string[];
}) {
  const extract = useAction(api.ai.extract.extractItinerary);
  const create = useMutation(api.ai.save.createItinerary);
  const list = useDraftList<ItineraryDraftItem>();
  const [dayDrafts, setDayDrafts] = useState<ItineraryDraftDay[]>([]);
  const [creating, setCreating] = useState(false);

  const reviewing = list.rows.length > 0 || dayDrafts.length > 0;
  const invalid = list.selected.some((r) => itemProblem(r.draft));

  const reset = () => {
    list.clear();
    setDayDrafts([]);
  };
  const close = (next: boolean) => {
    if (!next) reset();
    onOpenChange(next);
  };

  const onCreate = async () => {
    setCreating(true);
    try {
      const n = await create({
        bookingId,
        days: dayDrafts,
        items: list.selected.flatMap(({ draft }) =>
          draft.date ? [{ ...draft, date: draft.date }] : [],
        ),
      });
      toast.success(`${n} item${n === 1 ? "" : "s"} added to the itinerary`);
      close(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setCreating(false);
    }
  };

  // Group review cards by day, unplaced items last.
  const groups = [...days, null]
    .map((date) => ({
      date,
      headline: date ? dayDrafts.find((d) => d.date === date) : undefined,
      rows: list.rows.filter((r) => r.draft.date === date),
    }))
    .filter((g) => g.rows.length || g.headline);

  const count = list.selected.length;

  return (
    <ImportDialog
      open={open}
      onOpenChange={close}
      title="Import itinerary with AI"
      description="Paste a day-by-day programme from an email, proposal or document. AI places each item on a booking day; you review before anything is added."
      reviewing={reviewing}
      onBack={reset}
      createLabel={count ? `Add ${count} item${count === 1 ? "" : "s"}` : "Add day headlines"}
      canCreate={(count > 0 || dayDrafts.length > 0) && !invalid}
      creating={creating}
      onCreate={() => void onCreate()}
    >
      {reviewing ? (
        <div className="space-y-4 pb-1">
          <ReviewToolbar
            total={list.rows.length}
            selected={count}
            noun="items"
            onToggleAll={list.toggleAll}
          />
          {groups.map((g) => (
            <section key={g.date ?? NO_DAY} className="space-y-2">
              <div
                className={cn(
                  "flex flex-wrap items-baseline gap-x-2 border-b pb-1",
                  !g.date && "border-destructive/40",
                )}
              >
                <h3 className="font-mono text-xs tracking-wide text-muted-foreground uppercase">
                  {g.date ? dayLabel(days, g.date) : "Outside the booking dates"}
                </h3>
                {g.headline?.title ? (
                  <p className="font-display font-semibold">{g.headline.title}</p>
                ) : null}
              </div>
              {g.headline?.notes ? (
                <p className="text-xs text-muted-foreground">{g.headline.notes}</p>
              ) : null}
              {g.rows.map(({ key, draft, selected }) => {
                const set = (patch: Partial<ItineraryDraftItem>) => list.update(key, patch);
                const meta = ITEM_TYPE_META[draft.type];
                return (
                  <ReviewCard
                    key={key}
                    checked={selected}
                    onCheckedChange={(v) => list.toggle(key, v)}
                    label={draft.title || "item"}
                    warning={itemProblem(draft)}
                  >
                    <div className="flex flex-wrap items-end gap-2">
                      <Select
                        value={draft.type}
                        onValueChange={(v) => set({ type: v as ItineraryItemType })}
                      >
                        <SelectTrigger
                          size="sm"
                          aria-label="Type"
                          className={cn("h-8 w-36 cursor-pointer border-0", meta.tone)}
                        >
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {ITINERARY_ITEM_TYPES.map((t) => (
                            <SelectItem key={t} value={t} className="cursor-pointer">
                              {ITEM_TYPE_META[t].label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <DraftField
                        label="Title"
                        value={draft.title}
                        onChange={(v) => set({ title: v ?? "" })}
                        className="min-w-48 flex-1"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                      <label className="col-span-2 block space-y-1 sm:col-span-1">
                        <span className="text-[11px] font-medium text-muted-foreground">Day</span>
                        <Select
                          value={draft.date ?? NO_DAY}
                          onValueChange={(v) => set({ date: v === NO_DAY ? null : v })}
                        >
                          <SelectTrigger size="sm" className="h-8 w-full cursor-pointer">
                            <SelectValue placeholder="Pick a day" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value={NO_DAY} disabled>
                              Pick a day
                            </SelectItem>
                            {days.map((d) => (
                              <SelectItem key={d} value={d} className="cursor-pointer">
                                {dayLabel(days, d)}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </label>
                      <DraftField
                        label="Start"
                        value={draft.startTime}
                        placeholder="09:30"
                        onChange={(v) => set({ startTime: v })}
                      />
                      <DraftField
                        label="End"
                        value={draft.endTime}
                        placeholder="11:00"
                        onChange={(v) => set({ endTime: v })}
                      />
                      <DraftField
                        label="Location"
                        value={draft.location}
                        onChange={(v) => set({ location: v })}
                        className="col-span-2 sm:col-span-1"
                      />
                    </div>
                    {draft.description ? (
                      <p className="line-clamp-2 text-xs text-muted-foreground">{draft.description}</p>
                    ) : null}
                  </ReviewCard>
                );
              })}
            </section>
          ))}
          {dayDrafts.length ? (
            <p className="text-xs text-muted-foreground">
              Day headlines and notes only fill days that don't have them yet.
            </p>
          ) : null}
        </div>
      ) : (
        <SourceStep
          textPlaceholder={
            "Day 1 – Arrival\n14:00 Transfer from airport to Hotel Arts\n20:00 Welcome dinner at Els Pescadors\n\nDay 2 – City discovery\n09:30 Guided Sagrada Família tour…"
          }
          hint={`AI places items on the ${days.length} booking day${days.length === 1 ? "" : "s"}. Nothing is added yet.`}
          onExtract={async (source) => {
            if (source.kind !== "text") return;
            const result = await extract({ bookingId, text: source.text });
            setDayDrafts(result.days);
            list.load(result.items, (i) => i.date !== null);
          }}
        />
      )}
    </ImportDialog>
  );
}
