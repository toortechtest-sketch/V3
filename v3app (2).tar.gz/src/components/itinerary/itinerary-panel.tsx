import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import {
  AlertTriangle,
  CalendarRange,
  Lock,
  MapPin,
  MoreHorizontal,
  Pencil,
  Plus,
  Sparkles,
  Trash2,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import DayDialog from "@/components/itinerary/day-dialog.tsx";
import ItemDialog, { type EditableItem } from "@/components/itinerary/item-dialog.tsx";
import ItineraryImportDialog from "@/components/itinerary/itinerary-import-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { ITEM_TYPE_META, formatTimeRange } from "@/lib/itinerary.ts";
import { cn } from "@/lib/utils.ts";

type Itinerary = NonNullable<ReturnType<typeof useItinerary>>;
type Day = Itinerary["days"][number];

function useItinerary(bookingId: Id<"bookings">) {
  return useQuery(api.itinerary.get, { bookingId });
}

type DialogState =
  | { kind: "none" }
  | { kind: "add"; date: string }
  | { kind: "edit"; item: EditableItem }
  | { kind: "day"; day: Day; dayNumber: number | null };

function ItemRow({
  item,
  onEdit,
}: {
  item: Day["items"][number];
  onEdit: () => void;
}) {
  const remove = useMutation(api.itinerary.removeItem);
  const meta = ITEM_TYPE_META[item.type];
  const time = formatTimeRange(item.startTime, item.endTime);
  return (
    <div className="group flex gap-3 py-3">
      <div className="w-24 shrink-0 pt-1.5 font-mono text-xs text-muted-foreground sm:w-28">
        {time ?? "Any time"}
      </div>
      <div className={cn("flex size-8 shrink-0 items-center justify-center rounded-lg", meta.tone)}>
        <meta.icon className="size-4" />
      </div>
      <div className="min-w-0 flex-1 space-y-1">
        <button
          type="button"
          onClick={onEdit}
          className="block w-full cursor-pointer text-left font-medium break-words hover:text-primary"
        >
          {item.title}
        </button>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span>{meta.label}</span>
          {item.location ? (
            <span className="flex min-w-0 items-center gap-1">
              <MapPin className="size-3 shrink-0" />
              <span className="truncate">{item.location}</span>
            </span>
          ) : null}
          {item.supplier ? (
            <Link
              to={`/suppliers/${item.supplier._id}`}
              className="cursor-pointer rounded bg-secondary px-1.5 py-0.5 text-primary hover:underline"
            >
              {item.supplier.name}
            </Link>
          ) : null}
        </div>
        {item.description ? (
          <p className="text-sm whitespace-pre-wrap text-muted-foreground">{item.description}</p>
        ) : null}
        {item.internalNotes ? (
          <p className="flex gap-1.5 rounded-md bg-[#FFB800]/12 px-2 py-1 text-xs text-[#8a6400] dark:text-[#FFB800]">
            <Lock className="mt-0.5 size-3 shrink-0" />
            <span className="whitespace-pre-wrap">{item.internalNotes}</span>
          </p>
        ) : null}
      </div>
      <div className="flex shrink-0 flex-col items-end gap-1">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              size="icon"
              variant="ghost"
              aria-label={`Options for ${item.title}`}
              className="size-8 cursor-pointer text-muted-foreground"
            >
              <MoreHorizontal className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="cursor-pointer" onSelect={onEdit}>
              <Pencil /> Edit
            </DropdownMenuItem>
            <DropdownMenuItem
              variant="destructive"
              className="cursor-pointer"
              onSelect={() => {
                remove({ id: item._id }).then(
                  () => toast.success("Removed from the itinerary"),
                  (error: unknown) => toast.error(errorMessage(error)),
                );
              }}
            >
              <Trash2 /> Remove
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function DayCard({
  day,
  dayNumber,
  onDialog,
}: {
  day: Day;
  dayNumber: number | null;
  onDialog: (state: DialogState) => void;
}) {
  const date = parseISO(day.date);
  return (
    <Card id={`day-${day.date}`} className="scroll-mt-24 gap-0 overflow-hidden py-0">
      <div
        className={cn(
          "flex items-center gap-4 border-b px-4 py-3 sm:px-5",
          day.outsideDates && "bg-destructive/8",
        )}
      >
        <div className="flex w-12 shrink-0 flex-col items-center rounded-lg bg-sidebar py-1.5 text-sidebar-foreground">
          <span className="font-mono text-[10px] tracking-widest text-sidebar-primary uppercase">
            {format(date, "EEE")}
          </span>
          <span className="font-display text-xl leading-none font-semibold">{format(date, "d")}</span>
        </div>
        <button
          type="button"
          className="min-w-0 flex-1 cursor-pointer text-left"
          onClick={() => onDialog({ kind: "day", day, dayNumber })}
        >
          <p className="font-mono text-xs text-muted-foreground">
            {dayNumber ? `Day ${dayNumber}` : "Outside booking dates"} · {format(date, "MMMM yyyy")}
          </p>
          <p
            className={cn(
              "font-display text-lg font-semibold break-words",
              !day.title && "font-sans text-base font-normal text-muted-foreground",
            )}
          >
            {day.title ?? "Add a headline"}
          </p>
        </button>
        <Button
          size="sm"
          variant="secondary"
          className="shrink-0 cursor-pointer"
          disabled={day.outsideDates}
          onClick={() => onDialog({ kind: "add", date: day.date })}
        >
          <Plus className="size-4" /> <span className="hidden sm:inline">Add</span>
        </Button>
      </div>
      <div className="px-4 sm:px-5">
        {day.outsideDates ? (
          <p className="flex items-center gap-2 pt-3 text-sm text-destructive">
            <AlertTriangle className="size-4 shrink-0" />
            The booking dates changed. Move these items to another day or remove them.
          </p>
        ) : null}
        {day.notes ? (
          <p className="border-b border-dashed py-3 text-sm whitespace-pre-wrap text-muted-foreground">
            {day.notes}
          </p>
        ) : null}
        {day.items.length === 0 ? (
          <button
            type="button"
            className="w-full cursor-pointer py-5 text-left text-sm text-muted-foreground hover:text-foreground"
            onClick={() => onDialog({ kind: "add", date: day.date })}
          >
            Nothing planned yet. Add a transfer, meal, activity or free time.
          </button>
        ) : (
          <div className="divide-y">
            {day.items.map((item) => (
              <ItemRow
                key={item._id}
                item={item}
                onEdit={() => onDialog({ kind: "edit", item })}
              />
            ))}
          </div>
        )}
      </div>
    </Card>
  );
}

/** Quick jump strip across the days, handy for long programmes. */
function DayStrip({ days, bookingDays }: { days: Day[]; bookingDays: string[] }) {
  return (
    <div className="-mx-4 overflow-x-auto px-4 [scrollbar-width:none] sm:mx-0 sm:px-0">
      <div className="inline-flex gap-1.5">
        {days.map((day) => {
          const n = bookingDays.indexOf(day.date) + 1;
          return (
            <a
              key={day.date}
              href={`#day-${day.date}`}
              className={cn(
                "flex min-w-14 cursor-pointer flex-col items-center rounded-lg border bg-card px-2 py-1.5 text-xs transition-colors hover:border-primary",
                day.outsideDates && "border-destructive/50",
              )}
            >
              <span className="font-mono text-muted-foreground">{n ? `D${n}` : "–"}</span>
              <span className="font-medium">{format(parseISO(day.date), "d MMM")}</span>
              <span
                className={cn(
                  "mt-1 size-1.5 rounded-full",
                  day.items.length ? "bg-primary" : "bg-border",
                )}
              />
            </a>
          );
        })}
      </div>
    </div>
  );
}

export default function ItineraryPanel({ bookingId }: { bookingId: Id<"bookings"> }) {
  const itinerary = useItinerary(bookingId);
  const [dialog, setDialog] = useState<DialogState>({ kind: "none" });
  const [importing, setImporting] = useState(false);
  const close = () => setDialog({ kind: "none" });

  if (itinerary === undefined) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-14 w-full" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-40 w-full" />
        ))}
      </div>
    );
  }

  const bookingDays = itinerary.days.filter((d) => !d.outsideDates).map((d) => d.date);
  const firstDay = bookingDays[0] ?? itinerary.days[0]?.date;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <CalendarRange className="size-4" />
          {bookingDays.length} day{bookingDays.length === 1 ? "" : "s"} · {itinerary.itemCount} item
          {itinerary.itemCount === 1 ? "" : "s"} planned
        </p>
        {firstDay ? (
          <div className="flex gap-2">
            <Button
              variant="secondary"
              className="cursor-pointer"
              disabled={itinerary.isFull || bookingDays.length === 0}
              onClick={() => setImporting(true)}
            >
              <Sparkles className="size-4" /> Import with AI
            </Button>
            <Button
              className="cursor-pointer"
              disabled={itinerary.isFull}
              onClick={() => setDialog({ kind: "add", date: firstDay })}
            >
              <Plus className="size-4" /> Add item
            </Button>
          </div>
        ) : null}
      </div>
      {itinerary.days.length > 3 ? (
        <DayStrip days={itinerary.days} bookingDays={bookingDays} />
      ) : null}
      {itinerary.days.map((day) => {
        const n = bookingDays.indexOf(day.date) + 1;
        return (
          <DayCard key={day.date} day={day} dayNumber={n || null} onDialog={setDialog} />
        );
      })}

      {dialog.kind === "add" || dialog.kind === "edit" ? (
        <ItemDialog
          key={dialog.kind === "edit" ? dialog.item._id : `add-${dialog.date}`}
          open
          onOpenChange={(open) => !open && close()}
          bookingId={bookingId}
          days={bookingDays}
          date={dialog.kind === "add" ? dialog.date : dialog.item.date}
          item={dialog.kind === "edit" ? dialog.item : undefined}
        />
      ) : null}
      {dialog.kind === "day" ? (
        <DayDialog
          key={dialog.day.date}
          open
          onOpenChange={(open) => !open && close()}
          bookingId={bookingId}
          date={dialog.day.date}
          dayNumber={dialog.dayNumber}
          title={dialog.day.title}
          notes={dialog.day.notes}
        />
      ) : null}
      <ItineraryImportDialog
        open={importing}
        onOpenChange={setImporting}
        bookingId={bookingId}
        days={bookingDays}
      />
    </div>
  );
}
