import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import SupplierPicker, { type PickedSupplier } from "@/components/suppliers/supplier-picker.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { ITEM_TYPE_META, ITINERARY_ITEM_TYPES } from "@/lib/itinerary.ts";

const time = z
  .string()
  .refine((v) => v === "" || /^([01]\d|2[0-3]):[0-5]\d$/.test(v), { message: "Use a time like 09:30" });

const schema = z
  .object({
    date: z.string().min(1),
    type: z.enum(ITINERARY_ITEM_TYPES),
    startTime: time,
    endTime: time,
    title: z.string().trim().min(1, "Add a title").max(200),
    location: z.string().trim().max(300),
    description: z.string().trim().max(5000),
    internalNotes: z.string().trim().max(5000),
  })
  .refine((v) => !v.endTime || v.startTime, {
    path: ["endTime"],
    message: "Add a start time first",
  })
  .refine((v) => !v.startTime || !v.endTime || v.endTime >= v.startTime, {
    path: ["endTime"],
    message: "Must be after the start",
  });

type FormValues = z.infer<typeof schema>;

export type EditableItem = Doc<"itineraryItems"> & { supplier: PickedSupplier | null };

function defaultsFrom(date: string, item?: EditableItem): FormValues {
  return {
    date: item?.date ?? date,
    type: item?.type ?? "activity",
    startTime: item?.startTime ?? "",
    endTime: item?.endTime ?? "",
    title: item?.title ?? "",
    location: item?.location ?? "",
    description: item?.description ?? "",
    internalNotes: item?.internalNotes ?? "",
  };
}

export default function ItemDialog({
  open,
  onOpenChange,
  bookingId,
  days,
  date,
  item,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  /** Days the item may be placed on. */
  days: string[];
  /** Day to start on when adding. */
  date: string;
  /** Pass to edit; omit to add. */
  item?: EditableItem;
}) {
  const add = useMutation(api.itinerary.addItem);
  const update = useMutation(api.itinerary.updateItem);
  const [saving, setSaving] = useState(false);
  const [supplier, setSupplier] = useState<PickedSupplier | null>(item?.supplier ?? null);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(date, item),
  });

  // An item left on a day outside new booking dates can still be edited in place.
  const dayOptions = item && !days.includes(item.date) ? [item.date, ...days] : days;

  const handleOpenChange = (next: boolean) => {
    if (next) {
      form.reset(defaultsFrom(date, item));
      setSupplier(item?.supplier ?? null);
    }
    onOpenChange(next);
  };

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    const optional = (s: string) => (s === "" ? undefined : s);
    const args = {
      date: values.date,
      type: values.type,
      title: values.title,
      startTime: optional(values.startTime),
      endTime: optional(values.endTime),
      location: optional(values.location),
      description: optional(values.description),
      internalNotes: optional(values.internalNotes),
      supplierId: supplier?._id,
    };
    try {
      if (item) {
        await update({ id: item._id, ...args });
        toast.success("Itinerary updated");
      } else {
        await add({ bookingId, ...args });
        toast.success("Added to the itinerary");
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const textField = (
    name: "title" | "location" | "startTime" | "endTime",
    label: string,
    placeholder: string,
    type = "text",
  ) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input type={type} placeholder={placeholder} {...field} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {item ? "Edit itinerary item" : "Add to itinerary"}
          </DialogTitle>
          <DialogDescription>
            Times are local at the destination.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Day</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {dayOptions.map((d) => (
                        <SelectItem key={d} value={d} className="cursor-pointer">
                          Day {days.indexOf(d) + 1 || "–"} · {format(parseISO(d), "EEE d MMM")}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ITINERARY_ITEM_TYPES.map((t) => {
                        const Icon = ITEM_TYPE_META[t].icon;
                        return (
                          <SelectItem key={t} value={t} className="cursor-pointer">
                            <Icon className="size-4" /> {ITEM_TYPE_META[t].label}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="sm:col-span-2">
              {textField("title", "Title", "Welcome dinner at El Xampanyet")}
            </div>
            {textField("startTime", "Starts", "19:30", "time")}
            {textField("endTime", "Ends", "22:00", "time")}
            <div className="sm:col-span-2">
              {textField("location", "Location", "Carrer de Montcada 22, Barcelona")}
            </div>
            <div className="space-y-2 sm:col-span-2">
              <p className="text-sm font-medium">Supplier</p>
              <SupplierPicker value={supplier} onChange={setSupplier} />
            </div>
            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description for the client</FormLabel>
                    <FormControl>
                      <Textarea rows={3} placeholder="Tapas and cava in the heart of El Born" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="internalNotes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Internal notes</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={2}
                        placeholder="Staff only, e.g. set menu confirmed, 2 vegetarians"
                        className="bg-[#FFB800]/8"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {item ? "Save" : "Add item"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
