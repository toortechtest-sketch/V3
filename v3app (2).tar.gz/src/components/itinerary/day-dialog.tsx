import { useState } from "react";
import { useMutation } from "convex/react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";

export default function DayDialog({
  open,
  onOpenChange,
  bookingId,
  date,
  dayNumber,
  title,
  notes,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  date: string;
  dayNumber: number | null;
  title?: string;
  notes?: string;
}) {
  const save = useMutation(api.itinerary.saveDay);
  const [draftTitle, setDraftTitle] = useState(title ?? "");
  const [draftNotes, setDraftNotes] = useState(notes ?? "");
  const [saving, setSaving] = useState(false);

  const handleOpenChange = (next: boolean) => {
    if (next) {
      setDraftTitle(title ?? "");
      setDraftNotes(notes ?? "");
    }
    onOpenChange(next);
  };

  const onSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (draftTitle.trim().length > 200) {
      toast.error("Keep the day title under 200 characters.");
      return;
    }
    setSaving(true);
    try {
      await save({ bookingId, date, title: draftTitle, notes: draftNotes });
      toast.success("Day saved");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {dayNumber ? `Day ${dayNumber}` : "Day"} · {format(parseISO(date), "EEEE d MMM")}
          </DialogTitle>
          <DialogDescription>Give the day a headline the client will see.</DialogDescription>
        </DialogHeader>
        <form onSubmit={onSave} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="day-title">Headline</Label>
            <Input
              id="day-title"
              value={draftTitle}
              onChange={(e) => setDraftTitle(e.target.value)}
              placeholder="Arrival and welcome dinner"
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="day-notes">Notes</Label>
            <Textarea
              id="day-notes"
              rows={3}
              value={draftNotes}
              onChange={(e) => setDraftNotes(e.target.value)}
              placeholder="Dress code: smart casual"
            />
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="ghost"
              className="cursor-pointer"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={saving} className="cursor-pointer">
              {saving ? <Spinner /> : null}
              Save day
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
