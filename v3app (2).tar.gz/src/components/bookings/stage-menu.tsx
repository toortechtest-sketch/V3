import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { BOOKING_STAGES, STAGE_META, type BookingStage } from "@/lib/bookings.ts";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";
import StageBadge from "./stage-badge.tsx";

/** Clickable stage badge that moves a booking to another stage. */
export default function StageMenu({
  bookingId,
  stage,
}: {
  bookingId: Id<"bookings">;
  stage: BookingStage;
}) {
  const setStage = useMutation(api.bookings.setStage);
  const [busy, setBusy] = useState(false);

  const move = async (next: BookingStage) => {
    setBusy(true);
    try {
      await setStage({ id: bookingId, stage: next });
      toast.success(`Moved to ${STAGE_META[next].label}`);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        disabled={busy}
        className="cursor-pointer rounded-full outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-60"
        onClick={(e) => e.stopPropagation()}
      >
        <StageBadge stage={stage} withChevron className="pr-1.5" />
        <span className="sr-only">Change stage</span>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="start" onClick={(e) => e.stopPropagation()}>
        <DropdownMenuLabel className="text-xs text-muted-foreground">
          Move to stage
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        {BOOKING_STAGES.map((s) => (
          <DropdownMenuItem
            key={s}
            disabled={s === stage}
            className="cursor-pointer"
            onSelect={() => void move(s)}
          >
            <span className={cn("size-2 rounded-full", STAGE_META[s].dot)} />
            <span className="flex-1">{STAGE_META[s].label}</span>
            <span className="text-xs text-muted-foreground">
              {STAGE_META[s].hint}
            </span>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
