import { useState } from "react";
import { useForm, useWatch, type Control } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import {
  BOOKING_TYPES,
  CURRENCIES,
  TYPE_LABELS,
} from "@/lib/bookings.ts";
import { errorMessage } from "@/lib/errors.ts";

const optionalText = z.string().trim().max(500);

const schema = z
  .object({
    title: z.string().trim().min(1, "Add a booking title").max(200),
    type: z.enum(BOOKING_TYPES),
    clientName: z.string().trim().min(1, "Add a client name").max(200),
    clientContactName: optionalText,
    clientContactEmail: z
      .string()
      .trim()
      .refine((v) => v === "" || z.email().safeParse(v).success, {
        message: "Enter a valid email",
      }),
    clientContactPhone: optionalText,
    destination: z.string().trim().min(1, "Add a destination").max(200),
    startDate: z.string().min(1, "Pick a start date"),
    endDate: z.string().min(1, "Pick an end date"),
    pax: z.string().refine((v) => Number.isInteger(Number(v)) && Number(v) >= 1, {
      message: "At least 1 whole traveller",
    }),
    currency: z.enum(CURRENCIES),
    exchangeRateToBase: z.string().refine((v) => Number(v) > 0, {
      message: "Must be above 0",
    }),
    markupPercent: z.string().refine((v) => v === "" || Number(v) >= 0, {
      message: "Cannot be negative",
    }),
    notes: z.string().max(5000),
    ownerId: z.string(),
  })
  .refine((v) => !v.startDate || !v.endDate || v.endDate >= v.startDate, {
    path: ["endDate"],
    message: "End date is before the start date",
  })
  .refine((v) => v.currency !== "EUR" || Number(v.exchangeRateToBase) === 1, {
    path: ["exchangeRateToBase"],
    message: "EUR bookings use a rate of 1",
  });

type FormValues = z.infer<typeof schema>;

function defaultsFrom(booking?: Doc<"bookings">): FormValues {
  return {
    title: booking?.title ?? "",
    type: booking?.type ?? "group",
    clientName: booking?.clientName ?? "",
    clientContactName: booking?.clientContactName ?? "",
    clientContactEmail: booking?.clientContactEmail ?? "",
    clientContactPhone: booking?.clientContactPhone ?? "",
    destination: booking?.destination ?? "",
    startDate: booking?.startDate ?? "",
    endDate: booking?.endDate ?? "",
    pax: String(booking?.pax ?? 10),
    currency: booking?.currency ?? "EUR",
    exchangeRateToBase: String(booking?.exchangeRateToBase ?? 1),
    markupPercent:
      booking?.markupPercent === undefined ? "" : String(booking.markupPercent),
    notes: booking?.notes ?? "",
    ownerId: booking?.ownerId ?? "",
  };
}

function toArgs(values: FormValues) {
  const optional = (s: string) => (s.trim() === "" ? undefined : s.trim());
  return {
    title: values.title,
    type: values.type,
    clientName: values.clientName,
    clientContactName: optional(values.clientContactName),
    clientContactEmail: optional(values.clientContactEmail),
    clientContactPhone: optional(values.clientContactPhone),
    destination: values.destination,
    startDate: values.startDate,
    endDate: values.endDate,
    pax: Number(values.pax),
    currency: values.currency,
    exchangeRateToBase: Number(values.exchangeRateToBase),
    markupPercent:
      values.markupPercent === "" ? undefined : Number(values.markupPercent),
    notes: optional(values.notes),
    ownerId: values.ownerId ? (values.ownerId as Id<"users">) : undefined,
  };
}

function OwnerField({ control }: { control: Control<FormValues> }) {
  const owners = useQuery(api.bookings.listAssignableOwners, {});
  return (
    <FormField
      control={control}
      name="ownerId"
      render={({ field }) => (
        <FormItem>
          <FormLabel>Booking owner</FormLabel>
          <Select
            value={field.value || undefined}
            onValueChange={field.onChange}
            disabled={owners === undefined}
          >
            <FormControl>
              <SelectTrigger className="w-full cursor-pointer">
                <SelectValue placeholder="Me" />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              {(owners ?? []).map((o) => (
                <SelectItem
                  key={o.userId}
                  value={o.userId}
                  className="cursor-pointer"
                >
                  {o.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>
      )}
    />
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <p className="col-span-full pt-2 font-mono text-[11px] tracking-widest text-muted-foreground uppercase">
      {children}
    </p>
  );
}

export default function BookingFormDialog({
  open,
  onOpenChange,
  booking,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Pass to edit; omit to create. */
  booking?: Doc<"bookings">;
}) {
  const { isManager } = useStaff();
  const navigate = useNavigate();
  const create = useMutation(api.bookings.create);
  const update = useMutation(api.bookings.update);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(booking),
  });
  const currency = useWatch({ control: form.control, name: "currency" });

  const handleOpenChange = (next: boolean) => {
    if (next) form.reset(defaultsFrom(booking));
    onOpenChange(next);
  };

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      const args = toArgs(values);
      if (booking) {
        await update({ id: booking._id, ...args });
        toast.success("Booking updated");
        onOpenChange(false);
      } else {
        const id = await create(args);
        toast.success("Booking created");
        onOpenChange(false);
        form.reset(defaultsFrom());
        navigate(`/bookings/${id}`);
      }
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const text = (
    name: keyof FormValues,
    label: string,
    placeholder: string,
    type = "text",
  ) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input type={type} placeholder={placeholder} {...field} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {booking ? `Edit ${booking.reference}` : "New booking"}
          </DialogTitle>
          <DialogDescription>
            {booking
              ? "Update the booking details."
              : "New bookings start as an enquiry. You can move them along the stages anytime."}
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-4 sm:grid-cols-2"
          >
            <SectionLabel>Booking</SectionLabel>
            <div className="sm:col-span-2">
              {text("title", "Title", "Acme sales kick-off 2026")}
            </div>
            <FormField
              control={form.control}
              name="type"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {BOOKING_TYPES.map((t) => (
                        <SelectItem key={t} value={t} className="cursor-pointer">
                          {TYPE_LABELS[t]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            {isManager ? (
              <OwnerField control={form.control} />
            ) : (
              <div className="hidden sm:block" />
            )}

            <SectionLabel>Client</SectionLabel>
            {text("clientName", "Client company", "Acme Corporation")}
            {text("clientContactName", "Contact name", "Jane Smith")}
            {text("clientContactEmail", "Contact email", "jane@acme.com", "email")}
            {text("clientContactPhone", "Contact phone", "+44 20 7946 0000", "tel")}

            <SectionLabel>Trip</SectionLabel>
            <div className="sm:col-span-2">
              {text("destination", "Destination", "Barcelona, Spain")}
            </div>
            {text("startDate", "Start date", "", "date")}
            {text("endDate", "End date", "", "date")}
            {text("pax", "Travellers", "40", "number")}
            <div />

            <SectionLabel>Money</SectionLabel>
            <FormField
              control={form.control}
              name="currency"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Currency</FormLabel>
                  <Select
                    value={field.value}
                    onValueChange={(value) => {
                      field.onChange(value);
                      if (value === "EUR") {
                        form.setValue("exchangeRateToBase", "1");
                      }
                    }}
                  >
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {CURRENCIES.map((c) => (
                        <SelectItem key={c} value={c} className="cursor-pointer">
                          {c}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="exchangeRateToBase"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>1 {currency} in EUR</FormLabel>
                  <FormControl>
                    <Input
                      type="number"
                      step="any"
                      disabled={currency === "EUR"}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            {text("markupPercent", "Default markup %", "20", "number")}
            <div />

            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={3}
                        placeholder="Anything the team should know"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {booking ? "Save changes" : "Create booking"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
