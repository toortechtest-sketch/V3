import { ChevronDown } from "lucide-react";
import { cn } from "@/lib/utils.ts";
import { STAGE_META, type BookingStage } from "@/lib/bookings.ts";

export default function StageBadge({
  stage,
  withChevron = false,
  className,
}: {
  stage: BookingStage;
  withChevron?: boolean;
  className?: string;
}) {
  const meta = STAGE_META[stage];
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-medium whitespace-nowrap",
        meta.badge,
        className,
      )}
    >
      <span className={cn("size-1.5 rounded-full", meta.dot)} />
      {meta.label}
      {withChevron ? <ChevronDown className="size-3 opacity-70" /> : null}
    </span>
  );
}
