import { useCallback, useEffect, useMemo, useState } from "react";
import { LanguageContext } from "@/lib/i18n/context.ts";
import {
  DEFAULT_LANGUAGE,
  LANGUAGES,
  isAvailableLanguage,
  type LanguageCode,
} from "@/lib/i18n/languages.ts";

// Stored per browser so each staff member keeps their own choice.
const STORAGE_KEY = "toor-language";

function readStoredLanguage(): LanguageCode {
  try {
    const saved = window.localStorage.getItem(STORAGE_KEY);
    return isAvailableLanguage(saved) ? saved : DEFAULT_LANGUAGE;
  } catch {
    return DEFAULT_LANGUAGE;
  }
}

export function LanguageProvider({ children }: { children: React.ReactNode }) {
  const [language, setLanguageState] = useState<LanguageCode>(readStoredLanguage);

  const setLanguage = useCallback((next: LanguageCode) => {
    if (!isAvailableLanguage(next)) return;
    setLanguageState(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, next);
    } catch {
      // Private browsing can block storage; the choice still applies for this visit.
    }
  }, []);

  // Keeps the page's language attribute in sync for screen readers and spellcheck.
  useEffect(() => {
    document.documentElement.lang = language;
  }, [language]);

  const value = useMemo(() => {
    const locale = LANGUAGES.find((l) => l.code === language)?.locale ?? "en-GB";
    return { language, locale, setLanguage };
  }, [language, setLanguage]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}
