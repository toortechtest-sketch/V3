import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import SupplierPicker, { type PickedSupplier } from "@/components/suppliers/supplier-picker.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import {
  BASIS_META,
  QUOTE_BASES,
  QUOTE_SECTIONS,
  SECTION_META,
  formatMoney,
  priceLine,
  type QuoteSection,
} from "@/lib/quotes.ts";

const amount = (label: string, max: number) =>
  z
    .string()
    .refine((v) => v !== "" && Number.isFinite(Number(v)) && Number(v) >= 0 && Number(v) <= max, {
      message: `${label} must be 0 or more`,
    });

const schema = z.object({
  section: z.enum(QUOTE_SECTIONS),
  description: z.string().trim().min(1, "Add a description").max(300),
  basis: z.enum(QUOTE_BASES),
  quantity: amount("Quantity", 100000),
  times: amount("Times", 1000),
  unitCost: amount("Unit cost", 1e9),
  markupPercent: z
    .string()
    .refine((v) => v === "" || (Number(v) >= 0 && Number(v) <= 1000), { message: "0 to 1000" }),
  internalNotes: z.string().trim().max(5000),
});

type FormValues = z.infer<typeof schema>;

export type EditableLine = Doc<"quoteLines"> & { supplier: PickedSupplier | null };

function defaultsFrom(section: QuoteSection, line?: EditableLine): FormValues {
  return {
    section: line?.section ?? section,
    description: line?.description ?? "",
    basis: line?.basis ?? (section === "accommodation" ? "per_unit" : "per_person"),
    quantity: String(line?.quantity ?? 1),
    times: String(line?.times ?? 1),
    unitCost: line ? String(line.unitCost) : "",
    markupPercent: line?.markupPercent === undefined ? "" : String(line.markupPercent),
    internalNotes: line?.internalNotes ?? "",
  };
}

export default function LineDialog({
  open,
  onOpenChange,
  bookingId,
  section,
  line,
  pax,
  currency,
  defaultMarkup,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  /** Section to start in when adding. */
  section: QuoteSection;
  /** Pass to edit; omit to add. */
  line?: EditableLine;
  pax: number;
  currency: string;
  defaultMarkup: number;
}) {
  const add = useMutation(api.quotes.addLine);
  const update = useMutation(api.quotes.updateLine);
  const [saving, setSaving] = useState(false);
  const [supplier, setSupplier] = useState<PickedSupplier | null>(line?.supplier ?? null);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(section, line),
  });

  const values = useWatch({ control: form.control });
  const preview = priceLine(
    {
      basis: values.basis ?? "per_person",
      quantity: Number(values.quantity) || 0,
      times: Number(values.times) || 0,
      unitCost: Number(values.unitCost) || 0,
      markupPercent: values.markupPercent ? Number(values.markupPercent) : undefined,
    },
    pax,
    defaultMarkup,
  );

  const onSubmit = async (v: FormValues) => {
    setSaving(true);
    const args = {
      section: v.section,
      description: v.description,
      basis: v.basis,
      quantity: Number(v.quantity),
      times: Number(v.times),
      unitCost: Number(v.unitCost),
      markupPercent: v.markupPercent === "" ? undefined : Number(v.markupPercent),
      internalNotes: v.internalNotes || undefined,
      supplierId: supplier?._id,
    };
    try {
      if (line) {
        await update({ id: line._id, ...args });
        toast.success("Quote line updated");
      } else {
        await add({ bookingId, ...args });
        toast.success("Added to the quote");
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const numberField = (
    name: "quantity" | "times" | "unitCost" | "markupPercent",
    label: string,
    placeholder: string,
  ) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input type="number" step="any" min={0} placeholder={placeholder} {...field} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {line ? "Edit quote line" : "Add to quote"}
          </DialogTitle>
          <DialogDescription>Costs are net supplier prices in {currency}.</DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            <FormField
              control={form.control}
              name="section"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Section</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {QUOTE_SECTIONS.map((s) => {
                        const Icon = SECTION_META[s].icon;
                        return (
                          <SelectItem key={s} value={s} className="cursor-pointer">
                            <Icon className="size-4" /> {SECTION_META[s].label}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="basis"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Priced</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {QUOTE_BASES.map((b) => (
                        <SelectItem key={b} value={b} className="cursor-pointer">
                          {BASIS_META[b].label}
                          <span className="text-xs text-muted-foreground">{BASIS_META[b].hint}</span>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description</FormLabel>
                    <FormControl>
                      <Input placeholder="Double room, bed and breakfast" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <div className="space-y-2 sm:col-span-2">
              <p className="text-sm font-medium">Supplier</p>
              <SupplierPicker value={supplier} onChange={setSupplier} />
            </div>

            {numberField("unitCost", `Unit cost (${currency})`, "120")}
            {values.basis === "per_unit" ? (
              numberField("quantity", "Quantity", "10")
            ) : (
              <div className="space-y-2">
                <p className="text-sm font-medium">Quantity</p>
                <p className="flex h-9 items-center rounded-md bg-muted px-3 text-sm text-muted-foreground">
                  {values.basis === "per_person" ? `${pax} travellers` : "Whole group"}
                </p>
              </div>
            )}
            {numberField("times", "Nights / days / times", "1")}
            {numberField("markupPercent", "Markup %", `${defaultMarkup} (booking default)`)}

            <div className="grid grid-cols-3 gap-px overflow-hidden rounded-lg border bg-border sm:col-span-2">
              {[
                { label: "Cost", value: preview.cost },
                { label: "Sell", value: preview.sell },
                { label: "Margin", value: preview.margin },
              ].map((cell) => (
                <div key={cell.label} className="bg-muted/50 px-3 py-2">
                  <p className="text-xs text-muted-foreground">{cell.label}</p>
                  <p className="font-mono text-sm font-medium">{formatMoney(cell.value, currency)}</p>
                </div>
              ))}
            </div>

            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="internalNotes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Internal notes</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={2}
                        placeholder="Staff only, e.g. rate valid until 15 Oct, 10% deposit"
                        className="bg-[#FFB800]/8"
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {line ? "Save" : "Add line"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
