import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import {
  AlertTriangle,
  Calculator,
  Lock,
  MoreHorizontal,
  Pencil,
  Plus,
  Settings2,
  Trash2,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import LineDialog, { type EditableLine } from "@/components/quotes/line-dialog.tsx";
import SettingsDialog from "@/components/quotes/settings-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { errorMessage } from "@/lib/errors.ts";
import {
  SECTION_META,
  formatMoney,
  formatPercent,
  lineFormula,
  type QuoteSection,
} from "@/lib/quotes.ts";
import { cn } from "@/lib/utils.ts";

type Quote = NonNullable<ReturnType<typeof useQuote>>;
type Section = Quote["sections"][number];
type Line = Section["lines"][number];

function useQuote(bookingId: Id<"bookings">) {
  return useQuery(api.quotes.get, { bookingId });
}

type DialogState =
  | { kind: "none" }
  | { kind: "add"; section: QuoteSection }
  | { kind: "edit"; line: EditableLine }
  | { kind: "settings" };

function Stat({
  label,
  value,
  sub,
  tone,
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: string;
}) {
  return (
    <div className="min-w-0 space-y-1 bg-card p-4 sm:p-5">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={cn("truncate font-display text-xl font-semibold sm:text-2xl", tone)}>{value}</p>
      {sub ? <p className="truncate font-mono text-xs text-muted-foreground">{sub}</p> : null}
    </div>
  );
}

function Summary({ quote, onSettings }: { quote: Quote; onSettings: () => void }) {
  const { totals, currency, settings } = quote;
  const eur = (n: number) => (currency === "EUR" ? undefined : `≈ ${formatMoney(n, "EUR")}`);
  const target = settings.targetMarginPercent;
  const belowTarget =
    target !== undefined && totals.marginPercent !== null && totals.marginPercent < target;

  return (
    <Card className="gap-0 overflow-hidden py-0">
      <div className="flex flex-wrap items-center justify-between gap-3 bg-sidebar px-4 py-3 text-sidebar-foreground sm:px-5">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 font-mono text-[11px] tracking-widest uppercase">
          <span className="text-sidebar-primary">Quote · {currency}</span>
          <span className="text-sidebar-foreground/70">
            {quote.pax} pax
            {settings.freePlaces ? ` · ${settings.freePlaces} free` : ""}
          </span>
          <span className="text-sidebar-foreground/70">Default markup {quote.defaultMarkup}%</span>
          {settings.validUntil ? (
            <span className="text-sidebar-foreground/70">
              Valid to {format(parseISO(settings.validUntil), "d MMM yyyy")}
            </span>
          ) : null}
        </div>
        <Button
          size="sm"
          variant="ghost"
          className="h-7 cursor-pointer text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
          onClick={onSettings}
        >
          <Settings2 className="size-4" /> Settings
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-px bg-border lg:grid-cols-5">
        <Stat label="Selling price" value={formatMoney(totals.sell, currency)} sub={eur(totals.base.sell)} />
        <Stat label="Net cost" value={formatMoney(totals.cost, currency)} sub={eur(totals.base.cost)} />
        <Stat
          label="Margin"
          value={formatMoney(totals.margin, currency)}
          sub={eur(totals.base.margin)}
          tone={totals.margin < 0 ? "text-destructive" : undefined}
        />
        <Stat
          label="Margin on sell"
          value={formatPercent(totals.marginPercent)}
          sub={target !== undefined ? `Target ${target}%` : undefined}
          tone={belowTarget ? "text-destructive" : "text-primary"}
        />
        <div className="col-span-2 lg:col-span-1">
          <Stat
            label="Per paying guest"
            value={totals.perPayingGuest === null ? "–" : formatMoney(totals.perPayingGuest, currency)}
            sub={`${totals.payingPax} paying`}
          />
        </div>
      </div>
      {belowTarget ? (
        <p className="flex items-center gap-2 border-t bg-destructive/8 px-4 py-2.5 text-sm text-destructive sm:px-5">
          <AlertTriangle className="size-4 shrink-0" />
          Margin is below the {target}% target. Raise markups or review costs.
        </p>
      ) : null}
    </Card>
  );
}

function LineRow({
  line,
  currency,
  onEdit,
}: {
  line: Line;
  currency: string;
  onEdit: () => void;
}) {
  const remove = useMutation(api.quotes.removeLine);
  const { priced } = line;
  return (
    <div className="grid grid-cols-[1fr_auto] gap-x-3 gap-y-1 py-3 md:grid-cols-[minmax(0,1fr)_7rem_7rem_6rem_2rem] md:items-center">
      <div className="min-w-0 space-y-1">
        <button
          type="button"
          onClick={onEdit}
          className="block w-full cursor-pointer text-left font-medium break-words hover:text-primary"
        >
          {line.description}
        </button>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          <span className="font-mono">{lineFormula(line, priced.units, currency)}</span>
          <span>+{priced.markupPercent}%</span>
          {line.supplier ? (
            <Link
              to={`/suppliers/${line.supplier._id}`}
              className="cursor-pointer rounded bg-secondary px-1.5 py-0.5 text-primary hover:underline"
            >
              {line.supplier.name}
            </Link>
          ) : null}
        </div>
        {line.internalNotes ? (
          <p className="flex gap-1.5 rounded-md bg-[#FFB800]/12 px-2 py-1 text-xs text-[#8a6400] dark:text-[#FFB800]">
            <Lock className="mt-0.5 size-3 shrink-0" />
            <span className="whitespace-pre-wrap">{line.internalNotes}</span>
          </p>
        ) : null}
      </div>
      <p className="hidden text-right font-mono text-sm text-muted-foreground md:block">
        {formatMoney(priced.cost, currency)}
      </p>
      <p className="row-start-1 text-right font-mono text-sm font-medium md:row-auto">
        {formatMoney(priced.sell, currency)}
      </p>
      <p
        className={cn(
          "hidden text-right font-mono text-xs md:block",
          priced.margin < 0 ? "text-destructive" : "text-muted-foreground",
        )}
      >
        {formatMoney(priced.margin, currency)}
      </p>
      <div className="col-start-2 row-start-2 flex justify-end md:col-auto md:row-auto">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              size="icon"
              variant="ghost"
              aria-label={`Options for ${line.description}`}
              className="size-8 cursor-pointer text-muted-foreground"
            >
              <MoreHorizontal className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="cursor-pointer" onSelect={onEdit}>
              <Pencil /> Edit
            </DropdownMenuItem>
            <DropdownMenuItem
              variant="destructive"
              className="cursor-pointer"
              onSelect={() => {
                remove({ id: line._id }).then(
                  () => toast.success("Removed from the quote"),
                  (error: unknown) => toast.error(errorMessage(error)),
                );
              }}
            >
              <Trash2 /> Remove
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
    </div>
  );
}

function SectionCard({
  section,
  currency,
  disabled,
  onDialog,
}: {
  section: Section;
  currency: string;
  disabled: boolean;
  onDialog: (state: DialogState) => void;
}) {
  const meta = SECTION_META[section.section];
  return (
    <Card className="gap-0 py-0">
      <div className="flex items-center gap-3 border-b px-4 py-3 sm:px-5">
        <div className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
          <meta.icon className="size-4" />
        </div>
        <p className="min-w-0 flex-1 font-display text-lg font-semibold">{meta.label}</p>
        <p className="hidden font-mono text-sm sm:block">
          {formatMoney(section.totals.sell, currency)}
          <span className="pl-2 text-xs text-muted-foreground">
            {formatPercent(section.totals.marginPercent)}
          </span>
        </p>
        <Button
          size="sm"
          variant="secondary"
          className="shrink-0 cursor-pointer"
          disabled={disabled}
          onClick={() => onDialog({ kind: "add", section: section.section })}
        >
          <Plus className="size-4" /> <span className="hidden sm:inline">Add</span>
        </Button>
      </div>
      <div className="px-4 sm:px-5">
        <div className="hidden grid-cols-[minmax(0,1fr)_7rem_7rem_6rem_2rem] gap-x-3 border-b py-2 text-xs text-muted-foreground md:grid">
          <span>Service</span>
          <span className="text-right">Cost</span>
          <span className="text-right">Sell</span>
          <span className="text-right">Margin</span>
          <span />
        </div>
        <div className="divide-y">
          {section.lines.map((line) => (
            <LineRow
              key={line._id}
              line={line}
              currency={currency}
              onEdit={() => onDialog({ kind: "edit", line })}
            />
          ))}
        </div>
      </div>
    </Card>
  );
}

export default function QuotePanel({ bookingId }: { bookingId: Id<"bookings"> }) {
  const quote = useQuote(bookingId);
  const [dialog, setDialog] = useState<DialogState>({ kind: "none" });
  const close = () => setDialog({ kind: "none" });

  if (quote === undefined) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-40 w-full" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <Summary quote={quote} onSettings={() => setDialog({ kind: "settings" })} />

      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <Calculator className="size-4" />
          {quote.lineCount} line{quote.lineCount === 1 ? "" : "s"} costed
        </p>
        <Button
          className="cursor-pointer"
          disabled={quote.isFull}
          onClick={() => setDialog({ kind: "add", section: "accommodation" })}
        >
          <Plus className="size-4" /> Add line
        </Button>
      </div>

      {quote.sections.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Calculator />
            </EmptyMedia>
            <EmptyTitle>No costs yet</EmptyTitle>
            <EmptyDescription>
              Add hotels, transfers, meals and activities at net cost. The selling
              price and margin are worked out for you.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button
              size="sm"
              className="cursor-pointer"
              onClick={() => setDialog({ kind: "add", section: "accommodation" })}
            >
              <Plus className="size-4" /> Add first line
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        quote.sections.map((section) => (
          <SectionCard
            key={section.section}
            section={section}
            currency={quote.currency}
            disabled={quote.isFull}
            onDialog={setDialog}
          />
        ))
      )}

      {quote.settings.terms ? (
        <Card className="gap-2 px-4 py-4 sm:px-5">
          <p className="text-xs text-muted-foreground">Terms and inclusions</p>
          <p className="text-sm whitespace-pre-wrap">{quote.settings.terms}</p>
        </Card>
      ) : null}

      {dialog.kind === "add" || dialog.kind === "edit" ? (
        <LineDialog
          key={dialog.kind === "edit" ? dialog.line._id : `add-${dialog.section}`}
          open
          onOpenChange={(open) => !open && close()}
          bookingId={bookingId}
          section={dialog.kind === "add" ? dialog.section : dialog.line.section}
          line={dialog.kind === "edit" ? dialog.line : undefined}
          pax={quote.pax}
          currency={quote.currency}
          defaultMarkup={quote.defaultMarkup}
        />
      ) : null}
      {dialog.kind === "settings" ? (
        <SettingsDialog
          open
          onOpenChange={(open) => !open && close()}
          bookingId={bookingId}
          pax={quote.pax}
          settings={quote.settings}
        />
      ) : null}
    </div>
  );
}
