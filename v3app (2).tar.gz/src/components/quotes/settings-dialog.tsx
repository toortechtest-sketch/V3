import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";

export type QuoteSettings = {
  freePlaces: number;
  targetMarginPercent?: number;
  validUntil?: string;
  terms?: string;
};

function makeSchema(pax: number) {
  return z.object({
    freePlaces: z
      .string()
      .refine((v) => Number.isInteger(Number(v)) && Number(v) >= 0, { message: "Whole number" })
      .refine((v) => Number(v) < pax, { message: "At least one traveller has to pay" }),
    targetMarginPercent: z
      .string()
      .refine((v) => v === "" || (Number(v) >= 0 && Number(v) <= 99), { message: "0 to 99" }),
    validUntil: z.string(),
    terms: z.string().trim().max(10000),
  });
}

type FormValues = z.infer<ReturnType<typeof makeSchema>>;

export default function SettingsDialog({
  open,
  onOpenChange,
  bookingId,
  pax,
  settings,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  pax: number;
  settings: QuoteSettings;
}) {
  const save = useMutation(api.quotes.saveSettings);
  const [saving, setSaving] = useState(false);
  const form = useForm<FormValues>({
    resolver: zodResolver(makeSchema(pax)),
    defaultValues: {
      freePlaces: String(settings.freePlaces),
      targetMarginPercent:
        settings.targetMarginPercent === undefined ? "" : String(settings.targetMarginPercent),
      validUntil: settings.validUntil ?? "",
      terms: settings.terms ?? "",
    },
  });

  const onSubmit = async (v: FormValues) => {
    setSaving(true);
    try {
      await save({
        bookingId,
        freePlaces: Number(v.freePlaces),
        targetMarginPercent: v.targetMarginPercent === "" ? undefined : Number(v.targetMarginPercent),
        validUntil: v.validUntil || undefined,
        terms: v.terms || undefined,
      });
      toast.success("Quote settings saved");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const field = (
    name: "freePlaces" | "targetMarginPercent" | "validUntil",
    label: string,
    placeholder: string,
    type: string,
  ) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field: f }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input type={type} placeholder={placeholder} {...f} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Quote settings</DialogTitle>
          <DialogDescription>
            Default markup and currency come from the booking brief.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            {field("freePlaces", "Free places", "1", "number")}
            {field("targetMarginPercent", "Target margin %", "15", "number")}
            <div className="sm:col-span-2">{field("validUntil", "Offer valid until", "", "date")}</div>
            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="terms"
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Terms and inclusions</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={4}
                        placeholder="Prices include VAT. 30% deposit on confirmation, balance 30 days before arrival."
                        {...f}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                Save
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
