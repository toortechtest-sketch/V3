import { useMutation } from "convex/react";
import type { FunctionReturnType } from "convex/server";
import { formatDistanceToNow, parseISO } from "date-fns";
import { toast } from "sonner";
import { CheckCircle2, Clock, MessageSquare, RotateCcw, XCircle } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";

type Link = FunctionReturnType<typeof api.shareLinks.list>[number];
type ClientRequest = Link["clientRequests"][number];

const ago = (iso: string) => formatDistanceToNow(parseISO(iso), { addSuffix: true });

function Outcome({ ok, children }: { ok: boolean; children: React.ReactNode }) {
  return (
    <div
      className={cn(
        "ml-12 rounded-lg border p-3 text-sm",
        ok ? "border-emerald-500/30 bg-emerald-500/5" : "border-destructive/30 bg-destructive/5",
      )}
    >
      {children}
    </div>
  );
}

function OfferResponse({ response }: { response: NonNullable<Link["response"]> }) {
  const accepted = response.decision === "accepted";
  return (
    <Outcome ok={accepted}>
      <p className="flex items-center gap-2 font-medium">
        {accepted ? (
          <CheckCircle2 className="size-4 text-emerald-600 dark:text-emerald-400" />
        ) : (
          <XCircle className="size-4 text-destructive" />
        )}
        {response.name} {accepted ? "accepted the offer" : "declined the offer"}
        <span className="font-normal text-muted-foreground">· {ago(response.respondedAt)}</span>
      </p>
      {response.message ? (
        <p className="mt-1 whitespace-pre-wrap text-muted-foreground">{response.message}</p>
      ) : null}
    </Outcome>
  );
}

function HotelOutcome({ change }: { change: NonNullable<Link["change"]> }) {
  if (change.status === "pending") {
    return (
      <p className="ml-12 flex items-center gap-1.5 text-xs text-[#8a6400] dark:text-[#FFB800]">
        <Clock className="size-3.5" /> Waiting on {change.supplierName} · {change.description}
      </p>
    );
  }
  if (change.status === "withdrawn") {
    return <p className="ml-12 text-xs text-muted-foreground">Change withdrawn · {change.description}</p>;
  }
  const approved = change.status === "approved";
  return (
    <Outcome ok={approved}>
      <p className="flex items-center gap-2 font-medium">
        {approved ? (
          <CheckCircle2 className="size-4 text-emerald-600 dark:text-emerald-400" />
        ) : (
          <XCircle className="size-4 text-destructive" />
        )}
        {change.supplierName} {approved ? "approved" : "declined"} the change
      </p>
      <p className="mt-1 text-muted-foreground">
        {change.description}
        {change.responseNote ? ` · ${change.responseNote}` : ""}
      </p>
    </Outcome>
  );
}

function RequestRow({ request }: { request: ClientRequest }) {
  const setHandled = useMutation(api.shareLinks.setRequestHandled);
  const handled = request.handledAt !== undefined;
  const toggle = () =>
    setHandled({ id: request._id, handled: !handled }).then(
      () => toast.success(handled ? "Reopened" : "Marked as handled"),
      (error: unknown) => toast.error(errorMessage(error)),
    );
  return (
    <li
      className={cn(
        "rounded-lg border p-3 text-sm",
        handled ? "bg-muted/40" : "border-[#FFB800]/40 bg-[#FFB800]/10",
      )}
    >
      <div className="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
        <div className="min-w-0 space-y-1">
          <p className="flex flex-wrap items-center gap-x-2 font-medium">
            <MessageSquare className="size-4 text-primary" /> {request.name} asked for a change
            <span className="font-normal text-muted-foreground">· {ago(request.createdAt)}</span>
          </p>
          <p className="break-words whitespace-pre-wrap text-muted-foreground">{request.message}</p>
        </div>
        <Button size="sm" variant={handled ? "ghost" : "secondary"} className="shrink-0 cursor-pointer" onClick={() => void toggle()}>
          {handled ? <RotateCcw className="size-4" /> : <CheckCircle2 className="size-4" />}
          {handled ? "Reopen" : "Mark handled"}
        </Button>
      </div>
    </li>
  );
}

/** What the client or supplier did through a link. */
export default function LinkActivity({ link }: { link: Link }) {
  if (link.response) return <OfferResponse response={link.response} />;
  if (link.change) return <HotelOutcome change={link.change} />;
  if (link.clientRequests.length === 0) return null;
  return (
    <ul className="ml-12 space-y-2">
      {link.clientRequests.map((r) => (
        <RequestRow key={r._id} request={r} />
      ))}
    </ul>
  );
}
