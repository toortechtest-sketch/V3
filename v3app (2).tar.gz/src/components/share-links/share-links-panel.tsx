import { useState } from "react";
import { useAction, useMutation, useQuery } from "convex/react";
import { format, formatDistanceToNow, parseISO } from "date-fns";
import { toast } from "sonner";
import {
  Ban,
  Copy,
  ExternalLink,
  Eye,
  Link2,
  Plus,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent } from "@/components/ui/card.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Label } from "@/components/ui/label.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { errorMessage } from "@/lib/errors.ts";
import {
  CLIENT_LINK_KINDS,
  LINK_DURATIONS,
  LINK_KIND_META,
  copyShareLink,
  shareUrl,
  type ShareLinkKind,
} from "@/lib/share-links.ts";
import { cn } from "@/lib/utils.ts";
import LinkActivity from "./link-activity.tsx";

type Link = NonNullable<ReturnType<typeof useLinks>>[number];

function useLinks(bookingId: Id<"bookings">) {
  return useQuery(api.shareLinks.list, { bookingId });
}

async function copyLink(token: string) {
  if (await copyShareLink(token)) toast.success("Link copied");
  else toast.error("Couldn't copy. Open the link and copy it from the address bar.");
}

function CreateDialog({
  bookingId,
  open,
  onOpenChange,
}: {
  bookingId: Id<"bookings">;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const create = useAction(api.shareLinks.create);
  const [kind, setKind] = useState<ShareLinkKind>("offer");
  const [days, setDays] = useState<number>(14);
  const [busy, setBusy] = useState(false);

  const submit = async () => {
    setBusy(true);
    try {
      const { token } = await create({ bookingId, kind, days });
      await copyLink(token);
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>New client link</DialogTitle>
          <DialogDescription>
            Anyone with the link can open it until it expires. Costs, margins
            and internal notes are never shown.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-5">
          <div className="space-y-2">
            <Label>What to share</Label>
            <div className="grid gap-2 sm:grid-cols-3">
              {CLIENT_LINK_KINDS.map((k) => {
                const meta = LINK_KIND_META[k];
                return (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setKind(k)}
                    className={cn(
                      "cursor-pointer rounded-lg border p-3 text-left transition-colors",
                      kind === k ? "border-primary bg-primary/5" : "hover:bg-muted",
                    )}
                  >
                    <span className="flex items-center gap-2 font-medium">
                      <meta.icon className="size-4 text-primary" /> {meta.label}
                    </span>
                    <span className="mt-1 block text-xs text-muted-foreground">
                      {meta.hint}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
          <div className="space-y-2">
            <Label>Expires after</Label>
            <div className="flex flex-wrap gap-2">
              {LINK_DURATIONS.map((d) => (
                <button
                  key={d.days}
                  type="button"
                  onClick={() => setDays(d.days)}
                  className={cn(
                    "cursor-pointer rounded-full border px-3 py-1 text-sm transition-colors",
                    days === d.days
                      ? "border-primary bg-primary text-primary-foreground"
                      : "hover:bg-muted",
                  )}
                >
                  {d.label}
                </button>
              ))}
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" className="cursor-pointer" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button className="cursor-pointer" disabled={busy} onClick={submit}>
            {busy ? <Spinner /> : <Link2 className="size-4" />} Create and copy
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

const STATE_STYLE: Record<Link["state"], string> = {
  active: "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400",
  expired: "bg-muted text-muted-foreground",
  revoked: "bg-destructive/10 text-destructive",
};

function LinkRow({ link }: { link: Link }) {
  const revoke = useMutation(api.shareLinks.revoke);
  const meta = LINK_KIND_META[link.kind];
  const active = link.state === "active";
  const expires = parseISO(link.expiresAt);

  const onRevoke = async () => {
    try {
      await revoke({ id: link._id });
      toast.success("Link turned off");
    } catch (error) {
      toast.error(errorMessage(error));
    }
  };

  return (
    <div className="space-y-3 py-4 first:pt-0 last:pb-0">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div className="flex min-w-0 items-start gap-3">
          <div className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
            <meta.icon className="size-4" />
          </div>
          <div className="min-w-0 space-y-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="font-medium">{meta.label}</p>
              <span
                className={cn(
                  "rounded-full px-2 py-0.5 text-xs font-medium capitalize",
                  STATE_STYLE[link.state],
                )}
              >
                {link.state}
              </span>
            </div>
            <p className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
              <span>
                {active ? "Expires" : "Expired"} {format(expires, "d MMM yyyy, HH:mm")}
              </span>
              <span className="inline-flex items-center gap-1">
                <Eye className="size-3" />
                {link.viewCount === 0
                  ? "Not opened yet"
                  : `${link.viewCount} view${link.viewCount === 1 ? "" : "s"}`}
                {link.lastViewedAt
                  ? `, last ${formatDistanceToNow(parseISO(link.lastViewedAt), { addSuffix: true })}`
                  : ""}
              </span>
            </p>
          </div>
        </div>
        {active ? (
          <div className="flex shrink-0 gap-1">
            <Button size="sm" variant="secondary" className="cursor-pointer" onClick={() => copyLink(link.token)}>
              <Copy className="size-4" /> Copy
            </Button>
            <Button size="sm" variant="ghost" asChild className="cursor-pointer">
              <a href={shareUrl(link.token)} target="_blank" rel="noreferrer" aria-label="Open link">
                <ExternalLink className="size-4" />
              </a>
            </Button>
            <Button
              size="sm"
              variant="ghost"
              className="cursor-pointer text-destructive hover:text-destructive"
              onClick={onRevoke}
              aria-label="Turn off link"
            >
              <Ban className="size-4" />
            </Button>
          </div>
        ) : null}
      </div>
      <LinkActivity link={link} />
    </div>
  );
}

export default function ShareLinksPanel({ bookingId }: { bookingId: Id<"bookings"> }) {
  const links = useLinks(bookingId);
  const [creating, setCreating] = useState(false);

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-sm text-muted-foreground">
          Secure links for the client. Each one expires and can be turned off at any time.
        </p>
        <Button className="cursor-pointer" onClick={() => setCreating(true)}>
          <Plus className="size-4" /> New link
        </Button>
      </div>

      {links === undefined ? (
        <Card>
          <CardContent className="space-y-4">
            {Array.from({ length: 3 }).map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </CardContent>
        </Card>
      ) : links.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Link2 />
            </EmptyMedia>
            <EmptyTitle>No client links yet</EmptyTitle>
            <EmptyDescription>
              Share the offer for the client to accept, or the itinerary once
              it's confirmed.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" className="cursor-pointer" onClick={() => setCreating(true)}>
              Create a link
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <Card>
          <CardContent className="divide-y">
            {links.map((link) => (
              <LinkRow key={link._id} link={link} />
            ))}
          </CardContent>
        </Card>
      )}

      <CreateDialog bookingId={bookingId} open={creating} onOpenChange={setCreating} />
    </div>
  );
}
