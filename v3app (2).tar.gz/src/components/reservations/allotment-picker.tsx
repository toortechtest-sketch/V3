import { useEffect, useMemo, useState } from "react";
import { useQuery } from "convex/react";
import { CalendarClock, PackageSearch, TriangleAlert } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { hotelNights } from "@/convex/lib/allotmentEngine.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Switch } from "@/components/ui/switch.tsx";
import { formatInZone, utcMsToZonedParts, zonedTimeToUtcMs } from "@/lib/allotments.ts";
import type { SupplierCategory } from "@/lib/suppliers.ts";
import { cn } from "@/lib/utils.ts";

export type AllotmentSelection = {
  poolId: Id<"allotmentPools">;
  sessionKey?: string;
  holdUntil?: number;
};

/** Resolves the service keys a selected pool needs for the current dates. */
function serviceKeysFor(
  kind: "hotel_night" | "session" | undefined,
  startDate: string,
  endDate: string | undefined,
  sessionKey: string,
): string[] {
  if (kind === "hotel_night") {
    if (!startDate || !endDate) return [];
    try {
      return hotelNights(startDate, endDate);
    } catch {
      return [];
    }
  }
  return sessionKey ? [sessionKey] : [];
}

/**
 * Lets staff link a reservation to a contracted-allotment pool instead of
 * booking it on request. Shows live remaining capacity and the release
 * deadline in the pool's own timezone. Picking a sold-out or missing date
 * disables the quantity so the mutation (which re-checks everything) is the
 * only thing that ever confirms stock, never this preview.
 */
export default function AllotmentPicker({
  supplierId,
  category,
  startDate,
  endDate,
  units,
  showHoldUntil,
  value,
  onChange,
  onBlockedChange,
}: {
  supplierId: Id<"suppliers"> | undefined;
  category: SupplierCategory;
  startDate: string;
  endDate: string | undefined;
  units: number;
  /** Show the hold-expiry control; only relevant while the reservation is an option. */
  showHoldUntil: boolean;
  value: AllotmentSelection | null;
  onChange: (next: AllotmentSelection | null) => void;
  /** Reports whether the current selection has no stock, so the dialog can block submit as a UX nicety (the mutation remains the real source of truth). */
  onBlockedChange?: (blocked: boolean) => void;
}) {
  const [sessionKey, setSessionKey] = useState(value?.sessionKey ?? "");
  const pools = useQuery(
    api.suppliers.allotmentAvailability.listSellablePools,
    supplierId ? { supplierId, category } : "skip",
  );
  const selectedPool = pools?.find((p) => p._id === value?.poolId);

  const sessionSlots = useQuery(
    api.suppliers.allotmentAvailability.listSellableSlots,
    selectedPool?.kind === "session" ? { poolId: selectedPool._id } : "skip",
  );

  const serviceKeys = useMemo(
    () => serviceKeysFor(selectedPool?.kind, startDate, endDate, sessionKey),
    [selectedPool?.kind, startDate, endDate, sessionKey],
  );
  const preview = useQuery(
    api.suppliers.allotmentAvailability.previewAvailability,
    selectedPool && serviceKeys.length > 0 ? { poolId: selectedPool._id, serviceKeys } : "skip",
  );

  // Missing means no slot exists at all for a required date; found-but-zero
  // means a real slot that's simply sold out. Both block confirming stock.
  const missing = serviceKeys.filter((k) => !preview?.some((p) => p.serviceKey === k));
  const minAvailable = preview && preview.length > 0 ? Math.min(...preview.map((p) => p.available)) : undefined;
  const insufficient = minAvailable !== undefined && minAvailable < units;
  const blocked = value !== null && (missing.length > 0 || insufficient);

  useEffect(() => {
    onBlockedChange?.(blocked);
  }, [blocked, onBlockedChange]);

  if (supplierId === undefined) {
    return (
      <p className="rounded-lg border bg-muted/40 p-3 text-sm text-muted-foreground">
        Link a supplier above to check for contracted allotments.
      </p>
    );
  }
  if (pools === undefined) return <Skeleton className="h-20 w-full" />;
  if (pools.length === 0) {
    return (
      <p className="rounded-lg border bg-muted/40 p-3 text-sm text-muted-foreground">
        This supplier has no contracted allotment for {category} yet. This reservation
        will be tracked as on-request.
      </p>
    );
  }

  const pickPool = (poolId: string) => {
    if (poolId === "none") {
      onChange(null);
      return;
    }
    setSessionKey("");
    onChange({ poolId: poolId as Id<"allotmentPools"> });
  };

  const pickSession = (key: string) => {
    setSessionKey(key);
    if (value) onChange({ ...value, sessionKey: key });
  };

  return (
    <div className="space-y-3 rounded-lg border p-3">
      <div className="flex items-center justify-between gap-2">
        <Label className="flex items-center gap-1.5 text-sm">
          <PackageSearch className="size-4" /> Contracted allotment
        </Label>
        <Switch
          className="cursor-pointer"
          checked={value !== null}
          onCheckedChange={(checked) => {
            if (!checked) {
              onChange(null);
              setSessionKey("");
            } else {
              onChange({ poolId: pools[0]._id, sessionKey: pools[0].kind === "session" ? "" : undefined });
            }
          }}
        />
      </div>
      {value ? (
        <div className="space-y-3">
          <Select value={value.poolId} onValueChange={pickPool}>
            <SelectTrigger className="w-full cursor-pointer">
              <SelectValue placeholder="Choose an allotment" />
            </SelectTrigger>
            <SelectContent>
              {pools.map((p) => (
                <SelectItem key={p._id} value={p._id} className="cursor-pointer">
                  {p.name} ({p.unit}s)
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          {selectedPool?.kind === "session" ? (
            <div className="space-y-1.5">
              <Label className="text-xs text-muted-foreground">Departure</Label>
              {sessionSlots === undefined ? (
                <Skeleton className="h-9 w-full" />
              ) : sessionSlots.length === 0 ? (
                <p className="text-sm text-muted-foreground">No sellable dates on this allotment yet.</p>
              ) : (
                <Select value={sessionKey} onValueChange={pickSession}>
                  <SelectTrigger className="w-full cursor-pointer">
                    <SelectValue placeholder="Choose a dated departure" />
                  </SelectTrigger>
                  <SelectContent>
                    {sessionSlots.map((s) => (
                      <SelectItem key={s.serviceKey} value={s.serviceKey} className="cursor-pointer">
                        {s.serviceKey} — {s.available} available
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
            </div>
          ) : null}

          {selectedPool?.kind === "hotel_night" && (!startDate || !endDate) ? (
            <p className="text-xs text-muted-foreground">Pick the from and to dates to check availability.</p>
          ) : null}

          {serviceKeys.length > 0 && selectedPool ? (
            preview === undefined ? (
              <Skeleton className="h-16 w-full" />
            ) : (
              <div className="space-y-1.5">
                {preview.map((p) => (
                  <div
                    key={p.serviceKey}
                    className={cn(
                      "flex items-center justify-between gap-2 rounded-md px-2 py-1 text-xs",
                      p.available < units ? "bg-destructive/10 text-destructive" : "bg-muted/60",
                    )}
                  >
                    <span className="flex items-center gap-1">
                      <CalendarClock className="size-3" /> {p.serviceDate}
                    </span>
                    <span>{p.available} available</span>
                    <span className="text-muted-foreground">
                      Releases {formatInZone(p.releaseAt, selectedPool.timezone)}
                    </span>
                  </div>
                ))}
                {missing.map((key) => (
                  <div
                    key={key}
                    className="flex items-center justify-between gap-2 rounded-md bg-destructive/10 px-2 py-1 text-xs text-destructive"
                  >
                    <span>{key}</span>
                    <span>No allotment for this date</span>
                  </div>
                ))}
              </div>
            )
          ) : null}

          {blocked ? (
            <Badge className="flex w-fit items-center gap-1 border-0 bg-destructive/15 text-destructive">
              <TriangleAlert className="size-3" />
              Not enough contracted stock for {units} {units === 1 ? "unit" : "units"}
            </Badge>
          ) : null}

          {showHoldUntil && selectedPool ? (
            <HoldUntilField
              timezone={selectedPool.timezone}
              earliestReleaseAt={preview && preview.length > 0 ? Math.min(...preview.map((p) => p.releaseAt)) : undefined}
              holdUntil={value.holdUntil}
              onChange={(holdUntil) => onChange({ ...value, holdUntil })}
            />
          ) : null}
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">
          Off: this reservation is tracked as on-request. Turn on to hold or confirm
          against contracted stock instead.
        </p>
      )}
    </div>
  );
}

/**
 * Lets staff set when the held stock is released back to the pool if the
 * option isn't confirmed in time. Entered and displayed in the pool's own
 * timezone (not the staff member's), then converted to a UTC instant. Must
 * never be later than the slot's own release deadline, since the engine
 * releases held stock at `releaseAt` regardless of what this says.
 */
function HoldUntilField({
  timezone,
  earliestReleaseAt,
  holdUntil,
  onChange,
}: {
  timezone: string;
  earliestReleaseAt: number | undefined;
  holdUntil: number | undefined;
  onChange: (holdUntil: number | undefined) => void;
}) {
  const parts = holdUntil !== undefined ? utcMsToZonedParts(holdUntil, timezone) : undefined;
  const pastRelease = holdUntil !== undefined && earliestReleaseAt !== undefined && holdUntil > earliestReleaseAt;

  const handleChange = (raw: string) => {
    if (!raw) {
      onChange(undefined);
      return;
    }
    const [datePart, timePart] = raw.split("T");
    if (!datePart || !timePart) return;
    onChange(zonedTimeToUtcMs(datePart, timePart, timezone));
  };

  return (
    <div className="space-y-1.5">
      <Label className="text-xs text-muted-foreground">
        Hold expires ({timezone})
      </Label>
      <Input
        type="datetime-local"
        value={parts ? `${parts.date}T${parts.time}` : ""}
        onChange={(e) => handleChange(e.target.value)}
        max={earliestReleaseAt !== undefined ? `${utcMsToZonedParts(earliestReleaseAt, timezone).date}T${utcMsToZonedParts(earliestReleaseAt, timezone).time}` : undefined}
      />
      {pastRelease ? (
        <p className="flex items-center gap-1 text-xs text-destructive">
          <TriangleAlert className="size-3" /> Must be on or before the allotment's release deadline.
        </p>
      ) : null}
    </div>
  );
}
