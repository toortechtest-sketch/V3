import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { BOARD_LABELS, BOARD_TYPES, type BoardType } from "@/lib/suppliers.ts";
import type { ReservationRow } from "./reservation-card.tsx";

type Kind = "change" | "cancel";

/** Asks the supplier to approve a change to a confirmed reservation. */
export function RequestChangeDialog({
  reservation,
  onOpenChange,
}: {
  reservation: ReservationRow;
  onOpenChange: (open: boolean) => void;
}) {
  const request = useMutation(api.reservations.requestChange);
  const [kind, setKind] = useState<Kind>("change");
  const [units, setUnits] = useState(String(reservation.units));
  const [startDate, setStartDate] = useState(reservation.startDate);
  const [endDate, setEndDate] = useState(reservation.endDate ?? "");
  const [description, setDescription] = useState(reservation.description);
  const [board, setBoard] = useState<BoardType | "none">(reservation.board ?? "none");
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    const unitCount = Number(units);
    if (kind === "change" && (!Number.isInteger(unitCount) || unitCount < 1)) {
      toast.error("Quantity must be a whole number of at least 1.");
      return;
    }
    setSaving(true);
    try {
      await request({
        reservationId: reservation._id,
        kind,
        changes:
          kind === "cancel"
            ? {}
            : {
                units: unitCount,
                startDate,
                endDate: endDate || undefined,
                description,
                board: board === "none" ? undefined : board,
              },
        message: message || undefined,
      });
      toast.success("Change request saved. Send it to the supplier for approval.");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const unitLabel = reservation.unitLabel ?? "units";

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Request a change</DialogTitle>
          <DialogDescription>
            {reservation.supplierName} has confirmed this reservation. Nothing changes until they
            approve.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <ToggleGroup
            type="single"
            variant="outline"
            value={kind}
            onValueChange={(v) => v && setKind(v as Kind)}
            className="w-full"
          >
            <ToggleGroupItem value="change" className="flex-1 cursor-pointer">
              Change details
            </ToggleGroupItem>
            <ToggleGroupItem value="cancel" className="flex-1 cursor-pointer">
              Cancel reservation
            </ToggleGroupItem>
          </ToggleGroup>

          {kind === "change" ? (
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="rc-units">Quantity ({unitLabel})</Label>
                <Input id="rc-units" type="number" min={1} value={units} onChange={(e) => setUnits(e.target.value)} />
              </div>
              {reservation.type === "hotel" ? (
                <div className="space-y-2">
                  <Label>Board</Label>
                  <Select value={board} onValueChange={(v) => setBoard(v as BoardType | "none")}>
                    <SelectTrigger className="w-full cursor-pointer">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {reservation.board ? null : (
                        <SelectItem value="none" className="cursor-pointer">Not set</SelectItem>
                      )}
                      {BOARD_TYPES.map((b) => (
                        <SelectItem key={b} value={b} className="cursor-pointer">
                          {BOARD_LABELS[b]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ) : (
                <div className="hidden sm:block" />
              )}
              <div className="space-y-2">
                <Label htmlFor="rc-start">From</Label>
                <Input id="rc-start" type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label htmlFor="rc-end">To</Label>
                <Input id="rc-end" type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="rc-desc">Service</Label>
                <Input id="rc-desc" value={description} onChange={(e) => setDescription(e.target.value)} />
              </div>
            </div>
          ) : (
            <p className="rounded-md bg-destructive/8 px-3 py-2 text-sm text-destructive">
              The reservation is cancelled only once {reservation.supplierName} agrees, so check
              their cancellation terms first.
            </p>
          )}

          <div className="space-y-2">
            <Label htmlFor="rc-msg">Message for the supplier</Label>
            <Textarea
              id="rc-msg"
              rows={3}
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Two more rooms for late registrations, same rate please"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" className="cursor-pointer" onClick={() => onOpenChange(false)}>
            Back
          </Button>
          <Button
            variant={kind === "cancel" ? "destructive" : "default"}
            disabled={saving}
            className="cursor-pointer"
            onClick={() => void submit()}
          >
            {saving ? <Spinner /> : null}
            Save request
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

/** Records the supplier's answer. Approving applies the change. */
export function RecordResponseDialog({
  changeId,
  supplierName,
  onOpenChange,
}: {
  changeId: Id<"reservationChanges">;
  supplierName: string;
  onOpenChange: (open: boolean) => void;
}) {
  const record = useMutation(api.reservations.recordResponse);
  const [decision, setDecision] = useState<"approved" | "declined">("approved");
  const [note, setNote] = useState("");
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    setSaving(true);
    try {
      await record({ changeId, decision, responseNote: note || undefined });
      toast.success(decision === "approved" ? "Approved and applied" : "Marked as declined");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Record {supplierName}'s answer</DialogTitle>
          <DialogDescription>
            Approving updates the reservation straight away. Declining keeps it as it is.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <ToggleGroup
            type="single"
            variant="outline"
            value={decision}
            onValueChange={(v) => v && setDecision(v as "approved" | "declined")}
            className="w-full"
          >
            <ToggleGroupItem value="approved" className="flex-1 cursor-pointer">
              Approved
            </ToggleGroupItem>
            <ToggleGroupItem value="declined" className="flex-1 cursor-pointer">
              Declined
            </ToggleGroupItem>
          </ToggleGroup>
          <div className="space-y-2">
            <Label htmlFor="rr-note">How did they answer?</Label>
            <Input
              id="rr-note"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Maria Lopez, by email on 3 Oct"
            />
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" className="cursor-pointer" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button disabled={saving} className="cursor-pointer" onClick={() => void submit()}>
            {saving ? <Spinner /> : null}
            Save answer
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
