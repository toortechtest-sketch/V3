import { useState } from "react";
import { useAction } from "convex/react";
import { toast } from "sonner";
import { Link2 } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { copyShareLink, shareUrl } from "@/lib/share-links.ts";

const HOTEL_LINK_DAYS = 14;

/** Creates (or reuses) a link the supplier opens to approve or decline the change. */
export default function HotelLinkButton({
  bookingId,
  changeId,
}: {
  bookingId: Id<"bookings">;
  changeId: Id<"reservationChanges">;
}) {
  const create = useAction(api.shareLinks.create);
  const [busy, setBusy] = useState(false);

  const onClick = async () => {
    setBusy(true);
    try {
      const { token } = await create({ bookingId, kind: "hotel_response", days: HOTEL_LINK_DAYS, changeId });
      if (await copyShareLink(token)) {
        toast.success("Response link copied", {
          description: "Paste it in your email. The supplier's answer updates the reservation.",
        });
      } else {
        window.open(shareUrl(token), "_blank", "noreferrer");
      }
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  return (
    <Button size="sm" variant="secondary" className="cursor-pointer" disabled={busy} onClick={() => void onClick()}>
      {busy ? <Spinner /> : <Link2 className="size-4" />} Copy response link
    </Button>
  );
}
