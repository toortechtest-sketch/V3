import { Link } from "react-router-dom";
import { useMutation } from "convex/react";
import type { FunctionReturnType } from "convex/server";
import { format, formatDistanceToNow, parseISO } from "date-fns";
import { toast } from "sonner";
import {
  ArrowRight,
  CalendarDays,
  Clock,
  History,
  Mail,
  MoreHorizontal,
  Pencil,
  ShieldCheck,
  Trash2,
  Undo2,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { formatMoney } from "@/lib/quotes.ts";
import {
  RESERVATION_STATUSES,
  RESERVATION_STATUS_META,
  dateSpan,
  day,
  describeChange,
  type ReservationStatus,
} from "@/lib/reservations.ts";
import { BOARD_LABELS, CATEGORY_META } from "@/lib/suppliers.ts";
import { cn } from "@/lib/utils.ts";
import HotelLinkButton from "./hotel-link-button.tsx";

export type ReservationRow = FunctionReturnType<typeof api.reservations.list>["reservations"][number];
type Change = ReservationRow["history"][number];

function supplierEmailHref(r: ReservationRow, change: Change, reference: string) {
  const email = r.supplier?.email;
  if (!email) return null;
  const unitLabel = r.unitLabel ?? "units";
  const lines = describeChange(change, unitLabel);
  const body = [
    `Hello${r.supplier?.contactName ? ` ${r.supplier.contactName}` : ""},`,
    "",
    `For our confirmed reservation${r.supplierRef ? ` (your ref ${r.supplierRef})` : ""}, ${r.description}, ${dateSpan(r.startDate, r.endDate)}, we would like to request:`,
    ...lines.map((l) => `- ${l}`),
    ...(change.message ? ["", change.message] : []),
    "",
    "Could you please confirm whether you can approve this change?",
    "",
    "Thank you",
  ].join("\n");
  const subject = `Change request: ${reference} ${r.description}`;
  return `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

const CHANGE_STATUS_LABEL: Record<Change["status"], string> = {
  pending: "Waiting on supplier",
  approved: "Approved",
  declined: "Declined",
  withdrawn: "Withdrawn",
};

function PendingBanner({
  reservation,
  change,
  reference,
  onRecord,
}: {
  reservation: ReservationRow;
  change: Change;
  reference: string;
  onRecord: () => void;
}) {
  const withdraw = useMutation(api.reservations.withdrawChange);
  const href = supplierEmailHref(reservation, change, reference);
  return (
    <div className="space-y-3 border-t bg-[#FFB800]/10 px-4 py-3 sm:px-5">
      <div className="flex items-start gap-2">
        <Clock className="mt-0.5 size-4 shrink-0 text-[#8a6400] dark:text-[#FFB800]" />
        <div className="min-w-0 flex-1 space-y-1">
          <p className="text-sm font-medium">
            Change waiting on {reservation.supplierName}
            <span className="font-normal text-muted-foreground">
              {" "}· asked by {change.requestedByName}{" "}
              {formatDistanceToNow(parseISO(change.requestedAt), { addSuffix: true })}
            </span>
          </p>
          <ul className="space-y-0.5 text-sm">
            {describeChange(change, reservation.unitLabel ?? "units").map((line) => (
              <li key={line} className="flex items-center gap-1.5">
                <ArrowRight className="size-3 shrink-0 text-muted-foreground" />
                <span className="break-words">{line}</span>
              </li>
            ))}
          </ul>
          {change.message ? (
            <p className="text-sm whitespace-pre-wrap text-muted-foreground">"{change.message}"</p>
          ) : null}
        </div>
      </div>
      <div className="flex flex-wrap gap-2">
        <Button size="sm" className="cursor-pointer" onClick={onRecord}>
          <ShieldCheck className="size-4" /> Record answer
        </Button>
        {href ? (
          <Button size="sm" variant="secondary" asChild className="cursor-pointer">
            <a href={href}>
              <Mail className="size-4" /> Email supplier
            </a>
          </Button>
        ) : null}
        <HotelLinkButton bookingId={reservation.bookingId} changeId={change._id} />
        <Button
          size="sm"
          variant="ghost"
          className="cursor-pointer"
          onClick={() => {
            withdraw({ changeId: change._id }).then(
              () => toast.success("Request withdrawn"),
              (error: unknown) => toast.error(errorMessage(error)),
            );
          }}
        >
          <Undo2 className="size-4" /> Withdraw
        </Button>
      </div>
    </div>
  );
}

function ChangeHistory({ reservation }: { reservation: ReservationRow }) {
  const past = reservation.history.filter((c) => c.status !== "pending");
  if (past.length === 0) return null;
  return (
    <Collapsible className="border-t px-4 sm:px-5">
      <CollapsibleTrigger className="flex w-full cursor-pointer items-center gap-2 py-2.5 text-xs text-muted-foreground hover:text-foreground">
        <History className="size-3.5" /> {past.length} past change request{past.length === 1 ? "" : "s"}
      </CollapsibleTrigger>
      <CollapsibleContent>
        <ol className="space-y-3 pb-3">
          {past.map((c) => (
            <li key={c._id} className="text-sm">
              <p className="flex flex-wrap items-center gap-x-2 text-xs text-muted-foreground">
                <span
                  className={cn(
                    "font-medium",
                    c.status === "approved" && "text-emerald-700 dark:text-emerald-400",
                    c.status === "declined" && "text-destructive",
                  )}
                >
                  {CHANGE_STATUS_LABEL[c.status]}
                </span>
                <span>{format(parseISO(c.respondedAt ?? c.requestedAt), "d MMM yyyy, HH:mm")}</span>
                <span>· asked by {c.requestedByName}</span>
              </p>
              <p className="break-words">{describeChange(c, reservation.unitLabel ?? "units").join(" · ")}</p>
              {c.responseNote ? <p className="text-xs text-muted-foreground">{c.responseNote}</p> : null}
            </li>
          ))}
        </ol>
      </CollapsibleContent>
    </Collapsible>
  );
}

export default function ReservationCard({
  reservation: r,
  currency,
  reference,
  onEdit,
  onRequestChange,
  onRecordResponse,
}: {
  reservation: ReservationRow;
  currency: string;
  reference: string;
  onEdit: () => void;
  onRequestChange: () => void;
  onRecordResponse: (change: Change) => void;
}) {
  const setStatus = useMutation(api.reservations.setStatus);
  const remove = useMutation(api.reservations.remove);
  const meta = CATEGORY_META[r.type];
  const status = RESERVATION_STATUS_META[r.status];
  const locked = r.status === "confirmed";
  const unitLabel = r.unitLabel ?? "units";
  const run = (p: Promise<unknown>, done: string) =>
    p.then(
      () => toast.success(done),
      (error: unknown) => toast.error(errorMessage(error)),
    );

  return (
    <Card className={cn("gap-0 overflow-hidden py-0", r.status === "cancelled" && "opacity-70")}>
      <div className="flex gap-3 px-4 py-4 sm:px-5">
        <div className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
          <meta.icon className="size-5" />
        </div>
        <div className="min-w-0 flex-1 space-y-1.5">
          <div className="flex flex-wrap items-center gap-2">
            <span className={cn("rounded-full px-2 py-0.5 text-xs font-medium", status.badge)}>
              {status.label}
            </span>
            {locked ? (
              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                <ShieldCheck className="size-3.5" /> Changes need supplier approval
              </span>
            ) : null}
            {r.status === "option" && r.optionUntil ? (
              <span className="text-xs text-muted-foreground">Held until {day(r.optionUntil)}</span>
            ) : null}
          </div>
          <p className="font-medium break-words">
            {r.supplier ? (
              <Link to={`/suppliers/${r.supplier._id}`} className="cursor-pointer hover:text-primary hover:underline">
                {r.supplierName}
              </Link>
            ) : (
              r.supplierName
            )}
            <span className="font-normal text-muted-foreground"> · {r.description}</span>
          </p>
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <CalendarDays className="size-3.5" /> {dateSpan(r.startDate, r.endDate)}
            </span>
            <span className="font-medium text-foreground">
              {r.units} {unitLabel}
            </span>
            {r.board ? <span>{BOARD_LABELS[r.board]}</span> : null}
            {r.supplierRef ? <span className="font-mono">Ref {r.supplierRef}</span> : null}
            {r.costPerUnit !== undefined ? (
              <span>
                Cost {formatMoney(r.costPerUnit * r.units, currency)}
                {r.sellPerUnit !== undefined ? ` · Sell ${formatMoney(r.sellPerUnit * r.units, currency)}` : ""}
              </span>
            ) : null}
          </div>
          {r.notes ? <p className="text-sm whitespace-pre-wrap text-muted-foreground">{r.notes}</p> : null}
        </div>
        <div className="flex shrink-0 items-start gap-1">
          {locked && !r.pendingChange ? (
            <Button size="sm" variant="secondary" className="hidden cursor-pointer sm:inline-flex" onClick={onRequestChange}>
              Request a change
            </Button>
          ) : null}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button size="icon" variant="ghost" aria-label={`Options for ${r.supplierName}`} className="size-8 cursor-pointer text-muted-foreground">
                <MoreHorizontal className="size-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {locked ? (
                <DropdownMenuItem className="cursor-pointer" disabled={!!r.pendingChange} onSelect={onRequestChange}>
                  <ShieldCheck /> Request a change
                </DropdownMenuItem>
              ) : (
                <>
                  <DropdownMenuItem className="cursor-pointer" onSelect={onEdit}>
                    <Pencil /> Edit
                  </DropdownMenuItem>
                  <DropdownMenuSeparator />
                  <DropdownMenuLabel className="text-xs text-muted-foreground">Set status</DropdownMenuLabel>
                  {RESERVATION_STATUSES.map((s: ReservationStatus) => (
                    <DropdownMenuItem
                      key={s}
                      disabled={s === r.status}
                      className="cursor-pointer"
                      onSelect={() => void run(setStatus({ id: r._id, status: s }), `Marked ${RESERVATION_STATUS_META[s].label.toLowerCase()}`)}
                    >
                      <span className="flex-1">{RESERVATION_STATUS_META[s].label}</span>
                      <span className="text-xs text-muted-foreground">{RESERVATION_STATUS_META[s].hint}</span>
                    </DropdownMenuItem>
                  ))}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem
                    variant="destructive"
                    className="cursor-pointer"
                    onSelect={() => void run(remove({ id: r._id }), "Reservation removed")}
                  >
                    <Trash2 /> Remove
                  </DropdownMenuItem>
                </>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
      {r.pendingChange ? (
        <PendingBanner
          reservation={r}
          change={r.pendingChange}
          reference={reference}
          onRecord={() => r.pendingChange && onRecordResponse(r.pendingChange)}
        />
      ) : null}
      <ChangeHistory reservation={r} />
    </Card>
  );
}
