import { useState } from "react";
import { useQuery } from "convex/react";
import { Clock, Hotel, Plus, ShieldCheck } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { RESERVATION_STATUSES, RESERVATION_STATUS_META } from "@/lib/reservations.ts";
import { cn } from "@/lib/utils.ts";
import ReservationCard, { type ReservationRow } from "./reservation-card.tsx";
import ReservationDialog from "./reservation-dialog.tsx";
import { RecordResponseDialog, RequestChangeDialog } from "./change-dialogs.tsx";

type DialogState =
  | { kind: "none" }
  | { kind: "add" }
  | { kind: "edit"; reservation: ReservationRow }
  | { kind: "request"; reservation: ReservationRow }
  | { kind: "respond"; changeId: Id<"reservationChanges">; supplierName: string };

export default function ReservationsPanel({
  bookingId,
  reference,
  startDate,
}: {
  bookingId: Id<"bookings">;
  reference: string;
  startDate: string;
}) {
  const data = useQuery(api.reservations.list, { bookingId });
  const [dialog, setDialog] = useState<DialogState>({ kind: "none" });
  const close = (open: boolean) => !open && setDialog({ kind: "none" });

  if (data === undefined) {
    return (
      <div className="space-y-3">
        <Skeleton className="h-10 w-full" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-28 w-full" />
        ))}
      </div>
    );
  }

  const { reservations, currency } = data;
  const counts = RESERVATION_STATUSES.map((s) => ({
    status: s,
    count: reservations.filter((r) => r.status === s).length,
  }));
  const pending = reservations.filter((r) => r.pendingChange).length;

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex flex-wrap items-center gap-2 text-sm">
          {counts.map(({ status, count }) =>
            count ? (
              <span key={status} className={cn("rounded-full px-2.5 py-0.5 text-xs font-medium", RESERVATION_STATUS_META[status].badge)}>
                {count} {RESERVATION_STATUS_META[status].label.toLowerCase()}
              </span>
            ) : null,
          )}
          {pending ? (
            <span className="flex items-center gap-1 text-xs font-medium text-[#8a6400] dark:text-[#FFB800]">
              <Clock className="size-3.5" /> {pending} waiting on supplier
            </span>
          ) : null}
        </div>
        {reservations.length ? (
          <Button className="cursor-pointer" disabled={data.isFull} onClick={() => setDialog({ kind: "add" })}>
            <Plus className="size-4" /> Add reservation
          </Button>
        ) : null}
      </div>

      {reservations.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <Hotel />
            </EmptyMedia>
            <EmptyTitle>No reservations yet</EmptyTitle>
            <EmptyDescription>
              Track rooms, transfers, venues and meals you hold with suppliers, from option to
              confirmed.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" className="cursor-pointer" onClick={() => setDialog({ kind: "add" })}>
              <Plus className="size-4" /> Add reservation
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <>
          {reservations.map((r) => (
            <ReservationCard
              key={r._id}
              reservation={r}
              currency={currency}
              reference={reference}
              onEdit={() => setDialog({ kind: "edit", reservation: r })}
              onRequestChange={() => setDialog({ kind: "request", reservation: r })}
              onRecordResponse={(change) =>
                setDialog({ kind: "respond", changeId: change._id, supplierName: r.supplierName })
              }
            />
          ))}
          <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <ShieldCheck className="size-3.5" />
            Confirmed reservations can only change once the supplier approves.
          </p>
        </>
      )}

      {dialog.kind === "add" || dialog.kind === "edit" ? (
        <ReservationDialog
          key={dialog.kind === "edit" ? dialog.reservation._id : "add"}
          open
          onOpenChange={close}
          bookingId={bookingId}
          defaultStartDate={startDate}
          currency={currency}
          reservation={dialog.kind === "edit" ? dialog.reservation : undefined}
        />
      ) : null}
      {dialog.kind === "request" ? (
        <RequestChangeDialog reservation={dialog.reservation} onOpenChange={close} />
      ) : null}
      {dialog.kind === "respond" ? (
        <RecordResponseDialog changeId={dialog.changeId} supplierName={dialog.supplierName} onOpenChange={close} />
      ) : null}
    </div>
  );
}
