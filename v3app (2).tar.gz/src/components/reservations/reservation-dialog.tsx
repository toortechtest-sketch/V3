import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import SupplierPicker, { type PickedSupplier } from "@/components/suppliers/supplier-picker.tsx";
import AllotmentPicker, { type AllotmentSelection } from "./allotment-picker.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { DEFAULT_UNIT_LABEL, RESERVATION_STATUSES, RESERVATION_STATUS_META } from "@/lib/reservations.ts";
import { BOARD_LABELS, BOARD_TYPES, CATEGORY_META, SUPPLIER_CATEGORIES } from "@/lib/suppliers.ts";

const money = z
  .string()
  .refine((v) => v === "" || (Number.isFinite(Number(v)) && Number(v) >= 0), {
    message: "Enter an amount",
  });

const schema = z
  .object({
    type: z.enum(SUPPLIER_CATEGORIES),
    status: z.enum(RESERVATION_STATUSES),
    supplierName: z.string().trim().min(1, "Add the supplier").max(200),
    description: z.string().trim().min(1, "Describe the service").max(300),
    startDate: z.string().min(1, "Pick a date"),
    endDate: z.string(),
    units: z.coerce.number().int("Whole numbers only").min(1, "At least 1"),
    unitLabel: z.string().trim().max(40),
    board: z.enum([...BOARD_TYPES, "none"]),
    supplierRef: z.string().trim().max(100),
    optionUntil: z.string(),
    costPerUnit: money,
    sellPerUnit: money,
    notes: z.string().trim().max(5000),
  })
  .refine((v) => !v.endDate || v.endDate >= v.startDate, {
    path: ["endDate"],
    message: "Must be on or after the start",
  });

type FormInput = z.input<typeof schema>;
type FormValues = z.output<typeof schema>;

export type EditableReservation = Doc<"reservations"> & { supplier: PickedSupplier | null };

function defaultsFrom(startDate: string, r?: EditableReservation): FormInput {
  const num = (n: number | undefined) => (n === undefined ? "" : String(n));
  return {
    type: r?.type ?? "hotel",
    status: r?.status ?? "option",
    supplierName: r?.supplierName ?? "",
    description: r?.description ?? "",
    startDate: r?.startDate ?? startDate,
    endDate: r?.endDate ?? "",
    units: r?.units ?? 1,
    unitLabel: r?.unitLabel ?? "",
    board: r?.board ?? "none",
    supplierRef: r?.supplierRef ?? "",
    optionUntil: r?.optionUntil ?? "",
    costPerUnit: num(r?.costPerUnit),
    sellPerUnit: num(r?.sellPerUnit),
    notes: r?.notes ?? "",
  };
}

export default function ReservationDialog({
  open,
  onOpenChange,
  bookingId,
  defaultStartDate,
  currency,
  reservation,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  defaultStartDate: string;
  currency: string;
  /** Pass to edit (never a confirmed one); omit to add. */
  reservation?: EditableReservation;
}) {
  const create = useMutation(api.reservations.create);
  const update = useMutation(api.reservations.update);
  const [saving, setSaving] = useState(false);
  const [allotmentBlocked, setAllotmentBlocked] = useState(false);
  const [supplier, setSupplier] = useState<PickedSupplier | null>(reservation?.supplier ?? null);
  const [allotment, setAllotment] = useState<AllotmentSelection | null>(
    reservation?.allotmentPoolId
      ? {
          poolId: reservation.allotmentPoolId,
          sessionKey: reservation.allotmentSessionKey,
          holdUntil: reservation.allotmentHoldUntil,
        }
      : null,
  );
  const form = useForm<FormInput, unknown, FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(defaultStartDate, reservation),
  });
  const type = useWatch({ control: form.control, name: "type" });
  const unitLabel = useWatch({ control: form.control, name: "unitLabel" });
  const status = useWatch({ control: form.control, name: "status" }) ?? reservation?.status ?? "option";
  const watchedStartDate = useWatch({ control: form.control, name: "startDate" });
  const watchedEndDate = useWatch({ control: form.control, name: "endDate" });
  const watchedUnits = useWatch({ control: form.control, name: "units" });

  const pickSupplier = (picked: PickedSupplier | null) => {
    setSupplier(picked);
    if (!picked) return;
    // Linking a supplier fills the name and type so staff type less.
    form.setValue("supplierName", picked.name, { shouldValidate: true });
    form.setValue("type", picked.category);
  };

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    const optional = (s: string) => (s === "" ? undefined : s);
    const amount = (s: string) => (s === "" ? undefined : Number(s));
    const args = {
      type: values.type,
      supplierId: supplier?._id,
      supplierName: values.supplierName,
      description: values.description,
      startDate: values.startDate,
      endDate: optional(values.endDate),
      units: values.units,
      unitLabel: optional(values.unitLabel),
      board: values.board === "none" ? undefined : values.board,
      supplierRef: optional(values.supplierRef),
      optionUntil: optional(values.optionUntil),
      costPerUnit: amount(values.costPerUnit),
      sellPerUnit: amount(values.sellPerUnit),
      notes: optional(values.notes),
      allotmentPoolId: allotment?.poolId,
      allotmentSessionKey: allotment?.sessionKey,
      allotmentHoldUntil: allotment?.holdUntil,
    };
    try {
      if (reservation) {
        await update({ id: reservation._id, ...args });
        toast.success("Reservation updated");
      } else {
        await create({ bookingId, status: values.status, ...args });
        toast.success("Reservation added");
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const field = (
    name: "description" | "startDate" | "endDate" | "unitLabel" | "supplierRef" | "optionUntil" | "costPerUnit" | "sellPerUnit" | "units" | "supplierName",
    label: string,
    placeholder: string,
    inputType = "text",
  ) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field: f }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input
              type={inputType}
              placeholder={placeholder}
              {...f}
              value={f.value === undefined ? "" : String(f.value)}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {reservation ? "Edit reservation" : "Add reservation"}
          </DialogTitle>
          <DialogDescription>
            Amounts are per {unitLabel || DEFAULT_UNIT_LABEL[type]} in {currency}.
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2 sm:col-span-2">
              <p className="text-sm font-medium">Supplier</p>
              <SupplierPicker value={supplier} onChange={pickSupplier} />
            </div>
            {field("supplierName", "Supplier name", "Hotel Arts Barcelona")}
            <FormField
              control={form.control}
              name="type"
              render={({ field: f }) => (
                <FormItem>
                  <FormLabel>Type</FormLabel>
                  <Select value={f.value} onValueChange={f.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {SUPPLIER_CATEGORIES.map((c) => {
                        const Icon = CATEGORY_META[c].icon;
                        return (
                          <SelectItem key={c} value={c} className="cursor-pointer">
                            <Icon className="size-4" /> {CATEGORY_META[c].label}
                          </SelectItem>
                        );
                      })}
                    </SelectContent>
                  </Select>
                </FormItem>
              )}
            />
            <div className="sm:col-span-2">
              {field("description", "Service", "Deluxe double, sea view")}
            </div>
            {field("startDate", "From", "", "date")}
            {field("endDate", "To (optional)", "", "date")}
            {field("units", "Quantity", "10", "number")}
            {field("unitLabel", "Counted as", DEFAULT_UNIT_LABEL[type])}
            <div className="sm:col-span-2">
              <AllotmentPicker
                supplierId={supplier?._id}
                category={type}
                startDate={watchedStartDate ?? ""}
                endDate={watchedEndDate || undefined}
                units={Number(watchedUnits) || 1}
                showHoldUntil={status === "option"}
                value={allotment}
                onChange={setAllotment}
                onBlockedChange={setAllotmentBlocked}
              />
            </div>
            {type === "hotel" ? (
              <FormField
                control={form.control}
                name="board"
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Board</FormLabel>
                    <Select value={f.value} onValueChange={f.onChange}>
                      <FormControl>
                        <SelectTrigger className="w-full cursor-pointer">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="none" className="cursor-pointer">Not set</SelectItem>
                        {BOARD_TYPES.map((b) => (
                          <SelectItem key={b} value={b} className="cursor-pointer">
                            {BOARD_LABELS[b]}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            ) : null}
            {reservation ? null : (
              <FormField
                control={form.control}
                name="status"
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Status</FormLabel>
                    <Select value={f.value} onValueChange={f.onChange}>
                      <FormControl>
                        <SelectTrigger className="w-full cursor-pointer">
                          <SelectValue />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {RESERVATION_STATUSES.filter((s) => s !== "cancelled").map((s) => (
                          <SelectItem key={s} value={s} className="cursor-pointer">
                            {RESERVATION_STATUS_META[s].label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </FormItem>
                )}
              />
            )}
            {field("optionUntil", "Option held until", "", "date")}
            {field("supplierRef", "Supplier reference", "CONF-88231")}
            {field("costPerUnit", "Cost per unit", "180", "number")}
            {field("sellPerUnit", "Sell per unit", "225", "number")}
            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="notes"
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea rows={2} placeholder="Release date, rooming deadline, special requests" {...f} />
                    </FormControl>
                  </FormItem>
                )}
              />
            </div>
            <DialogFooter className="sm:col-span-2">
              <Button type="button" variant="ghost" className="cursor-pointer" onClick={() => onOpenChange(false)}>
                Cancel
              </Button>
              <Button type="submit" disabled={saving || allotmentBlocked} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {reservation ? "Save" : "Add reservation"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
