import { useState } from "react";
import { useQuery } from "convex/react";
import { ListChecks, Plus } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import TaskDialog, { type EditableTask } from "@/components/tasks/task-dialog.tsx";
import TaskRow from "@/components/tasks/task-row.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.tsx";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";

type DialogState = { kind: "none" } | { kind: "add" } | { kind: "edit"; task: EditableTask };

/** The booking's Tasks tab: open work first, then recently finished. */
export default function BookingTasksPanel({ bookingId }: { bookingId: Id<"bookings"> }) {
  const data = useQuery(api.tasks.listForBooking, { bookingId });
  const [dialog, setDialog] = useState<DialogState>({ kind: "none" });

  const dialogEl = (
    <TaskDialog
      open={dialog.kind !== "none"}
      onOpenChange={(open) => !open && setDialog({ kind: "none" })}
      bookingId={bookingId}
      task={dialog.kind === "edit" ? dialog.task : undefined}
    />
  );

  if (data === undefined) {
    return (
      <Card>
        <CardContent className="space-y-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <Skeleton key={i} className="h-12 w-full" />
          ))}
        </CardContent>
      </Card>
    );
  }

  if (data.open.length === 0 && data.done.length === 0) {
    return (
      <>
        <Empty className="border bg-card">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <ListChecks />
            </EmptyMedia>
            <EmptyTitle>No tasks yet</EmptyTitle>
            <EmptyDescription>
              Track what needs doing on this booking, like chasing the hotel or
              sending the rooming list.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent>
            <Button size="sm" className="cursor-pointer" onClick={() => setDialog({ kind: "add" })}>
              <Plus className="size-4" /> Add task
            </Button>
          </EmptyContent>
        </Empty>
        {dialogEl}
      </>
    );
  }

  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between gap-2">
        <CardTitle className="font-display text-lg">
          Open tasks{" "}
          <span className="font-mono text-sm font-normal text-muted-foreground">
            {data.open.length}
          </span>
        </CardTitle>
        <Button size="sm" className="cursor-pointer" onClick={() => setDialog({ kind: "add" })}>
          <Plus className="size-4" /> Add task
        </Button>
      </CardHeader>
      <CardContent className="space-y-4">
        {data.open.length === 0 ? (
          <p className="py-4 text-sm text-muted-foreground">Everything is done here.</p>
        ) : (
          <div className="divide-y">
            {data.open.map((task) => (
              <TaskRow
                key={task._id}
                task={task}
                onEdit={() => setDialog({ kind: "edit", task })}
              />
            ))}
          </div>
        )}

        {data.done.length > 0 ? (
          <Collapsible>
            <CollapsibleTrigger className="cursor-pointer text-sm font-medium text-muted-foreground hover:text-foreground">
              Show completed ({data.done.length}
              {data.done.length >= 50 ? "+" : ""})
            </CollapsibleTrigger>
            <CollapsibleContent className="divide-y">
              {data.done.map((task) => (
                <TaskRow
                  key={task._id}
                  task={task}
                  onEdit={() => setDialog({ kind: "edit", task })}
                />
              ))}
            </CollapsibleContent>
          </Collapsible>
        ) : null}
      </CardContent>
      {dialogEl}
    </Card>
  );
}
