import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import {
  CalendarClock,
  Check,
  Circle,
  CircleDot,
  MoreHorizontal,
  Pencil,
  PhoneForwarded,
  Trash2,
  UserRound,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { dueState, formatDue, type TaskStatus } from "@/lib/tasks.ts";
import { cn } from "@/lib/utils.ts";

export type TaskRowData = Doc<"tasks"> & {
  assigneeName: string | null;
  booking?: { _id: string; reference: string; title: string } | null;
};

const DUE_TONE = {
  overdue: "text-destructive",
  today: "text-[#b05300] dark:text-[#ffa257]",
  upcoming: "text-muted-foreground",
  none: "text-muted-foreground",
} as const;

export default function TaskRow({
  task,
  onEdit,
  showBooking = false,
}: {
  task: TaskRowData;
  onEdit?: () => void;
  showBooking?: boolean;
}) {
  const setStatus = useMutation(api.tasks.setStatus);
  const remove = useMutation(api.tasks.remove);
  const [busy, setBusy] = useState(false);
  const done = task.status === "done";
  const due = done ? "none" : dueState(task.dueDate);

  const run = async (action: () => Promise<unknown>, success?: string) => {
    setBusy(true);
    try {
      await action();
      if (success) toast.success(success);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  const move = (status: TaskStatus) => run(() => setStatus({ id: task._id, status }));

  return (
    <div className={cn("group flex items-start gap-3 py-3", done && "opacity-60")}>
      <button
        type="button"
        disabled={busy}
        onClick={() => void move(done ? "open" : "done")}
        aria-label={done ? "Reopen task" : "Mark as done"}
        className={cn(
          "mt-0.5 flex size-5 shrink-0 cursor-pointer items-center justify-center rounded-full border-2 transition-colors disabled:opacity-50",
          done
            ? "border-emerald-500 bg-emerald-500 text-white"
            : "border-muted-foreground/40 hover:border-primary hover:bg-primary/10",
        )}
      >
        {done ? <Check className="size-3" strokeWidth={3} /> : null}
      </button>

      <div className="min-w-0 flex-1 space-y-1">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={onEdit}
            disabled={!onEdit}
            className={cn(
              "min-w-0 cursor-pointer text-left font-medium break-words hover:text-primary disabled:cursor-default disabled:hover:text-foreground",
              done && "line-through",
            )}
          >
            {task.title}
          </button>
          {task.kind === "follow_up" ? (
            <Badge variant="secondary" className="gap-1 font-normal">
              <PhoneForwarded className="size-3" /> Follow-up
            </Badge>
          ) : null}
          {task.status === "in_progress" ? (
            <Badge className="gap-1 bg-primary/12 font-normal text-primary dark:text-[#7fa6ff]">
              <CircleDot className="size-3" /> In progress
            </Badge>
          ) : null}
        </div>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-muted-foreground">
          {task.dueDate ? (
            <span className={cn("flex items-center gap-1", DUE_TONE[due])}>
              <CalendarClock className="size-3" />
              {due === "overdue" ? "Overdue · " : null}
              {formatDue(task.dueDate)}
            </span>
          ) : null}
          <span className="flex items-center gap-1">
            <UserRound className="size-3" />
            {task.assigneeName ?? "Unknown"}
          </span>
          {showBooking ? (
            task.booking ? (
              <Link
                to={`/bookings/${task.booking._id}?tab=tasks`}
                className="flex min-w-0 cursor-pointer items-center gap-1.5 hover:text-primary"
              >
                <span className="font-mono">{task.booking.reference}</span>
                <span className="truncate">{task.booking.title}</span>
              </Link>
            ) : (
              <span>Booking no longer assigned to you</span>
            )
          ) : null}
        </div>
        {task.notes ? (
          <p className="line-clamp-2 text-sm whitespace-pre-wrap text-muted-foreground">
            {task.notes}
          </p>
        ) : null}
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            variant="ghost"
            size="icon"
            disabled={busy}
            className="size-8 shrink-0 cursor-pointer text-muted-foreground"
          >
            <MoreHorizontal className="size-4" />
            <span className="sr-only">Task actions</span>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          {onEdit ? (
            <DropdownMenuItem className="cursor-pointer" onSelect={onEdit}>
              <Pencil className="size-4" /> Edit
            </DropdownMenuItem>
          ) : null}
          {task.status !== "open" ? (
            <DropdownMenuItem className="cursor-pointer" onSelect={() => void move("open")}>
              <Circle className="size-4" /> Mark as to do
            </DropdownMenuItem>
          ) : null}
          {task.status !== "in_progress" ? (
            <DropdownMenuItem className="cursor-pointer" onSelect={() => void move("in_progress")}>
              <CircleDot className="size-4" /> Mark in progress
            </DropdownMenuItem>
          ) : null}
          {task.status !== "done" ? (
            <DropdownMenuItem className="cursor-pointer" onSelect={() => void move("done")}>
              <Check className="size-4" /> Mark done
            </DropdownMenuItem>
          ) : null}
          <DropdownMenuSeparator />
          <DropdownMenuItem
            variant="destructive"
            className="cursor-pointer"
            onSelect={() => void run(() => remove({ id: task._id }), "Task deleted")}
          >
            <Trash2 className="size-4" /> Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
