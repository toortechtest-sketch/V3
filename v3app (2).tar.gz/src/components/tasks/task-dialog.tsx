import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQuery } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { KIND_LABELS, TASK_KINDS } from "@/lib/tasks.ts";

const schema = z.object({
  kind: z.enum(TASK_KINDS),
  title: z.string().trim().min(1, "Add a title").max(200),
  dueDate: z.string(),
  assigneeId: z.string(),
  notes: z.string().max(5000),
});

type FormValues = z.infer<typeof schema>;

export type EditableTask = Pick<
  Doc<"tasks">,
  "_id" | "kind" | "title" | "dueDate" | "assigneeId" | "notes"
>;

function defaultsFrom(task?: EditableTask): FormValues {
  return {
    kind: task?.kind ?? "task",
    title: task?.title ?? "",
    dueDate: task?.dueDate ?? "",
    assigneeId: task?.assigneeId ?? "",
    notes: task?.notes ?? "",
  };
}

export default function TaskDialog({
  open,
  onOpenChange,
  bookingId,
  task,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  /** Pass to edit; omit to create. */
  task?: EditableTask;
}) {
  const create = useMutation(api.tasks.create);
  const update = useMutation(api.tasks.update);
  const assignees = useQuery(api.tasks.listAssignees, open ? { bookingId } : "skip");
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(task),
  });

  const handleOpenChange = (next: boolean) => {
    if (next) form.reset(defaultsFrom(task));
    onOpenChange(next);
  };

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    const args = {
      kind: values.kind,
      title: values.title,
      dueDate: values.dueDate || undefined,
      notes: values.notes.trim() || undefined,
      assigneeId: values.assigneeId ? (values.assigneeId as Id<"users">) : undefined,
    };
    try {
      if (task) {
        await update({ id: task._id, ...args });
        toast.success("Task updated");
      } else {
        await create({ bookingId, ...args });
        toast.success(values.kind === "follow_up" ? "Follow-up added" : "Task added");
        form.reset(defaultsFrom());
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {task ? "Edit task" : "New task"}
          </DialogTitle>
          <DialogDescription>
            Follow-ups are for chasing a client, hotel or supplier.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="kind"
              render={({ field }) => (
                <FormItem>
                  <FormControl>
                    <ToggleGroup
                      type="single"
                      variant="outline"
                      value={field.value}
                      onValueChange={(v) => v && field.onChange(v)}
                      className="w-full"
                    >
                      {TASK_KINDS.map((k) => (
                        <ToggleGroupItem key={k} value={k} className="flex-1 cursor-pointer">
                          {KIND_LABELS[k]}
                        </ToggleGroupItem>
                      ))}
                    </ToggleGroup>
                  </FormControl>
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="title"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Title</FormLabel>
                  <FormControl>
                    <Input placeholder="Chase hotel for rooming confirmation" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <div className="grid gap-4 sm:grid-cols-2">
              <FormField
                control={form.control}
                name="dueDate"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Due</FormLabel>
                    <FormControl>
                      <Input type="date" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="assigneeId"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Assigned to</FormLabel>
                    <Select
                      value={field.value || undefined}
                      onValueChange={field.onChange}
                      disabled={assignees === undefined}
                    >
                      <FormControl>
                        <SelectTrigger className="w-full cursor-pointer">
                          <SelectValue placeholder="Me" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {(assignees ?? []).map((a) => (
                          <SelectItem key={a.userId} value={a.userId} className="cursor-pointer">
                            {a.name}
                            {a.isBookingOwner ? (
                              <span className="text-xs text-muted-foreground">Booking owner</span>
                            ) : null}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Textarea rows={3} placeholder="Details, contact, what to ask" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter>
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {task ? "Save changes" : "Add"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
