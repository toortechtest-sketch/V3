import { useState } from "react";

export type DraftRow<T> = { key: number; draft: T; selected: boolean };

/** Reviewable list of AI drafts: tick, untick and edit before creating. */
export function useDraftList<T>() {
  const [rows, setRows] = useState<DraftRow<T>[]>([]);

  return {
    rows,
    selected: rows.filter((r) => r.selected),
    load: (drafts: T[], isSelected: (draft: T) => boolean = () => true) =>
      setRows(drafts.map((draft, key) => ({ key, draft, selected: isSelected(draft) }))),
    clear: () => setRows([]),
    update: (key: number, patch: Partial<T>) =>
      setRows((prev) =>
        prev.map((r) => (r.key === key ? { ...r, draft: { ...r.draft, ...patch } } : r)),
      ),
    toggle: (key: number, selected: boolean) =>
      setRows((prev) => prev.map((r) => (r.key === key ? { ...r, selected } : r))),
    toggleAll: (selected: boolean) =>
      setRows((prev) => prev.map((r) => ({ ...r, selected }))),
  };
}
