import { AlertTriangle } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox.tsx";
import { Input } from "@/components/ui/input.tsx";
import { cn } from "@/lib/utils.ts";

/** One AI draft on the review screen; unticked drafts are not created. */
export function ReviewCard({
  checked,
  onCheckedChange,
  label,
  warning,
  children,
}: {
  checked: boolean;
  onCheckedChange: (checked: boolean) => void;
  label: string;
  warning?: string;
  children: React.ReactNode;
}) {
  return (
    <div
      className={cn(
        "flex gap-3 rounded-lg border bg-card p-3 transition-opacity",
        !checked && "opacity-55",
      )}
    >
      <Checkbox
        checked={checked}
        onCheckedChange={(v) => onCheckedChange(v === true)}
        aria-label={`Include ${label}`}
        className="mt-2.5 cursor-pointer"
      />
      <div className="min-w-0 flex-1 space-y-2">
        {children}
        {warning ? (
          <p className="flex items-center gap-1.5 text-xs text-[#8a6400] dark:text-[#FFB800]">
            <AlertTriangle className="size-3.5 shrink-0" /> {warning}
          </p>
        ) : null}
      </div>
    </div>
  );
}

/** Compact labelled input used across review cards. */
export function DraftField({
  label,
  value,
  onChange,
  placeholder,
  className,
}: {
  label: string;
  value: string | undefined;
  onChange: (value: string | undefined) => void;
  placeholder?: string;
  className?: string;
}) {
  return (
    <label className={cn("block min-w-0 space-y-1", className)}>
      <span className="text-[11px] font-medium text-muted-foreground">{label}</span>
      <Input
        value={value ?? ""}
        placeholder={placeholder ?? "—"}
        onChange={(e) => onChange(e.target.value || undefined)}
        className="h-8 text-sm"
      />
    </label>
  );
}

/** "Select all" bar above the drafts. */
export function ReviewToolbar({
  total,
  selected,
  noun,
  onToggleAll,
}: {
  total: number;
  selected: number;
  noun: string;
  onToggleAll: (selected: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between gap-3 rounded-lg bg-secondary px-3 py-2 text-sm">
      <p>
        <span className="font-semibold">{selected}</span> of {total} {noun} selected
      </p>
      <button
        type="button"
        className="cursor-pointer text-xs font-medium text-primary hover:underline"
        onClick={() => onToggleAll(selected < total)}
      >
        {selected < total ? "Select all" : "Clear all"}
      </button>
    </div>
  );
}
