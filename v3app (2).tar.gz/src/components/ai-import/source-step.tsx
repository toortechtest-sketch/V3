import { useState } from "react";
import { toast } from "sonner";
import { ClipboardPaste, Globe, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";

// Mirrors MAX_IMPORT_TEXT on the backend.
const MAX_TEXT = 30_000;

export type ImportSource = { kind: "text"; text: string } | { kind: "website"; url: string };

/** First step of every import: paste text, or point at a website. */
export default function SourceStep({
  textPlaceholder,
  websitePlaceholder,
  hint,
  onExtract,
}: {
  textPlaceholder: string;
  /** Omit to offer pasted text only. */
  websitePlaceholder?: string;
  hint: string;
  onExtract: (source: ImportSource) => Promise<void>;
}) {
  const [mode, setMode] = useState<ImportSource["kind"]>("text");
  const [text, setText] = useState("");
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);

  const value = mode === "text" ? text.trim() : url.trim();
  const tooLong = mode === "text" && text.length > MAX_TEXT;

  const run = async () => {
    setBusy(true);
    try {
      await onExtract(mode === "text" ? { kind: "text", text } : { kind: "website", url });
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setBusy(false);
    }
  };

  const modes = [
    { value: "text" as const, label: "Paste text", icon: ClipboardPaste },
    { value: "website" as const, label: "From a website", icon: Globe },
  ];

  return (
    <div className="space-y-4">
      {websitePlaceholder ? (
        <div className="inline-flex gap-1 rounded-lg bg-muted p-1">
          {modes.map((m) => (
            <button
              key={m.value}
              type="button"
              onClick={() => setMode(m.value)}
              className={cn(
                "flex cursor-pointer items-center gap-1.5 rounded-md px-3 py-1 text-sm text-muted-foreground transition-colors hover:text-foreground",
                mode === m.value && "bg-background text-foreground shadow-sm",
              )}
            >
              <m.icon className="size-3.5" /> {m.label}
            </button>
          ))}
        </div>
      ) : null}

      {mode === "text" ? (
        <div className="space-y-1.5">
          <Textarea
            rows={10}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={textPlaceholder}
            className="max-h-[45vh] font-mono text-xs"
            aria-label="Text to import"
          />
          <p className={cn("text-xs text-muted-foreground", tooLong && "text-destructive")}>
            {tooLong
              ? "That's a lot of text. Import it in smaller parts."
              : `${text.length.toLocaleString()} / ${MAX_TEXT.toLocaleString()} characters`}
          </p>
        </div>
      ) : (
        <Input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder={websitePlaceholder}
          aria-label="Website address"
          onKeyDown={(e) => {
            if (e.key === "Enter" && value && !busy) void run();
          }}
        />
      )}

      <div className="flex flex-col gap-3 rounded-lg border border-dashed bg-muted/40 p-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-xs text-muted-foreground">{hint}</p>
        <Button
          className="shrink-0 cursor-pointer"
          disabled={!value || tooLong || busy}
          onClick={() => void run()}
        >
          {busy ? <Spinner /> : <Sparkles className="size-4" />}
          {busy ? "Reading…" : "Read with AI"}
        </Button>
      </div>
    </div>
  );
}
