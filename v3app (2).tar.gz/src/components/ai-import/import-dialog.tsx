import { ArrowLeft, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";

/**
 * Shell for every AI import: source step, then a review step whose footer
 * creates only the ticked drafts.
 */
export default function ImportDialog({
  open,
  onOpenChange,
  title,
  description,
  reviewing,
  onBack,
  createLabel,
  canCreate,
  creating,
  onCreate,
  children,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description: string;
  reviewing: boolean;
  onBack: () => void;
  createLabel: string;
  canCreate: boolean;
  creating: boolean;
  onCreate: () => void;
  children: React.ReactNode;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="flex max-h-[90vh] flex-col gap-4 sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-display text-xl">
            <span className="flex size-7 items-center justify-center rounded-md bg-sidebar text-sidebar-primary">
              <Sparkles className="size-4" />
            </span>
            {title}
          </DialogTitle>
          <DialogDescription>
            {reviewing
              ? "Check each record. Untick anything you don't want; nothing is saved until you create it."
              : description}
          </DialogDescription>
        </DialogHeader>

        <div className="-mx-6 min-h-0 flex-1 overflow-y-auto px-6">{children}</div>

        {reviewing ? (
          <DialogFooter className="gap-2 sm:justify-between">
            <Button variant="ghost" className="cursor-pointer" onClick={onBack} disabled={creating}>
              <ArrowLeft className="size-4" /> Start over
            </Button>
            <Button className="cursor-pointer" disabled={!canCreate || creating} onClick={onCreate}>
              {creating ? <Spinner /> : null}
              {createLabel}
            </Button>
          </DialogFooter>
        ) : null}
      </DialogContent>
    </Dialog>
  );
}
