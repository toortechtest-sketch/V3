import { useMemo, useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import {
  ROOM_TYPES,
  ROOM_TYPE_LABELS,
  fullName,
  parseTravellerList,
  type RoomType,
} from "@/lib/travellers.ts";

const MAX = 300;

export default function BulkAddDialog({
  open,
  onOpenChange,
  bookingId,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
}) {
  const addMany = useMutation(api.travellers.addTravellers);
  const [text, setText] = useState("");
  const [room, setRoom] = useState<RoomType>("twin");
  const [saving, setSaving] = useState(false);
  const parsed = useMemo(() => parseTravellerList(text, room), [text, room]);

  const onSave = async () => {
    setSaving(true);
    try {
      const count = await addMany({ bookingId, travellers: parsed });
      toast.success(`${count} traveller${count === 1 ? "" : "s"} added`);
      setText("");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">Paste a name list</DialogTitle>
          <DialogDescription>
            One traveller per line. Copy straight from a spreadsheet: first name, last name, and
            optionally email and room type.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <Textarea
            rows={8}
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={"Ana Ruiz\nBob\tMoss\tbob@acme.com\tsingle"}
            className="font-mono text-sm"
          />
          <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
            <Label className="text-sm font-normal text-muted-foreground">
              Room request when none is given
            </Label>
            <Select value={room} onValueChange={(v) => setRoom(v as RoomType)}>
              <SelectTrigger className="w-full cursor-pointer sm:w-40">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ROOM_TYPES.map((t) => (
                  <SelectItem key={t} value={t} className="cursor-pointer">
                    {ROOM_TYPE_LABELS[t]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {parsed.length > 0 ? (
            <div className="rounded-lg border bg-muted/40">
              <p className="border-b px-3 py-2 font-mono text-xs text-muted-foreground">
                Preview · {parsed.length} traveller{parsed.length === 1 ? "" : "s"}
              </p>
              <ul className="max-h-48 divide-y overflow-y-auto text-sm">
                {parsed.slice(0, 50).map((t, i) => (
                  <li key={i} className="flex items-center justify-between gap-3 px-3 py-1.5">
                    <span className="min-w-0 truncate font-medium">{fullName(t)}</span>
                    <span className="shrink-0 text-xs text-muted-foreground">
                      {t.email ? `${t.email} · ` : ""}
                      {ROOM_TYPE_LABELS[t.roomPreference]}
                    </span>
                  </li>
                ))}
              </ul>
              {parsed.length > 50 ? (
                <p className="border-t px-3 py-2 text-xs text-muted-foreground">
                  and {parsed.length - 50} more
                </p>
              ) : null}
            </div>
          ) : null}
          {parsed.length > MAX ? (
            <p className="text-sm text-destructive">Add up to {MAX} travellers at a time.</p>
          ) : null}
        </div>
        <DialogFooter>
          <Button
            type="button"
            variant="ghost"
            className="cursor-pointer"
            onClick={() => onOpenChange(false)}
          >
            Cancel
          </Button>
          <Button
            className="cursor-pointer"
            disabled={saving || parsed.length === 0 || parsed.length > MAX}
            onClick={onSave}
          >
            {saving ? <Spinner /> : null}
            Add {parsed.length || ""} traveller{parsed.length === 1 ? "" : "s"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
