import { useState } from "react";
import { useMutation } from "convex/react";
import type { FunctionReturnType } from "convex/server";
import { toast } from "sonner";
import { BedDouble, MoreHorizontal, Pencil, Trash2, UserRound, Utensils } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { Input } from "@/components/ui/input.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { ROOM_TYPE_LABELS, fullName } from "@/lib/travellers.ts";

export type TravellerData = FunctionReturnType<typeof api.travellers.get>;
type TravellerView = TravellerData["travellers"][number];

function TravellerRow({
  traveller,
  onEdit,
}: {
  traveller: TravellerView;
  onEdit: (t: Doc<"travellers">) => void;
}) {
  const remove = useMutation(api.travellers.removeTraveller);
  const { room: assigned, ...doc } = traveller;
  const name = fullName(traveller);
  return (
    <div className="flex items-center gap-3 px-4 py-3 sm:px-5">
      <div className="flex size-9 shrink-0 items-center justify-center rounded-full bg-secondary font-mono text-xs font-medium text-primary uppercase">
        {(traveller.firstName[0] ?? "") + (traveller.lastName[0] ?? "")}
      </div>
      <div className="min-w-0 flex-1">
        <button
          type="button"
          onClick={() => onEdit(doc)}
          className="block max-w-full cursor-pointer truncate text-left font-medium hover:text-primary"
        >
          {name}
        </button>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-muted-foreground">
          <span>{ROOM_TYPE_LABELS[traveller.roomPreference]} requested</span>
          {traveller.sharingWith ? <span className="truncate">with {traveller.sharingWith}</span> : null}
          {traveller.email ? <span className="truncate">{traveller.email}</span> : null}
          {traveller.dietaryRequirements ? (
            <span className="flex items-center gap-1 text-[#b05300] dark:text-[#ffa257]">
              <Utensils className="size-3" />
              <span className="truncate">{traveller.dietaryRequirements}</span>
            </span>
          ) : null}
        </div>
      </div>
      <div className="hidden shrink-0 sm:block">
        {assigned ? (
          <span className="inline-flex items-center gap-1.5 rounded-md bg-primary/10 px-2 py-1 text-xs text-primary dark:text-[#7fa6ff]">
            <BedDouble className="size-3.5" />
            {assigned.roomNumber ? `Room ${assigned.roomNumber}` : ROOM_TYPE_LABELS[assigned.roomType]}
            {assigned.hotel ? ` · ${assigned.hotel}` : ""}
          </span>
        ) : (
          <span className="rounded-md bg-[#FFB800]/15 px-2 py-1 text-xs text-[#8a6400] dark:text-[#FFB800]">
            No room yet
          </span>
        )}
      </div>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button
            size="icon"
            variant="ghost"
            aria-label={`Options for ${name}`}
            className="size-8 shrink-0 cursor-pointer text-muted-foreground"
          >
            <MoreHorizontal className="size-4" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem className="cursor-pointer" onSelect={() => onEdit(doc)}>
            <Pencil /> Edit
          </DropdownMenuItem>
          <DropdownMenuItem
            variant="destructive"
            className="cursor-pointer"
            onSelect={() => {
              remove({ id: traveller._id }).then(
                () => toast.success(`${name} removed`),
                (error: unknown) => toast.error(errorMessage(error)),
              );
            }}
          >
            <Trash2 /> Remove
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

export default function TravellerList({
  data,
  onEdit,
}: {
  data: TravellerData;
  onEdit: (t: Doc<"travellers">) => void;
}) {
  const [search, setSearch] = useState("");
  const term = search.trim().toLowerCase();
  // The full (bounded) list is already loaded, so filtering here is instant.
  const shown = term
    ? data.travellers.filter((t) =>
        `${t.firstName} ${t.lastName} ${t.email ?? ""}`.toLowerCase().includes(term),
      )
    : data.travellers;

  return (
    <Card className="gap-0 overflow-hidden py-0">
      <div className="border-b px-4 py-3 sm:px-5">
        <Input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search by name or email"
          className="max-w-sm"
        />
      </div>
      {shown.length === 0 ? (
        <p className="flex items-center gap-2 px-5 py-8 text-sm text-muted-foreground">
          <UserRound className="size-4" /> No travellers match that search.
        </p>
      ) : (
        <div className="divide-y">
          {shown.map((t) => (
            <TravellerRow key={t._id} traveller={t} onEdit={onEdit} />
          ))}
        </div>
      )}
    </Card>
  );
}
