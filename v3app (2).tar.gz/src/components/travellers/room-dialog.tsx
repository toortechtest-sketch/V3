import { useState } from "react";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import SupplierPicker, { type PickedSupplier } from "@/components/suppliers/supplier-picker.tsx";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Label } from "@/components/ui/label.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import {
  DEFAULT_CAPACITY,
  ROOM_STATUSES,
  ROOM_TYPES,
  ROOM_TYPE_LABELS,
  type RoomStatus,
  type RoomType,
} from "@/lib/travellers.ts";

export type EditableRoom = Doc<"rooms"> & { supplier: PickedSupplier | null };

const STATUS_LABELS: Record<RoomStatus, string> = {
  tentative: "Tentative",
  confirmed: "Confirmed by hotel",
};

function Field({ id, label, children }: { id: string; label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id}>{label}</Label>
      {children}
    </div>
  );
}

export default function RoomDialog({
  open,
  onOpenChange,
  bookingId,
  room,
  defaultSupplier,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  /** Pass to edit; omit to add. */
  room?: EditableRoom;
  /** Hotel to preselect when adding, usually the last one used. */
  defaultSupplier?: PickedSupplier | null;
}) {
  const add = useMutation(api.travellers.addRoom);
  const update = useMutation(api.travellers.updateRoom);
  const [supplier, setSupplier] = useState<PickedSupplier | null>(
    room ? room.supplier : (defaultSupplier ?? null),
  );
  const [roomType, setRoomType] = useState<RoomType>(room?.roomType ?? "twin");
  const [capacity, setCapacity] = useState(String(room?.capacity ?? DEFAULT_CAPACITY.twin));
  const [count, setCount] = useState("1");
  const [roomNumber, setRoomNumber] = useState(room?.roomNumber ?? "");
  const [status, setStatus] = useState<RoomStatus>(room?.status ?? "tentative");
  const [notes, setNotes] = useState(room?.notes ?? "");
  const [saving, setSaving] = useState(false);

  const many = !room && Number(count) > 1;

  const onSave = async (e: React.FormEvent) => {
    e.preventDefault();
    const size = Number(capacity);
    const howMany = Number(count);
    if (!Number.isInteger(size) || size < 1 || size > 12) {
      toast.error("A room sleeps between 1 and 12 guests.");
      return;
    }
    if (!room && (!Number.isInteger(howMany) || howMany < 1 || howMany > 100)) {
      toast.error("Add between 1 and 100 rooms at a time.");
      return;
    }
    setSaving(true);
    const fields = {
      supplierId: supplier?._id,
      roomType,
      capacity: size,
      roomNumber: roomNumber.trim() || undefined,
      status,
      notes: notes.trim() || undefined,
    };
    try {
      if (room) {
        await update({ id: room._id, ...fields });
        toast.success("Room updated");
      } else {
        const added = await add({ bookingId, ...fields, count: howMany });
        toast.success(`${added} room${added === 1 ? "" : "s"} added`);
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-lg">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">{room ? "Edit room" : "Add rooms"}</DialogTitle>
          <DialogDescription>
            {room ? "Guests stay in the room when you change it." : "Add one room or a block of the same type."}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={onSave} className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2 sm:col-span-2">
            <p className="text-sm font-medium">Hotel</p>
            <SupplierPicker value={supplier} onChange={setSupplier} />
          </div>
          <Field id="room-type" label="Room type">
            <Select
              value={roomType}
              onValueChange={(v) => {
                const next = v as RoomType;
                setRoomType(next);
                setCapacity(String(DEFAULT_CAPACITY[next]));
              }}
            >
              <SelectTrigger id="room-type" className="w-full cursor-pointer">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {ROOM_TYPES.map((t) => (
                  <SelectItem key={t} value={t} className="cursor-pointer">
                    {ROOM_TYPE_LABELS[t]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </Field>
          <Field id="room-capacity" label="Sleeps">
            <Input
              id="room-capacity"
              type="number"
              min={1}
              max={12}
              value={capacity}
              onChange={(e) => setCapacity(e.target.value)}
            />
          </Field>
          {room ? null : (
            <Field id="room-count" label="How many rooms">
              <Input
                id="room-count"
                type="number"
                min={1}
                max={100}
                value={count}
                onChange={(e) => setCount(e.target.value)}
              />
            </Field>
          )}
          <Field id="room-number" label="Room number">
            <Input
              id="room-number"
              value={many ? "" : roomNumber}
              disabled={many}
              placeholder={many ? "Add per room later" : "412"}
              onChange={(e) => setRoomNumber(e.target.value)}
            />
          </Field>
          <div className={room ? "" : "sm:col-span-2"}>
            <Field id="room-status" label="Status">
              <Select value={status} onValueChange={(v) => setStatus(v as RoomStatus)}>
                <SelectTrigger id="room-status" className="w-full cursor-pointer">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {ROOM_STATUSES.map((s) => (
                    <SelectItem key={s} value={s} className="cursor-pointer">
                      {STATUS_LABELS[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>
          </div>
          <div className="sm:col-span-2">
            <Field id="room-notes" label="Notes">
              <Textarea
                id="room-notes"
                rows={2}
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Connecting with 414, sea view requested"
              />
            </Field>
          </div>
          <DialogFooter className="sm:col-span-2">
            <Button
              type="button"
              variant="ghost"
              className="cursor-pointer"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={saving} className="cursor-pointer">
              {saving ? <Spinner /> : null}
              {room ? "Save" : many ? `Add ${count} rooms` : "Add room"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
