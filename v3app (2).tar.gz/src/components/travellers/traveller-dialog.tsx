import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { ROOM_TYPES, ROOM_TYPE_LABELS } from "@/lib/travellers.ts";

const schema = z
  .object({
    firstName: z.string().trim().max(100),
    lastName: z.string().trim().max(100),
    email: z.union([z.literal(""), z.string().trim().email("Enter a valid email")]),
    phone: z.string().trim().max(50),
    roomPreference: z.enum(ROOM_TYPES),
    sharingWith: z.string().trim().max(200),
    dietaryRequirements: z.string().trim().max(500),
    notes: z.string().trim().max(2000),
  })
  .refine((v) => v.firstName || v.lastName, { path: ["firstName"], message: "Add a name" });

type FormValues = z.infer<typeof schema>;

function defaultsFrom(t?: Doc<"travellers">): FormValues {
  return {
    firstName: t?.firstName ?? "",
    lastName: t?.lastName ?? "",
    email: t?.email ?? "",
    phone: t?.phone ?? "",
    roomPreference: t?.roomPreference ?? "twin",
    sharingWith: t?.sharingWith ?? "",
    dietaryRequirements: t?.dietaryRequirements ?? "",
    notes: t?.notes ?? "",
  };
}

type TextName = Exclude<keyof FormValues, "roomPreference">;

export default function TravellerDialog({
  open,
  onOpenChange,
  bookingId,
  traveller,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  /** Pass to edit; omit to add. */
  traveller?: Doc<"travellers">;
}) {
  const add = useMutation(api.travellers.addTraveller);
  const update = useMutation(api.travellers.updateTraveller);
  const [saving, setSaving] = useState(false);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(traveller),
  });

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    const optional = (s: string) => (s === "" ? undefined : s);
    const args = {
      firstName: values.firstName,
      lastName: values.lastName,
      roomPreference: values.roomPreference,
      email: optional(values.email),
      phone: optional(values.phone),
      sharingWith: optional(values.sharingWith),
      dietaryRequirements: optional(values.dietaryRequirements),
      notes: optional(values.notes),
    };
    try {
      if (traveller) {
        await update({ id: traveller._id, ...args });
        toast.success("Traveller updated");
      } else {
        await add({ bookingId, ...args });
        toast.success("Traveller added");
        // Keep the dialog open with a fresh form for quick entry of the next one.
        form.reset({ ...defaultsFrom(), roomPreference: values.roomPreference });
        return;
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const textField = (name: TextName, label: string, placeholder: string, type = "text") => (
    <FormField
      control={form.control}
      name={name}
      render={({ field }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input type={type} placeholder={placeholder} {...field} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {traveller ? "Edit traveller" : "Add traveller"}
          </DialogTitle>
          <DialogDescription>
            {traveller ? "Changes show on the rooming list straight away." : "Saved travellers stay here so you can add the next one."}
          </DialogDescription>
        </DialogHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="grid gap-4 sm:grid-cols-2">
            {textField("firstName", "First name", "Ana")}
            {textField("lastName", "Last name", "Ruiz")}
            {textField("email", "Email", "ana@acme.com", "email")}
            {textField("phone", "Phone", "+34 600 000 000", "tel")}
            <FormField
              control={form.control}
              name="roomPreference"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Room request</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {ROOM_TYPES.map((t) => (
                        <SelectItem key={t} value={t} className="cursor-pointer">
                          {ROOM_TYPE_LABELS[t]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            {textField("sharingWith", "Sharing with", "Bob Moss")}
            <div className="sm:col-span-2">
              {textField("dietaryRequirements", "Dietary needs", "Vegetarian, no nuts")}
            </div>
            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea rows={2} placeholder="Arrives a day early, VIP" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                {traveller ? "Cancel" : "Done"}
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {traveller ? "Save" : "Add traveller"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
