import { useState } from "react";
import { useQuery } from "convex/react";
import { BedDouble, ClipboardPaste, Download, Plus, UserPlus, UsersRound } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import BulkAddDialog from "@/components/travellers/bulk-add-dialog.tsx";
import RoomDialog, { type EditableRoom } from "@/components/travellers/room-dialog.tsx";
import RoomingBoard from "@/components/travellers/rooming-board.tsx";
import TravellerDialog from "@/components/travellers/traveller-dialog.tsx";
import TravellerList, { type TravellerData } from "@/components/travellers/traveller-list.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Empty,
  EmptyContent,
  EmptyDescription,
  EmptyHeader,
  EmptyMedia,
  EmptyTitle,
} from "@/components/ui/empty.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs.tsx";
import { ROOM_TYPE_LABELS, downloadCsv } from "@/lib/travellers.ts";
import { cn } from "@/lib/utils.ts";

type DialogState =
  | { kind: "none" }
  | { kind: "traveller"; traveller?: Doc<"travellers"> }
  | { kind: "bulk" }
  | { kind: "room"; room?: EditableRoom };

function Stat({ label, value, warn }: { label: string; value: string; warn?: boolean }) {
  return (
    <div className="space-y-0.5 bg-card px-4 py-3">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={cn("font-display text-xl font-semibold", warn && "text-[#b05300] dark:text-[#ffa257]")}>
        {value}
      </p>
    </div>
  );
}

function exportRoomingList(data: TravellerData, reference: string) {
  const rows = data.travellers.map((t) => ({
    "Last name": t.lastName,
    "First name": t.firstName,
    Hotel: t.room?.hotel ?? "",
    "Room number": t.room?.roomNumber ?? "",
    "Room type": t.room ? ROOM_TYPE_LABELS[t.room.roomType] : "Unassigned",
    "Requested room": ROOM_TYPE_LABELS[t.roomPreference],
    "Sharing with": t.sharingWith ?? "",
    "Dietary needs": t.dietaryRequirements ?? "",
    Email: t.email ?? "",
    Phone: t.phone ?? "",
    Notes: t.notes ?? "",
  }));
  // Group by room so the hotel sees roommates next to each other.
  rows.sort(
    (a, b) =>
      a.Hotel.localeCompare(b.Hotel) ||
      a["Room number"].localeCompare(b["Room number"], undefined, { numeric: true }) ||
      a["Last name"].localeCompare(b["Last name"]),
  );
  downloadCsv(`${reference}-rooming-list.csv`, rows);
}

export default function TravellersPanel({
  bookingId,
  reference,
}: {
  bookingId: Id<"bookings">;
  reference: string;
}) {
  const data = useQuery(api.travellers.get, { bookingId });
  const [dialog, setDialog] = useState<DialogState>({ kind: "none" });
  const [view, setView] = useState("travellers");
  const close = (open: boolean) => !open && setDialog({ kind: "none" });

  if (data === undefined) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-20 w-full" />
        {Array.from({ length: 4 }).map((_, i) => (
          <Skeleton key={i} className="h-14 w-full" />
        ))}
      </div>
    );
  }

  const count = data.travellers.length;
  const lastHotel = data.rooms.at(-1)?.supplier ?? null;

  return (
    <div className="space-y-4">
      <Card className="gap-0 overflow-hidden py-0">
        <div className="grid grid-cols-2 gap-px bg-border sm:grid-cols-4">
          <Stat
            label="Named travellers"
            value={`${count} / ${data.expectedPax}`}
            warn={count !== data.expectedPax}
          />
          <Stat label="Without a room" value={String(data.unassignedCount)} warn={data.unassignedCount > 0} />
          <Stat label="Rooms" value={String(data.rooms.length)} />
          <Stat label="Beds" value={String(data.bedCount)} warn={data.bedCount > 0 && data.bedCount < count} />
        </div>
      </Card>

      {count === 0 && data.rooms.length === 0 ? (
        <Empty className="border">
          <EmptyHeader>
            <EmptyMedia variant="icon">
              <UsersRound />
            </EmptyMedia>
            <EmptyTitle>No travellers yet</EmptyTitle>
            <EmptyDescription>
              Add the group one by one, or paste the name list the client sent.
            </EmptyDescription>
          </EmptyHeader>
          <EmptyContent className="flex-row justify-center gap-2">
            <Button size="sm" className="cursor-pointer" onClick={() => setDialog({ kind: "bulk" })}>
              <ClipboardPaste className="size-4" /> Paste list
            </Button>
            <Button
              size="sm"
              variant="secondary"
              className="cursor-pointer"
              onClick={() => setDialog({ kind: "traveller" })}
            >
              <UserPlus className="size-4" /> Add one
            </Button>
          </EmptyContent>
        </Empty>
      ) : (
        <Tabs value={view} onValueChange={setView} className="gap-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <TabsList>
              <TabsTrigger value="travellers" className="cursor-pointer">
                Travellers
              </TabsTrigger>
              <TabsTrigger value="rooming" className="cursor-pointer">
                Rooming list
              </TabsTrigger>
            </TabsList>
            <div className="flex flex-wrap gap-2">
              <Button
                variant="ghost"
                size="sm"
                className="cursor-pointer"
                disabled={count === 0}
                onClick={() => exportRoomingList(data, reference)}
              >
                <Download className="size-4" /> Export
              </Button>
              {view === "travellers" ? (
                <>
                  <Button
                    variant="secondary"
                    size="sm"
                    className="cursor-pointer"
                    disabled={data.isFull}
                    onClick={() => setDialog({ kind: "bulk" })}
                  >
                    <ClipboardPaste className="size-4" /> Paste list
                  </Button>
                  <Button
                    size="sm"
                    className="cursor-pointer"
                    disabled={data.isFull}
                    onClick={() => setDialog({ kind: "traveller" })}
                  >
                    <UserPlus className="size-4" /> Add traveller
                  </Button>
                </>
              ) : (
                <Button
                  size="sm"
                  className="cursor-pointer"
                  disabled={data.roomsFull}
                  onClick={() => setDialog({ kind: "room" })}
                >
                  <Plus className="size-4" /> Add rooms
                </Button>
              )}
            </div>
          </div>
          <TabsContent value="travellers">
            {count === 0 ? (
              <p className="text-sm text-muted-foreground">No travellers yet. Add or paste the name list.</p>
            ) : (
              <TravellerList data={data} onEdit={(traveller) => setDialog({ kind: "traveller", traveller })} />
            )}
          </TabsContent>
          <TabsContent value="rooming">
            {data.rooms.length === 0 ? (
              <Empty className="border">
                <EmptyHeader>
                  <EmptyMedia variant="icon">
                    <BedDouble />
                  </EmptyMedia>
                  <EmptyTitle>No rooms yet</EmptyTitle>
                  <EmptyDescription>
                    Add the room block from the hotel, then place each traveller in a room.
                  </EmptyDescription>
                </EmptyHeader>
                <EmptyContent>
                  <Button size="sm" className="cursor-pointer" onClick={() => setDialog({ kind: "room" })}>
                    <Plus className="size-4" /> Add rooms
                  </Button>
                </EmptyContent>
              </Empty>
            ) : (
              <RoomingBoard data={data} onEdit={(room) => setDialog({ kind: "room", room })} />
            )}
          </TabsContent>
        </Tabs>
      )}

      {dialog.kind === "traveller" ? (
        <TravellerDialog
          key={dialog.traveller?._id ?? "new"}
          open
          onOpenChange={close}
          bookingId={bookingId}
          traveller={dialog.traveller}
        />
      ) : null}
      {dialog.kind === "bulk" ? <BulkAddDialog open onOpenChange={close} bookingId={bookingId} /> : null}
      {dialog.kind === "room" ? (
        <RoomDialog
          key={dialog.room?._id ?? "new"}
          open
          onOpenChange={close}
          bookingId={bookingId}
          room={dialog.room}
          defaultSupplier={lastHotel}
        />
      ) : null}
    </div>
  );
}
