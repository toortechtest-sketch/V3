import { useState } from "react";
import { Link } from "react-router-dom";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { BedDouble, Check, MoreHorizontal, Pencil, Plus, Trash2, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import type { EditableRoom } from "@/components/travellers/room-dialog.tsx";
import type { TravellerData } from "@/components/travellers/traveller-list.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { ROOM_TYPE_LABELS, fullName } from "@/lib/travellers.ts";
import { cn } from "@/lib/utils.ts";

type RoomView = TravellerData["rooms"][number];
type TravellerView = TravellerData["travellers"][number];

function useAssign() {
  const assign = useMutation(api.travellers.assign);
  return (travellerId: Id<"travellers">, roomId: Id<"rooms"> | null) =>
    assign({ travellerId, roomId }).catch((error: unknown) => toast.error(errorMessage(error)));
}

/** Lists unassigned travellers, requested room type first, to drop into a room. */
function AddGuest({ room, unassigned }: { room: RoomView; unassigned: TravellerView[] }) {
  const [open, setOpen] = useState(false);
  const assign = useAssign();
  const matching = unassigned.filter((t) => t.roomPreference === room.roomType);
  const others = unassigned.filter((t) => t.roomPreference !== room.roomType);
  const item = (t: TravellerView) => (
    <CommandItem
      key={t._id}
      value={`${fullName(t)} ${t._id}`}
      className="cursor-pointer"
      onSelect={() => {
        setOpen(false);
        void assign(t._id, room._id);
      }}
    >
      <span className="min-w-0 flex-1 truncate">{fullName(t)}</span>
      <span className="text-xs text-muted-foreground">
        {t.sharingWith ? `with ${t.sharingWith}` : ROOM_TYPE_LABELS[t.roomPreference]}
      </span>
    </CommandItem>
  );
  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <button
          type="button"
          className="flex w-full cursor-pointer items-center gap-2 rounded-md border border-dashed px-2.5 py-1.5 text-sm text-muted-foreground transition-colors hover:border-primary hover:text-primary"
        >
          <Plus className="size-3.5" /> Add guest
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-72 p-0" align="start">
        <Command>
          <CommandInput placeholder="Search travellers" />
          <CommandList>
            <CommandEmpty>Everyone has a room.</CommandEmpty>
            {matching.length ? (
              <CommandGroup heading={`Asked for ${ROOM_TYPE_LABELS[room.roomType].toLowerCase()}`}>
                {matching.map(item)}
              </CommandGroup>
            ) : null}
            {others.length ? <CommandGroup heading="Everyone else">{others.map(item)}</CommandGroup> : null}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}

function RoomCard({
  room,
  unassigned,
  onEdit,
}: {
  room: RoomView;
  unassigned: TravellerView[];
  onEdit: (room: EditableRoom) => void;
}) {
  const remove = useMutation(api.travellers.removeRoom);
  const assign = useAssign();
  const { occupants, ...doc } = room;
  const free = room.capacity - occupants.length;
  return (
    <Card className="gap-0 py-0">
      <div className="flex items-start gap-3 border-b px-4 py-3">
        <div
          className={cn(
            "flex size-9 shrink-0 items-center justify-center rounded-lg",
            free === 0 ? "bg-primary text-primary-foreground" : "bg-secondary text-primary",
          )}
        >
          <BedDouble className="size-4" />
        </div>
        <button type="button" onClick={() => onEdit(doc)} className="min-w-0 flex-1 cursor-pointer text-left">
          <p className="truncate font-medium">
            {room.roomNumber ? `Room ${room.roomNumber}` : "No number yet"}
          </p>
          <p className="truncate text-xs text-muted-foreground">
            {ROOM_TYPE_LABELS[room.roomType]} · sleeps {room.capacity}
          </p>
        </button>
        <span
          className={cn(
            "shrink-0 rounded px-1.5 py-0.5 text-[11px] font-medium",
            room.status === "confirmed"
              ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-400"
              : "bg-muted text-muted-foreground",
          )}
        >
          {room.status === "confirmed" ? (
            <span className="flex items-center gap-1">
              <Check className="size-3" /> Confirmed
            </span>
          ) : (
            "Tentative"
          )}
        </span>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              size="icon"
              variant="ghost"
              aria-label="Room options"
              className="-mt-1 -mr-2 size-8 shrink-0 cursor-pointer text-muted-foreground"
            >
              <MoreHorizontal className="size-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem className="cursor-pointer" onSelect={() => onEdit(doc)}>
              <Pencil /> Edit room
            </DropdownMenuItem>
            <DropdownMenuItem
              variant="destructive"
              className="cursor-pointer"
              onSelect={() => {
                remove({ id: room._id }).then(
                  () => toast.success("Room removed, guests moved to unassigned"),
                  (error: unknown) => toast.error(errorMessage(error)),
                );
              }}
            >
              <Trash2 /> Remove room
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </div>
      <div className="space-y-1.5 p-3">
        {occupants.map((t) => (
          <div key={t._id} className="group flex items-center gap-2 rounded-md bg-muted/60 px-2.5 py-1.5 text-sm">
            <span className="min-w-0 flex-1 truncate">{fullName(t)}</span>
            <button
              type="button"
              aria-label={`Take ${fullName(t)} out of this room`}
              className="cursor-pointer text-muted-foreground hover:text-destructive"
              onClick={() => void assign(t._id, null)}
            >
              <X className="size-3.5" />
            </button>
          </div>
        ))}
        {free > 0 && unassigned.length > 0 ? <AddGuest room={room} unassigned={unassigned} /> : null}
        {free > 0 && unassigned.length === 0 ? (
          <p className="px-1 py-1 text-xs text-muted-foreground">
            {free} bed{free === 1 ? "" : "s"} free
          </p>
        ) : null}
      </div>
    </Card>
  );
}

export default function RoomingBoard({
  data,
  onEdit,
}: {
  data: TravellerData;
  onEdit: (room: EditableRoom) => void;
}) {
  const unassigned = data.travellers.filter((t) => !t.room);
  // Rooms arrive sorted by hotel, so grouping keeps that order.
  const groups = new Map<string, { hotel: RoomView["supplier"]; rooms: RoomView[] }>();
  for (const room of data.rooms) {
    const key = room.supplier?._id ?? "none";
    const group = groups.get(key) ?? { hotel: room.supplier, rooms: [] };
    group.rooms.push(room);
    groups.set(key, group);
  }

  return (
    <div className="space-y-6">
      {[...groups.entries()].map(([key, group]) => {
        const guests = group.rooms.reduce((n, r) => n + r.occupants.length, 0);
        return (
          <section key={key} className="space-y-3">
            <div className="flex flex-wrap items-baseline justify-between gap-2">
              {group.hotel ? (
                <Link
                  to={`/suppliers/${group.hotel._id}`}
                  className="cursor-pointer font-display text-lg font-semibold hover:text-primary"
                >
                  {group.hotel.name}
                </Link>
              ) : (
                <p className="font-display text-lg font-semibold text-muted-foreground">Hotel not chosen</p>
              )}
              <p className="font-mono text-xs text-muted-foreground">
                {group.rooms.length} room{group.rooms.length === 1 ? "" : "s"} · {guests} guest
                {guests === 1 ? "" : "s"}
              </p>
            </div>
            <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
              {group.rooms.map((room) => (
                <RoomCard key={room._id} room={room} unassigned={unassigned} onEdit={onEdit} />
              ))}
            </div>
          </section>
        );
      })}
    </div>
  );
}
