import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import FinanceDialog, { TextField } from "@/components/finance/finance-dialog.tsx";
import { Form } from "@/components/ui/form.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { isPositiveAmount } from "@/lib/finance.ts";
import { formatMoney } from "@/lib/quotes.ts";

const schema = z.object({
  value: z.string().refine((v) => v === "" || isPositiveAmount(v), {
    message: "Enter an amount above 0, or leave empty",
  }),
});

type FormValues = z.infer<typeof schema>;

export default function ValueDialog({
  open,
  onOpenChange,
  bookingId,
  currency,
  quoteSell,
  current,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  currency: string;
  quoteSell: number;
  current?: number;
}) {
  const save = useMutation(api.finance.setContractValue);
  const [saving, setSaving] = useState(false);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { value: current === undefined ? "" : String(current) },
  });

  const onSubmit = async (v: FormValues) => {
    setSaving(true);
    try {
      await save({ bookingId, contractValue: v.value === "" ? undefined : Number(v.value) });
      toast.success("Package value saved");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Form {...form}>
      <FinanceDialog
        open={open}
        onOpenChange={onOpenChange}
        title="Package value"
        description={`The agreed price the payment schedule is based on. Leave empty to follow the quote (${formatMoney(quoteSell, currency)}).`}
        saving={saving}
        onSubmit={form.handleSubmit(onSubmit)}
      >
        <TextField
          control={form.control}
          name="value"
          label={`Agreed value (${currency})`}
          placeholder={String(quoteSell || 25000)}
          type="number"
          className="sm:col-span-2"
        />
      </FinanceDialog>
    </Form>
  );
}
