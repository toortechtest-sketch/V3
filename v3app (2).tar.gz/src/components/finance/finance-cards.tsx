import { useMutation } from "convex/react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import {
  CalendarClock,
  FileMinus,
  FileText,
  MoreHorizontal,
  Pencil,
  Plus,
  ReceiptText,
  Trash2,
  Wallet,
} from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import type { EditableInstallment } from "@/components/finance/installment-dialog.tsx";
import type { OpenInvoice } from "@/components/finance/payment-dialog.tsx";
import { Badge } from "@/components/ui/badge.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { METHOD_LABELS, isOverdue, todayKey } from "@/lib/finance.ts";
import { formatMoney } from "@/lib/quotes.ts";
import { cn } from "@/lib/utils.ts";
import type { Finance } from "./finance-panel.tsx";

const day = (d: string) => format(parseISO(d), "d MMM yyyy");

const run = (promise: Promise<unknown>, success: string) =>
  promise.then(
    () => toast.success(success),
    (error: unknown) => toast.error(errorMessage(error)),
  );

function SectionCard({
  icon: Icon,
  title,
  action,
  children,
}: {
  icon: typeof Wallet;
  title: string;
  action?: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <Card className="gap-0 py-0">
      <div className="flex items-center gap-3 border-b px-4 py-3 sm:px-5">
        <div className="flex size-8 shrink-0 items-center justify-center rounded-lg bg-secondary text-primary">
          <Icon className="size-4" />
        </div>
        <p className="min-w-0 flex-1 font-display text-lg font-semibold">{title}</p>
        {action}
      </div>
      <div className="divide-y px-4 sm:px-5">{children}</div>
    </Card>
  );
}

function EmptyRow({ children }: { children: React.ReactNode }) {
  return <p className="py-6 text-center text-sm text-muted-foreground">{children}</p>;
}

function RowMenu({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button
          size="icon"
          variant="ghost"
          aria-label={`Options for ${label}`}
          className="size-8 cursor-pointer text-muted-foreground"
        >
          <MoreHorizontal className="size-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">{children}</DropdownMenuContent>
    </DropdownMenu>
  );
}

export function ScheduleCard({
  finance,
  bookingId,
  locked,
  onAdd,
  onEdit,
}: {
  finance: Finance;
  bookingId: Id<"bookings">;
  locked: boolean;
  onAdd: () => void;
  onEdit: (installment: EditableInstallment) => void;
}) {
  const applyStandard = useMutation(api.finance.applyStandardSchedule);
  const invoice = useMutation(api.finance.invoiceInstallment);
  const remove = useMutation(api.finance.removeInstallment);
  const { currency, installments } = finance;
  const totalPercent = installments.reduce((s, i) => s + i.percent, 0);

  return (
    <SectionCard
      icon={CalendarClock}
      title="Payment schedule"
      action={
        <Button
          size="sm"
          variant="secondary"
          className="shrink-0 cursor-pointer"
          disabled={locked || finance.limits.installmentsFull}
          onClick={onAdd}
        >
          <Plus className="size-4" /> <span className="hidden sm:inline">Add</span>
        </Button>
      }
    >
      {installments.length === 0 ? (
        <div className="flex flex-col items-center gap-3 py-6 text-center">
          <p className="text-sm text-muted-foreground">
            Split the package value into a deposit and balance.
          </p>
          <Button
            size="sm"
            className="cursor-pointer"
            disabled={locked}
            onClick={() =>
              run(applyStandard({ bookingId, today: todayKey() }), "Standard schedule added")
            }
          >
            Use 30% deposit, 70% balance
          </Button>
        </div>
      ) : (
        <>
          {installments.map((i) => {
            const isLate = !i.invoiceId && i.dueDate < todayKey();
            return (
              <div key={i._id} className="flex items-center gap-3 py-3">
                <div className="min-w-0 flex-1">
                  <p className="truncate font-medium">{i.label}</p>
                  <p className={cn("text-xs text-muted-foreground", isLate && "text-destructive")}>
                    {i.percent}% · due {day(i.dueDate)}
                  </p>
                </div>
                <p className="font-mono text-sm font-medium">{formatMoney(i.amount, currency)}</p>
                {i.invoiceNumber ? (
                  <Badge variant="secondary" className="font-mono">
                    {i.invoiceNumber}
                  </Badge>
                ) : (
                  <Button
                    size="sm"
                    variant="secondary"
                    className="cursor-pointer"
                    disabled={locked}
                    onClick={() =>
                      run(invoice({ id: i._id, issueDate: todayKey() }), `${i.label} invoiced`)
                    }
                  >
                    <FileText className="size-4" />
                    <span className="hidden sm:inline">Invoice</span>
                  </Button>
                )}
                {locked || i.invoiceId ? (
                  <span className="size-8" />
                ) : (
                  <RowMenu label={i.label}>
                    <DropdownMenuItem className="cursor-pointer" onSelect={() => onEdit(i)}>
                      <Pencil /> Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      variant="destructive"
                      className="cursor-pointer"
                      onSelect={() => run(remove({ id: i._id }), "Instalment removed")}
                    >
                      <Trash2 /> Remove
                    </DropdownMenuItem>
                  </RowMenu>
                )}
              </div>
            );
          })}
          {totalPercent !== 100 ? (
            <p className="py-2.5 text-xs text-muted-foreground">
              Instalments add up to {totalPercent}% of the package value.
            </p>
          ) : null}
        </>
      )}
    </SectionCard>
  );
}

export function InvoicesCard({
  finance,
  locked,
  onNew,
  onPay,
}: {
  finance: Finance;
  locked: boolean;
  onNew: (kind: "invoice" | "credit_note") => void;
  onPay: (invoice: OpenInvoice) => void;
}) {
  const voidInvoice = useMutation(api.finance.voidInvoice);
  const { currency, invoices } = finance;
  const today = todayKey();

  return (
    <SectionCard
      icon={ReceiptText}
      title="Invoices"
      action={
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button
              size="sm"
              variant="secondary"
              className="shrink-0 cursor-pointer"
              disabled={finance.limits.invoicesFull}
            >
              <Plus className="size-4" /> <span className="hidden sm:inline">New</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem
              className="cursor-pointer"
              disabled={locked}
              onSelect={() => onNew("invoice")}
            >
              <FileText /> Invoice
            </DropdownMenuItem>
            <DropdownMenuItem className="cursor-pointer" onSelect={() => onNew("credit_note")}>
              <FileMinus /> Credit note
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      }
    >
      {invoices.length === 0 ? (
        <EmptyRow>No invoices yet. Invoice an instalment or create one.</EmptyRow>
      ) : (
        invoices.map((inv) => {
          const isCredit = inv.kind === "credit_note";
          const isVoid = inv.status === "void";
          const overdue = isOverdue(inv, inv.balance, today);
          return (
            <div key={inv._id} className="flex items-center gap-3 py-3">
              <div className="min-w-0 flex-1 space-y-0.5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="font-mono text-xs text-muted-foreground">{inv.number}</span>
                  {isVoid ? (
                    <Badge variant="secondary">Void</Badge>
                  ) : isCredit ? (
                    <Badge variant="secondary">Credit note</Badge>
                  ) : inv.balance.isPaid ? (
                    <Badge className="bg-[#0f9f6e] text-white">Paid</Badge>
                  ) : overdue ? (
                    <Badge variant="destructive">Overdue</Badge>
                  ) : inv.balance.paid > 0 ? (
                    <Badge className="bg-[#FFB800] text-[#0b1b2b]">Part paid</Badge>
                  ) : (
                    <Badge variant="secondary">Open</Badge>
                  )}
                </div>
                <p className={cn("truncate font-medium", isVoid && "text-muted-foreground line-through")}>
                  {inv.label}
                </p>
                <p className="text-xs text-muted-foreground">
                  Issued {day(inv.issueDate)}
                  {inv.dueDate ? ` · due ${day(inv.dueDate)}` : ""}
                  {!isCredit && !isVoid && inv.balance.paid > 0 && !inv.balance.isPaid
                    ? ` · ${formatMoney(inv.balance.open, currency)} open`
                    : ""}
                </p>
              </div>
              <p className={cn("font-mono text-sm font-medium", isVoid && "text-muted-foreground")}>
                {isCredit ? "−" : ""}
                {formatMoney(inv.amount, currency)}
              </p>
              {locked || isVoid ? (
                <span className="size-8" />
              ) : (
                <RowMenu label={inv.number}>
                  {!isCredit && inv.balance.open > 0 ? (
                    <DropdownMenuItem
                      className="cursor-pointer"
                      onSelect={() =>
                        onPay({ _id: inv._id, number: inv.number, label: inv.label, open: inv.balance.open })
                      }
                    >
                      <Wallet /> Record payment
                    </DropdownMenuItem>
                  ) : null}
                  <DropdownMenuItem
                    variant="destructive"
                    className="cursor-pointer"
                    onSelect={() => run(voidInvoice({ id: inv._id }), `${inv.number} voided`)}
                  >
                    <Trash2 /> Void
                  </DropdownMenuItem>
                </RowMenu>
              )}
            </div>
          );
        })
      )}
    </SectionCard>
  );
}

export function PaymentsCard({
  finance,
  locked,
  onRecord,
}: {
  finance: Finance;
  locked: boolean;
  onRecord: () => void;
}) {
  const remove = useMutation(api.finance.removePayment);
  const { currency, payments } = finance;

  return (
    <SectionCard
      icon={Wallet}
      title="Payments received"
      action={
        <Button
          size="sm"
          variant="secondary"
          className="shrink-0 cursor-pointer"
          disabled={locked || finance.limits.paymentsFull}
          onClick={onRecord}
        >
          <Plus className="size-4" /> <span className="hidden sm:inline">Record</span>
        </Button>
      }
    >
      {payments.length === 0 ? (
        <EmptyRow>No payments received yet.</EmptyRow>
      ) : (
        payments.map((p) => (
          <div key={p._id} className="flex items-center gap-3 py-3">
            <div className="min-w-0 flex-1">
              <p className="truncate font-medium">
                {METHOD_LABELS[p.method]}
                {p.reference ? (
                  <span className="pl-2 font-mono text-xs text-muted-foreground">{p.reference}</span>
                ) : null}
              </p>
              <p className="text-xs text-muted-foreground">
                {day(p.receivedDate)}
                {p.invoiceNumber ? ` · for ${p.invoiceNumber}` : " · not matched"}
              </p>
            </div>
            <p className="font-mono text-sm font-medium text-[#0f9f6e] dark:text-[#34d399]">
              +{formatMoney(p.amount, currency)}
            </p>
            {locked ? (
              <span className="size-8" />
            ) : (
              <RowMenu label="payment">
                <DropdownMenuItem
                  variant="destructive"
                  className="cursor-pointer"
                  onSelect={() => run(remove({ id: p._id }), "Payment removed")}
                >
                  <Trash2 /> Remove
                </DropdownMenuItem>
              </RowMenu>
            )}
          </div>
        ))
      )}
    </SectionCard>
  );
}
