import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import FinanceDialog, { TextField } from "@/components/finance/finance-dialog.tsx";
import { Form } from "@/components/ui/form.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { formatMoney } from "@/lib/quotes.ts";

const schema = z.object({
  label: z.string().trim().min(1, "Add a label").max(100),
  percent: z
    .string()
    .refine((v) => Number(v) > 0 && Number(v) <= 100, { message: "Between 0 and 100" }),
  dueDate: z.string().min(1, "Pick a date"),
});

type FormValues = z.infer<typeof schema>;

export type EditableInstallment = {
  _id: Id<"paymentInstallments">;
  label: string;
  percent: number;
  dueDate: string;
};

export default function InstallmentDialog({
  open,
  onOpenChange,
  bookingId,
  installment,
  contractValue,
  currency,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  installment?: EditableInstallment;
  contractValue: number;
  currency: string;
}) {
  const add = useMutation(api.finance.addInstallment);
  const update = useMutation(api.finance.updateInstallment);
  const [saving, setSaving] = useState(false);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      label: installment?.label ?? "",
      percent: installment ? String(installment.percent) : "",
      dueDate: installment?.dueDate ?? "",
    },
  });
  const percent = Number(useWatch({ control: form.control, name: "percent" })) || 0;

  const onSubmit = async (v: FormValues) => {
    setSaving(true);
    try {
      const fields = { label: v.label, percent: Number(v.percent), dueDate: v.dueDate };
      if (installment) await update({ id: installment._id, ...fields });
      else await add({ bookingId, ...fields });
      toast.success(installment ? "Instalment updated" : "Instalment added");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Form {...form}>
      <FinanceDialog
        open={open}
        onOpenChange={onOpenChange}
        title={installment ? "Edit instalment" : "Add instalment"}
        description={`${percent}% of the package value is ${formatMoney((contractValue * percent) / 100, currency)}.`}
        saving={saving}
        onSubmit={form.handleSubmit(onSubmit)}
      >
        <TextField
          control={form.control}
          name="label"
          label="Label"
          placeholder="Second payment"
          className="sm:col-span-2"
        />
        <TextField control={form.control} name="percent" label="Share %" placeholder="40" type="number" />
        <TextField control={form.control} name="dueDate" label="Due date" type="date" />
      </FinanceDialog>
    </Form>
  );
}
