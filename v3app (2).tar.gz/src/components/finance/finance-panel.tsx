import { useState } from "react";
import { useMutation, useQuery } from "convex/react";
import { format, parseISO } from "date-fns";
import { toast } from "sonner";
import { Lock, LockOpen, Pencil } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import InstallmentDialog, { type EditableInstallment } from "@/components/finance/installment-dialog.tsx";
import InvoiceDialog from "@/components/finance/invoice-dialog.tsx";
import PaymentDialog, { type OpenInvoice } from "@/components/finance/payment-dialog.tsx";
import ValueDialog from "@/components/finance/value-dialog.tsx";
import { InvoicesCard, PaymentsCard, ScheduleCard } from "@/components/finance/finance-cards.tsx";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog.tsx";
import { Button } from "@/components/ui/button.tsx";
import { Card } from "@/components/ui/card.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { formatMoney } from "@/lib/quotes.ts";
import { cn } from "@/lib/utils.ts";

function useFinance(bookingId: Id<"bookings">) {
  return useQuery(api.finance.get, { bookingId });
}
export type Finance = NonNullable<ReturnType<typeof useFinance>> & { bookingId: Id<"bookings"> };

type DialogState =
  | { kind: "none" }
  | { kind: "value" }
  | { kind: "installment"; installment?: EditableInstallment }
  | { kind: "invoice"; invoiceKind: "invoice" | "credit_note" }
  | { kind: "payment"; preselect?: OpenInvoice }
  | { kind: "lock" };

function Stat({ label, value, sub, tone }: { label: string; value: string; sub?: string; tone?: string }) {
  return (
    <div className="min-w-0 space-y-1 bg-card p-4 sm:p-5">
      <p className="text-xs text-muted-foreground">{label}</p>
      <p className={cn("truncate font-display text-xl font-semibold sm:text-2xl", tone)}>{value}</p>
      {sub ? <p className="truncate font-mono text-xs text-muted-foreground">{sub}</p> : null}
    </div>
  );
}

function Summary({ finance, onDialog }: { finance: Finance; onDialog: (d: DialogState) => void }) {
  const setLocked = useMutation(api.finance.setLocked);
  const { summary, currency, lock } = finance;
  const m = (n: number) => formatMoney(n, currency);
  const paidShare =
    summary.contractValue > 0 ? Math.min(100, (summary.received / summary.contractValue) * 100) : 0;

  const unlock = () =>
    setLocked({ bookingId: finance.bookingId, locked: false }).then(
      () => toast.success("Booking reopened"),
      (error: unknown) => toast.error(errorMessage(error)),
    );

  return (
    <Card className="gap-0 overflow-hidden py-0">
      <div className="flex flex-wrap items-center justify-between gap-3 bg-sidebar px-4 py-3 text-sidebar-foreground sm:px-5">
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 font-mono text-[11px] tracking-widest uppercase">
          <span className="text-sidebar-primary">Finance · {currency}</span>
          <span className="text-sidebar-foreground/70">
            {finance.contractValueIsCustom ? "Agreed value" : "Following quote"}
          </span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            size="sm"
            variant="ghost"
            disabled={lock !== null}
            className="h-7 cursor-pointer text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
            onClick={() => onDialog({ kind: "value" })}
          >
            <Pencil className="size-4" /> Value
          </Button>
          {lock ? (
            finance.canUnlock ? (
              <Button
                size="sm"
                variant="ghost"
                className="h-7 cursor-pointer text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
                onClick={unlock}
              >
                <LockOpen className="size-4" /> Reopen
              </Button>
            ) : null
          ) : (
            <Button
              size="sm"
              variant="ghost"
              className="h-7 cursor-pointer text-sidebar-foreground hover:bg-sidebar-accent hover:text-sidebar-accent-foreground"
              onClick={() => onDialog({ kind: "lock" })}
            >
              <Lock className="size-4" /> Lock
            </Button>
          )}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-px bg-border lg:grid-cols-4">
        <Stat label="Package value" value={m(summary.contractValue)} sub={`Quote ${m(finance.quoteSell)}`} />
        <Stat
          label="Invoiced"
          value={m(summary.netInvoiced)}
          sub={summary.credited > 0 ? `after ${m(summary.credited)} credit` : `${m(summary.toInvoice)} to invoice`}
        />
        <Stat label="Received" value={m(summary.received)} tone="text-[#0f9f6e] dark:text-[#34d399]" />
        <Stat
          label={summary.outstanding < 0 ? "Overpaid" : "Outstanding"}
          value={m(Math.abs(summary.outstanding))}
          sub="on issued invoices"
          tone={summary.outstanding > 0 ? "text-primary" : undefined}
        />
      </div>
      <div className="h-1.5 bg-muted">
        <div className="h-full bg-[#0f9f6e] transition-all" style={{ width: `${paidShare}%` }} />
      </div>
      {lock ? (
        <p className="flex items-center gap-2 bg-[#FFB800]/12 px-4 py-2.5 text-sm text-[#8a6400] sm:px-5 dark:text-[#FFB800]">
          <Lock className="size-4 shrink-0" />
          Locked for full payment by {lock.lockedByName} on {format(parseISO(lock.lockedAt), "d MMM yyyy")}.
          Quote, reservations and payments are read-only; credit notes can still be added.
        </p>
      ) : null}
    </Card>
  );
}

export default function FinancePanel({ bookingId }: { bookingId: Id<"bookings"> }) {
  const data = useFinance(bookingId);
  const setLocked = useMutation(api.finance.setLocked);
  const [dialog, setDialog] = useState<DialogState>({ kind: "none" });
  const close = (open: boolean) => !open && setDialog({ kind: "none" });

  if (data === undefined) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-44 w-full" />
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-32 w-full" />
        ))}
      </div>
    );
  }

  const finance = { ...data, bookingId };
  const locked = finance.lock !== null;
  const openInvoices: OpenInvoice[] = finance.invoices
    .filter((i) => i.kind === "invoice" && i.status === "issued" && i.balance.open > 0)
    .map((i) => ({ _id: i._id, number: i.number, label: i.label, open: i.balance.open }));

  const lock = () =>
    setLocked({ bookingId, locked: true }).then(
      () => toast.success("Booking locked for full payment"),
      (error: unknown) => toast.error(errorMessage(error)),
    );

  return (
    <div className="space-y-4">
      <Summary finance={finance} onDialog={setDialog} />
      <div className="grid gap-4 lg:grid-cols-2">
        <div className="space-y-4">
          <ScheduleCard
            finance={finance}
            bookingId={bookingId}
            locked={locked}
            onAdd={() => setDialog({ kind: "installment" })}
            onEdit={(installment) => setDialog({ kind: "installment", installment })}
          />
          <PaymentsCard finance={finance} locked={locked} onRecord={() => setDialog({ kind: "payment" })} />
        </div>
        <InvoicesCard
          finance={finance}
          locked={locked}
          onNew={(invoiceKind) => setDialog({ kind: "invoice", invoiceKind })}
          onPay={(preselect) => setDialog({ kind: "payment", preselect })}
        />
      </div>

      {dialog.kind === "value" ? (
        <ValueDialog
          open
          onOpenChange={close}
          bookingId={bookingId}
          currency={finance.currency}
          quoteSell={finance.quoteSell}
          current={finance.contractValueIsCustom ? finance.contractValue : undefined}
        />
      ) : null}
      {dialog.kind === "installment" ? (
        <InstallmentDialog
          open
          onOpenChange={close}
          bookingId={bookingId}
          installment={dialog.installment}
          contractValue={finance.contractValue}
          currency={finance.currency}
        />
      ) : null}
      {dialog.kind === "invoice" ? (
        <InvoiceDialog
          open
          onOpenChange={close}
          bookingId={bookingId}
          kind={dialog.invoiceKind}
          currency={finance.currency}
        />
      ) : null}
      {dialog.kind === "payment" ? (
        <PaymentDialog
          open
          onOpenChange={close}
          bookingId={bookingId}
          currency={finance.currency}
          openInvoices={openInvoices}
          preselect={dialog.preselect}
        />
      ) : null}
      <AlertDialog open={dialog.kind === "lock"} onOpenChange={close}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Lock this booking for full payment?</AlertDialogTitle>
            <AlertDialogDescription>
              The quote, reservations, schedule, invoices and payments become read-only. You can
              still add credit notes. Only an owner or global manager can reopen it.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="cursor-pointer">Cancel</AlertDialogCancel>
            <AlertDialogAction className="cursor-pointer" onClick={lock}>
              Lock booking
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
