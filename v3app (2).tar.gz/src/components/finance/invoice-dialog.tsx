import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import FinanceDialog, { TextField } from "@/components/finance/finance-dialog.tsx";
import { Form } from "@/components/ui/form.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { isPositiveAmount, todayKey } from "@/lib/finance.ts";

const schema = z
  .object({
    label: z.string().trim().min(1, "Add a description").max(200),
    amount: z.string().refine(isPositiveAmount, { message: "Enter an amount above 0" }),
    issueDate: z.string().min(1, "Pick a date"),
    dueDate: z.string(),
    notes: z.string().trim().max(2000),
  })
  .refine((v) => !v.dueDate || v.dueDate >= v.issueDate, {
    message: "Can't be before the issue date",
    path: ["dueDate"],
  });

type FormValues = z.infer<typeof schema>;

export default function InvoiceDialog({
  open,
  onOpenChange,
  bookingId,
  kind,
  currency,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  kind: "invoice" | "credit_note";
  currency: string;
}) {
  const create = useMutation(api.finance.createInvoice);
  const [saving, setSaving] = useState(false);
  const isCredit = kind === "credit_note";
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: { label: "", amount: "", issueDate: todayKey(), dueDate: "", notes: "" },
  });

  const onSubmit = async (v: FormValues) => {
    setSaving(true);
    try {
      await create({
        bookingId,
        kind,
        label: v.label,
        amount: Number(v.amount),
        issueDate: v.issueDate,
        dueDate: isCredit ? undefined : v.dueDate || undefined,
        notes: v.notes || undefined,
      });
      toast.success(isCredit ? "Credit note issued" : "Invoice issued");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Form {...form}>
      <FinanceDialog
        open={open}
        onOpenChange={onOpenChange}
        title={isCredit ? "New credit note" : "New invoice"}
        description={
          isCredit
            ? "Reduces what the client owes. Allowed even when the booking is locked."
            : "A number is given automatically when you issue it."
        }
        saving={saving}
        submitLabel="Issue"
        onSubmit={form.handleSubmit(onSubmit)}
      >
        <TextField
          control={form.control}
          name="label"
          label="Description"
          placeholder={isCredit ? "Refund for cancelled dinner" : "Extra night for 4 rooms"}
          className="sm:col-span-2"
        />
        <TextField
          control={form.control}
          name="amount"
          label={`Amount (${currency})`}
          placeholder="1200"
          type="number"
          className="sm:col-span-2"
        />
        <TextField control={form.control} name="issueDate" label="Issue date" type="date" />
        {isCredit ? null : (
          <TextField control={form.control} name="dueDate" label="Due date" type="date" />
        )}
        <TextField
          control={form.control}
          name="notes"
          label="Notes"
          placeholder="Optional"
          className="sm:col-span-2"
        />
      </FinanceDialog>
    </Form>
  );
}
