import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import FinanceDialog, { TextField } from "@/components/finance/finance-dialog.tsx";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { METHOD_LABELS, PAYMENT_METHODS, isPositiveAmount, todayKey } from "@/lib/finance.ts";
import { formatMoney } from "@/lib/quotes.ts";

const NO_INVOICE = "none";

const schema = z.object({
  amount: z.string().refine(isPositiveAmount, { message: "Enter an amount above 0" }),
  receivedDate: z.string().min(1, "Pick a date"),
  method: z.enum(PAYMENT_METHODS),
  invoiceId: z.string(),
  reference: z.string().trim().max(100),
});

type FormValues = z.infer<typeof schema>;

export type OpenInvoice = { _id: Id<"invoices">; number: string; label: string; open: number };

export default function PaymentDialog({
  open,
  onOpenChange,
  bookingId,
  currency,
  openInvoices,
  preselect,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  bookingId: Id<"bookings">;
  currency: string;
  openInvoices: OpenInvoice[];
  preselect?: OpenInvoice;
}) {
  const record = useMutation(api.finance.recordPayment);
  const [saving, setSaving] = useState(false);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      amount: preselect ? String(preselect.open) : "",
      receivedDate: todayKey(),
      method: "bank_transfer",
      invoiceId: preselect?._id ?? NO_INVOICE,
      reference: "",
    },
  });

  const onSubmit = async (v: FormValues) => {
    setSaving(true);
    try {
      const invoice = openInvoices.find((i) => i._id === v.invoiceId);
      await record({
        bookingId,
        amount: Number(v.amount),
        receivedDate: v.receivedDate,
        method: v.method,
        invoiceId: invoice?._id,
        reference: v.reference || undefined,
      });
      toast.success("Payment recorded");
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Form {...form}>
      <FinanceDialog
        open={open}
        onOpenChange={onOpenChange}
        title="Record payment"
        description="Money received from the client."
        saving={saving}
        onSubmit={form.handleSubmit(onSubmit)}
      >
        <TextField
          control={form.control}
          name="amount"
          label={`Amount (${currency})`}
          placeholder="3000"
          type="number"
        />
        <TextField control={form.control} name="receivedDate" label="Received on" type="date" />
        <FormField
          control={form.control}
          name="method"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Method</FormLabel>
              <Select value={field.value} onValueChange={field.onChange}>
                <FormControl>
                  <SelectTrigger className="w-full cursor-pointer">
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  {PAYMENT_METHODS.map((m) => (
                    <SelectItem key={m} value={m} className="cursor-pointer">
                      {METHOD_LABELS[m]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormItem>
          )}
        />
        <TextField control={form.control} name="reference" label="Reference" placeholder="Bank ref." />
        <FormField
          control={form.control}
          name="invoiceId"
          render={({ field }) => (
            <FormItem className="sm:col-span-2">
              <FormLabel>For invoice</FormLabel>
              <Select value={field.value} onValueChange={field.onChange}>
                <FormControl>
                  <SelectTrigger className="w-full cursor-pointer">
                    <SelectValue />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value={NO_INVOICE} className="cursor-pointer">
                    Not matched to an invoice
                  </SelectItem>
                  {openInvoices.map((i) => (
                    <SelectItem key={i._id} value={i._id} className="cursor-pointer">
                      {i.number} · {i.label} · {formatMoney(i.open, currency)} open
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </FormItem>
          )}
        />
      </FinanceDialog>
    </Form>
  );
}
