import { cn } from "@/lib/utils.ts";

export const BRAND_EYES_SRC = "/brand/toor-eyes.svg";

/** Toor.tech eyes mark on its white rounded tile. */
export function BrandMark({ className }: { className?: string }) {
  return (
    <img
      src={BRAND_EYES_SRC}
      alt=""
      width={376}
      height={215}
      draggable={false}
      className={cn("h-auto shrink-0 rounded-md bg-white p-0.5", className)}
    />
  );
}

/** "Toor.tech" wordmark. `onDark` is for navy surfaces like the sidebar. */
export function BrandWordmark({
  onDark = false,
  className,
}: {
  onDark?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn(
        "font-brand font-bold leading-none tracking-[-0.045em]",
        onDark ? "text-white" : "text-[#0B1B2B] dark:text-white",
        className,
      )}
    >
      Toor<span className="text-[#FFB800]">.</span>
      <span
        className={
          onDark ? "text-[#00BDEB]" : "text-[#0754EA] dark:text-[#00BDEB]"
        }
      >
        tech
      </span>
    </span>
  );
}

export default function BrandLogo({
  onDark = false,
  className,
}: {
  onDark?: boolean;
  className?: string;
}) {
  return (
    <span
      className={cn("inline-flex items-center gap-2.5", className)}
      aria-label="Toor.tech"
    >
      <BrandMark className="w-9" />
      <BrandWordmark onDark={onDark} className="text-xl" />
    </span>
  );
}
