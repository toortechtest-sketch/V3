import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { Building2, User } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group.tsx";
import { CLIENT_KINDS } from "@/lib/clients.ts";
import { errorMessage } from "@/lib/errors.ts";
import CompanyPicker, { type CompanyOption } from "./company-picker.tsx";

const text = z.string().trim().max(500);

const schema = z.object({
  kind: z.enum(CLIENT_KINDS),
  name: z.string().trim().min(1, "Add the client name").max(200),
  contactName: text,
  email: z
    .string()
    .trim()
    .refine((v) => v === "" || z.email().safeParse(v).success, {
      message: "Enter a valid email",
    }),
  phone: text,
  address: text,
  city: text,
  country: text,
  taxId: text,
  notes: z.string().max(5000),
});

type FormValues = z.infer<typeof schema>;

export type EditableClient = Doc<"clients"> & {
  parent: { _id: Id<"clients">; name: string } | null;
};

function defaultsFrom(client?: EditableClient): FormValues {
  return {
    kind: client?.kind ?? "company",
    name: client?.name ?? "",
    contactName: client?.contactName ?? "",
    email: client?.email ?? "",
    phone: client?.phone ?? "",
    address: client?.address ?? "",
    city: client?.city ?? "",
    country: client?.country ?? "",
    taxId: client?.taxId ?? "",
    notes: client?.notes ?? "",
  };
}

const KIND_OPTIONS = [
  { value: "company", label: "Company", icon: Building2 },
  { value: "individual", label: "Person", icon: User },
] as const;

export default function ClientFormDialog({
  open,
  onOpenChange,
  client,
  defaultCompany,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Pass to edit; omit to create. */
  client?: EditableClient;
  /** Pre-fill a new person as working at this company. */
  defaultCompany?: CompanyOption;
}) {
  const navigate = useNavigate();
  const create = useMutation(api.clients.create);
  const update = useMutation(api.clients.update);
  const [saving, setSaving] = useState(false);
  const initialCompany = (): CompanyOption | null =>
    client?.parent
      ? { id: client.parent._id, name: client.parent.name }
      : (defaultCompany ?? null);
  const [company, setCompany] = useState<CompanyOption | null>(initialCompany);

  const initialValues = (): FormValues => ({
    ...defaultsFrom(client),
    ...(defaultCompany && !client ? { kind: "individual" as const } : {}),
  });

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: initialValues(),
  });
  const kind = useWatch({ control: form.control, name: "kind" });

  const handleOpenChange = (next: boolean) => {
    if (next) {
      form.reset(initialValues());
      setCompany(initialCompany());
    }
    onOpenChange(next);
  };

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    const optional = (s: string) => (s === "" ? undefined : s);
    const args = {
      kind: values.kind,
      name: values.name,
      parentClientId:
        values.kind === "individual" ? company?.id : undefined,
      contactName:
        values.kind === "company" ? optional(values.contactName) : undefined,
      email: optional(values.email),
      phone: optional(values.phone),
      address: optional(values.address),
      city: optional(values.city),
      country: optional(values.country),
      taxId: optional(values.taxId),
      notes: optional(values.notes),
    };
    try {
      if (client) {
        await update({ id: client._id, ...args });
        toast.success("Client updated");
        onOpenChange(false);
      } else {
        const id = await create(args);
        toast.success("Client added");
        onOpenChange(false);
        navigate(`/clients/${id}`);
      }
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const field = (
    name: Exclude<keyof FormValues, "kind" | "notes">,
    label: string,
    placeholder: string,
    type = "text",
  ) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field: f }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input type={type} placeholder={placeholder} {...f} />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {client ? `Edit ${client.name}` : "New client"}
          </DialogTitle>
          <DialogDescription>
            Clients are shared with the whole team.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-4 sm:grid-cols-2"
          >
            <FormField
              control={form.control}
              name="kind"
              render={({ field: f }) => (
                <FormItem className="sm:col-span-2">
                  <FormLabel>Type</FormLabel>
                  <ToggleGroup
                    type="single"
                    variant="outline"
                    value={f.value}
                    onValueChange={(v) => v && f.onChange(v)}
                    className="w-full"
                  >
                    {KIND_OPTIONS.map((o) => (
                      <ToggleGroupItem
                        key={o.value}
                        value={o.value}
                        className="flex-1 cursor-pointer data-[state=on]:bg-secondary data-[state=on]:text-primary"
                      >
                        <o.icon className="size-4" />
                        {o.label}
                      </ToggleGroupItem>
                    ))}
                  </ToggleGroup>
                </FormItem>
              )}
            />

            <div className="sm:col-span-2">
              {field(
                "name",
                kind === "company" ? "Company name" : "Full name",
                kind === "company" ? "Acme Corporation" : "Jane Smith",
              )}
            </div>

            {kind === "company" ? (
              <div className="sm:col-span-2">
                {field("contactName", "Main contact", "Jane Smith")}
              </div>
            ) : (
              <div className="space-y-2 sm:col-span-2">
                <p className="text-sm font-medium">Works at</p>
                <CompanyPicker
                  value={company}
                  onChange={setCompany}
                  excludeId={client?._id}
                />
              </div>
            )}

            {field("email", "Email", "jane@acme.com", "email")}
            {field("phone", "Phone", "+44 20 7946 0000", "tel")}
            <div className="sm:col-span-2">
              {field("address", "Address", "12 High Street")}
            </div>
            {field("city", "City", "London")}
            {field("country", "Country", "United Kingdom")}
            {field(
              "taxId",
              kind === "company" ? "VAT / tax ID" : "Tax ID",
              "GB123456789",
            )}
            <div className="hidden sm:block" />

            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="notes"
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={3}
                        placeholder="Preferences, billing details, history"
                        {...f}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {client ? "Save changes" : "Add client"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
