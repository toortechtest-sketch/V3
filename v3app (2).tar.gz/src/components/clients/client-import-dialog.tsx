import { useState } from "react";
import { useAction, useMutation } from "convex/react";
import { toast } from "sonner";
import { Building2, User } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { ClientDraft } from "@/convex/ai/normalize.ts";
import ImportDialog from "@/components/ai-import/import-dialog.tsx";
import SourceStep, { type ImportSource } from "@/components/ai-import/source-step.tsx";
import { DraftField, ReviewCard, ReviewToolbar } from "@/components/ai-import/review.tsx";
import { useDraftList } from "@/components/ai-import/use-draft-list.ts";
import { CLIENT_KINDS, KIND_LABELS } from "@/lib/clients.ts";
import { errorMessage } from "@/lib/errors.ts";
import { cn } from "@/lib/utils.ts";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export default function ClientImportDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const extract = useAction(api.ai.extract.extractClients);
  const create = useMutation(api.ai.save.createClients);
  const list = useDraftList<ClientDraft>();
  const [existing, setExisting] = useState<Set<string>>(new Set());
  const [creating, setCreating] = useState(false);

  const reviewing = list.rows.length > 0;
  const invalid = list.selected.some(
    (r) => !r.draft.name.trim() || (r.draft.email && !EMAIL_PATTERN.test(r.draft.email)),
  );

  const close = (next: boolean) => {
    if (!next) list.clear();
    onOpenChange(next);
  };

  const onExtract = async (source: ImportSource) => {
    const result = await extract({ source });
    const known = new Set(result.existing);
    setExisting(known);
    // Likely duplicates start unticked so they aren't created twice by accident.
    list.load(result.drafts, (d) => !known.has(d.name.toLowerCase()));
  };

  const onCreate = async () => {
    setCreating(true);
    try {
      const n = await create({ clients: list.selected.map((r) => r.draft) });
      toast.success(`${n} client${n === 1 ? "" : "s"} created`);
      close(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setCreating(false);
    }
  };

  const count = list.selected.length;

  return (
    <ImportDialog
      open={open}
      onOpenChange={close}
      title="Import clients with AI"
      description="Paste an email signature, contact list or spreadsheet rows, or give a company website. You'll review everything before it's saved."
      reviewing={reviewing}
      onBack={list.clear}
      createLabel={`Create ${count} client${count === 1 ? "" : "s"}`}
      canCreate={count > 0 && !invalid}
      creating={creating}
      onCreate={() => void onCreate()}
    >
      {reviewing ? (
        <div className="space-y-3 pb-1">
          <ReviewToolbar
            total={list.rows.length}
            selected={count}
            noun="clients"
            onToggleAll={list.toggleAll}
          />
          {list.rows.map(({ key, draft, selected }) => {
            const set = (patch: Partial<ClientDraft>) => list.update(key, patch);
            const duplicate = existing.has(draft.name.trim().toLowerCase());
            return (
              <ReviewCard
                key={key}
                checked={selected}
                onCheckedChange={(v) => list.toggle(key, v)}
                label={draft.name || "client"}
                warning={
                  !draft.name.trim()
                    ? "Add a name to create this client."
                    : draft.email && !EMAIL_PATTERN.test(draft.email)
                      ? "That email doesn't look right."
                      : duplicate
                        ? "A client with this name already exists."
                        : undefined
                }
              >
                <div className="flex flex-wrap items-end gap-2">
                  <div className="inline-flex gap-0.5 rounded-md bg-muted p-0.5">
                    {CLIENT_KINDS.map((k) => {
                      const Icon = k === "company" ? Building2 : User;
                      return (
                        <button
                          key={k}
                          type="button"
                          onClick={() => set({ kind: k })}
                          className={cn(
                            "flex cursor-pointer items-center gap-1 rounded px-2 py-1 text-xs text-muted-foreground",
                            draft.kind === k && "bg-background text-foreground shadow-sm",
                          )}
                        >
                          <Icon className="size-3" /> {KIND_LABELS[k]}
                        </button>
                      );
                    })}
                  </div>
                  <DraftField
                    label="Name"
                    value={draft.name}
                    onChange={(v) => set({ name: v ?? "" })}
                    className="min-w-48 flex-1"
                  />
                </div>
                <div className="grid gap-2 sm:grid-cols-3">
                  {draft.kind === "individual" ? (
                    <DraftField
                      label="Works at"
                      value={draft.companyName}
                      onChange={(v) => set({ companyName: v })}
                    />
                  ) : (
                    <DraftField
                      label="Contact person"
                      value={draft.contactName}
                      onChange={(v) => set({ contactName: v })}
                    />
                  )}
                  <DraftField label="Email" value={draft.email} onChange={(v) => set({ email: v })} />
                  <DraftField label="Phone" value={draft.phone} onChange={(v) => set({ phone: v })} />
                  <DraftField label="City" value={draft.city} onChange={(v) => set({ city: v })} />
                  <DraftField
                    label="Country"
                    value={draft.country}
                    onChange={(v) => set({ country: v })}
                  />
                  <DraftField label="Tax / VAT ID" value={draft.taxId} onChange={(v) => set({ taxId: v })} />
                </div>
                {draft.notes ? (
                  <p className="line-clamp-2 text-xs text-muted-foreground">{draft.notes}</p>
                ) : null}
              </ReviewCard>
            );
          })}
          <p className="text-xs text-muted-foreground">
            People are linked to a company with the same name, if it exists or is created here.
          </p>
        </div>
      ) : (
        <SourceStep
          textPlaceholder={
            "Maria Garcia\nEvents Manager, Acme Pharma\nmaria.garcia@acmepharma.com\n+34 600 123 456"
          }
          websitePlaceholder="acmepharma.com"
          hint="AI reads the text and drafts clients. Nothing is created yet."
          onExtract={onExtract}
        />
      )}
    </ImportDialog>
  );
}
