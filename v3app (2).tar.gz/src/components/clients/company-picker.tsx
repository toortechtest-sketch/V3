import { useState } from "react";
import { useQuery } from "convex/react";
import { Building2, Check, ChevronsUpDown, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command.tsx";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { cn } from "@/lib/utils.ts";

export type CompanyOption = { id: Id<"clients">; name: string };

/** Searchable picker for the company a person works at. */
export default function CompanyPicker({
  value,
  onChange,
  excludeId,
}: {
  value: CompanyOption | null;
  onChange: (value: CompanyOption | null) => void;
  excludeId?: Id<"clients">;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [term] = useDebounce(search, 250);
  const companies = useQuery(
    api.clients.searchCompanies,
    open ? { search: term } : "skip",
  );
  const options = (companies ?? []).filter((c) => c._id !== excludeId);

  return (
    <div className="flex gap-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="secondary"
            role="combobox"
            aria-expanded={open}
            className="flex-1 cursor-pointer justify-between font-normal"
          >
            <span
              className={cn(
                "flex min-w-0 items-center gap-2 truncate",
                !value && "text-muted-foreground",
              )}
            >
              <Building2 className="size-4 shrink-0" />
              {value?.name ?? "No company"}
            </span>
            <ChevronsUpDown className="size-4 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent
          className="w-(--radix-popover-trigger-width) p-0"
          align="start"
        >
          <Command shouldFilter={false}>
            <CommandInput
              value={search}
              onValueChange={setSearch}
              placeholder="Search companies"
            />
            <CommandList>
              {companies === undefined ? (
                <div className="flex justify-center py-6">
                  <Spinner />
                </div>
              ) : (
                <>
                  <CommandEmpty>No companies found.</CommandEmpty>
                  <CommandGroup>
                    {options.map((c) => (
                      <CommandItem
                        key={c._id}
                        value={c._id}
                        className="cursor-pointer"
                        onSelect={() => {
                          onChange({ id: c._id, name: c.name });
                          setOpen(false);
                        }}
                      >
                        <Check
                          className={cn(
                            "size-4",
                            value?.id === c._id ? "opacity-100" : "opacity-0",
                          )}
                        />
                        <span className="truncate">{c.name}</span>
                        {c.city ? (
                          <span className="ml-auto truncate text-xs text-muted-foreground">
                            {c.city}
                          </span>
                        ) : null}
                      </CommandItem>
                    ))}
                  </CommandGroup>
                </>
              )}
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      {value ? (
        <Button
          type="button"
          variant="ghost"
          size="icon"
          aria-label="Remove company"
          className="cursor-pointer"
          onClick={() => onChange(null)}
        >
          <X className="size-4" />
        </Button>
      ) : null}
    </div>
  );
}
