import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAction, useMutation } from "convex/react";
import { toast } from "sonner";
import { X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { SupplierDraft } from "@/convex/ai/normalize.ts";
import ImportDialog from "@/components/ai-import/import-dialog.tsx";
import SourceStep, { type ImportSource } from "@/components/ai-import/source-step.tsx";
import { DraftField, ReviewCard, ReviewToolbar } from "@/components/ai-import/review.tsx";
import { useDraftList } from "@/components/ai-import/use-draft-list.ts";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { errorMessage } from "@/lib/errors.ts";
import {
  BOARD_LABELS,
  CATEGORY_META,
  HOTEL_CLASS_LABELS,
  SUPPLIER_CATEGORIES,
  type SupplierCategory,
} from "@/lib/suppliers.ts";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function RoomTypes({
  draft,
  onRemove,
}: {
  draft: SupplierDraft;
  onRemove: (index: number) => void;
}) {
  if (draft.category !== "hotel") return null;
  const facts = [
    draft.hotelClass ? HOTEL_CLASS_LABELS[draft.hotelClass] : null,
    draft.totalRooms !== undefined ? `${draft.totalRooms} rooms` : null,
    draft.meetingRooms !== undefined ? `${draft.meetingRooms} meeting rooms` : null,
    draft.largestMeetingCapacity !== undefined
      ? `largest room ${draft.largestMeetingCapacity} guests`
      : null,
  ].filter(Boolean);
  return (
    <div className="space-y-1.5 rounded-md bg-muted/50 p-2">
      <p className="text-xs text-muted-foreground">
        {facts.length ? facts.join(" · ") : "No hotel details found"}
      </p>
      {draft.roomTypes.length ? (
        <div className="flex flex-wrap gap-1.5">
          {draft.roomTypes.map((r, i) => (
            <span
              key={`${r.name}-${i}`}
              className="inline-flex items-center gap-1 rounded bg-background py-0.5 pr-1 pl-2 text-xs"
            >
              {r.name} · sleeps {r.occupancy} · {BOARD_LABELS[r.board]}
              {r.nightlyRate !== undefined ? ` · ${r.nightlyRate}` : ""}
              <button
                type="button"
                aria-label={`Remove ${r.name}`}
                onClick={() => onRemove(i)}
                className="cursor-pointer rounded p-0.5 text-muted-foreground hover:bg-muted hover:text-foreground"
              >
                <X className="size-3" />
              </button>
            </span>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export default function SupplierImportDialog({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const navigate = useNavigate();
  const extract = useAction(api.ai.extract.extractSuppliers);
  const create = useMutation(api.ai.save.createSuppliers);
  const list = useDraftList<SupplierDraft>();
  const [existing, setExisting] = useState<Set<string>>(new Set());
  const [creating, setCreating] = useState(false);

  const reviewing = list.rows.length > 0;
  const invalid = list.selected.some(
    (r) => !r.draft.name.trim() || (r.draft.email && !EMAIL_PATTERN.test(r.draft.email)),
  );

  const close = (next: boolean) => {
    if (!next) list.clear();
    onOpenChange(next);
  };

  const onExtract = async (source: ImportSource) => {
    const result = await extract({ source });
    const known = new Set(result.existing);
    setExisting(known);
    list.load(result.drafts, (d) => !known.has(d.name.toLowerCase()));
  };

  const onCreate = async () => {
    setCreating(true);
    try {
      const ids = await create({
        suppliers: list.selected.map(({ draft }) => ({
          ...draft,
          status: "active" as const,
          roomTypes: draft.category === "hotel" ? draft.roomTypes : [],
        })),
      });
      toast.success(`${ids.length} supplier${ids.length === 1 ? "" : "s"} created`);
      close(false);
      if (ids.length === 1) navigate(`/suppliers/${ids[0]}`);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setCreating(false);
    }
  };

  const count = list.selected.length;

  return (
    <ImportDialog
      open={open}
      onOpenChange={close}
      title="Import suppliers with AI"
      description="Paste a hotel fact sheet, supplier list or email, or give a hotel or supplier website. Hotels include their room types. You'll review everything before it's saved."
      reviewing={reviewing}
      onBack={list.clear}
      createLabel={`Create ${count} supplier${count === 1 ? "" : "s"}`}
      canCreate={count > 0 && !invalid}
      creating={creating}
      onCreate={() => void onCreate()}
    >
      {reviewing ? (
        <div className="space-y-3 pb-1">
          <ReviewToolbar
            total={list.rows.length}
            selected={count}
            noun="suppliers"
            onToggleAll={list.toggleAll}
          />
          {list.rows.map(({ key, draft, selected }) => {
            const set = (patch: Partial<SupplierDraft>) => list.update(key, patch);
            const duplicate = existing.has(draft.name.trim().toLowerCase());
            return (
              <ReviewCard
                key={key}
                checked={selected}
                onCheckedChange={(v) => list.toggle(key, v)}
                label={draft.name || "supplier"}
                warning={
                  !draft.name.trim()
                    ? "Add a name to create this supplier."
                    : draft.email && !EMAIL_PATTERN.test(draft.email)
                      ? "That email doesn't look right."
                      : duplicate
                        ? "A supplier with this name already exists."
                        : undefined
                }
              >
                <div className="flex flex-wrap items-end gap-2">
                  <label className="space-y-1">
                    <span className="block text-[11px] font-medium text-muted-foreground">Type</span>
                    <Select
                      value={draft.category}
                      onValueChange={(v) => set({ category: v as SupplierCategory })}
                    >
                      <SelectTrigger size="sm" className="h-8 w-36 cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {SUPPLIER_CATEGORIES.map((c) => (
                          <SelectItem key={c} value={c} className="cursor-pointer">
                            {CATEGORY_META[c].label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </label>
                  <DraftField
                    label="Name"
                    value={draft.name}
                    onChange={(v) => set({ name: v ?? "" })}
                    className="min-w-48 flex-1"
                  />
                </div>
                <div className="grid gap-2 sm:grid-cols-3">
                  <DraftField
                    label="Contact person"
                    value={draft.contactName}
                    onChange={(v) => set({ contactName: v })}
                  />
                  <DraftField label="Email" value={draft.email} onChange={(v) => set({ email: v })} />
                  <DraftField label="Phone" value={draft.phone} onChange={(v) => set({ phone: v })} />
                  <DraftField label="City" value={draft.city} onChange={(v) => set({ city: v })} />
                  <DraftField
                    label="Country"
                    value={draft.country}
                    onChange={(v) => set({ country: v })}
                  />
                  <DraftField
                    label="Website"
                    value={draft.website}
                    onChange={(v) => set({ website: v })}
                  />
                </div>
                <RoomTypes
                  draft={draft}
                  onRemove={(i) => set({ roomTypes: draft.roomTypes.filter((_, j) => j !== i) })}
                />
                {draft.notes ? (
                  <p className="line-clamp-2 text-xs text-muted-foreground">{draft.notes}</p>
                ) : null}
              </ReviewCard>
            );
          })}
        </div>
      ) : (
        <SourceStep
          textPlaceholder={
            "Hotel Arts Barcelona, 5-star, 483 rooms\nCarrer de la Marina 19-21, Barcelona\nGroups: sales@hotelarts.com\nDeluxe King (2 guests, B&B) from EUR 420"
          }
          websitePlaceholder="hotelarts.com"
          hint="AI reads the text and drafts suppliers. Nothing is created yet."
          onExtract={onExtract}
        />
      )}
    </ImportDialog>
  );
}
