import { useState } from "react";
import { useQuery } from "convex/react";
import { Check, ChevronsUpDown, X } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import type { Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command.tsx";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { useDebounce } from "@/hooks/use-debounce.ts";
import { CATEGORY_META, type SupplierCategory } from "@/lib/suppliers.ts";
import { cn } from "@/lib/utils.ts";

export type PickedSupplier = {
  _id: Id<"suppliers">;
  name: string;
  category: SupplierCategory;
};

const RESULT_COUNT = 20;

/** Searches the shared supplier list on the server; only queries while open. */
export default function SupplierPicker({
  value,
  onChange,
}: {
  value: PickedSupplier | null;
  onChange: (supplier: PickedSupplier | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");
  const [term] = useDebounce(search.trim(), 250);
  const results = useQuery(
    api.suppliers.list,
    open
      ? { paginationOpts: { numItems: RESULT_COUNT, cursor: null }, search: term || undefined }
      : "skip",
  );
  const options = results?.page ?? [];
  const Icon = value ? CATEGORY_META[value.category].icon : null;

  return (
    <div className="flex gap-2">
      <Popover open={open} onOpenChange={setOpen}>
        <PopoverTrigger asChild>
          <Button
            type="button"
            variant="secondary"
            role="combobox"
            aria-expanded={open}
            className="min-w-0 flex-1 cursor-pointer justify-between font-normal"
          >
            <span className={cn("flex min-w-0 items-center gap-2", !value && "text-muted-foreground")}>
              {Icon ? <Icon className="size-4 shrink-0" /> : null}
              <span className="truncate">{value?.name ?? "Link a supplier (optional)"}</span>
            </span>
            <ChevronsUpDown className="size-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-(--radix-popover-trigger-width) min-w-64 p-0" align="start">
          <Command shouldFilter={false}>
            <CommandInput
              value={search}
              onValueChange={setSearch}
              placeholder="Search suppliers"
            />
            <CommandList>
              {results === undefined ? (
                <div className="flex justify-center py-6">
                  <Spinner />
                </div>
              ) : (
                <>
                  <CommandEmpty>No suppliers found.</CommandEmpty>
                  <CommandGroup>
                    {options.map((s) => {
                      const ItemIcon = CATEGORY_META[s.category].icon;
                      return (
                        <CommandItem
                          key={s._id}
                          value={s._id}
                          className="cursor-pointer"
                          onSelect={() => {
                            onChange({ _id: s._id, name: s.name, category: s.category });
                            setOpen(false);
                          }}
                        >
                          <ItemIcon />
                          <span className="min-w-0 flex-1 truncate">{s.name}</span>
                          <span className="text-xs text-muted-foreground">
                            {s.status === "archived" ? "Archived" : (s.city ?? CATEGORY_META[s.category].label)}
                          </span>
                          {value?._id === s._id ? <Check className="text-primary" /> : null}
                        </CommandItem>
                      );
                    })}
                  </CommandGroup>
                </>
              )}
            </CommandList>
          </Command>
        </PopoverContent>
      </Popover>
      {value ? (
        <Button
          type="button"
          size="icon"
          variant="ghost"
          aria-label="Remove supplier link"
          className="shrink-0 cursor-pointer"
          onClick={() => onChange(null)}
        >
          <X className="size-4" />
        </Button>
      ) : null}
    </div>
  );
}
