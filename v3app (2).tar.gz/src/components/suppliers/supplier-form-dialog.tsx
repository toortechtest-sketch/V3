import { useState } from "react";
import { useForm, useWatch } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { Textarea } from "@/components/ui/textarea.tsx";
import { CURRENCIES } from "@/lib/bookings.ts";
import { errorMessage } from "@/lib/errors.ts";
import {
  CATEGORY_META,
  HOTEL_CLASSES,
  HOTEL_CLASS_LABELS,
  STATUS_META,
  SUPPLIER_CATEGORIES,
  SUPPLIER_STATUSES,
} from "@/lib/suppliers.ts";

const NONE = "none";
const text = z.string().trim().max(500);
// Number inputs stay strings in the form and are converted on submit.
const count = z
  .string()
  .trim()
  .refine((v) => v === "" || /^\d+$/.test(v), { message: "Whole number" });

const schema = z.object({
  name: z.string().trim().min(1, "Add the supplier name").max(200),
  category: z.enum(SUPPLIER_CATEGORIES),
  status: z.enum(SUPPLIER_STATUSES),
  contactName: text,
  email: z
    .string()
    .trim()
    .refine((v) => v === "" || z.email().safeParse(v).success, {
      message: "Enter a valid email",
    }),
  phone: text,
  website: text,
  address: text,
  city: text,
  country: text,
  currency: z.enum([NONE, ...CURRENCIES]),
  hotelClass: z.enum([NONE, ...HOTEL_CLASSES]),
  totalRooms: count,
  meetingRooms: count,
  largestMeetingCapacity: count,
  notes: z.string().max(5000),
});

type FormValues = z.infer<typeof schema>;
type TextField = Exclude<
  keyof FormValues,
  "category" | "status" | "currency" | "hotelClass" | "notes"
>;

function defaultsFrom(s?: Doc<"suppliers">): FormValues {
  const num = (n?: number) => (n === undefined ? "" : String(n));
  return {
    name: s?.name ?? "",
    category: s?.category ?? "hotel",
    status: s?.status ?? "active",
    contactName: s?.contactName ?? "",
    email: s?.email ?? "",
    phone: s?.phone ?? "",
    website: s?.website ?? "",
    address: s?.address ?? "",
    city: s?.city ?? "",
    country: s?.country ?? "",
    currency: s?.currency ?? NONE,
    hotelClass: s?.hotelClass ?? NONE,
    totalRooms: num(s?.totalRooms),
    meetingRooms: num(s?.meetingRooms),
    largestMeetingCapacity: num(s?.largestMeetingCapacity),
    notes: s?.notes ?? "",
  };
}

function toArgs(values: FormValues) {
  const optional = (s: string) => (s === "" ? undefined : s);
  const num = (s: string) => (s === "" ? undefined : Number(s));
  const isHotel = values.category === "hotel";
  return {
    name: values.name,
    category: values.category,
    status: values.status,
    contactName: optional(values.contactName),
    email: optional(values.email),
    phone: optional(values.phone),
    website: optional(values.website),
    address: optional(values.address),
    city: optional(values.city),
    country: optional(values.country),
    notes: optional(values.notes),
    currency: values.currency === NONE ? undefined : values.currency,
    hotelClass:
      isHotel && values.hotelClass !== NONE ? values.hotelClass : undefined,
    totalRooms: isHotel ? num(values.totalRooms) : undefined,
    meetingRooms: isHotel ? num(values.meetingRooms) : undefined,
    largestMeetingCapacity: isHotel
      ? num(values.largestMeetingCapacity)
      : undefined,
  };
}

type Option = { value: string; label: string };

const CATEGORY_OPTIONS: Option[] = SUPPLIER_CATEGORIES.map((c) => ({
  value: c,
  label: CATEGORY_META[c].label,
}));
const STATUS_OPTIONS: Option[] = SUPPLIER_STATUSES.map((s) => ({
  value: s,
  label: STATUS_META[s].label,
}));
const CURRENCY_OPTIONS: Option[] = [
  { value: NONE, label: "Not set" },
  ...CURRENCIES.map((c) => ({ value: c, label: c })),
];
const CLASS_OPTIONS: Option[] = [
  { value: NONE, label: "Not set" },
  ...HOTEL_CLASSES.map((c) => ({ value: c, label: HOTEL_CLASS_LABELS[c] })),
];

export default function SupplierFormDialog({
  open,
  onOpenChange,
  supplier,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Pass to edit; omit to create. */
  supplier?: Doc<"suppliers">;
}) {
  const navigate = useNavigate();
  const create = useMutation(api.suppliers.create);
  const update = useMutation(api.suppliers.update);
  const [saving, setSaving] = useState(false);

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(supplier),
  });
  const category = useWatch({ control: form.control, name: "category" });
  const isHotel = category === "hotel";

  const handleOpenChange = (next: boolean) => {
    if (next) form.reset(defaultsFrom(supplier));
    onOpenChange(next);
  };

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    try {
      const args = toArgs(values);
      if (supplier) {
        await update({ id: supplier._id, ...args });
        toast.success("Supplier updated");
        onOpenChange(false);
      } else {
        const id = await create(args);
        toast.success("Supplier added");
        onOpenChange(false);
        navigate(`/suppliers/${id}`);
      }
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  const field = (
    name: TextField,
    label: string,
    placeholder: string,
    type = "text",
  ) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field: f }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <FormControl>
            <Input
              type={type}
              inputMode={type === "number" ? "numeric" : undefined}
              min={type === "number" ? 0 : undefined}
              placeholder={placeholder}
              {...f}
            />
          </FormControl>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  const select = (
    name: "category" | "status" | "currency" | "hotelClass",
    label: string,
    options: Option[],
  ) => (
    <FormField
      control={form.control}
      name={name}
      render={({ field: f }) => (
        <FormItem>
          <FormLabel>{label}</FormLabel>
          <Select value={f.value} onValueChange={f.onChange}>
            <FormControl>
              <SelectTrigger className="w-full cursor-pointer">
                <SelectValue />
              </SelectTrigger>
            </FormControl>
            <SelectContent>
              {options.map((o) => (
                <SelectItem key={o.value} value={o.value} className="cursor-pointer">
                  {o.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <FormMessage />
        </FormItem>
      )}
    />
  );

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-h-[90vh] overflow-y-auto sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {supplier ? `Edit ${supplier.name}` : "New supplier"}
          </DialogTitle>
          <DialogDescription>
            Suppliers and hotels are shared with the whole team.
          </DialogDescription>
        </DialogHeader>

        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid gap-4 sm:grid-cols-2"
          >
            <div className="sm:col-span-2">
              {field(
                "name",
                "Name",
                isHotel ? "Hotel Arts Barcelona" : "Barcelona Coaches",
              )}
            </div>
            {select("category", "Type", CATEGORY_OPTIONS)}
            {select("status", "Status", STATUS_OPTIONS)}

            {isHotel ? (
              <fieldset className="grid gap-4 rounded-lg border bg-muted/40 p-4 sm:col-span-2 sm:grid-cols-2">
                <legend className="px-1 text-sm font-medium">Hotel details</legend>
                {select("hotelClass", "Class", CLASS_OPTIONS)}
                {field("totalRooms", "Total rooms", "250", "number")}
                {field("meetingRooms", "Meeting rooms", "12", "number")}
                {field(
                  "largestMeetingCapacity",
                  "Largest meeting room (guests)",
                  "800",
                  "number",
                )}
              </fieldset>
            ) : null}

            {field("contactName", "Contact person", "Maria Garcia")}
            {field("email", "Email", "sales@hotelarts.com", "email")}
            {field("phone", "Phone", "+34 932 211 000", "tel")}
            {field("website", "Website", "hotelarts.com")}
            <div className="sm:col-span-2">
              {field("address", "Address", "Carrer de la Marina 19-21")}
            </div>
            {field("city", "City", "Barcelona")}
            {field("country", "Country", "Spain")}
            {select("currency", "Contract currency", CURRENCY_OPTIONS)}
            <div className="hidden sm:block" />

            <div className="sm:col-span-2">
              <FormField
                control={form.control}
                name="notes"
                render={({ field: f }) => (
                  <FormItem>
                    <FormLabel>Notes</FormLabel>
                    <FormControl>
                      <Textarea
                        rows={3}
                        placeholder="Payment terms, release dates, what groups liked"
                        {...f}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <DialogFooter className="sm:col-span-2">
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {supplier ? "Save changes" : "Add supplier"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
