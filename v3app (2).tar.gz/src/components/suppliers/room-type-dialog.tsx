import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "convex/react";
import { toast } from "sonner";
import { api } from "@/convex/_generated/api.js";
import type { Doc, Id } from "@/convex/_generated/dataModel.d.ts";
import { Button } from "@/components/ui/button.tsx";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog.tsx";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form.tsx";
import { Input } from "@/components/ui/input.tsx";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";
import { errorMessage } from "@/lib/errors.ts";
import { BOARD_LABELS, BOARD_TYPES } from "@/lib/suppliers.ts";

const schema = z.object({
  name: z.string().trim().min(1, "Add the room type name").max(120),
  occupancy: z
    .string()
    .trim()
    .refine((v) => /^\d+$/.test(v) && Number(v) >= 1 && Number(v) <= 50, {
      message: "1 to 50 guests",
    }),
  board: z.enum(BOARD_TYPES),
  nightlyRate: z
    .string()
    .trim()
    .refine((v) => v === "" || (/^\d+(\.\d{1,2})?$/.test(v)), {
      message: "Enter an amount like 180 or 180.50",
    }),
  notes: z.string().trim().max(500),
});

type FormValues = z.infer<typeof schema>;

function defaultsFrom(room?: Doc<"supplierRoomTypes">): FormValues {
  return {
    name: room?.name ?? "",
    occupancy: String(room?.occupancy ?? 2),
    board: room?.board ?? "breakfast",
    nightlyRate: room?.nightlyRate === undefined ? "" : String(room.nightlyRate),
    notes: room?.notes ?? "",
  };
}

export default function RoomTypeDialog({
  open,
  onOpenChange,
  supplierId,
  currency,
  room,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  supplierId: Id<"suppliers">;
  currency?: string;
  /** Pass to edit; omit to add. */
  room?: Doc<"supplierRoomTypes">;
}) {
  const add = useMutation(api.suppliers.addRoomType);
  const update = useMutation(api.suppliers.updateRoomType);
  const [saving, setSaving] = useState(false);
  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: defaultsFrom(room),
  });

  const handleOpenChange = (next: boolean) => {
    if (next) form.reset(defaultsFrom(room));
    onOpenChange(next);
  };

  const onSubmit = async (values: FormValues) => {
    setSaving(true);
    const args = {
      name: values.name,
      occupancy: Number(values.occupancy),
      board: values.board,
      nightlyRate: values.nightlyRate === "" ? undefined : Number(values.nightlyRate),
      notes: values.notes === "" ? undefined : values.notes,
    };
    try {
      if (room) {
        await update({ id: room._id, ...args });
        toast.success("Room type updated");
      } else {
        await add({ supplierId, ...args });
        toast.success("Room type added");
      }
      onOpenChange(false);
    } catch (error) {
      toast.error(errorMessage(error));
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="font-display text-xl">
            {room ? "Edit room type" : "Add room type"}
          </DialogTitle>
        </DialogHeader>
        <Form {...form}>
          <form
            onSubmit={form.handleSubmit(onSubmit)}
            className="grid grid-cols-2 gap-4"
          >
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem className="col-span-2">
                  <FormLabel>Room type</FormLabel>
                  <FormControl>
                    <Input placeholder="Deluxe sea view double" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="occupancy"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Sleeps</FormLabel>
                  <FormControl>
                    <Input type="number" inputMode="numeric" min={1} {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="nightlyRate"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>
                    Nightly rate{currency ? ` (${currency})` : ""}
                  </FormLabel>
                  <FormControl>
                    <Input inputMode="decimal" placeholder="180" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="board"
              render={({ field }) => (
                <FormItem className="col-span-2">
                  <FormLabel>Board</FormLabel>
                  <Select value={field.value} onValueChange={field.onChange}>
                    <FormControl>
                      <SelectTrigger className="w-full cursor-pointer">
                        <SelectValue />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {BOARD_TYPES.map((b) => (
                        <SelectItem key={b} value={b} className="cursor-pointer">
                          {BOARD_LABELS[b]}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem className="col-span-2">
                  <FormLabel>Notes</FormLabel>
                  <FormControl>
                    <Input placeholder="Extra bed possible, max 3 adults" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            <DialogFooter className="col-span-2">
              <Button
                type="button"
                variant="ghost"
                className="cursor-pointer"
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={saving} className="cursor-pointer">
                {saving ? <Spinner /> : null}
                {room ? "Save" : "Add room type"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
