import { Component, type ReactNode } from "react";

/** Shows `fallback` when a child throws, e.g. a query for a deleted record. */
export default class QueryErrorBoundary extends Component<
  { children: ReactNode; fallback: ReactNode },
  { failed: boolean }
> {
  state = { failed: false };

  static getDerivedStateFromError() {
    return { failed: true };
  }

  render() {
    return this.state.failed ? this.props.fallback : this.props.children;
  }
}
