import { Link, NavLink, Outlet, useLocation } from "react-router-dom";
import { Authenticated, AuthLoading, Unauthenticated } from "convex/react";
import { toast } from "sonner";
import BrandLogo from "@/components/brand-logo.tsx";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuBadge,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar.tsx";
import { useStaff } from "@/hooks/use-staff.ts";
import { useActivityHeartbeat } from "@/hooks/use-activity-heartbeat.ts";
import {
  LoadingScreen,
  PendingScreen,
  SignInScreen,
  SyncingScreen,
} from "./gate-screens.tsx";
import { FOOTER_NAV, NAV_GROUPS, type NavItem } from "./nav-config.ts";
import UserMenu from "./user-menu.tsx";

function NavEntry({ item }: { item: NavItem }) {
  const { pathname } = useLocation();
  if (!item.to) {
    return (
      <SidebarMenuItem>
        <SidebarMenuButton
          className="cursor-pointer text-sidebar-foreground/55"
          onClick={() => toast("Coming soon in a future milestone!")}
          tooltip={item.label}
        >
          <item.icon />
          <span>{item.label}</span>
        </SidebarMenuButton>
        <SidebarMenuBadge className="text-[10px] font-normal text-sidebar-foreground/40">
          Soon
        </SidebarMenuBadge>
      </SidebarMenuItem>
    );
  }
  const active =
    item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
  return (
    <SidebarMenuItem>
      <SidebarMenuButton
        asChild
        isActive={active}
        tooltip={item.label}
        className="data-[active=true]:bg-sidebar-accent data-[active=true]:text-white data-[active=true]:[&>svg]:text-sidebar-primary"
      >
        <NavLink to={item.to}>
          <item.icon />
          <span>{item.label}</span>
        </NavLink>
      </SidebarMenuButton>
    </SidebarMenuItem>
  );
}

function AppSidebar({ isManager }: { isManager: boolean }) {
  const footerItems = FOOTER_NAV.filter((i) => !i.managersOnly || isManager);
  return (
    <Sidebar collapsible="icon">
      <SidebarHeader className="px-3 py-4">
        <Link to="/" className="flex items-center gap-2 overflow-hidden">
          <BrandLogo onDark />
          <span className="rounded bg-sidebar-primary px-1.5 py-0.5 font-mono text-[10px] font-semibold text-sidebar-primary-foreground group-data-[collapsible=icon]:hidden">
            V3
          </span>
        </Link>
      </SidebarHeader>
      <SidebarContent>
        {NAV_GROUPS.map((group) => (
          <SidebarGroup key={group.label}>
            <SidebarGroupLabel className="text-[11px] uppercase tracking-wider text-sidebar-foreground/45">
              {group.label}
            </SidebarGroupLabel>
            <SidebarMenu>
              {group.items
                .filter((i) => !i.managersOnly || isManager)
                .map((item) => (
                  <NavEntry key={item.label} item={item} />
                ))}
            </SidebarMenu>
          </SidebarGroup>
        ))}
      </SidebarContent>
      <SidebarFooter>
        <SidebarMenu>
          {footerItems.map((item) => (
            <NavEntry key={item.label} item={item} />
          ))}
        </SidebarMenu>
        <UserMenu />
      </SidebarFooter>
    </Sidebar>
  );
}

function StaffShell() {
  const { me, isManager } = useStaff();
  useActivityHeartbeat(me?.status === "active");
  if (me === undefined) return <LoadingScreen />;
  if (me.status === "unsynced") return <SyncingScreen />;
  if (me.status === "pending") return <PendingScreen email={me.email} />;

  return (
    <SidebarProvider>
      <AppSidebar isManager={isManager} />
      <SidebarInset>
        <header className="sticky top-0 z-10 flex h-12 items-center gap-2 border-b bg-background/80 px-3 backdrop-blur md:hidden">
          <SidebarTrigger className="cursor-pointer" />
          <BrandLogo className="[&_span]:text-base [&_img]:w-7" />
        </header>
        <Outlet />
      </SidebarInset>
    </SidebarProvider>
  );
}

export default function AppLayout() {
  return (
    <>
      <AuthLoading>
        <LoadingScreen />
      </AuthLoading>
      <Unauthenticated>
        <SignInScreen />
      </Unauthenticated>
      <Authenticated>
        <StaffShell />
      </Authenticated>
    </>
  );
}
