import { Check, Languages } from "lucide-react";
import { useLanguage } from "@/hooks/use-language.ts";
import {
  AVAILABLE_LANGUAGES,
  LANGUAGES,
  isAvailableLanguage,
} from "@/lib/i18n/languages.ts";
import {
  DropdownMenuItem,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
} from "@/components/ui/dropdown-menu.tsx";

/** Language picker shown inside the profile menu. */
export default function LanguageMenu() {
  const { language, setLanguage } = useLanguage();
  const current = LANGUAGES.find((l) => l.code === language);

  return (
    <DropdownMenuSub>
      <DropdownMenuSubTrigger className="cursor-pointer gap-2">
        <Languages className="size-4 text-muted-foreground" />
        <span className="flex-1">Language</span>
        <span className="text-xs text-muted-foreground">{current?.name}</span>
      </DropdownMenuSubTrigger>
      <DropdownMenuSubContent className="w-48">
        {LANGUAGES.map((lang) => {
          const ready = AVAILABLE_LANGUAGES.includes(lang.code);
          return (
            <DropdownMenuItem
              key={lang.code}
              disabled={!ready}
              className="cursor-pointer"
              onClick={() => {
                if (isAvailableLanguage(lang.code)) setLanguage(lang.code);
              }}
            >
              <span lang={lang.code} className="flex-1">
                {lang.name}
              </span>
              {lang.code === language ? (
                <Check className="size-4" />
              ) : !ready ? (
                <span className="text-[10px] text-muted-foreground">Coming soon</span>
              ) : null}
            </DropdownMenuItem>
          );
        })}
      </DropdownMenuSubContent>
    </DropdownMenuSub>
  );
}
