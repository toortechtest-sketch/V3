import { useQuery } from "convex/react";
import { Activity, Clock, History } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog.tsx";
import { DropdownMenuItem } from "@/components/ui/dropdown-menu.tsx";
import { Skeleton } from "@/components/ui/skeleton.tsx";
import { formatDuration, formatLastSeen } from "@/lib/activity.ts";

function SessionRow({ session }: { session: { startedAt: string; lastSeenAt: string; durationMs: number } }) {
  const date = new Date(session.startedAt);
  return (
    <div className="flex items-center justify-between py-1.5 text-sm">
      <span className="text-muted-foreground">
        {date.toLocaleDateString(undefined, { day: "numeric", month: "short" })}
        {" · "}
        {date.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" })}
      </span>
      <span className="font-medium tabular-nums">{formatDuration(session.durationMs)}</span>
    </div>
  );
}

function MyActivityContent() {
  const stats = useQuery(api.activity.myStats, {});
  if (stats === undefined) {
    return (
      <div className="space-y-2">
        <Skeleton className="h-16 w-full" />
        <Skeleton className="h-40 w-full" />
      </div>
    );
  }
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-lg border bg-muted/40 px-3 py-2.5">
          <p className="text-xs text-muted-foreground">Active today</p>
          <p className="font-display text-xl font-semibold">{formatDuration(stats.todayMs)}</p>
        </div>
        <div className="rounded-lg border bg-muted/40 px-3 py-2.5">
          <p className="text-xs text-muted-foreground">Active this week</p>
          <p className="font-display text-xl font-semibold">{formatDuration(stats.weekMs)}</p>
        </div>
      </div>
      <div>
        <p className="mb-1 flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
          <History className="size-3.5" /> Recent sessions
        </p>
        {stats.recentSessions.length === 0 ? (
          <p className="py-4 text-center text-sm text-muted-foreground">No activity recorded yet.</p>
        ) : (
          <div className="max-h-64 divide-y overflow-y-auto">
            {stats.recentSessions.map((s, i) => (
              <SessionRow key={i} session={s} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default function MyActivityDialog() {
  return (
    <Dialog>
      <DialogTrigger asChild>
        <DropdownMenuItem className="cursor-pointer" onSelect={(e) => e.preventDefault()}>
          <Activity className="size-4" /> My activity
        </DropdownMenuItem>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Clock className="size-4" /> Your activity
          </DialogTitle>
          <DialogDescription>Time you've spent active in Toor, tracked by this browser.</DialogDescription>
        </DialogHeader>
        <MyActivityContent />
      </DialogContent>
    </Dialog>
  );
}
