import {
  Banknote,
  BarChart3,
  BedDouble,
  BookOpenCheck,
  CalendarRange,
  FileSpreadsheet,
  Inbox,
  LayoutDashboard,
  ListChecks,
  Plug,
  Users,
  UsersRound,
  type LucideIcon,
} from "lucide-react";

export type NavItem = {
  label: string;
  icon: LucideIcon;
  /** Route path; omitted for modules not built yet. */
  to?: string;
  managersOnly?: boolean;
};

export type NavGroup = { label: string; items: NavItem[] };

export const NAV_GROUPS: NavGroup[] = [
  {
    label: "Daily work",
    items: [
      { label: "Today", icon: LayoutDashboard, to: "/" },
      { label: "Inbox", icon: Inbox, to: "/inbox" },
      { label: "Tasks & follow-ups", icon: ListChecks, to: "/tasks" },
      { label: "Departures calendar", icon: CalendarRange, to: "/departures" },
    ],
  },
  {
    label: "Bookings",
    items: [{ label: "Bookings & events", icon: BookOpenCheck, to: "/bookings" }],
  },
  {
    label: "Contacts",
    items: [
      { label: "Clients", icon: Users, to: "/clients" },
      { label: "Suppliers & hotels", icon: BedDouble, to: "/suppliers" },
    ],
  },
  {
    label: "Finance",
    items: [
      { label: "Booking finance", icon: Banknote, to: "/finance" },
      { label: "Company accounting", icon: FileSpreadsheet, to: "/accounting", managersOnly: true },
    ],
  },
  {
    label: "Insights",
    items: [{ label: "Analytics", icon: BarChart3, to: "/analytics", managersOnly: true }],
  },
];

export const FOOTER_NAV: NavItem[] = [
  { label: "Connected apps", icon: Plug, to: "/connected-apps", managersOnly: true },
  { label: "Team", icon: UsersRound, to: "/team", managersOnly: true },
];
