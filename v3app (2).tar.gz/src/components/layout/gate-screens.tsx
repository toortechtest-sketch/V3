import { useEffect } from "react";
import { useMutation } from "convex/react";
import { Clock, ShieldCheck } from "lucide-react";
import { api } from "@/convex/_generated/api.js";
import BrandLogo from "@/components/brand-logo.tsx";
import { SignInButton } from "@/components/ui/signin.tsx";
import { Spinner } from "@/components/ui/spinner.tsx";

function GateShell({ children }: { children: React.ReactNode }) {
  return (
    <div className="relative flex min-h-svh flex-col items-center justify-center overflow-hidden bg-sidebar px-6 text-sidebar-foreground">
      <div className="pointer-events-none absolute -top-40 -right-32 size-[520px] rounded-full bg-[#0754EA]/30 blur-3xl" />
      <div className="pointer-events-none absolute -bottom-48 -left-24 size-[420px] rounded-full bg-[#00BDEB]/15 blur-3xl" />
      <div className="relative w-full max-w-sm space-y-8 text-center">
        <BrandLogo onDark className="mx-auto [&_span]:text-3xl [&_img]:w-14" />
        {children}
      </div>
    </div>
  );
}

export function SignInScreen() {
  return (
    <GateShell>
      <div className="space-y-2">
        <h1 className="font-display text-2xl font-semibold text-white">
          Staff workspace
        </h1>
        <p className="text-sm text-sidebar-foreground/70">
          Sign in with your Toor.tech account to continue.
        </p>
      </div>
      <SignInButton
        size="lg"
        signInText="Sign in"
        className="w-full bg-[#FFB800] text-[#0B1B2B] hover:bg-[#FFB800]/90"
      />
      <p className="flex items-center justify-center gap-1.5 text-xs text-sidebar-foreground/50">
        <ShieldCheck className="size-3.5" />
        Access is limited to approved team members
      </p>
    </GateShell>
  );
}

export function PendingScreen({ email }: { email: string | null }) {
  const sync = useMutation(api.users.updateCurrentUser);
  useEffect(() => {
    // Re-sync once: if no owner exists yet (e.g. a session that predates
    // roles), this promotes the first user so the workspace isn't locked.
    void sync().catch(() => undefined);
  }, [sync]);
  return (
    <GateShell>
      <div className="space-y-3">
        <div className="mx-auto flex size-12 items-center justify-center rounded-full bg-[#FFB800]/15 text-[#FFB800]">
          <Clock className="size-6" />
        </div>
        <h1 className="font-display text-2xl font-semibold text-white">
          Waiting for approval
        </h1>
        <p className="text-sm text-sidebar-foreground/70">
          {email ? (
            <>
              You're signed in as <span className="text-white">{email}</span>.{" "}
            </>
          ) : null}
          Ask an owner or global manager to give you a role on the Team page.
          This screen updates automatically once you're approved.
        </p>
      </div>
      <SignInButton
        variant="secondary"
        signOutText="Sign out"
        className="w-full"
      />
    </GateShell>
  );
}

/** Shown when the user is signed in but their user record isn't created yet. */
export function SyncingScreen() {
  const sync = useMutation(api.users.updateCurrentUser);
  useEffect(() => {
    // Covers returning sessions that skipped /auth/callback.
    void sync().catch(() => undefined);
  }, [sync]);
  return <LoadingScreen />;
}

export function LoadingScreen() {
  return (
    <div className="flex min-h-svh items-center justify-center bg-background">
      <Spinner className="size-6 text-muted-foreground" />
    </div>
  );
}
